"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ON_WIDGET_LOAD = exports.ON_EXIT_INTENT = exports.NEVER = void 0;
const NEVER = exports.NEVER = 'NEVER';
const ON_WIDGET_LOAD = exports.ON_WIDGET_LOAD = 'ON_WIDGET_LOAD';
const ON_EXIT_INTENT = exports.ON_EXIT_INTENT = 'ON_EXIT_INTENT';