"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.test2 = exports.na1 = exports.eu1 = void 0;
const na1 = exports.na1 = 'na1';
const test2 = exports.test2 = 'test2';
const eu1 = exports.eu1 = 'eu1';