(window.webpackChunkStripeJSinner = window.webpackChunkStripeJSinner || []).push([
    [3712], {
        10723: function(e, t, n) {
            "use strict";

            function a(e) {
                c.length || (i(), !0), c[c.length] = e
            }

            function o() {
                for (; p < c.length;) {
                    var e = p;
                    if (p += 1, c[e].call(), p > 1024) {
                        for (var t = 0, n = c.length - p; t < n; t++) c[t] = c[t + p];
                        c.length -= p, p = 0
                    }
                }
                c.length = 0, p = 0, !1
            }

            function r(e) {
                return function() {
                    function t() {
                        clearTimeout(n), clearInterval(a), e()
                    }
                    var n = setTimeout(t, 0),
                        a = setInterval(t, 50)
                }
            }
            e.exports = a;
            var i, u, s, l, c = [],
                p = 0,
                d = void 0 !== n.g ? n.g : self,
                m = d.MutationObserver || d.WebKitMutationObserver;
            "function" == typeof m ? (u = 1, s = new m(o), l = document.createTextNode(""), s.observe(l, {
                characterData: !0
            }), i = function() {
                u = -u, l.data = u
            }) : i = r(o), a.requestFlush = i, a.makeRequestCallFromTimer = r
        },
        64198: function(e, t, n) {
            var a = n(12897);
            e.exports = a
        },
        14771: function(e, t, n) {
            n(80290);
            var a = n(5379);
            e.exports = a("Array", "fill")
        },
        9554: function(e, t, n) {
            var a = n(64198);
            e.exports = a
        },
        24883: function(e, t, n) {
            var a = n(57475),
                o = n(69826),
                r = TypeError;
            e.exports = function(e) {
                if (a(e)) return e;
                throw r(o(e) + " is not a function")
            }
        },
        18479: function(e) {
            e.exports = function() {}
        },
        96059: function(e, t, n) {
            var a = n(10941),
                o = String,
                r = TypeError;
            e.exports = function(e) {
                if (a(e)) return e;
                throw r(o(e) + " is not an object")
            }
        },
        91860: function(e, t, n) {
            "use strict";
            var a = n(89678),
                o = n(59413),
                r = n(10623);
            e.exports = function(e) {
                for (var t = a(this), n = r(t), i = arguments.length, u = o(i > 1 ? arguments[1] : void 0, n), s = i > 2 ? arguments[2] : void 0, l = void 0 === s ? n : o(s, n); l > u;) t[u++] = e;
                return t
            }
        },
        82532: function(e, t, n) {
            var a = n(95329),
                o = a({}.toString),
                r = a("".slice);
            e.exports = function(e) {
                return r(o(e), 8, -1)
            }
        },
        32029: function(e, t, n) {
            var a = n(55746),
                o = n(65988),
                r = n(31887);
            e.exports = a ? function(e, t, n) {
                return o.f(e, t, r(1, n))
            } : function(e, t, n) {
                return e[t] = n, e
            }
        },
        31887: function(e) {
            e.exports = function(e, t) {
                return {
                    enumerable: !(1 & e),
                    configurable: !(2 & e),
                    writable: !(4 & e),
                    value: t
                }
            }
        },
        75609: function(e, t, n) {
            var a = n(21899),
                o = Object.defineProperty;
            e.exports = function(e, t) {
                try {
                    o(a, e, {
                        value: t,
                        configurable: !0,
                        writable: !0
                    })
                } catch (n) {
                    a[e] = t
                }
                return t
            }
        },
        55746: function(e, t, n) {
            var a = n(95981);
            e.exports = !a((function() {
                return 7 != Object.defineProperty({}, 1, {
                    get: function() {
                        return 7
                    }
                })[1]
            }))
        },
        76616: function(e) {
            var t = "object" == typeof document && document.all,
                n = void 0 === t && void 0 !== t;
            e.exports = {
                all: t,
                IS_HTMLDDA: n
            }
        },
        61333: function(e, t, n) {
            var a = n(21899),
                o = n(10941),
                r = a.document,
                i = o(r) && o(r.createElement);
            e.exports = function(e) {
                return i ? r.createElement(e) : {}
            }
        },
        2861: function(e) {
            e.exports = "undefined" != typeof navigator && String(navigator.userAgent) || ""
        },
        53385: function(e, t, n) {
            var a, o, r = n(21899),
                i = n(2861),
                u = r.process,
                s = r.Deno,
                l = u && u.versions || s && s.version,
                c = l && l.v8;
            c && (o = (a = c.split("."))[0] > 0 && a[0] < 4 ? 1 : +(a[0] + a[1])), !o && i && (!(a = i.match(/Edge\/(\d+)/)) || a[1] >= 74) && (a = i.match(/Chrome\/(\d+)/)) && (o = +a[1]), e.exports = o
        },
        5379: function(e, t, n) {
            var a = n(626);
            e.exports = a
        },
        76887: function(e, t, n) {
            "use strict";
            var a = n(21899),
                o = n(79730),
                r = n(97484),
                i = n(57475),
                u = n(49677).f,
                s = n(37252),
                l = n(54058),
                c = n(86843),
                p = n(32029),
                d = n(90953),
                m = function(e) {
                    var t = function(n, a, r) {
                        if (this instanceof t) {
                            switch (arguments.length) {
                                case 0:
                                    return new e;
                                case 1:
                                    return new e(n);
                                case 2:
                                    return new e(n, a)
                            }
                            return new e(n, a, r)
                        }
                        return o(e, this, arguments)
                    };
                    return t.prototype = e.prototype, t
                };
            e.exports = function(e, t) {
                var n, o, y, _, b, h, f, g, k, v = e.target,
                    w = e.global,
                    A = e.stat,
                    P = e.proto,
                    E = w ? a : A ? a[v] : (a[v] || {}).prototype,
                    S = w ? l : l[v] || p(l, v, {})[v],
                    L = S.prototype;
                for (_ in t) o = !(n = s(w ? _ : v + (A ? "." : "#") + _, e.forced)) && E && d(E, _), h = S[_], o && (f = e.dontCallGetSet ? (k = u(E, _)) && k.value : E[_]), b = o && f ? f : t[_], o && typeof h == typeof b || (g = e.bind && o ? c(b, a) : e.wrap && o ? m(b) : P && i(b) ? r(b) : b, (e.sham || b && b.sham || h && h.sham) && p(g, "sham", !0), p(S, _, g), P && (d(l, y = v + "Prototype") || p(l, y, {}), p(l[y], _, b), e.real && L && (n || !L[_]) && p(L, _, b)))
            }
        },
        95981: function(e) {
            e.exports = function(e) {
                try {
                    return !!e()
                } catch (e) {
                    return !0
                }
            }
        },
        79730: function(e, t, n) {
            var a = n(18285),
                o = Function.prototype,
                r = o.apply,
                i = o.call;
            e.exports = "object" == typeof Reflect && Reflect.apply || (a ? i.bind(r) : function() {
                return i.apply(r, arguments)
            })
        },
        86843: function(e, t, n) {
            var a = n(97484),
                o = n(24883),
                r = n(18285),
                i = a(a.bind);
            e.exports = function(e, t) {
                return o(e), void 0 === t ? e : r ? i(e, t) : function() {
                    return e.apply(t, arguments)
                }
            }
        },
        18285: function(e, t, n) {
            var a = n(95981);
            e.exports = !a((function() {
                var e = function() {}.bind();
                return "function" != typeof e || e.hasOwnProperty("prototype")
            }))
        },
        78834: function(e, t, n) {
            var a = n(18285),
                o = Function.prototype.call;
            e.exports = a ? o.bind(o) : function() {
                return o.apply(o, arguments)
            }
        },
        97484: function(e, t, n) {
            var a = n(82532),
                o = n(95329);
            e.exports = function(e) {
                if ("Function" === a(e)) return o(e)
            }
        },
        95329: function(e, t, n) {
            var a = n(18285),
                o = Function.prototype,
                r = o.call,
                i = a && o.bind.bind(r, r);
            e.exports = a ? i : function(e) {
                return function() {
                    return r.apply(e, arguments)
                }
            }
        },
        626: function(e, t, n) {
            var a = n(54058),
                o = n(21899),
                r = n(57475),
                i = function(e) {
                    return r(e) ? e : void 0
                };
            e.exports = function(e, t) {
                return arguments.length < 2 ? i(a[e]) || i(o[e]) : a[e] && a[e][t] || o[e] && o[e][t]
            }
        },
        14229: function(e, t, n) {
            var a = n(24883),
                o = n(82119);
            e.exports = function(e, t) {
                var n = e[t];
                return o(n) ? void 0 : a(n)
            }
        },
        21899: function(e, t, n) {
            var a = function(e) {
                return e && e.Math == Math && e
            };
            e.exports = a("object" == typeof globalThis && globalThis) || a("object" == typeof window && window) || a("object" == typeof self && self) || a("object" == typeof n.g && n.g) || function() {
                return this
            }() || Function("return this")()
        },
        90953: function(e, t, n) {
            var a = n(95329),
                o = n(89678),
                r = a({}.hasOwnProperty);
            e.exports = Object.hasOwn || function(e, t) {
                return r(o(e), t)
            }
        },
        2840: function(e, t, n) {
            var a = n(55746),
                o = n(95981),
                r = n(61333);
            e.exports = !a && !o((function() {
                return 7 != Object.defineProperty(r("div"), "a", {
                    get: function() {
                        return 7
                    }
                }).a
            }))
        },
        37026: function(e, t, n) {
            var a = n(95329),
                o = n(95981),
                r = n(82532),
                i = Object,
                u = a("".split);
            e.exports = o((function() {
                return !i("z").propertyIsEnumerable(0)
            })) ? function(e) {
                return "String" == r(e) ? u(e, "") : i(e)
            } : i
        },
        57475: function(e, t, n) {
            var a = n(76616),
                o = a.all;
            e.exports = a.IS_HTMLDDA ? function(e) {
                return "function" == typeof e || e === o
            } : function(e) {
                return "function" == typeof e
            }
        },
        37252: function(e, t, n) {
            var a = n(95981),
                o = n(57475),
                r = /#|\.prototype\./,
                i = function(e, t) {
                    var n = s[u(e)];
                    return n == c || n != l && (o(t) ? a(t) : !!t)
                },
                u = i.normalize = function(e) {
                    return String(e).replace(r, ".").toLowerCase()
                },
                s = i.data = {},
                l = i.NATIVE = "N",
                c = i.POLYFILL = "P";
            e.exports = i
        },
        82119: function(e) {
            e.exports = function(e) {
                return null == e
            }
        },
        10941: function(e, t, n) {
            var a = n(57475),
                o = n(76616),
                r = o.all;
            e.exports = o.IS_HTMLDDA ? function(e) {
                return "object" == typeof e ? null !== e : a(e) || e === r
            } : function(e) {
                return "object" == typeof e ? null !== e : a(e)
            }
        },
        82529: function(e) {
            e.exports = !0
        },
        56664: function(e, t, n) {
            var a = n(626),
                o = n(57475),
                r = n(7046),
                i = n(32302),
                u = Object;
            e.exports = i ? function(e) {
                return "symbol" == typeof e
            } : function(e) {
                var t = a("Symbol");
                return o(t) && r(t.prototype, u(e))
            }
        },
        10623: function(e, t, n) {
            var a = n(43057);
            e.exports = function(e) {
                return a(e.length)
            }
        },
        35331: function(e) {
            var t = Math.ceil,
                n = Math.floor;
            e.exports = Math.trunc || function(e) {
                var a = +e;
                return (a > 0 ? n : t)(a)
            }
        },
        65988: function(e, t, n) {
            var a = n(55746),
                o = n(2840),
                r = n(83937),
                i = n(96059),
                u = n(83894),
                s = TypeError,
                l = Object.defineProperty,
                c = Object.getOwnPropertyDescriptor,
                p = "enumerable",
                d = "configurable",
                m = "writable";
            t.f = a ? r ? function(e, t, n) {
                if (i(e), t = u(t), i(n), "function" == typeof e && "prototype" === t && "value" in n && m in n && !n.writable) {
                    var a = c(e, t);
                    a && a.writable && (e[t] = n.value, n = {
                        configurable: d in n ? n.configurable : a.configurable,
                        enumerable: p in n ? n.enumerable : a.enumerable,
                        writable: !1
                    })
                }
                return l(e, t, n)
            } : l : function(e, t, n) {
                if (i(e), t = u(t), i(n), o) try {
                    return l(e, t, n)
                } catch (e) {}
                if ("get" in n || "set" in n) throw s("Accessors not supported");
                return "value" in n && (e[t] = n.value), e
            }
        },
        49677: function(e, t, n) {
            var a = n(55746),
                o = n(78834),
                r = n(36760),
                i = n(31887),
                u = n(74529),
                s = n(83894),
                l = n(90953),
                c = n(2840),
                p = Object.getOwnPropertyDescriptor;
            t.f = a ? p : function(e, t) {
                if (e = u(e), t = s(t), c) try {
                    return p(e, t)
                } catch (e) {}
                if (l(e, t)) return i(!o(r.f, e, t), e[t])
            }
        },
        7046: function(e, t, n) {
            var a = n(95329);
            e.exports = a({}.isPrototypeOf)
        },
        36760: function(e, t) {
            "use strict";
            var n = {}.propertyIsEnumerable,
                a = Object.getOwnPropertyDescriptor,
                o = a && !n.call({
                    1: 2
                }, 1);
            t.f = o ? function(e) {
                var t = a(this, e);
                return !!t && t.enumerable
            } : n
        },
        39811: function(e, t, n) {
            var a = n(78834),
                o = n(57475),
                r = n(10941),
                i = TypeError;
            e.exports = function(e, t) {
                var n, u;
                if ("string" === t && o(n = e.toString) && !r(u = a(n, e))) return u;
                if (o(n = e.valueOf) && !r(u = a(n, e))) return u;
                if ("string" !== t && o(n = e.toString) && !r(u = a(n, e))) return u;
                throw i("Can't convert object to primitive value")
            }
        },
        54058: function(e) {
            e.exports = {}
        },
        48219: function(e, t, n) {
            var a = n(82119),
                o = TypeError;
            e.exports = function(e) {
                if (a(e)) throw o("Can't call method on " + e);
                return e
            }
        },
        63030: function(e, t, n) {
            var a = n(21899),
                o = n(75609),
                r = "__core-js_shared__",
                i = a[r] || o(r, {});
            e.exports = i
        },
        68726: function(e, t, n) {
            var a = n(82529),
                o = n(63030);
            (e.exports = function(e, t) {
                return o[e] || (o[e] = void 0 !== t ? t : {})
            })("versions", []).push({
                version: "3.29.1",
                mode: a ? "pure" : "global",
                copyright: "© 2014-2023 Denis Pushkarev (zloirock.ru)",
                license: "https://github.com/zloirock/core-js/blob/v3.29.1/LICENSE",
                source: "https://github.com/zloirock/core-js"
            })
        },
        63405: function(e, t, n) {
            var a = n(53385),
                o = n(95981);
            e.exports = !!Object.getOwnPropertySymbols && !o((function() {
                var e = Symbol();
                return !String(e) || !(Object(e) instanceof Symbol) || !Symbol.sham && a && a < 41
            }))
        },
        59413: function(e, t, n) {
            var a = n(62435),
                o = Math.max,
                r = Math.min;
            e.exports = function(e, t) {
                var n = a(e);
                return n < 0 ? o(n + t, 0) : r(n, t)
            }
        },
        74529: function(e, t, n) {
            var a = n(37026),
                o = n(48219);
            e.exports = function(e) {
                return a(o(e))
            }
        },
        62435: function(e, t, n) {
            var a = n(35331);
            e.exports = function(e) {
                var t = +e;
                return t != t || 0 === t ? 0 : a(t)
            }
        },
        43057: function(e, t, n) {
            var a = n(62435),
                o = Math.min;
            e.exports = function(e) {
                return e > 0 ? o(a(e), 9007199254740991) : 0
            }
        },
        89678: function(e, t, n) {
            var a = n(48219),
                o = Object;
            e.exports = function(e) {
                return o(a(e))
            }
        },
        46935: function(e, t, n) {
            var a = n(78834),
                o = n(10941),
                r = n(56664),
                i = n(14229),
                u = n(39811),
                s = n(99813),
                l = TypeError,
                c = s("toPrimitive");
            e.exports = function(e, t) {
                if (!o(e) || r(e)) return e;
                var n, s = i(e, c);
                if (s) {
                    if (void 0 === t && (t = "default"), n = a(s, e, t), !o(n) || r(n)) return n;
                    throw l("Can't convert object to primitive value")
                }
                return void 0 === t && (t = "number"), u(e, t)
            }
        },
        83894: function(e, t, n) {
            var a = n(46935),
                o = n(56664);
            e.exports = function(e) {
                var t = a(e, "string");
                return o(t) ? t : t + ""
            }
        },
        69826: function(e) {
            var t = String;
            e.exports = function(e) {
                try {
                    return t(e)
                } catch (e) {
                    return "Object"
                }
            }
        },
        99418: function(e, t, n) {
            var a = n(95329),
                o = 0,
                r = Math.random(),
                i = a(1..toString);
            e.exports = function(e) {
                return "Symbol(" + (void 0 === e ? "" : e) + ")_" + i(++o + r, 36)
            }
        },
        32302: function(e, t, n) {
            var a = n(63405);
            e.exports = a && !Symbol.sham && "symbol" == typeof Symbol.iterator
        },
        83937: function(e, t, n) {
            var a = n(55746),
                o = n(95981);
            e.exports = a && o((function() {
                return 42 != Object.defineProperty((function() {}), "prototype", {
                    value: 42,
                    writable: !1
                }).prototype
            }))
        },
        99813: function(e, t, n) {
            var a = n(21899),
                o = n(68726),
                r = n(90953),
                i = n(99418),
                u = n(63405),
                s = n(32302),
                l = a.Symbol,
                c = o("wks"),
                p = s ? l.for || l : l && l.withoutSetter || i;
            e.exports = function(e) {
                return r(c, e) || (c[e] = u && r(l, e) ? l[e] : p("Symbol." + e)), c[e]
            }
        },
        80290: function(e, t, n) {
            var a = n(76887),
                o = n(91860),
                r = n(18479);
            a({
                target: "Array",
                proto: !0
            }, {
                fill: o
            }), r("fill")
        },
        12897: function(e, t, n) {
            var a = n(14771);
            e.exports = a
        },
        43657: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/ar-ea588174be92cf76be922b0e091bd09b.json"
        },
        65873: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/bg-da2e945034300b2c8a616b9552b0a953.json"
        },
        57128: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/cs-5aa51e08709aa6b8d1aa17eed64c559a.json"
        },
        63645: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/da-fa3543a723e646e9065e26a58ffb340a.json"
        },
        44460: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/de-1d58e2f5a98446c35001471342b85162.json"
        },
        30085: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/el-a54f1b93a4520f759f2485a778934308.json"
        },
        12623: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/en-GB-fd124b72ff06a34c584e1faa09e27f1b.json"
        },
        91084: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/es-419-6d4b8a23a8b3f12ef830a1171b69d4e2.json"
        },
        97480: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/es-78fdb676a7a95a9c0db49442feefc737.json"
        },
        62638: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/et-01380812e527276a6cefd7a13920a7da.json"
        },
        977: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/fi-7ec00a793233c8cb0e1c1caa8a6211ed.json"
        },
        28185: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/fil-81ceacdaf172fd6f90f6eed34affa88c.json"
        },
        78963: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/fr-CA-0651c35d920514f61a9d0d60ff5d9db2.json"
        },
        38501: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/fr-011a3a6d20af4abeddcece9179ee649b.json"
        },
        86802: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/he-2db826699425ac33654033b3267675a7.json"
        },
        6771: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/hr-5eb5e39343509083337167d9e6ad5ff0.json"
        },
        22844: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/hu-d6dd6ca2b0b4e9eeaaf12ceb30705b6e.json"
        },
        61579: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/id-f73f6291f646655c26c76dc76e169361.json"
        },
        52392: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/it-0dfd2d52e09291459df9dd049d56aeca.json"
        },
        98801: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/ja-3c3ad6e6b5c5a5f522867b598e2840b0.json"
        },
        10903: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/ko-ee4df3e9a3ac37c526089d4691fa7905.json"
        },
        28496: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/lt-53287a70bf24212039dcbef6034e16fc.json"
        },
        64225: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/lv-dda45d10dd3b396826939ef3708c839e.json"
        },
        8973: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/ms-92481c1d85603860100f21bdbf94c93c.json"
        },
        8946: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/mt-91a0e083a5ba4f4eceaa90632f14c23c.json"
        },
        78086: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/nb-dd24c882028107c4d69075b5189f7250.json"
        },
        36023: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/nl-BE-2ea1fee68e449254904da1e7baa18472.json"
        },
        18780: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/nl-2ea1fee68e449254904da1e7baa18472.json"
        },
        5525: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/pl-302c466df38a98ac1051befcaea9fb1f.json"
        },
        61909: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/pt-BR-4406376d802bf27525376ea25f063331.json"
        },
        37322: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/pt-00f4608e08b55defed6d08aa80ab92f5.json"
        },
        42413: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/ro-50c4947190586c21b33410314228a041.json"
        },
        69226: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/ru-8217876c1f4dcd4cbdee65e65f99105b.json"
        },
        60640: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/sk-2d3f024c5929b6cfa5e5996c2834328f.json"
        },
        51038: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/sl-369c6c8a53b13eb9814995efc7a0f4e7.json"
        },
        81301: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/sv-92fbafa7bd467827cdc8498412e1309f.json"
        },
        79992: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/th-b5c6679a7a92e9a12f356aff292ca344.json"
        },
        8177: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/tr-27eb74e6373baf19f6fb26908b166880.json"
        },
        94126: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/vi-54a701aed2251fb856e787d523ac5342.json"
        },
        70934: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/zh-HK-fd8e5a88818e8848bd681e6bd2e0b851.json"
        },
        99770: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/zh-TW-9b88f01a487b59fd66fe2a38dfe69d0a.json"
        },
        53166: function(e, t, n) {
            e.exports = n.p + "fingerprinted/data/zh-54f76d4fbf6b262ecd82e8d00476d10d.json"
        },
        16284: function(e, t, n) {
            "use strict";

            function a(e, t) {
                return t ? Object.keys(e).reduce((function(n, a) {
                    var o, i;
                    return n[a] = (o = e[a], (i = t[a]) ? (0, r.__assign)((0, r.__assign)((0, r.__assign)({}, o || {}), i || {}), Object.keys(o).reduce((function(e, t) {
                        return e[t] = (0, r.__assign)((0, r.__assign)({}, o[t]), i[t] || {}), e
                    }), {})) : o), n
                }), (0, r.__assign)({}, e)) : e
            }

            function o(e) {
                return {
                    create: function() {
                        return {
                            get: function(t) {
                                return e[t]
                            },
                            set: function(t, n) {
                                e[t] = n
                            }
                        }
                    }
                }
            }
            n.d(t, {
                C: function() {
                    return l
                }
            });
            var r = n(70655),
                i = n(65366),
                u = n(81695),
                s = n(61092),
                l = function() {
                    function e(t, n, i, l) {
                        void 0 === n && (n = e.defaultLocale);
                        var c, p = this;
                        if (this.formatterCache = {
                                number: {},
                                dateTime: {},
                                pluralRules: {}
                            }, this.format = function(e) {
                                var t = p.formatToParts(e);
                                if (1 === t.length) return t[0].value;
                                var n = t.reduce((function(e, t) {
                                    return e.length && t.type === s.du.literal && "string" == typeof e[e.length - 1] ? e[e.length - 1] += t.value : e.push(t.value), e
                                }), []);
                                return n.length <= 1 ? n[0] || "" : n
                            }, this.formatToParts = function(e) {
                                return (0, s.FK)(p.ast, p.locales, p.formatters, p.formats, e, void 0, p.message)
                            }, this.resolvedOptions = function() {
                                var e;
                                return {
                                    locale: (null === (e = p.resolvedLocale) || void 0 === e ? void 0 : e.toString()) || Intl.NumberFormat.supportedLocalesOf(p.locales)[0]
                                }
                            }, this.getAst = function() {
                                return p.ast
                            }, this.locales = n, this.resolvedLocale = e.resolveLocale(n), "string" == typeof t) {
                            if (this.message = t, !e.__parse) throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
                            this.ast = e.__parse(t, {
                                ignoreTag: null == l ? void 0 : l.ignoreTag,
                                locale: this.resolvedLocale
                            })
                        } else this.ast = t;
                        if (!Array.isArray(this.ast)) throw new TypeError("A message must be provided as a String or AST.");
                        this.formats = a(e.formats, i), this.formatters = l && l.formatters || (void 0 === (c = this.formatterCache) && (c = {
                            number: {},
                            dateTime: {},
                            pluralRules: {}
                        }), {
                            getNumberFormat: (0, u.Z)((function() {
                                for (var e, t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                                return new((e = Intl.NumberFormat).bind.apply(e, (0, r.__spreadArray)([void 0], t, !1)))
                            }), {
                                cache: o(c.number),
                                strategy: u.A.variadic
                            }),
                            getDateTimeFormat: (0, u.Z)((function() {
                                for (var e, t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                                return new((e = Intl.DateTimeFormat).bind.apply(e, (0, r.__spreadArray)([void 0], t, !1)))
                            }), {
                                cache: o(c.dateTime),
                                strategy: u.A.variadic
                            }),
                            getPluralRules: (0, u.Z)((function() {
                                for (var e, t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                                return new((e = Intl.PluralRules).bind.apply(e, (0, r.__spreadArray)([void 0], t, !1)))
                            }), {
                                cache: o(c.pluralRules),
                                strategy: u.A.variadic
                            })
                        })
                    }
                    return Object.defineProperty(e, "defaultLocale", {
                        get: function() {
                            return e.memoizedDefaultLocale || (e.memoizedDefaultLocale = (new Intl.NumberFormat).resolvedOptions().locale), e.memoizedDefaultLocale
                        },
                        enumerable: !1,
                        configurable: !0
                    }), e.memoizedDefaultLocale = null, e.resolveLocale = function(e) {
                        if (void 0 !== Intl.Locale) {
                            var t = Intl.NumberFormat.supportedLocalesOf(e);
                            return t.length > 0 ? new Intl.Locale(t[0]) : new Intl.Locale("string" == typeof e ? e : e[0])
                        }
                    }, e.__parse = i.Qc, e.formats = {
                        number: {
                            integer: {
                                maximumFractionDigits: 0
                            },
                            currency: {
                                style: "currency"
                            },
                            percent: {
                                style: "percent"
                            }
                        },
                        date: {
                            short: {
                                month: "numeric",
                                day: "numeric",
                                year: "2-digit"
                            },
                            medium: {
                                month: "short",
                                day: "numeric",
                                year: "numeric"
                            },
                            long: {
                                month: "long",
                                day: "numeric",
                                year: "numeric"
                            },
                            full: {
                                weekday: "long",
                                month: "long",
                                day: "numeric",
                                year: "numeric"
                            }
                        },
                        time: {
                            short: {
                                hour: "numeric",
                                minute: "numeric"
                            },
                            medium: {
                                hour: "numeric",
                                minute: "numeric",
                                second: "numeric"
                            },
                            long: {
                                hour: "numeric",
                                minute: "numeric",
                                second: "numeric",
                                timeZoneName: "short"
                            },
                            full: {
                                hour: "numeric",
                                minute: "numeric",
                                second: "numeric",
                                timeZoneName: "short"
                            }
                        }
                    }, e
                }()
        },
        11050: function(e, t, n) {
            "use strict";
            n.d(t, {
                C8: function() {
                    return i
                },
                HR: function() {
                    return s
                },
                YR: function() {
                    return u
                },
                jK: function() {
                    return a
                },
                u_: function() {
                    return r
                }
            });
            var a, o = n(70655);
            ! function(e) {
                e.MISSING_VALUE = "MISSING_VALUE", e.INVALID_VALUE = "INVALID_VALUE", e.MISSING_INTL_API = "MISSING_INTL_API"
            }(a || (a = {}));
            var r = function(e) {
                    function t(t, n, a) {
                        var o = e.call(this, t) || this;
                        return o.code = n, o.originalMessage = a, o
                    }
                    return (0, o.__extends)(t, e), t.prototype.toString = function() {
                        return "[formatjs Error: ".concat(this.code, "] ").concat(this.message)
                    }, t
                }(Error),
                i = function(e) {
                    function t(t, n, o, r) {
                        return e.call(this, 'Invalid values for "'.concat(t, '": "').concat(n, '". Options are "').concat(Object.keys(o).join('", "'), '"'), a.INVALID_VALUE, r) || this
                    }
                    return (0, o.__extends)(t, e), t
                }(r),
                u = function(e) {
                    function t(t, n, o) {
                        return e.call(this, 'Value for "'.concat(t, '" must be of type ').concat(n), a.INVALID_VALUE, o) || this
                    }
                    return (0, o.__extends)(t, e), t
                }(r),
                s = function(e) {
                    function t(t, n) {
                        return e.call(this, 'The intl string context variable "'.concat(t, '" was not provided to the string "').concat(n, '"'), a.MISSING_VALUE, n) || this
                    }
                    return (0, o.__extends)(t, e), t
                }(r)
        },
        61092: function(e, t, n) {
            "use strict";

            function a(e) {
                return "function" == typeof e
            }

            function o(e, t, n, s, l, c, p) {
                if (1 === e.length && (0, i.O4)(e[0])) return [{
                    type: r.literal,
                    value: e[0].value
                }];
                for (var d = [], m = 0, y = e; m < y.length; m++) {
                    var _ = y[m];
                    if ((0, i.O4)(_)) d.push({
                        type: r.literal,
                        value: _.value
                    });
                    else if ((0, i.yx)(_)) "number" == typeof c && d.push({
                        type: r.literal,
                        value: n.getNumberFormat(t).format(c)
                    });
                    else {
                        var b = _.value;
                        if (!l || !(b in l)) throw new u.HR(b, p);
                        var h = l[b];
                        if ((0, i.VG)(_)) h && "string" != typeof h && "number" != typeof h || (h = "string" == typeof h || "number" == typeof h ? String(h) : ""), d.push({
                            type: "string" == typeof h ? r.literal : r.object,
                            value: h
                        });
                        else if ((0, i.rp)(_)) {
                            var f = "string" == typeof _.style ? s.date[_.style] : (0, i.Ii)(_.style) ? _.style.parsedOptions : void 0;
                            d.push({
                                type: r.literal,
                                value: n.getDateTimeFormat(t, f).format(h)
                            })
                        } else if ((0, i.pe)(_)) {
                            f = "string" == typeof _.style ? s.time[_.style] : (0, i.Ii)(_.style) ? _.style.parsedOptions : s.time.medium;
                            d.push({
                                type: r.literal,
                                value: n.getDateTimeFormat(t, f).format(h)
                            })
                        } else if ((0, i.uf)(_)) {
                            (f = "string" == typeof _.style ? s.number[_.style] : (0, i.Wh)(_.style) ? _.style.parsedOptions : void 0) && f.scale && (h *= f.scale || 1), d.push({
                                type: r.literal,
                                value: n.getNumberFormat(t, f).format(h)
                            })
                        } else {
                            if ((0, i.HI)(_)) {
                                var g = _.children,
                                    k = _.value,
                                    v = l[k];
                                if (!a(v)) throw new u.YR(k, "function", p);
                                var w = v(o(g, t, n, s, l, c).map((function(e) {
                                    return e.value
                                })));
                                Array.isArray(w) || (w = [w]), d.push.apply(d, w.map((function(e) {
                                    return {
                                        type: "string" == typeof e ? r.literal : r.object,
                                        value: e
                                    }
                                })))
                            }
                            if ((0, i.Wi)(_)) {
                                if (!(A = _.options[h] || _.options.other)) throw new u.C8(_.value, h, Object.keys(_.options), p);
                                d.push.apply(d, o(A.value, t, n, s, l))
                            } else if ((0, i.Jo)(_)) {
                                var A;
                                if (!(A = _.options["=".concat(h)])) {
                                    if (!Intl.PluralRules) throw new u.u_('Intl.PluralRules is not available in this environment.\nTry polyfilling it using "@formatjs/intl-pluralrules"\n', u.jK.MISSING_INTL_API, p);
                                    var P = n.getPluralRules(t, {
                                        type: _.pluralType
                                    }).select(h - (_.offset || 0));
                                    A = _.options[P] || _.options.other
                                }
                                if (!A) throw new u.C8(_.value, h, Object.keys(_.options), p);
                                d.push.apply(d, o(A.value, t, n, s, l, h - (_.offset || 0)))
                            } else;
                        }
                    }
                }
                return function(e) {
                    return e.length < 2 ? e : e.reduce((function(e, t) {
                        var n = e[e.length - 1];
                        return n && n.type === r.literal && t.type === r.literal ? n.value += t.value : e.push(t), e
                    }), [])
                }(d)
            }
            n.d(t, {
                FK: function() {
                    return o
                },
                du: function() {
                    return r
                }
            });
            var r, i = n(65366);
            if (!/^(2(400|417|760)|3(081|092|179|58)|8(022|05|384|889)|5663)$/.test(n.j)) var u = n(11050);
            ! function(e) {
                e[e.literal = 0] = "literal", e[e.object = 1] = "object"
            }(r || (r = {}))
        },
        81695: function(e, t, n) {
            "use strict";

            function a(e, t) {
                var n = t && t.cache ? t.cache : c,
                    a = t && t.serializer ? t.serializer : l;
                return (t && t.strategy ? t.strategy : u)(e, {
                    cache: n,
                    serializer: a
                })
            }

            function o(e, t, n, a) {
                var o, r = null == (o = a) || "number" == typeof o || "boolean" == typeof o ? a : n(a),
                    i = t.get(r);
                return void 0 === i && (i = e.call(this, a), t.set(r, i)), i
            }

            function r(e, t, n) {
                var a = Array.prototype.slice.call(arguments, 3),
                    o = n(a),
                    r = t.get(o);
                return void 0 === r && (r = e.apply(this, a), t.set(o, r)), r
            }

            function i(e, t, n, a, o) {
                return n.bind(t, e, a, o)
            }

            function u(e, t) {
                return i(e, this, 1 === e.length ? o : r, t.cache.create(), t.serializer)
            }

            function s() {
                this.cache = Object.create(null)
            }
            n.d(t, {
                A: function() {
                    return p
                },
                Z: function() {
                    return a
                }
            });
            var l = function() {
                return JSON.stringify(arguments)
            };
            s.prototype.get = function(e) {
                return this.cache[e]
            }, s.prototype.set = function(e, t) {
                this.cache[e] = t
            };
            var c = {
                    create: function() {
                        return new s
                    }
                },
                p = {
                    variadic: function(e, t) {
                        return i(e, this, r, t.cache.create(), t.serializer)
                    },
                    monadic: function(e, t) {
                        return i(e, this, o, t.cache.create(), t.serializer)
                    }
                }
        },
        53134: function(e, t, n) {
            "use strict";

            function a(e, t) {
                for (var n = "", a = 0; a < e.length; a++) {
                    var r = e.charAt(a);
                    if ("j" === r) {
                        for (var i = 0; a + 1 < e.length && e.charAt(a + 1) === r;) i++, a++;
                        var u = 1 + (1 & i),
                            s = i < 2 ? 1 : 3 + (i >> 1),
                            l = o(t);
                        for ("H" != l && "k" != l || (s = 0); s-- > 0;) n += "a";
                        for (; u-- > 0;) n = l + n
                    } else n += "J" === r ? "H" : r
                }
                return n
            }

            function o(e) {
                var t = e.hourCycle;
                if (void 0 === t && e.hourCycles && e.hourCycles.length && (t = e.hourCycles[0]), t) switch (t) {
                    case "h24":
                        return "k";
                    case "h23":
                        return "H";
                    case "h12":
                        return "h";
                    case "h11":
                        return "K";
                    default:
                        throw new Error("Invalid hourCycle")
                }
                var n, a = e.language;
                return "root" !== a && (n = e.maximize().region), (r._[n || ""] || r._[a || ""] || r._["".concat(a, "-001")] || r._["001"])[0]
            }
            n.d(t, {
                T: function() {
                    return a
                }
            });
            var r = n(62651)
        },
        12830: function(e, t, n) {
            "use strict";
            var a;
            n.d(t, {
                    o: function() {
                        return a
                    }
                }),
                function(e) {
                    e[e.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", e[e.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", e[e.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", e[e.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", e[e.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", e[e.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", e[e.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", e[e.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", e[e.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", e[e.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", e[e.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", e[e.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", e[e.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", e[e.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", e[e.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", e[e.INVALID_TAG = 23] = "INVALID_TAG", e[e.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", e[e.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", e[e.UNCLOSED_TAG = 27] = "UNCLOSED_TAG"
                }(a || (a = {}))
        },
        65366: function(e, t, n) {
            "use strict";

            function a(e) {
                e.forEach((function(e) {
                    if (delete e.location, (0, s.Wi)(e) || (0, s.Jo)(e))
                        for (var t in e.options) delete e.options[t].location, a(e.options[t].value);
                    else(0, s.uf)(e) && (0, s.Wh)(e.style) || ((0, s.rp)(e) || (0, s.pe)(e)) && (0, s.Ii)(e.style) ? delete e.style.location : (0, s.HI)(e) && a(e.children)
                }))
            }

            function o(e, t) {
                void 0 === t && (t = {}), t = (0, r.__assign)({
                    shouldParseSkeletons: !0,
                    requiresOtherClause: !0
                }, t);
                var n = new u._(e, t).parse();
                if (n.err) {
                    var o = SyntaxError(i.o[n.err.kind]);
                    throw o.location = n.err.location, o.originalMessage = n.err.message, o
                }
                return (null == t ? void 0 : t.captureLocation) || a(n.val), n.val
            }
            if (n.d(t, {
                    HI: function() {
                        return s.HI
                    },
                    Ii: function() {
                        return s.Ii
                    },
                    Jo: function() {
                        return s.Jo
                    },
                    O4: function() {
                        return s.O4
                    },
                    Qc: function() {
                        return o
                    },
                    VG: function() {
                        return s.VG
                    },
                    Wh: function() {
                        return s.Wh
                    },
                    Wi: function() {
                        return s.Wi
                    },
                    pe: function() {
                        return s.pe
                    },
                    rp: function() {
                        return s.rp
                    },
                    uf: function() {
                        return s.uf
                    },
                    yx: function() {
                        return s.yx
                    }
                }), !/^(2(400|417|760)|3(081|092|179|58)|8(022|05|384|889)|5663)$/.test(n.j)) var r = n(70655);
            var i = n(12830),
                u = n(29472),
                s = n(46365)
        },
        29472: function(e, t, n) {
            "use strict";

            function a(e, t) {
                return {
                    start: e,
                    end: t
                }
            }

            function o(e, t) {
                return new RegExp(e, t)
            }

            function r(e) {
                return e >= 97 && e <= 122 || e >= 65 && e <= 90
            }

            function i(e) {
                return e >= 9 && e <= 13 || 32 === e || 133 === e || e >= 8206 && e <= 8207 || 8232 === e || 8233 === e
            }

            function u(e) {
                return e >= 33 && e <= 35 || 36 === e || e >= 37 && e <= 39 || 40 === e || 41 === e || 42 === e || 43 === e || 44 === e || 45 === e || e >= 46 && e <= 47 || e >= 58 && e <= 59 || e >= 60 && e <= 62 || e >= 63 && e <= 64 || 91 === e || 92 === e || 93 === e || 94 === e || 96 === e || 123 === e || 124 === e || 125 === e || 126 === e || 161 === e || e >= 162 && e <= 165 || 166 === e || 167 === e || 169 === e || 171 === e || 172 === e || 174 === e || 176 === e || 177 === e || 182 === e || 187 === e || 191 === e || 215 === e || 247 === e || e >= 8208 && e <= 8213 || e >= 8214 && e <= 8215 || 8216 === e || 8217 === e || 8218 === e || e >= 8219 && e <= 8220 || 8221 === e || 8222 === e || 8223 === e || e >= 8224 && e <= 8231 || e >= 8240 && e <= 8248 || 8249 === e || 8250 === e || e >= 8251 && e <= 8254 || e >= 8257 && e <= 8259 || 8260 === e || 8261 === e || 8262 === e || e >= 8263 && e <= 8273 || 8274 === e || 8275 === e || e >= 8277 && e <= 8286 || e >= 8592 && e <= 8596 || e >= 8597 && e <= 8601 || e >= 8602 && e <= 8603 || e >= 8604 && e <= 8607 || 8608 === e || e >= 8609 && e <= 8610 || 8611 === e || e >= 8612 && e <= 8613 || 8614 === e || e >= 8615 && e <= 8621 || 8622 === e || e >= 8623 && e <= 8653 || e >= 8654 && e <= 8655 || e >= 8656 && e <= 8657 || 8658 === e || 8659 === e || 8660 === e || e >= 8661 && e <= 8691 || e >= 8692 && e <= 8959 || e >= 8960 && e <= 8967 || 8968 === e || 8969 === e || 8970 === e || 8971 === e || e >= 8972 && e <= 8991 || e >= 8992 && e <= 8993 || e >= 8994 && e <= 9e3 || 9001 === e || 9002 === e || e >= 9003 && e <= 9083 || 9084 === e || e >= 9085 && e <= 9114 || e >= 9115 && e <= 9139 || e >= 9140 && e <= 9179 || e >= 9180 && e <= 9185 || e >= 9186 && e <= 9254 || e >= 9255 && e <= 9279 || e >= 9280 && e <= 9290 || e >= 9291 && e <= 9311 || e >= 9472 && e <= 9654 || 9655 === e || e >= 9656 && e <= 9664 || 9665 === e || e >= 9666 && e <= 9719 || e >= 9720 && e <= 9727 || e >= 9728 && e <= 9838 || 9839 === e || e >= 9840 && e <= 10087 || 10088 === e || 10089 === e || 10090 === e || 10091 === e || 10092 === e || 10093 === e || 10094 === e || 10095 === e || 10096 === e || 10097 === e || 10098 === e || 10099 === e || 10100 === e || 10101 === e || e >= 10132 && e <= 10175 || e >= 10176 && e <= 10180 || 10181 === e || 10182 === e || e >= 10183 && e <= 10213 || 10214 === e || 10215 === e || 10216 === e || 10217 === e || 10218 === e || 10219 === e || 10220 === e || 10221 === e || 10222 === e || 10223 === e || e >= 10224 && e <= 10239 || e >= 10240 && e <= 10495 || e >= 10496 && e <= 10626 || 10627 === e || 10628 === e || 10629 === e || 10630 === e || 10631 === e || 10632 === e || 10633 === e || 10634 === e || 10635 === e || 10636 === e || 10637 === e || 10638 === e || 10639 === e || 10640 === e || 10641 === e || 10642 === e || 10643 === e || 10644 === e || 10645 === e || 10646 === e || 10647 === e || 10648 === e || e >= 10649 && e <= 10711 || 10712 === e || 10713 === e || 10714 === e || 10715 === e || e >= 10716 && e <= 10747 || 10748 === e || 10749 === e || e >= 10750 && e <= 11007 || e >= 11008 && e <= 11055 || e >= 11056 && e <= 11076 || e >= 11077 && e <= 11078 || e >= 11079 && e <= 11084 || e >= 11085 && e <= 11123 || e >= 11124 && e <= 11125 || e >= 11126 && e <= 11157 || 11158 === e || e >= 11159 && e <= 11263 || e >= 11776 && e <= 11777 || 11778 === e || 11779 === e || 11780 === e || 11781 === e || e >= 11782 && e <= 11784 || 11785 === e || 11786 === e || 11787 === e || 11788 === e || 11789 === e || e >= 11790 && e <= 11798 || 11799 === e || e >= 11800 && e <= 11801 || 11802 === e || 11803 === e || 11804 === e || 11805 === e || e >= 11806 && e <= 11807 || 11808 === e || 11809 === e || 11810 === e || 11811 === e || 11812 === e || 11813 === e || 11814 === e || 11815 === e || 11816 === e || 11817 === e || e >= 11818 && e <= 11822 || 11823 === e || e >= 11824 && e <= 11833 || e >= 11834 && e <= 11835 || e >= 11836 && e <= 11839 || 11840 === e || 11841 === e || 11842 === e || e >= 11843 && e <= 11855 || e >= 11856 && e <= 11857 || 11858 === e || e >= 11859 && e <= 11903 || e >= 12289 && e <= 12291 || 12296 === e || 12297 === e || 12298 === e || 12299 === e || 12300 === e || 12301 === e || 12302 === e || 12303 === e || 12304 === e || 12305 === e || e >= 12306 && e <= 12307 || 12308 === e || 12309 === e || 12310 === e || 12311 === e || 12312 === e || 12313 === e || 12314 === e || 12315 === e || 12316 === e || 12317 === e || e >= 12318 && e <= 12319 || 12320 === e || 12336 === e || 64830 === e || 64831 === e || e >= 65093 && e <= 65094
            }
            n.d(t, {
                _: function() {
                    return j
                }
            });
            var s, l = n(70655),
                c = n(12830),
                p = n(46365),
                d = n(86891),
                m = n(91768),
                y = n(74926),
                _ = n(53134),
                b = new RegExp("^".concat(d.p.source, "*")),
                h = new RegExp("".concat(d.p.source, "*$")),
                f = !!String.prototype.startsWith,
                g = !!String.fromCodePoint,
                k = !!Object.fromEntries,
                v = !!String.prototype.codePointAt,
                w = !!String.prototype.trimStart,
                A = !!String.prototype.trimEnd,
                P = !!Number.isSafeInteger ? Number.isSafeInteger : function(e) {
                    return "number" == typeof e && isFinite(e) && Math.floor(e) === e && Math.abs(e) <= 9007199254740991
                },
                E = !0;
            try {
                E = "a" === (null === (s = o("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu").exec("a")) || void 0 === s ? void 0 : s[0])
            } catch (e) {
                E = !1
            }
            var S, L = f ? function(e, t, n) {
                    return e.startsWith(t, n)
                } : function(e, t, n) {
                    return e.slice(n, n + t.length) === t
                },
                C = g ? String.fromCodePoint : function() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    for (var n, a = "", o = e.length, r = 0; o > r;) {
                        if ((n = e[r++]) > 1114111) throw RangeError(n + " is not a valid code point");
                        a += n < 65536 ? String.fromCharCode(n) : String.fromCharCode(55296 + ((n -= 65536) >> 10), n % 1024 + 56320)
                    }
                    return a
                },
                N = k ? Object.fromEntries : function(e) {
                    for (var t = {}, n = 0, a = e; n < a.length; n++) {
                        var o = a[n],
                            r = o[0],
                            i = o[1];
                        t[r] = i
                    }
                    return t
                },
                T = v ? function(e, t) {
                    return e.codePointAt(t)
                } : function(e, t) {
                    var n = e.length;
                    if (!(t < 0 || t >= n)) {
                        var a, o = e.charCodeAt(t);
                        return o < 55296 || o > 56319 || t + 1 === n || (a = e.charCodeAt(t + 1)) < 56320 || a > 57343 ? o : a - 56320 + (o - 55296 << 10) + 65536
                    }
                },
                x = w ? function(e) {
                    return e.trimStart()
                } : function(e) {
                    return e.replace(b, "")
                },
                I = A ? function(e) {
                    return e.trimEnd()
                } : function(e) {
                    return e.replace(h, "")
                };
            if (E) {
                var B = o("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
                S = function(e, t) {
                    var n;
                    return B.lastIndex = t, null !== (n = B.exec(e)[1]) && void 0 !== n ? n : ""
                }
            } else S = function(e, t) {
                for (var n = [];;) {
                    var a = T(e, t);
                    if (void 0 === a || i(a) || u(a)) break;
                    n.push(a), t += a >= 65536 ? 2 : 1
                }
                return C.apply(void 0, n)
            };
            var j = function() {
                function e(e, t) {
                    void 0 === t && (t = {}), this.message = e, this.position = {
                        offset: 0,
                        line: 1,
                        column: 1
                    }, this.ignoreTag = !!t.ignoreTag, this.locale = t.locale, this.requiresOtherClause = !!t.requiresOtherClause, this.shouldParseSkeletons = !!t.shouldParseSkeletons
                }
                return e.prototype.parse = function() {
                    if (0 !== this.offset()) throw Error("parser can only be used once");
                    return this.parseMessage(0, "", !1)
                }, e.prototype.parseMessage = function(e, t, n) {
                    for (var o = []; !this.isEOF();) {
                        var i = this.char();
                        if (123 === i) {
                            if ((u = this.parseArgument(e, n)).err) return u;
                            o.push(u.val)
                        } else {
                            if (125 === i && e > 0) break;
                            if (35 !== i || "plural" !== t && "selectordinal" !== t) {
                                if (60 === i && !this.ignoreTag && 47 === this.peek()) {
                                    if (n) break;
                                    return this.error(c.o.UNMATCHED_CLOSING_TAG, a(this.clonePosition(), this.clonePosition()))
                                }
                                if (60 === i && !this.ignoreTag && r(this.peek() || 0)) {
                                    if ((u = this.parseTag(e, t)).err) return u;
                                    o.push(u.val)
                                } else {
                                    var u;
                                    if ((u = this.parseLiteral(e, t)).err) return u;
                                    o.push(u.val)
                                }
                            } else {
                                var s = this.clonePosition();
                                this.bump(), o.push({
                                    type: p.wD.pound,
                                    location: a(s, this.clonePosition())
                                })
                            }
                        }
                    }
                    return {
                        val: o,
                        err: null
                    }
                }, e.prototype.parseTag = function(e, t) {
                    var n = this.clonePosition();
                    this.bump();
                    var o = this.parseTagName();
                    if (this.bumpSpace(), this.bumpIf("/>")) return {
                        val: {
                            type: p.wD.literal,
                            value: "<".concat(o, "/>"),
                            location: a(n, this.clonePosition())
                        },
                        err: null
                    };
                    if (this.bumpIf(">")) {
                        var i = this.parseMessage(e + 1, t, !0);
                        if (i.err) return i;
                        var u = i.val,
                            s = this.clonePosition();
                        if (this.bumpIf("</")) {
                            if (this.isEOF() || !r(this.char())) return this.error(c.o.INVALID_TAG, a(s, this.clonePosition()));
                            var l = this.clonePosition();
                            return o !== this.parseTagName() ? this.error(c.o.UNMATCHED_CLOSING_TAG, a(l, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
                                val: {
                                    type: p.wD.tag,
                                    value: o,
                                    children: u,
                                    location: a(n, this.clonePosition())
                                },
                                err: null
                            } : this.error(c.o.INVALID_TAG, a(s, this.clonePosition())))
                        }
                        return this.error(c.o.UNCLOSED_TAG, a(n, this.clonePosition()))
                    }
                    return this.error(c.o.INVALID_TAG, a(n, this.clonePosition()))
                }, e.prototype.parseTagName = function() {
                    var e, t = this.offset();
                    for (this.bump(); !this.isEOF() && (45 === (e = this.char()) || 46 === e || e >= 48 && e <= 57 || 95 === e || e >= 97 && e <= 122 || e >= 65 && e <= 90 || 183 == e || e >= 192 && e <= 214 || e >= 216 && e <= 246 || e >= 248 && e <= 893 || e >= 895 && e <= 8191 || e >= 8204 && e <= 8205 || e >= 8255 && e <= 8256 || e >= 8304 && e <= 8591 || e >= 11264 && e <= 12271 || e >= 12289 && e <= 55295 || e >= 63744 && e <= 64975 || e >= 65008 && e <= 65533 || e >= 65536 && e <= 983039);) this.bump();
                    return this.message.slice(t, this.offset())
                }, e.prototype.parseLiteral = function(e, t) {
                    for (var n = this.clonePosition(), o = "";;) {
                        var r = this.tryParseQuote(t);
                        if (r) o += r;
                        else {
                            var i = this.tryParseUnquoted(e, t);
                            if (i) o += i;
                            else {
                                var u = this.tryParseLeftAngleBracket();
                                if (!u) break;
                                o += u
                            }
                        }
                    }
                    var s = a(n, this.clonePosition());
                    return {
                        val: {
                            type: p.wD.literal,
                            value: o,
                            location: s
                        },
                        err: null
                    }
                }, e.prototype.tryParseLeftAngleBracket = function() {
                    return this.isEOF() || 60 !== this.char() || !this.ignoreTag && (r(e = this.peek() || 0) || 47 === e) ? null : (this.bump(), "<");
                    var e
                }, e.prototype.tryParseQuote = function(e) {
                    if (this.isEOF() || 39 !== this.char()) return null;
                    switch (this.peek()) {
                        case 39:
                            return this.bump(), this.bump(), "'";
                        case 123:
                        case 60:
                        case 62:
                        case 125:
                            break;
                        case 35:
                            if ("plural" === e || "selectordinal" === e) break;
                            return null;
                        default:
                            return null
                    }
                    this.bump();
                    var t = [this.char()];
                    for (this.bump(); !this.isEOF();) {
                        var n = this.char();
                        if (39 === n) {
                            if (39 !== this.peek()) {
                                this.bump();
                                break
                            }
                            t.push(39), this.bump()
                        } else t.push(n);
                        this.bump()
                    }
                    return C.apply(void 0, t)
                }, e.prototype.tryParseUnquoted = function(e, t) {
                    if (this.isEOF()) return null;
                    var n = this.char();
                    return 60 === n || 123 === n || 35 === n && ("plural" === t || "selectordinal" === t) || 125 === n && e > 0 ? null : (this.bump(), C(n))
                }, e.prototype.parseArgument = function(e, t) {
                    var n = this.clonePosition();
                    if (this.bump(), this.bumpSpace(), this.isEOF()) return this.error(c.o.EXPECT_ARGUMENT_CLOSING_BRACE, a(n, this.clonePosition()));
                    if (125 === this.char()) return this.bump(), this.error(c.o.EMPTY_ARGUMENT, a(n, this.clonePosition()));
                    var o = this.parseIdentifierIfPossible().value;
                    if (!o) return this.error(c.o.MALFORMED_ARGUMENT, a(n, this.clonePosition()));
                    if (this.bumpSpace(), this.isEOF()) return this.error(c.o.EXPECT_ARGUMENT_CLOSING_BRACE, a(n, this.clonePosition()));
                    switch (this.char()) {
                        case 125:
                            return this.bump(), {
                                val: {
                                    type: p.wD.argument,
                                    value: o,
                                    location: a(n, this.clonePosition())
                                },
                                err: null
                            };
                        case 44:
                            return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(c.o.EXPECT_ARGUMENT_CLOSING_BRACE, a(n, this.clonePosition())) : this.parseArgumentOptions(e, t, o, n);
                        default:
                            return this.error(c.o.MALFORMED_ARGUMENT, a(n, this.clonePosition()))
                    }
                }, e.prototype.parseIdentifierIfPossible = function() {
                    var e = this.clonePosition(),
                        t = this.offset(),
                        n = S(this.message, t),
                        o = t + n.length;
                    return this.bumpTo(o), {
                        value: n,
                        location: a(e, this.clonePosition())
                    }
                }, e.prototype.parseArgumentOptions = function(e, t, n, o) {
                    var r, i = this.clonePosition(),
                        u = this.parseIdentifierIfPossible().value,
                        s = this.clonePosition();
                    switch (u) {
                        case "":
                            return this.error(c.o.EXPECT_ARGUMENT_TYPE, a(i, s));
                        case "number":
                        case "date":
                        case "time":
                            this.bumpSpace();
                            var d = null;
                            if (this.bumpIf(",")) {
                                this.bumpSpace();
                                var y = this.clonePosition();
                                if ((A = this.parseSimpleArgStyleIfPossible()).err) return A;
                                if (0 === (g = I(A.val)).length) return this.error(c.o.EXPECT_ARGUMENT_STYLE, a(this.clonePosition(), this.clonePosition()));
                                d = {
                                    style: g,
                                    styleLocation: a(y, this.clonePosition())
                                }
                            }
                            if ((P = this.tryParseArgumentClose(o)).err) return P;
                            var b = a(o, this.clonePosition());
                            if (d && L(null == d ? void 0 : d.style, "::", 0)) {
                                var h = x(d.style.slice(2));
                                if ("number" === u) return (A = this.parseNumberSkeletonFromString(h, d.styleLocation)).err ? A : {
                                    val: {
                                        type: p.wD.number,
                                        value: n,
                                        location: b,
                                        style: A.val
                                    },
                                    err: null
                                };
                                if (0 === h.length) return this.error(c.o.EXPECT_DATE_TIME_SKELETON, b);
                                var f = h;
                                this.locale && (f = (0, _.T)(h, this.locale));
                                var g = {
                                    type: p.aV.dateTime,
                                    pattern: f,
                                    location: d.styleLocation,
                                    parsedOptions: this.shouldParseSkeletons ? (0, m.T)(f) : {}
                                };
                                return {
                                    val: {
                                        type: "date" === u ? p.wD.date : p.wD.time,
                                        value: n,
                                        location: b,
                                        style: g
                                    },
                                    err: null
                                }
                            }
                            return {
                                val: {
                                    type: "number" === u ? p.wD.number : "date" === u ? p.wD.date : p.wD.time,
                                    value: n,
                                    location: b,
                                    style: null !== (r = null == d ? void 0 : d.style) && void 0 !== r ? r : null
                                },
                                err: null
                            };
                        case "plural":
                        case "selectordinal":
                        case "select":
                            var k = this.clonePosition();
                            if (this.bumpSpace(), !this.bumpIf(",")) return this.error(c.o.EXPECT_SELECT_ARGUMENT_OPTIONS, a(k, (0, l.__assign)({}, k)));
                            this.bumpSpace();
                            var v = this.parseIdentifierIfPossible(),
                                w = 0;
                            if ("select" !== u && "offset" === v.value) {
                                if (!this.bumpIf(":")) return this.error(c.o.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, a(this.clonePosition(), this.clonePosition()));
                                var A;
                                if (this.bumpSpace(), (A = this.tryParseDecimalInteger(c.o.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, c.o.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE)).err) return A;
                                this.bumpSpace(), v = this.parseIdentifierIfPossible(), w = A.val
                            }
                            var P, E = this.tryParsePluralOrSelectOptions(e, u, t, v);
                            if (E.err) return E;
                            if ((P = this.tryParseArgumentClose(o)).err) return P;
                            var S = a(o, this.clonePosition());
                            return "select" === u ? {
                                val: {
                                    type: p.wD.select,
                                    value: n,
                                    options: N(E.val),
                                    location: S
                                },
                                err: null
                            } : {
                                val: {
                                    type: p.wD.plural,
                                    value: n,
                                    options: N(E.val),
                                    offset: w,
                                    pluralType: "plural" === u ? "cardinal" : "ordinal",
                                    location: S
                                },
                                err: null
                            };
                        default:
                            return this.error(c.o.INVALID_ARGUMENT_TYPE, a(i, s))
                    }
                }, e.prototype.tryParseArgumentClose = function(e) {
                    return this.isEOF() || 125 !== this.char() ? this.error(c.o.EXPECT_ARGUMENT_CLOSING_BRACE, a(e, this.clonePosition())) : (this.bump(), {
                        val: !0,
                        err: null
                    })
                }, e.prototype.parseSimpleArgStyleIfPossible = function() {
                    for (var e = 0, t = this.clonePosition(); !this.isEOF();) {
                        switch (this.char()) {
                            case 39:
                                this.bump();
                                var n = this.clonePosition();
                                if (!this.bumpUntil("'")) return this.error(c.o.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, a(n, this.clonePosition()));
                                this.bump();
                                break;
                            case 123:
                                e += 1, this.bump();
                                break;
                            case 125:
                                if (!(e > 0)) return {
                                    val: this.message.slice(t.offset, this.offset()),
                                    err: null
                                };
                                e -= 1;
                                break;
                            default:
                                this.bump()
                        }
                    }
                    return {
                        val: this.message.slice(t.offset, this.offset()),
                        err: null
                    }
                }, e.prototype.parseNumberSkeletonFromString = function(e, t) {
                    var n = [];
                    try {
                        n = (0, y.O)(e)
                    } catch (e) {
                        return this.error(c.o.INVALID_NUMBER_SKELETON, t)
                    }
                    return {
                        val: {
                            type: p.aV.number,
                            tokens: n,
                            location: t,
                            parsedOptions: this.shouldParseSkeletons ? (0, y.I)(n) : {}
                        },
                        err: null
                    }
                }, e.prototype.tryParsePluralOrSelectOptions = function(e, t, n, o) {
                    for (var r, i = !1, u = [], s = new Set, l = o.value, p = o.location;;) {
                        if (0 === l.length) {
                            var d = this.clonePosition();
                            if ("select" === t || !this.bumpIf("=")) break;
                            var m = this.tryParseDecimalInteger(c.o.EXPECT_PLURAL_ARGUMENT_SELECTOR, c.o.INVALID_PLURAL_ARGUMENT_SELECTOR);
                            if (m.err) return m;
                            p = a(d, this.clonePosition()), l = this.message.slice(d.offset, this.offset())
                        }
                        if (s.has(l)) return this.error("select" === t ? c.o.DUPLICATE_SELECT_ARGUMENT_SELECTOR : c.o.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, p);
                        "other" === l && (i = !0), this.bumpSpace();
                        var y = this.clonePosition();
                        if (!this.bumpIf("{")) return this.error("select" === t ? c.o.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : c.o.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, a(this.clonePosition(), this.clonePosition()));
                        var _ = this.parseMessage(e + 1, t, n);
                        if (_.err) return _;
                        var b = this.tryParseArgumentClose(y);
                        if (b.err) return b;
                        u.push([l, {
                            value: _.val,
                            location: a(y, this.clonePosition())
                        }]), s.add(l), this.bumpSpace(), l = (r = this.parseIdentifierIfPossible()).value, p = r.location
                    }
                    return 0 === u.length ? this.error("select" === t ? c.o.EXPECT_SELECT_ARGUMENT_SELECTOR : c.o.EXPECT_PLURAL_ARGUMENT_SELECTOR, a(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !i ? this.error(c.o.MISSING_OTHER_CLAUSE, a(this.clonePosition(), this.clonePosition())) : {
                        val: u,
                        err: null
                    }
                }, e.prototype.tryParseDecimalInteger = function(e, t) {
                    var n = 1,
                        o = this.clonePosition();
                    this.bumpIf("+") || this.bumpIf("-") && (n = -1);
                    for (var r = !1, i = 0; !this.isEOF();) {
                        var u = this.char();
                        if (!(u >= 48 && u <= 57)) break;
                        r = !0, i = 10 * i + (u - 48), this.bump()
                    }
                    var s = a(o, this.clonePosition());
                    return r ? P(i *= n) ? {
                        val: i,
                        err: null
                    } : this.error(t, s) : this.error(e, s)
                }, e.prototype.offset = function() {
                    return this.position.offset
                }, e.prototype.isEOF = function() {
                    return this.offset() === this.message.length
                }, e.prototype.clonePosition = function() {
                    return {
                        offset: this.position.offset,
                        line: this.position.line,
                        column: this.position.column
                    }
                }, e.prototype.char = function() {
                    var e = this.position.offset;
                    if (e >= this.message.length) throw Error("out of bound");
                    var t = T(this.message, e);
                    if (void 0 === t) throw Error("Offset ".concat(e, " is at invalid UTF-16 code unit boundary"));
                    return t
                }, e.prototype.error = function(e, t) {
                    return {
                        val: null,
                        err: {
                            kind: e,
                            message: this.message,
                            location: t
                        }
                    }
                }, e.prototype.bump = function() {
                    if (!this.isEOF()) {
                        var e = this.char();
                        10 === e ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += e < 65536 ? 1 : 2)
                    }
                }, e.prototype.bumpIf = function(e) {
                    if (L(this.message, e, this.offset())) {
                        for (var t = 0; t < e.length; t++) this.bump();
                        return !0
                    }
                    return !1
                }, e.prototype.bumpUntil = function(e) {
                    var t = this.offset(),
                        n = this.message.indexOf(e, t);
                    return n >= 0 ? (this.bumpTo(n), !0) : (this.bumpTo(this.message.length), !1)
                }, e.prototype.bumpTo = function(e) {
                    if (this.offset() > e) throw Error("targetOffset ".concat(e, " must be greater than or equal to the current offset ").concat(this.offset()));
                    for (e = Math.min(e, this.message.length);;) {
                        var t = this.offset();
                        if (t === e) break;
                        if (t > e) throw Error("targetOffset ".concat(e, " is at invalid UTF-16 code unit boundary"));
                        if (this.bump(), this.isEOF()) break
                    }
                }, e.prototype.bumpSpace = function() {
                    for (; !this.isEOF() && i(this.char());) this.bump()
                }, e.prototype.peek = function() {
                    if (this.isEOF()) return null;
                    var e = this.char(),
                        t = this.offset(),
                        n = this.message.charCodeAt(t + (e >= 65536 ? 2 : 1));
                    return null != n ? n : null
                }, e
            }()
        },
        86891: function(e, t, n) {
            "use strict";
            n.d(t, {
                p: function() {
                    return a
                }
            });
            var a = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/
        },
        62651: function(e, t, n) {
            "use strict";
            n.d(t, {
                _: function() {
                    return a
                }
            });
            var a = {
                AX: ["H"],
                BQ: ["H"],
                CP: ["H"],
                CZ: ["H"],
                DK: ["H"],
                FI: ["H"],
                ID: ["H"],
                IS: ["H"],
                ML: ["H"],
                NE: ["H"],
                RU: ["H"],
                SE: ["H"],
                SJ: ["H"],
                SK: ["H"],
                AS: ["h", "H"],
                BT: ["h", "H"],
                DJ: ["h", "H"],
                ER: ["h", "H"],
                GH: ["h", "H"],
                IN: ["h", "H"],
                LS: ["h", "H"],
                PG: ["h", "H"],
                PW: ["h", "H"],
                SO: ["h", "H"],
                TO: ["h", "H"],
                VU: ["h", "H"],
                WS: ["h", "H"],
                "001": ["H", "h"],
                AL: ["h", "H", "hB"],
                TD: ["h", "H", "hB"],
                "ca-ES": ["H", "h", "hB"],
                CF: ["H", "h", "hB"],
                CM: ["H", "h", "hB"],
                "fr-CA": ["H", "h", "hB"],
                "gl-ES": ["H", "h", "hB"],
                "it-CH": ["H", "h", "hB"],
                "it-IT": ["H", "h", "hB"],
                LU: ["H", "h", "hB"],
                NP: ["H", "h", "hB"],
                PF: ["H", "h", "hB"],
                SC: ["H", "h", "hB"],
                SM: ["H", "h", "hB"],
                SN: ["H", "h", "hB"],
                TF: ["H", "h", "hB"],
                VA: ["H", "h", "hB"],
                CY: ["h", "H", "hb", "hB"],
                GR: ["h", "H", "hb", "hB"],
                CO: ["h", "H", "hB", "hb"],
                DO: ["h", "H", "hB", "hb"],
                KP: ["h", "H", "hB", "hb"],
                KR: ["h", "H", "hB", "hb"],
                NA: ["h", "H", "hB", "hb"],
                PA: ["h", "H", "hB", "hb"],
                PR: ["h", "H", "hB", "hb"],
                VE: ["h", "H", "hB", "hb"],
                AC: ["H", "h", "hb", "hB"],
                AI: ["H", "h", "hb", "hB"],
                BW: ["H", "h", "hb", "hB"],
                BZ: ["H", "h", "hb", "hB"],
                CC: ["H", "h", "hb", "hB"],
                CK: ["H", "h", "hb", "hB"],
                CX: ["H", "h", "hb", "hB"],
                DG: ["H", "h", "hb", "hB"],
                FK: ["H", "h", "hb", "hB"],
                GB: ["H", "h", "hb", "hB"],
                GG: ["H", "h", "hb", "hB"],
                GI: ["H", "h", "hb", "hB"],
                IE: ["H", "h", "hb", "hB"],
                IM: ["H", "h", "hb", "hB"],
                IO: ["H", "h", "hb", "hB"],
                JE: ["H", "h", "hb", "hB"],
                LT: ["H", "h", "hb", "hB"],
                MK: ["H", "h", "hb", "hB"],
                MN: ["H", "h", "hb", "hB"],
                MS: ["H", "h", "hb", "hB"],
                NF: ["H", "h", "hb", "hB"],
                NG: ["H", "h", "hb", "hB"],
                NR: ["H", "h", "hb", "hB"],
                NU: ["H", "h", "hb", "hB"],
                PN: ["H", "h", "hb", "hB"],
                SH: ["H", "h", "hb", "hB"],
                SX: ["H", "h", "hb", "hB"],
                TA: ["H", "h", "hb", "hB"],
                ZA: ["H", "h", "hb", "hB"],
                "af-ZA": ["H", "h", "hB", "hb"],
                AR: ["H", "h", "hB", "hb"],
                CL: ["H", "h", "hB", "hb"],
                CR: ["H", "h", "hB", "hb"],
                CU: ["H", "h", "hB", "hb"],
                EA: ["H", "h", "hB", "hb"],
                "es-BO": ["H", "h", "hB", "hb"],
                "es-BR": ["H", "h", "hB", "hb"],
                "es-EC": ["H", "h", "hB", "hb"],
                "es-ES": ["H", "h", "hB", "hb"],
                "es-GQ": ["H", "h", "hB", "hb"],
                "es-PE": ["H", "h", "hB", "hb"],
                GT: ["H", "h", "hB", "hb"],
                HN: ["H", "h", "hB", "hb"],
                IC: ["H", "h", "hB", "hb"],
                KG: ["H", "h", "hB", "hb"],
                KM: ["H", "h", "hB", "hb"],
                LK: ["H", "h", "hB", "hb"],
                MA: ["H", "h", "hB", "hb"],
                MX: ["H", "h", "hB", "hb"],
                NI: ["H", "h", "hB", "hb"],
                PY: ["H", "h", "hB", "hb"],
                SV: ["H", "h", "hB", "hb"],
                UY: ["H", "h", "hB", "hb"],
                JP: ["H", "h", "K"],
                AD: ["H", "hB"],
                AM: ["H", "hB"],
                AO: ["H", "hB"],
                AT: ["H", "hB"],
                AW: ["H", "hB"],
                BE: ["H", "hB"],
                BF: ["H", "hB"],
                BJ: ["H", "hB"],
                BL: ["H", "hB"],
                BR: ["H", "hB"],
                CG: ["H", "hB"],
                CI: ["H", "hB"],
                CV: ["H", "hB"],
                DE: ["H", "hB"],
                EE: ["H", "hB"],
                FR: ["H", "hB"],
                GA: ["H", "hB"],
                GF: ["H", "hB"],
                GN: ["H", "hB"],
                GP: ["H", "hB"],
                GW: ["H", "hB"],
                HR: ["H", "hB"],
                IL: ["H", "hB"],
                IT: ["H", "hB"],
                KZ: ["H", "hB"],
                MC: ["H", "hB"],
                MD: ["H", "hB"],
                MF: ["H", "hB"],
                MQ: ["H", "hB"],
                MZ: ["H", "hB"],
                NC: ["H", "hB"],
                NL: ["H", "hB"],
                PM: ["H", "hB"],
                PT: ["H", "hB"],
                RE: ["H", "hB"],
                RO: ["H", "hB"],
                SI: ["H", "hB"],
                SR: ["H", "hB"],
                ST: ["H", "hB"],
                TG: ["H", "hB"],
                TR: ["H", "hB"],
                WF: ["H", "hB"],
                YT: ["H", "hB"],
                BD: ["h", "hB", "H"],
                PK: ["h", "hB", "H"],
                AZ: ["H", "hB", "h"],
                BA: ["H", "hB", "h"],
                BG: ["H", "hB", "h"],
                CH: ["H", "hB", "h"],
                GE: ["H", "hB", "h"],
                LI: ["H", "hB", "h"],
                ME: ["H", "hB", "h"],
                RS: ["H", "hB", "h"],
                UA: ["H", "hB", "h"],
                UZ: ["H", "hB", "h"],
                XK: ["H", "hB", "h"],
                AG: ["h", "hb", "H", "hB"],
                AU: ["h", "hb", "H", "hB"],
                BB: ["h", "hb", "H", "hB"],
                BM: ["h", "hb", "H", "hB"],
                BS: ["h", "hb", "H", "hB"],
                CA: ["h", "hb", "H", "hB"],
                DM: ["h", "hb", "H", "hB"],
                "en-001": ["h", "hb", "H", "hB"],
                FJ: ["h", "hb", "H", "hB"],
                FM: ["h", "hb", "H", "hB"],
                GD: ["h", "hb", "H", "hB"],
                GM: ["h", "hb", "H", "hB"],
                GU: ["h", "hb", "H", "hB"],
                GY: ["h", "hb", "H", "hB"],
                JM: ["h", "hb", "H", "hB"],
                KI: ["h", "hb", "H", "hB"],
                KN: ["h", "hb", "H", "hB"],
                KY: ["h", "hb", "H", "hB"],
                LC: ["h", "hb", "H", "hB"],
                LR: ["h", "hb", "H", "hB"],
                MH: ["h", "hb", "H", "hB"],
                MP: ["h", "hb", "H", "hB"],
                MW: ["h", "hb", "H", "hB"],
                NZ: ["h", "hb", "H", "hB"],
                SB: ["h", "hb", "H", "hB"],
                SG: ["h", "hb", "H", "hB"],
                SL: ["h", "hb", "H", "hB"],
                SS: ["h", "hb", "H", "hB"],
                SZ: ["h", "hb", "H", "hB"],
                TC: ["h", "hb", "H", "hB"],
                TT: ["h", "hb", "H", "hB"],
                UM: ["h", "hb", "H", "hB"],
                US: ["h", "hb", "H", "hB"],
                VC: ["h", "hb", "H", "hB"],
                VG: ["h", "hb", "H", "hB"],
                VI: ["h", "hb", "H", "hB"],
                ZM: ["h", "hb", "H", "hB"],
                BO: ["H", "hB", "h", "hb"],
                EC: ["H", "hB", "h", "hb"],
                ES: ["H", "hB", "h", "hb"],
                GQ: ["H", "hB", "h", "hb"],
                PE: ["H", "hB", "h", "hb"],
                AE: ["h", "hB", "hb", "H"],
                "ar-001": ["h", "hB", "hb", "H"],
                BH: ["h", "hB", "hb", "H"],
                DZ: ["h", "hB", "hb", "H"],
                EG: ["h", "hB", "hb", "H"],
                EH: ["h", "hB", "hb", "H"],
                HK: ["h", "hB", "hb", "H"],
                IQ: ["h", "hB", "hb", "H"],
                JO: ["h", "hB", "hb", "H"],
                KW: ["h", "hB", "hb", "H"],
                LB: ["h", "hB", "hb", "H"],
                LY: ["h", "hB", "hb", "H"],
                MO: ["h", "hB", "hb", "H"],
                MR: ["h", "hB", "hb", "H"],
                OM: ["h", "hB", "hb", "H"],
                PH: ["h", "hB", "hb", "H"],
                PS: ["h", "hB", "hb", "H"],
                QA: ["h", "hB", "hb", "H"],
                SA: ["h", "hB", "hb", "H"],
                SD: ["h", "hB", "hb", "H"],
                SY: ["h", "hB", "hb", "H"],
                TN: ["h", "hB", "hb", "H"],
                YE: ["h", "hB", "hb", "H"],
                AF: ["H", "hb", "hB", "h"],
                LA: ["H", "hb", "hB", "h"],
                CN: ["H", "hB", "hb", "h"],
                LV: ["H", "hB", "hb", "h"],
                TL: ["H", "hB", "hb", "h"],
                "zu-ZA": ["H", "hB", "hb", "h"],
                CD: ["hB", "H"],
                IR: ["hB", "H"],
                "hi-IN": ["hB", "h", "H"],
                "kn-IN": ["hB", "h", "H"],
                "ml-IN": ["hB", "h", "H"],
                "te-IN": ["hB", "h", "H"],
                KH: ["hB", "h", "H", "hb"],
                "ta-IN": ["hB", "h", "hb", "H"],
                BN: ["hb", "hB", "h", "H"],
                MY: ["hb", "hB", "h", "H"],
                ET: ["hB", "hb", "h", "H"],
                "gu-IN": ["hB", "hb", "h", "H"],
                "mr-IN": ["hB", "hb", "h", "H"],
                "pa-IN": ["hB", "hb", "h", "H"],
                TW: ["hB", "hb", "h", "H"],
                KE: ["hB", "hb", "H", "h"],
                MM: ["hB", "hb", "H", "h"],
                TZ: ["hB", "hb", "H", "h"],
                UG: ["hB", "hb", "H", "h"]
            }
        },
        46365: function(e, t, n) {
            "use strict";

            function a(e) {
                return e.type === y.literal
            }

            function o(e) {
                return e.type === y.argument
            }

            function r(e) {
                return e.type === y.number
            }

            function i(e) {
                return e.type === y.date
            }

            function u(e) {
                return e.type === y.time
            }

            function s(e) {
                return e.type === y.select
            }

            function l(e) {
                return e.type === y.plural
            }

            function c(e) {
                return e.type === y.pound
            }

            function p(e) {
                return e.type === y.tag
            }

            function d(e) {
                return !(!e || "object" != typeof e || e.type !== _.number)
            }

            function m(e) {
                return !(!e || "object" != typeof e || e.type !== _.dateTime)
            }
            var y, _;
            n.d(t, {
                    HI: function() {
                        return p
                    },
                    Ii: function() {
                        return m
                    },
                    Jo: function() {
                        return l
                    },
                    O4: function() {
                        return a
                    },
                    VG: function() {
                        return o
                    },
                    Wh: function() {
                        return d
                    },
                    Wi: function() {
                        return s
                    },
                    aV: function() {
                        return _
                    },
                    pe: function() {
                        return u
                    },
                    rp: function() {
                        return i
                    },
                    uf: function() {
                        return r
                    },
                    wD: function() {
                        return y
                    },
                    yx: function() {
                        return c
                    }
                }),
                function(e) {
                    e[e.literal = 0] = "literal", e[e.argument = 1] = "argument", e[e.number = 2] = "number", e[e.date = 3] = "date", e[e.time = 4] = "time", e[e.select = 5] = "select", e[e.plural = 6] = "plural", e[e.pound = 7] = "pound", e[e.tag = 8] = "tag"
                }(y || (y = {})),
                function(e) {
                    e[e.number = 0] = "number", e[e.dateTime = 1] = "dateTime"
                }(_ || (_ = {}))
        },
        91768: function(e, t, n) {
            "use strict";

            function a(e) {
                var t = {};
                return e.replace(o, (function(e) {
                    var n = e.length;
                    switch (e[0]) {
                        case "G":
                            t.era = 4 === n ? "long" : 5 === n ? "narrow" : "short";
                            break;
                        case "y":
                            t.year = 2 === n ? "2-digit" : "numeric";
                            break;
                        case "Y":
                        case "u":
                        case "U":
                        case "r":
                            throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
                        case "q":
                        case "Q":
                            throw new RangeError("`q/Q` (quarter) patterns are not supported");
                        case "M":
                        case "L":
                            t.month = ["numeric", "2-digit", "short", "long", "narrow"][n - 1];
                            break;
                        case "w":
                        case "W":
                            throw new RangeError("`w/W` (week) patterns are not supported");
                        case "d":
                            t.day = ["numeric", "2-digit"][n - 1];
                            break;
                        case "D":
                        case "F":
                        case "g":
                            throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
                        case "E":
                            t.weekday = 4 === n ? "short" : 5 === n ? "narrow" : "short";
                            break;
                        case "e":
                            if (n < 4) throw new RangeError("`e..eee` (weekday) patterns are not supported");
                            t.weekday = ["short", "long", "narrow", "short"][n - 4];
                            break;
                        case "c":
                            if (n < 4) throw new RangeError("`c..ccc` (weekday) patterns are not supported");
                            t.weekday = ["short", "long", "narrow", "short"][n - 4];
                            break;
                        case "a":
                            t.hour12 = !0;
                            break;
                        case "b":
                        case "B":
                            throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
                        case "h":
                            t.hourCycle = "h12", t.hour = ["numeric", "2-digit"][n - 1];
                            break;
                        case "H":
                            t.hourCycle = "h23", t.hour = ["numeric", "2-digit"][n - 1];
                            break;
                        case "K":
                            t.hourCycle = "h11", t.hour = ["numeric", "2-digit"][n - 1];
                            break;
                        case "k":
                            t.hourCycle = "h24", t.hour = ["numeric", "2-digit"][n - 1];
                            break;
                        case "j":
                        case "J":
                        case "C":
                            throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
                        case "m":
                            t.minute = ["numeric", "2-digit"][n - 1];
                            break;
                        case "s":
                            t.second = ["numeric", "2-digit"][n - 1];
                            break;
                        case "S":
                        case "A":
                            throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
                        case "z":
                            t.timeZoneName = n < 4 ? "short" : "long";
                            break;
                        case "Z":
                        case "O":
                        case "v":
                        case "V":
                        case "X":
                        case "x":
                            throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead")
                    }
                    return ""
                })), t
            }
            n.d(t, {
                T: function() {
                    return a
                }
            });
            var o = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g
        },
        74926: function(e, t, n) {
            "use strict";

            function a(e) {
                if (0 === e.length) throw new Error("Number skeleton cannot be empty");
                for (var t = [], n = 0, a = e.split(c.r).filter((function(e) {
                        return e.length > 0
                    })); n < a.length; n++) {
                    var o = a[n].split("/");
                    if (0 === o.length) throw new Error("Invalid number skeleton");
                    for (var r = o[0], i = o.slice(1), u = 0, s = i; u < s.length; u++) {
                        if (0 === s[u].length) throw new Error("Invalid number skeleton")
                    }
                    t.push({
                        stem: r,
                        options: i
                    })
                }
                return t
            }

            function o(e) {
                var t = {};
                return "r" === e[e.length - 1] ? t.roundingPriority = "morePrecision" : "s" === e[e.length - 1] && (t.roundingPriority = "lessPrecision"), e.replace(d, (function(e, n, a) {
                    return "string" != typeof a ? (t.minimumSignificantDigits = n.length, t.maximumSignificantDigits = n.length) : "+" === a ? t.minimumSignificantDigits = n.length : "#" === n[0] ? t.maximumSignificantDigits = n.length : (t.minimumSignificantDigits = n.length, t.maximumSignificantDigits = n.length + ("string" == typeof a ? a.length : 0)), ""
                })), t
            }

            function r(e) {
                switch (e) {
                    case "sign-auto":
                        return {
                            signDisplay: "auto"
                        };
                    case "sign-accounting":
                    case "()":
                        return {
                            currencySign: "accounting"
                        };
                    case "sign-always":
                    case "+!":
                        return {
                            signDisplay: "always"
                        };
                    case "sign-accounting-always":
                    case "()!":
                        return {
                            signDisplay: "always",
                            currencySign: "accounting"
                        };
                    case "sign-except-zero":
                    case "+?":
                        return {
                            signDisplay: "exceptZero"
                        };
                    case "sign-accounting-except-zero":
                    case "()?":
                        return {
                            signDisplay: "exceptZero",
                            currencySign: "accounting"
                        };
                    case "sign-never":
                    case "+_":
                        return {
                            signDisplay: "never"
                        }
                }
            }

            function i(e) {
                var t;
                if ("E" === e[0] && "E" === e[1] ? (t = {
                        notation: "engineering"
                    }, e = e.slice(2)) : "E" === e[0] && (t = {
                        notation: "scientific"
                    }, e = e.slice(1)), t) {
                    var n = e.slice(0, 2);
                    if ("+!" === n ? (t.signDisplay = "always", e = e.slice(2)) : "+?" === n && (t.signDisplay = "exceptZero", e = e.slice(2)), !y.test(e)) throw new Error("Malformed concise eng/scientific notation");
                    t.minimumIntegerDigits = e.length
                }
                return t
            }

            function u(e) {
                var t = r(e);
                return t || {}
            }

            function s(e) {
                for (var t = {}, n = 0, a = e; n < a.length; n++) {
                    var s = a[n];
                    switch (s.stem) {
                        case "percent":
                        case "%":
                            t.style = "percent";
                            continue;
                        case "%x100":
                            t.style = "percent", t.scale = 100;
                            continue;
                        case "currency":
                            t.style = "currency", t.currency = s.options[0];
                            continue;
                        case "group-off":
                        case ",_":
                            t.useGrouping = !1;
                            continue;
                        case "precision-integer":
                        case ".":
                            t.maximumFractionDigits = 0;
                            continue;
                        case "measure-unit":
                        case "unit":
                            t.style = "unit", t.unit = s.options[0].replace(/^(.*?)-/, "");
                            continue;
                        case "compact-short":
                        case "K":
                            t.notation = "compact", t.compactDisplay = "short";
                            continue;
                        case "compact-long":
                        case "KK":
                            t.notation = "compact", t.compactDisplay = "long";
                            continue;
                        case "scientific":
                            t = (0, l.__assign)((0, l.__assign)((0, l.__assign)({}, t), {
                                notation: "scientific"
                            }), s.options.reduce((function(e, t) {
                                return (0, l.__assign)((0, l.__assign)({}, e), u(t))
                            }), {}));
                            continue;
                        case "engineering":
                            t = (0, l.__assign)((0, l.__assign)((0, l.__assign)({}, t), {
                                notation: "engineering"
                            }), s.options.reduce((function(e, t) {
                                return (0, l.__assign)((0, l.__assign)({}, e), u(t))
                            }), {}));
                            continue;
                        case "notation-simple":
                            t.notation = "standard";
                            continue;
                        case "unit-width-narrow":
                            t.currencyDisplay = "narrowSymbol", t.unitDisplay = "narrow";
                            continue;
                        case "unit-width-short":
                            t.currencyDisplay = "code", t.unitDisplay = "short";
                            continue;
                        case "unit-width-full-name":
                            t.currencyDisplay = "name", t.unitDisplay = "long";
                            continue;
                        case "unit-width-iso-code":
                            t.currencyDisplay = "symbol";
                            continue;
                        case "scale":
                            t.scale = parseFloat(s.options[0]);
                            continue;
                        case "integer-width":
                            if (s.options.length > 1) throw new RangeError("integer-width stems only accept a single optional option");
                            s.options[0].replace(m, (function(e, n, a, o, r, i) {
                                if (n) t.minimumIntegerDigits = a.length;
                                else {
                                    if (o && r) throw new Error("We currently do not support maximum integer digits");
                                    if (i) throw new Error("We currently do not support exact integer digits")
                                }
                                return ""
                            }));
                            continue
                    }
                    if (y.test(s.stem)) t.minimumIntegerDigits = s.stem.length;
                    else if (p.test(s.stem)) {
                        if (s.options.length > 1) throw new RangeError("Fraction-precision stems only accept a single optional option");
                        s.stem.replace(p, (function(e, n, a, o, r, i) {
                            return "*" === a ? t.minimumFractionDigits = n.length : o && "#" === o[0] ? t.maximumFractionDigits = o.length : r && i ? (t.minimumFractionDigits = r.length, t.maximumFractionDigits = r.length + i.length) : (t.minimumFractionDigits = n.length, t.maximumFractionDigits = n.length), ""
                        }));
                        var c = s.options[0];
                        "w" === c ? t = (0, l.__assign)((0, l.__assign)({}, t), {
                            trailingZeroDisplay: "stripIfInteger"
                        }) : c && (t = (0, l.__assign)((0, l.__assign)({}, t), o(c)))
                    } else if (d.test(s.stem)) t = (0, l.__assign)((0, l.__assign)({}, t), o(s.stem));
                    else {
                        var _ = r(s.stem);
                        _ && (t = (0, l.__assign)((0, l.__assign)({}, t), _));
                        var b = i(s.stem);
                        b && (t = (0, l.__assign)((0, l.__assign)({}, t), b))
                    }
                }
                return t
            }
            if (n.d(t, {
                    I: function() {
                        return s
                    },
                    O: function() {
                        return a
                    }
                }), !/^(2(400|417|760)|3(081|092|179|58)|8(022|05|384|889)|5663)$/.test(n.j)) var l = n(70655);
            if (!/^(2(400|417|760)|3(081|092|179|58)|8(022|05|384|889)|5663)$/.test(n.j)) var c = n(59654);
            var p = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g,
                d = /^(@+)?(\+|#+)?[rs]?$/g,
                m = /(\*)(0+)|(#+)(0+)|(0+)/g,
                y = /^(0+)$/
        },
        59654: function(e, t, n) {
            "use strict";
            n.d(t, {
                r: function() {
                    return a
                }
            });
            var a = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i
        },
        3434: function(e, t, n) {
            "use strict";

            function a() {}

            function o(e) {
                if ("object" != typeof this) throw new TypeError("Promises must be constructed via new");
                if ("function" != typeof e) throw new TypeError("not a function");
                this._45 = 0, this._81 = 0, this._65 = null, this._54 = null, e !== a && c(e, this)
            }

            function r(e, t) {
                for (; 3 === e._81;) e = e._65;
                if (o._10 && o._10(e), 0 === e._81) return 0 === e._45 ? (e._45 = 1, void(e._54 = t)) : 1 === e._45 ? (e._45 = 2, void(e._54 = [e._54, t])) : void e._54.push(t);
                ! function(e, t) {
                    p((function() {
                        var n = 1 === e._81 ? t.onFulfilled : t.onRejected;
                        if (null !== n) {
                            var a = function(e, t) {
                                try {
                                    return e(t)
                                } catch (e) {
                                    return d = e, m
                                }
                            }(n, e._65);
                            a === m ? u(t.promise, d) : i(t.promise, a)
                        } else 1 === e._81 ? i(t.promise, e._65) : u(t.promise, e._65)
                    }))
                }(e, t)
            }

            function i(e, t) {
                if (t === e) return u(e, new TypeError("A promise cannot be resolved with itself."));
                if (t && ("object" == typeof t || "function" == typeof t)) {
                    var n = function(e) {
                        try {
                            return e.then
                        } catch (e) {
                            return d = e, m
                        }
                    }(t);
                    if (n === m) return u(e, d);
                    if (n === e.then && t instanceof o) return e._81 = 3, e._65 = t, void s(e);
                    if ("function" == typeof n) return void c(n.bind(t), e)
                }
                e._81 = 1, e._65 = t, s(e)
            }

            function u(e, t) {
                e._81 = 2, e._65 = t, o._97 && o._97(e, t), s(e)
            }

            function s(e) {
                if (1 === e._45 && (r(e, e._54), e._54 = null), 2 === e._45) {
                    for (var t = 0; t < e._54.length; t++) r(e, e._54[t]);
                    e._54 = null
                }
            }

            function l(e, t, n) {
                this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.promise = n
            }

            function c(e, t) {
                var n = !1,
                    a = function(e, t, n) {
                        try {
                            e(t, n)
                        } catch (e) {
                            return d = e, m
                        }
                    }(e, (function(e) {
                        n || (n = !0, i(t, e))
                    }), (function(e) {
                        n || (n = !0, u(t, e))
                    }));
                n || a !== m || (n = !0, u(t, d))
            }
            var p = n(10723),
                d = null,
                m = {};
            e.exports = o, o._10 = null, o._97 = null, o._61 = a, o.prototype.then = function(e, t) {
                if (this.constructor !== o) return function(e, t, n) {
                    return new e.constructor((function(i, u) {
                        var s = new o(a);
                        s.then(i, u), r(e, new l(t, n, s))
                    }))
                }(this, e, t);
                var n = new o(a);
                return r(this, new l(e, t, n)), n
            }
        },
        21803: function(e, t, n) {
            "use strict";

            function a(e) {
                var t = new o(o._61);
                return t._81 = 1, t._65 = e, t
            }
            var o = n(3434);
            e.exports = o;
            var r = a(!0),
                i = a(!1),
                u = a(null),
                s = a(void 0),
                l = a(0),
                c = a("");
            o.resolve = function(e) {
                if (e instanceof o) return e;
                if (null === e) return u;
                if (void 0 === e) return s;
                if (!0 === e) return r;
                if (!1 === e) return i;
                if (0 === e) return l;
                if ("" === e) return c;
                if ("object" == typeof e || "function" == typeof e) try {
                    var t = e.then;
                    if ("function" == typeof t) return new o(t.bind(e))
                } catch (e) {
                    return new o((function(t, n) {
                        n(e)
                    }))
                }
                return a(e)
            }, o.all = function(e) {
                var t = Array.prototype.slice.call(e);
                return new o((function(e, n) {
                    function a(i, u) {
                        if (u && ("object" == typeof u || "function" == typeof u)) {
                            if (u instanceof o && u.then === o.prototype.then) {
                                for (; 3 === u._81;) u = u._65;
                                return 1 === u._81 ? a(i, u._65) : (2 === u._81 && n(u._65), void u.then((function(e) {
                                    a(i, e)
                                }), n))
                            }
                            var s = u.then;
                            if ("function" == typeof s) return void new o(s.bind(u)).then((function(e) {
                                a(i, e)
                            }), n)
                        }
                        t[i] = u, 0 == --r && e(t)
                    }
                    if (0 === t.length) return e([]);
                    for (var r = t.length, i = 0; i < t.length; i++) a(i, t[i])
                }))
            }, o.reject = function(e) {
                return new o((function(t, n) {
                    n(e)
                }))
            }, o.race = function(e) {
                return new o((function(t, n) {
                    e.forEach((function(e) {
                        o.resolve(e).then(t, n)
                    }))
                }))
            }, o.prototype.catch = function(e) {
                return this.then(null, e)
            }
        },
        78029: function(e, t, n) {
            "use strict";
            var a = n(3434);
            e.exports = a, a.prototype.finally = function(e) {
                return this.then((function(t) {
                    return a.resolve(e()).then((function() {
                        return t
                    }))
                }), (function(t) {
                    return a.resolve(e()).then((function() {
                        throw t
                    }))
                }))
            }
        },
        43514: function(e, t, n) {
            "use strict";
            n.d(t, {
                XG: function() {
                    return B
                },
                bI: function() {
                    return T
                },
                eK: function() {
                    return k
                },
                ix: function() {
                    return C
                },
                nS: function() {
                    return j
                }
            });
            var a = n(43144),
                o = n(15671),
                r = n(60136),
                i = n(29388),
                u = n(7112);
            if (/^(1(180|283|789)|22(04|9)|3(033|58|607)|5(194|815|941)|8(05|285|308)|4110|4784|7047|9411)$/.test(n.j)) var s = n(1413);
            var l = n(4942),
                c = n(94217),
                p = n(69792),
                d = n(77489),
                m = n(84490);
            if (/^(1(180|283|789)|22(04|9)|3(033|58|607)|5(194|815|941)|8(05|285|308)|4110|4784|7047|9411)$/.test(n.j)) var y = n(11937);
            var _, b = n(57306),
                h = n(41216),
                f = n(56274).Promise,
                g = "".concat("https://merchant-ui-api.stripe.com/", "link/") || 0,
                k = function(e) {
                    return e.CheckoutStripe = "checkout-stripe", e.CheckoutLink = "checkout-link", e.MerchantUiApi = "merchant-ui-api", e
                }({}),
                v = (_ = {}, (0, l.Z)(_, k.CheckoutStripe, "https://checkout-cookies.stripe.com/api/"), (0, l.Z)(_, k.CheckoutLink, "https://checkout-cookies.link.com/api/"), (0, l.Z)(_, k.MerchantUiApi, g), _),
                w = Object.freeze({
                    Accept: "application/json"
                }),
                A = Object.freeze({
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    "X-Requested-With": "fetch"
                }),
                P = function(e, t, n) {
                    return (0, c.h)({
                        url: e,
                        method: t,
                        data: n,
                        withCredentials: !0,
                        headers: "POST" === t ? A : w,
                        contentType: "POST" === t ? "application/json" : void 0
                    }).then((function(t) {
                        var n = {};
                        try {
                            n = JSON.parse(t.responseText)
                        } catch (e) {
                            n.error = {
                                message: "client generated error: could not parse responseText"
                            }
                        }
                        return 200 === t.status ? {
                            type: "object",
                            object: n
                        } : {
                            type: "error",
                            error: (0, s.Z)((0, s.Z)({}, n.error), {}, {
                                status: t.status || 0,
                                url: e
                            })
                        }
                    }))
                },
                E = function(e) {
                    function t(e) {
                        var a, r = e.status,
                            i = e.message,
                            u = e.apiError;
                        return (0, o.Z)(this, t), (a = n.call(this, i)).status = r, a.apiError = u, a
                    }(0, r.Z)(t, e);
                    var n = (0, i.Z)(t);
                    return (0, a.Z)(t)
                }((0, u.Z)(Error)),
                S = function(e) {
                    return new f((function(t, n) {
                        e.then((function(e) {
                            if ("error" === e.type) {
                                var a = e.error;
                                return n(new E((0, s.Z)((0, s.Z)({}, a), {}, {
                                    apiError: a
                                })))
                            }
                            var o = (0, y.P9)(e.object.auth_session_client_secret);
                            return o && "" !== o.trim() ? t(e) : n(new E({
                                status: 204,
                                message: "Cookie not found",
                                apiError: null
                            }))
                        }))
                    }))
                },
                L = function(e) {
                    return (0, d.Z)(e.map((function(e) {
                        return n = v[t = e], a = (0, s.Z)({}, t === k.MerchantUiApi && "" !== m.Z_ ? {
                            referrer_host: m.Z_
                        } : null), P("".concat(n, "get-cookie"), "GET", a).then((function(e) {
                            return "error" === e.type ? e : (0, s.Z)((0, s.Z)({}, e), {}, {
                                object: (0, s.Z)((0, s.Z)({}, e.object), {}, {
                                    auth_session_client_secret: (0, y.eB)(e.object.auth_session_client_secret)
                                })
                            })
                        }));
                        var t, n, a
                    })).map(S)).then((function(e) {
                        return e
                    })).catch((function(e) {
                        var t = e.errors.filter((function(e) {
                            return 204 !== e.status
                        }));
                        return t.length > 0 ? {
                            type: "error",
                            error: t[0]
                        } : {
                            type: "object",
                            object: {
                                auth_session_client_secret: (0, y.eB)("")
                            }
                        }
                    }))
                },
                C = function(e) {
                    return h.td || (0, b.tl)(e) ? [k.MerchantUiApi, k.CheckoutStripe] : null
                },
                N = null,
                T = function(e) {
                    return N || (N = L(e), (new p.E).getAsPosixTime()), N
                },
                x = function(e) {
                    return P("".concat(v[e], "delete-cookie"), "POST")
                },
                I = function(e) {
                    for (var t = 0; t < e.length; t++) {
                        var n = e[t];
                        if ("error" === n.type) return n
                    }
                    return null
                },
                B = function(e) {
                    return f.all(e.map((function(e) {
                        return x(e)
                    }))).then((function(e) {
                        return I(e) || e[0]
                    }))
                },
                j = function(e) {
                    var t = e.newAuthSessionClientSecret,
                        n = e.currentAuthSessionClientSecret,
                        a = e.validDomains;
                    return f.all(a.map((function(e) {
                        return function(e) {
                            var t = e.cookieDomain,
                                n = e.newAuthSessionClientSecret,
                                a = e.currentAuthSessionClientSecret,
                                o = (0, y.P9)(n),
                                r = (0, y.P9)(a);
                            return "" === o ? x(t) : o && o !== r ? P("".concat(v[t], "set-cookie"), "POST", {
                                auth_session_client_secret: o
                            }) : f.resolve({
                                type: "object",
                                object: {}
                            })
                        }({
                            cookieDomain: e,
                            newAuthSessionClientSecret: t,
                            currentAuthSessionClientSecret: n
                        })
                    }))).then((function(e) {
                        return I(e) || e[0]
                    }))
                }
        },
        74416: function(e, t, n) {
            "use strict";
            n.d(t, {
                t: function() {
                    return l
                }
            });
            var a = n(87655),
                o = !1,
                r = null,
                i = null,
                u = null,
                s = function() {
                    return u || (u = (r || (r = n.e(7058).then(n.bind(n, 47499)).catch((function() {
                        return o = !0, null
                    }))), r).then((function(e) {
                        return e ? i = new e.LocalStorage : null
                    }))), u
                },
                l = {
                    get: function(e) {
                        return i ? i.get(e) : (s().then((function(t) {
                            return null == t ? void 0 : t.get(e)
                        })), o ? null : null === (t = (0, a.X)()) || void 0 === t ? void 0 : t.getItem(e));
                        var t
                    },
                    set: function(e, t) {
                        return s().then((function(n) {
                            var a;
                            return null !== (a = null == n ? void 0 : n.set(e, t)) && void 0 !== a && a
                        }))
                    }
                }
        },
        40069: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    f2: function() {
                        return b
                    },
                    hl: function() {
                        return p
                    },
                    jC: function() {
                        return y
                    },
                    qF: function() {
                        return d
                    },
                    tt: function() {
                        return _
                    }
                }), /^(1(180|283|789)|22(04|9)|3(033|58|607)|5(194|815|941)|8(05|285|308)|4110|4784|7047|9411)$/.test(n.j)) var a = n(4942);
            if (/^(1(180|283|789)|22(04|9)|3(033|58|607)|5(194|815|941)|8(05|285|308)|4110|4784|7047|9411)$/.test(n.j)) var o = n(1413);
            var r = n(74416);
            if (/^(1(180|283|789)|22(04|9)|3(033|58|607)|5(194|815|941)|8(05|285|308)|4110|4784|7047|9411)$/.test(n.j)) var i = n(11937);
            var u = "link.auth_session_client_secret",
                s = {
                    live: null,
                    test: {}
                },
                l = function() {
                    try {
                        var e = r.t.get(u);
                        if (!e) return s;
                        var t = JSON.parse(e);
                        return {
                            live: (null == t ? void 0 : t.live) || null,
                            test: (null == t ? void 0 : t.test) || {}
                        }
                    } catch (e) {
                        return s
                    }
                },
                c = /^(1(180|283|789)|22(04|9)|3(033|58|607)|5(194|815|941)|8(05|285|308)|4110|4784|7047|9411)$/.test(n.j) ? 31536e6 : null,
                p = function(e) {
                    var t = e.authSessionClientSecret,
                        n = e.key,
                        s = e.livemode,
                        p = e.expiry,
                        d = void 0 === p ? Date.now() + c : p,
                        m = l(),
                        y = s ? (0, o.Z)((0, o.Z)({}, m), {}, {
                            live: {
                                value: (0, i.P9)(t),
                                expiry: d
                            }
                        }) : (0, o.Z)((0, o.Z)({}, m), {}, {
                            test: (0, o.Z)((0, o.Z)({}, m.test), {}, (0, a.Z)({}, n, {
                                value: (0, i.P9)(t),
                                expiry: d
                            }))
                        });
                    r.t.set(u, JSON.stringify(y)).catch((function() {}))
                },
                d = function(e) {
                    var t = e.authSessionClientSecret,
                        n = e.keys,
                        a = e.livemode,
                        s = e.expiry,
                        p = void 0 === s ? Date.now() + c : s,
                        d = l(),
                        m = n.reduce((function(e, n) {
                            return e[n] = {
                                value: (0, i.P9)(t),
                                expiry: p
                            }, e
                        }), {}),
                        y = a ? (0, o.Z)((0, o.Z)({}, d), {}, {
                            live: {
                                value: (0, i.P9)(t),
                                expiry: p
                            }
                        }) : (0, o.Z)((0, o.Z)({}, d), {}, {
                            test: (0, o.Z)((0, o.Z)({}, d.test), m)
                        });
                    r.t.set(u, JSON.stringify(y)).catch((function() {}))
                },
                m = function(e) {
                    return e ? "string" == typeof e ? (0, i.eB)(e) : e.expiry < Date.now() ? null : (0, i.eB)(e.value) : null
                },
                y = function(e) {
                    var t = e.key,
                        n = e.livemode;
                    try {
                        var a = l();
                        return m(n ? a.live : a.test[t])
                    } catch (e) {
                        return null
                    }
                },
                _ = function(e) {
                    var t = e.key,
                        n = e.livemode,
                        a = l();
                    n ? a.live = null : delete a.test[t], r.t.set(u, JSON.stringify(a)).catch((function() {}))
                },
                b = function(e) {
                    var t = e.keys,
                        n = e.livemode,
                        a = l();
                    n ? a.live = null : t.forEach((function(e) {
                        delete a.test[e]
                    })), r.t.set(u, JSON.stringify(a)).catch((function() {}))
                }
        },
        11937: function(e, t, n) {
            "use strict";
            n.d(t, {
                OP: function() {
                    return r
                },
                P9: function() {
                    return a
                },
                eB: function() {
                    return o
                }
            });
            var a = function(e) {
                    return e
                },
                o = function(e) {
                    return e
                },
                r = function(e) {
                    return e
                }
        },
        77489: function(e, t, n) {
            "use strict";
            var a = n(43144),
                o = n(15671),
                r = n(60136),
                i = n(29388),
                u = n(7112),
                s = n(56274).Promise,
                l = function(e) {
                    function t(e, a) {
                        var r;
                        return (0, o.Z)(this, t), (r = n.call(this, a)).errors = e, r
                    }(0, r.Z)(t, e);
                    var n = (0, i.Z)(t);
                    return (0, a.Z)(t)
                }((0, u.Z)(Error));
            t.Z = /^(1(180|283|789)|22(04|9)|3(033|58|607)|5(194|815|941)|8(05|285|308)|4110|4784|7047|9411)$/.test(n.j) ? function(e) {
                return new s((function(t, n) {
                    var a = [];
                    e.forEach((function(o) {
                        o.then((function(e) {
                            return t(e)
                        }), (function(t) {
                            a.push(t), a.length === e.length && n(new l(a, "All promises were rejected."))
                        }))
                    })), 0 === e.length && n(new l([], "No promises to resolve."))
                }))
            } : null
        },
        48229: function(e, t, n) {
            "use strict";
            n.d(t, {
                Az: function() {
                    return o
                },
                jL: function() {
                    return l
                },
                mY: function() {
                    return i
                },
                pM: function() {
                    return c
                },
                sU: function() {
                    return p
                },
                sf: function() {
                    return u
                },
                uB: function() {
                    return r
                },
                yT: function() {
                    return s
                }
            });
            var a = /^(2(204|449|627)|5(075|592|663)|1580|3092|3379|9487)$/.test(n.j) ? ["KLARNA"] : null,
                o = function(e) {
                    return -1 !== a.indexOf(e)
                },
                r = {
                    KLARNA: "KLARNA",
                    CARD: "CARD",
                    INSTANT_DEBITS: "BANK_ACCOUNT",
                    US_BANK_ACCOUNT: "BANK_ACCOUNT"
                },
                i = /^(4505|5075|7297)$/.test(n.j) ? ["shopping", "price", "return", "product"] : null,
                u = function(e) {
                    return e.EMAIL = "EMAIL", e.SMS = "SMS", e.WEBAUTHN = "WEBAUTHN", e
                }({}),
                s = function(e) {
                    return e.Card = "card", e.BankAccount = "bank_account", e.Klarna = "klarna", e
                }({}),
                l = function(e) {
                    return e.Checkout = "web_checkout", e.PaymentElement = "web_payment_element", e.Connections = "web_connections", e.InstantDebits = "web_instant_debits", e.CryptoOnramp = "web_crypto_onramp", e.CryptoPayins = "web_crypto_payins", e.LegacyElementsPopup = "web_legacy_elements_popup", e.CheckoutPopup = "web_checkout_popup", e.CardElementPopup = "web_card_element_popup", e.SplitCardElementPopup = "web_split_card_element_popup", e.HostedInvoicePagePopup = "web_hosted_invoice_page_popup", e.HostedInvoicePagePaymentElement = "web_hosted_invoice_page_payment_element", e.ExpressCheckoutElementPopup = "web_pay_button_element_popup", e.ElementsController = "web_elements_controller", e.MobileSdkPopup = "web_mobile_sdk_popup", e.LinkAuthenticationInPaymentElement = "web_link_authentication_in_payment_element", e.LinkAuthenticationElement = "web_link_authentication_element", e
                }({}),
                c = function(e) {
                    return e.NoCheckboxPrefilledNone = "no_checkbox_prefilled_none", e.NoCheckboxPrefilledSome = "no_checkbox_prefilled_some", e.NoCheckboxPrefilledAll = "no_checkbox_prefilled_all", e.PrecheckedOptinBoxPrefilledNone = "prechecked_opt_in_box_prefilled_none", e.PrecheckedOptinBoxPrefilledSome = "prechecked_opt_in_box_prefilled_some", e.PrecheckedOptinBoxPrefilledAll = "prechecked_opt_in_box_prefilled_all", e.CheckedOptInBoxEnteredPhoneNumber = "checked_opt_in_box_entered_phone_number", e.CheckedOptInBoxPrefilledPhoneNumber = "checked_opt_in_box_prefilled_phone_number", e.CheckedOptInBoxAutofilledPhoneNumber = "checked_opt_in_box_autofilled_phone_number", e.EnteredPhoneNumber = "entered_phone_number", e.AutofilledPhoneNumber = "autofilled_phone_number", e.DefaultOptInEnteredPhoneNumber = "default_opt_in_entered_phone_number", e.DefaultOptInPrefilledPhoneNumber = "default_opt_in_prefilled_phone_number", e.DefaultOptInAutofilledPhoneNumber = "default_opt_in_autofilled_phone_number", e.EnteredPhoneNumberClickedSaveToLink = "entered_phone_number_clicked_save_to_link", e.EnteredPhoneNumberEmailClickedSignupCryptoOnramp = "entered_phone_number_email_clicked_signup_crypto_onramp", e.ClickedPromptEnteredPhoneNumber = "clicked_prompt_entered_phone_number", e.ClickedPromptPrefilledPhoneNumber = "clicked_prompt_prefilled_phone_number", e.ImpliedConsentWithSpm = "implied_consent_withspm", e.ImpliedConsentWithSpmPrefilledPhoneNumber = "implied_consent_withspm_prefilled_phone_number", e
                }({}),
                p = function(e) {
                    return e.LINK_OTP_EMAIL = "LINK_OTP_EMAIL", e.NETWORKED_CONNECTIONS_OTP_EMAIL = "NETWORKED_CONNECTIONS_OTP_EMAIL", e
                }({})
        },
        92531: function(e, t, n) {
            "use strict";
            n.d(t, {
                A9: function() {
                    return c
                },
                KA: function() {
                    return _
                },
                QS: function() {
                    return m
                },
                VS: function() {
                    return y
                },
                bT: function() {
                    return d
                },
                eG: function() {
                    return s
                },
                f3: function() {
                    return i
                },
                fh: function() {
                    return l
                },
                gJ: function() {
                    return p
                },
                mj: function() {
                    return h
                },
                uN: function() {
                    return u
                },
                y$: function() {
                    return b
                }
            });
            var a, o = n(4942),
                r = n(60276),
                i = "experiment_exposure",
                u = {
                    account: "account",
                    bank_account: "bank_account",
                    card: "card",
                    person: "person",
                    pii: "pii",
                    cvc_update: "cvc_update"
                },
                s = (a = {}, (0, o.Z)(a, r.Yj.card, u.card), (0, o.Z)(a, r.Yj.cardNumber, u.card), (0, o.Z)(a, r.Yj.cardExpiry, u.card), (0, o.Z)(a, r.Yj.cardCvc, u.card), (0, o.Z)(a, r.Yj.postalCode, u.card), (0, o.Z)(a, r.Yj.iban, u.bank_account), a),
                l = 64,
                c = 8,
                p = 2,
                d = 0,
                m = "a",
                y = "b",
                _ = "c",
                b = 2204 == n.j ? ["wechat_pay"] : null,
                h = "2022-08-01"
        },
        49924: function(e, t, n) {
            "use strict";
            var a = n(1413),
                o = n(74165),
                r = n(15861),
                i = n(89062),
                u = n(15671),
                s = n(43144),
                l = n(97326),
                c = n(60136),
                p = n(29388),
                d = n(60276),
                m = n(36617),
                y = n(97412),
                _ = n(80755),
                b = n(32583),
                h = n(71873),
                f = n(84346),
                g = n(84490),
                k = n(66751),
                v = n(45791),
                w = n(70136),
                A = n(73341),
                P = n(75336),
                E = n(97922),
                S = n(56274).Promise,
                L = function(e, t) {
                    return {
                        action: "stripe-frame-action-response",
                        payload: {
                            nonce: e,
                            faRes: t
                        }
                    }
                },
                C = function(e, t) {
                    return {
                        action: "stripe-frame-action-error",
                        payload: {
                            nonce: e,
                            faErr: t
                        }
                    }
                },
                N = [d.Yj.linkAuthentication, d.Yj.payment, d.Yj.shippingAddress, d.Yj.address, d.Yj.expressCheckout, d.Yj.payButton, d.Yj.achBankSearchResults, d.Yj.autocompleteSuggestions],
                T = function(e) {
                    function t(e, a) {
                        var s, c = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                        (0, u.Z)(this, t), (s = n.call(this)).sharedInnerData = {
                            get: function(e) {
                                return s.innerAction("SHARED_INNER_DATA_GET", {
                                    key: e
                                })
                            },
                            delete: function(e) {
                                return s.innerAction("SHARED_INNER_DATA_DELETE", {
                                    key: e
                                })
                            },
                            consume: function(e) {
                                return s.innerAction("SHARED_INNER_DATA_CONSUME", {
                                    key: e
                                })
                            },
                            set: function(e, t) {
                                return s.innerAction("SHARED_INNER_DATA_SET", {
                                    key: e,
                                    value: t
                                })
                            }
                        }, s.innerAction = function() {
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            var a = t[0],
                                o = t[1],
                                r = (0, y.To)(a);
                            return new S((function(e, t) {
                                s._requests[r] = {
                                    resolve: e,
                                    reject: t
                                }, s._sendControllerMessage({
                                    action: "stripe-inner-action",
                                    payload: {
                                        type: a,
                                        options: o || {},
                                        nonce: r
                                    }
                                })
                            }))
                        }, s.warn = function() {
                            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            s._sendControllerMessage({
                                action: "stripe-controller-warn",
                                payload: {
                                    args: t
                                }
                            })
                        }, s.controllerFor = function() {
                            return s._innerMetadata.element
                        }, s._sendParentMessage = function(e) {
                            var t = {
                                type: "parent",
                                sourceFrameId: s._frameId,
                                controllerAppFrameId: s._controllerAppFrameId,
                                message: e
                            };
                            (0, _.oi)(t)
                        }, s._sendControllerMessage = function(e) {
                            var t = {
                                type: "sibling",
                                sourceFrameId: s._frameId,
                                targetFrameId: s._controllerAppFrameId,
                                controllerAppFrameId: s._controllerAppFrameId,
                                message: e
                            };
                            s._controllerFrameLoaded ? (0, _.oi)(t) : s._queuedMessages = [].concat((0, i.Z)(s._queuedMessages), [t])
                        }, s._sendSiblingMessage = function(e, t) {
                            var n = {
                                type: "sibling",
                                sourceFrameId: s._frameId,
                                targetFrameId: t,
                                controllerAppFrameId: s._controllerAppFrameId,
                                message: e
                            };
                            (0, _.oi)(n)
                        }, s._controllerEvents = {
                            controllerUpdate: new _.LP("controller-update", (0, l.Z)(s)),
                            controllerInit: new _.o9("controller-init", (0, l.Z)(s)),
                            groupAction: new _.zS("group-action", (0, l.Z)(s)),
                            siblingAction: new _.zS("sibling-action", (0, l.Z)(s)),
                            broadcast: new _.zS("broadcast", (0, l.Z)(s)),
                            controllerRequest: new _.LP("controller-request", (0, l.Z)(s)),
                            consumerSessionUpdate: new _.zS("consumer-session-update", (0, l.Z)(s)),
                            elementsDispatch: new _.zS("elements-dispatch", (0, l.Z)(s)),
                            outsideClick: new _.o9("outside-click", (0, l.Z)(s)),
                            linkModalAbort: new _.o9("link-modal-abort", (0, l.Z)(s))
                        }, s.frameActionEvents = {
                            perform3DS2Challenge: new _.zS("PERFORM_3DS2_CHALLENGE", (0, l.Z)(s)),
                            perform3DS2Fingerprint: new _.zS("PERFORM_3DS2_FINGERPRINT", (0, l.Z)(s)),
                            performOneClickWebauthnAuthentication: new _.zS("PERFORM_ONE_CLICK_WEBAUTHN_AUTHENTICATION", (0, l.Z)(s)),
                            show3DS2Spinner: new _.zS("SHOW_3DS2_SPINNER", (0, l.Z)(s)),
                            showCardholderInfoMessage: new _.zS("SHOW_CARDHOLDERINFO_MESSAGE", (0, l.Z)(s)),
                            checkCanMakePayment: new _.zS("CHECK_CAN_MAKE_PAYMENT", (0, l.Z)(s)),
                            closeLightboxFrame: new _.zS("CLOSE_LIGHTBOX_FRAME", (0, l.Z)(s)),
                            openLightboxFrame: new _.zS("OPEN_LIGHTBOX_FRAME", (0, l.Z)(s)),
                            setFocusTarget: new _.zS("SET_FOCUS_TARGET", (0, l.Z)(s))
                        }, s._respondUsingPromise = function(e, t) {
                            new S((function(e) {
                                return t(e)
                            })).then((function(t) {
                                return L(e, t)
                            }), (function(t) {
                                return C(e, t)
                            })).then(s._sendParentMessage)
                        }, s.referrer = x(), s._controllerAppFrameId = e, s._frameId = window.name, s._innerMetadata = a, s._controllerFrameLoaded = !1, s._queuedMessages = [], s._requests = {}, s._innerAppLoaded = !1, s._controllerEvents.controllerUpdate = new _.LP("controller-update", (0, l.Z)(s), s.getUpdateReplayCount());
                        var p, d = c.reporting_app;
                        s._reporting_app = d || w.QO.DEFAULT, s._setupPostMessage(), (0, k.u)((0, l.Z)(s), (function() {
                            return s._innerAppLoaded
                        })), s._checkFrameMountedProperly();
                        try {
                            var m = (0, E.l)(s.report.bind((0, l.Z)(s)), "inner_controller_loader", e, {
                                control: 99,
                                treatment: 1
                            });
                            "treatment" === m && (s._controllerMessenger = new P.J_({
                                controllerAppFrameId: e,
                                innerFrameId: s._frameId,
                                handlers: {
                                    requestState: (p = (0, r.Z)((0, o.Z)().mark((function e(t) {
                                        return (0, o.Z)().wrap((function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                                case 0:
                                                    return s.report("debug.inner_controller.request_state", t), e.abrupt("return", {
                                                        frameId: s._frameId
                                                    });
                                                case 2:
                                                case "end":
                                                    return e.stop()
                                            }
                                        }), e)
                                    }))), function(e) {
                                        return p.apply(this, arguments)
                                    })
                                }
                            }))
                        } catch (e) {
                            window.parent !== window && s.report("debug.error.inner_controller.messenger_error", {
                                e_name: e.name,
                                e_message: e.message
                            })
                        }
                        return (0, A.IR)({
                            types: ["resource", "longtask", "long-animation-frame"],
                            reporter: function(e) {
                                s.innerAction("RECORD_ELEMENTS_PERFORMANCE_TIMELINE", {
                                    frameSrc: location.href,
                                    entries: e
                                })
                            }
                        }), s
                    }(0, c.Z)(t, e);
                    var n = (0, p.Z)(t);
                    return (0, s.Z)(t, [{
                        key: "groupUpdate",
                        value: function(e) {
                            this._sendControllerMessage({
                                action: "stripe-group-update",
                                payload: e
                            })
                        }
                    }, {
                        key: "groupAction",
                        value: function(e, t) {
                            this._sendControllerMessage({
                                action: "stripe-group-action",
                                payload: {
                                    action: e,
                                    target: t
                                }
                            })
                        }
                    }, {
                        key: "siblingAction",
                        value: function(e, t) {
                            this._sendSiblingMessage({
                                action: "stripe-sibling-action",
                                payload: {
                                    action: e,
                                    sourceFrame: this._frameId
                                }
                            }, t)
                        }
                    }, {
                        key: "broadcast",
                        value: function(e) {
                            this._sendControllerMessage({
                                action: "stripe-broadcast",
                                payload: e
                            })
                        }
                    }, {
                        key: "controllerReportData",
                        value: function(e) {
                            return (0, a.Z)((0, a.Z)({
                                frame_width: window.innerWidth
                            }, e), this._innerMetadata)
                        }
                    }, {
                        key: "report",
                        value: function(e, t) {
                            this._sendControllerMessage({
                                action: "stripe-controller-report",
                                payload: {
                                    event: e,
                                    data: this.controllerReportData(t)
                                }
                            })
                        }
                    }, {
                        key: "trackExperimentExposure",
                        value: function(e) {
                            this._sendControllerMessage({
                                action: "stripe-controller-experiment-exposure",
                                payload: {
                                    data: this.controllerReportData(e)
                                }
                            })
                        }
                    }, {
                        key: "updateLogParams",
                        value: function(e) {
                            this._sendControllerMessage({
                                action: "stripe-controller-update-log-params",
                                payload: {
                                    data: e
                                }
                            })
                        }
                    }, {
                        key: "error",
                        value: function(e) {
                            this._sendParentMessage({
                                action: "stripe-frame-error",
                                payload: {
                                    message: e
                                }
                            })
                        }
                    }, {
                        key: "reportIntegrationError",
                        value: function(e) {
                            this._sendParentMessage({
                                action: "stripe-integration-error",
                                payload: {
                                    message: e
                                }
                            })
                        }
                    }, {
                        key: "event",
                        value: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                            "load" === e && (this._innerAppLoaded = !0), this._sendParentMessage({
                                action: "stripe-frame-event",
                                payload: {
                                    event: e,
                                    data: t
                                }
                            })
                        }
                    }, {
                        key: "getUpdateReplayCount",
                        value: function() {
                            return -1 !== N.indexOf(this.controllerFor()) ? 5 : 0
                        }
                    }, {
                        key: "reportError",
                        value: function(e) {
                            this._sendControllerMessage({
                                action: "report-error",
                                payload: {
                                    app: this._reporting_app,
                                    error: (0, v.Xy)(e)
                                }
                            })
                        }
                    }, {
                        key: "_setupPostMessage",
                        value: function() {
                            var e = this;
                            window.addEventListener("message", (function(t) {
                                var n = t.data,
                                    a = t.origin,
                                    o = (0, _.$G)(n);
                                if (o && ("parent" === o.type || o.targetFrameId === e._frameId)) {
                                    var r = o.message;
                                    if ((0, m.uW)(d.jQ, a)) e._handleInnerMessage(o, a);
                                    else {
                                        var i;
                                        if (window.parent !== window && t.source !== window.parent && !(0, m.Je)(a)) return void e.report("controller.action_from_non_parent", {
                                            action: r.action,
                                            actionName: null === (i = r.payload) || void 0 === i ? void 0 : i.actionName,
                                            origin: a
                                        });
                                        e._handleOuterMessage(o, a)
                                    }
                                }
                            }))
                        }
                    }, {
                        key: "_checkFrameMountedProperly",
                        value: function() {
                            if ((0, b.Hb)(this._frameId) !== window.self) {
                                this.report("error.iframe_unreachable", {
                                    frameId: this._frameId,
                                    controllerId: this._controllerAppFrameId
                                });
                                var e = this._innerMetadata.element;
                                e && this.error("".concat(e, " Element didn't mount normally."))
                            }
                        }
                    }, {
                        key: "_defineEvents",
                        value: function(e) {
                            return (0, a.Z)((0, a.Z)({}, this._controllerEvents), e)
                        }
                    }, {
                        key: "_handleInnerMessage",
                        value: function(e, t) {
                            var n = this,
                                a = e.message;
                            switch (a.action) {
                                case "stripe-group-update":
                                case "stripe-controller-update":
                                    this._controllerEvents.controllerUpdate.emit(a.payload, t);
                                    break;
                                case "stripe-controller-init":
                                    this._controllerEvents.controllerInit.emit();
                                    break;
                                case "stripe-elements-dispatch":
                                    this._controllerEvents.elementsDispatch.emit(a.payload);
                                    break;
                                case "stripe-inner-action-complete":
                                    this._requests[a.payload.nonce] && this._requests[a.payload.nonce].resolve(a.payload.result);
                                    break;
                                case "stripe-inner-action-error":
                                    this._requests[a.payload.nonce] && this._requests[a.payload.nonce].reject(new Error(a.payload.error));
                                    break;
                                case "stripe-group-action":
                                    this._controllerEvents.groupAction.emit(a.payload);
                                    break;
                                case "stripe-sibling-action":
                                    this._controllerEvents.siblingAction.emit(a.payload);
                                    break;
                                case "stripe-broadcast":
                                    this._controllerEvents.broadcast.emit(a.payload);
                                    break;
                                case "stripe-controller-request":
                                    var i = a.payload.nonce,
                                        u = !!a.payload.skipValidation;
                                    this._controllerEvents.controllerRequest.emit(function() {
                                        var e = (0, r.Z)((0, o.Z)().mark((function e(t) {
                                            var a;
                                            return (0, o.Z)().wrap((function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        return e.next = 2, t;
                                                    case 2:
                                                        a = e.sent, n._sendControllerMessage({
                                                            action: "stripe-controller-request-complete",
                                                            payload: {
                                                                result: a,
                                                                nonce: i
                                                            }
                                                        });
                                                    case 4:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }), e)
                                        })));
                                        return function(t) {
                                            return e.apply(this, arguments)
                                        }
                                    }(), {
                                        skipValidation: u
                                    });
                                    break;
                                default:
                                    this._handleOuterMessage(e, t)
                            }
                        }
                    }, {
                        key: "_handleOuterMessage",
                        value: function(e, t) {
                            var n = e.message;
                            switch (n.action) {
                                case "stripe-outer-controller-load":
                                    e.controllerAppFrameId === this._controllerAppFrameId && (this._controllerFrameLoaded = !0, this._queuedMessages.forEach(_.oi), this._queuedMessages = []);
                                    break;
                                case "stripe-frame-action":
                                    this._handleFrameAction(n.payload.nonce, n.payload.faReq);
                                    break;
                                case "stripe-outside-click":
                                    this._emit("outside-click");
                                    break;
                                case "stripe-link-modal-abort":
                                    this._emit("link-modal-abort");
                                    break;
                                default:
                                    this._handleAppMessage(e, t)
                            }
                        }
                    }, {
                        key: "_handleFrameAction",
                        value: function(e, t) {
                            var n = this;
                            switch (t.tag) {
                                case "PERFORM_3DS2_CHALLENGE":
                                    return this._respondUsingPromise(e, (function(e) {
                                        n.frameActionEvents.perform3DS2Challenge.emit({
                                            payload: t.value,
                                            complete: e
                                        })
                                    }));
                                case "PERFORM_3DS2_FINGERPRINT":
                                    return this._respondUsingPromise(e, (function(e) {
                                        n.frameActionEvents.perform3DS2Fingerprint.emit({
                                            payload: t.value,
                                            complete: e
                                        })
                                    }));
                                case "PERFORM_ONE_CLICK_WEBAUTHN_AUTHENTICATION":
                                    return this._respondUsingPromise(e, (function(e) {
                                        n.frameActionEvents.performOneClickWebauthnAuthentication.emit({
                                            payload: t.value,
                                            complete: e
                                        })
                                    }));
                                case "SHOW_3DS2_SPINNER":
                                    return this._respondUsingPromise(e, (function(e) {
                                        n.frameActionEvents.show3DS2Spinner.emit({
                                            payload: t.value,
                                            complete: e
                                        })
                                    }));
                                case "SHOW_CARDHOLDERINFO_MESSAGE":
                                    return this._respondUsingPromise(e, (function(e) {
                                        n.frameActionEvents.showCardholderInfoMessage.emit({
                                            payload: t.value,
                                            complete: e
                                        })
                                    }));
                                case "CHECK_CAN_MAKE_PAYMENT":
                                    return this._respondUsingPromise(e, (function(e) {
                                        n.frameActionEvents.checkCanMakePayment.emit({
                                            payload: t.value,
                                            complete: e
                                        })
                                    }));
                                case "CLOSE_LIGHTBOX_FRAME":
                                    return this._respondUsingPromise(e, (function(e) {
                                        n.frameActionEvents.closeLightboxFrame.emit({
                                            payload: t.value,
                                            complete: e
                                        })
                                    }));
                                case "OPEN_LIGHTBOX_FRAME":
                                    return this._respondUsingPromise(e, (function(e) {
                                        n.frameActionEvents.openLightboxFrame.emit({
                                            payload: t.value,
                                            complete: e
                                        })
                                    }));
                                case "SET_FOCUS_TARGET":
                                    return this._respondUsingPromise(e, (function(e) {
                                        n.frameActionEvents.setFocusTarget.emit({
                                            payload: t.value,
                                            complete: e
                                        })
                                    }));
                                default:
                                    return (0, h.Rz)(t)
                            }
                        }
                    }, {
                        key: "_handleAppMessage",
                        value: function() {}
                    }]), t
                }(f.Z);
            t.Z = /^(2204|2760|6364|8889)$/.test(n.j) ? null : T;
            var x = function() {
                var e = (0, m.Ds)(g.hI);
                if (e && e.host !== window.location.host) return g.hI;
                try {
                    var t = window.location.hash.substring(1).split("?")[0],
                        n = (0, m.vB)(t).referrer;
                    if ("string" == typeof n) return n
                } catch (e) {
                    return ""
                }
                return ""
            }
        },
        84346: function(e, t, n) {
            "use strict";
            if (!/^(2204|2760|6364|8889)$/.test(n.j)) var a = n(43144);
            if (!/^(2204|2760|6364|8889)$/.test(n.j)) var o = n(15671);
            var r = /^(2204|2760|6364|8889)$/.test(n.j) ? null : (0, a.Z)((function e() {
                var t = this;
                (0, o.Z)(this, e), this._emit = function(e) {
                    for (var n = arguments.length, a = new Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) a[o - 1] = arguments[o];
                    var r = t._callbacks[e] || [];
                    return r.forEach((function(e) {
                        e.apply(void 0, a)
                    })), t
                }, this._on = function(e, n) {
                    return t._callbacks[e] = t._callbacks[e] || [], t._callbacks[e].push(n), t
                }, this._off = function(e, n) {
                    if (n) {
                        for (var a = t._callbacks[e], o = 0; o < a.length; o++)
                            if (a[o] === n) {
                                a.splice(o, 1);
                                break
                            }
                    } else delete t._callbacks[e];
                    return t
                }, this._callbacks = {}
            }));
            t.Z = /^(2204|2760|6364|8889)$/.test(n.j) ? null : r
        },
        85340: function(e, t, n) {
            "use strict";
            n.d(t, {
                Y: function() {
                    return a
                },
                j: function() {
                    return o
                }
            });
            var a = [{
                    code: "amount_too_small"
                }, {
                    code: "amount_too_large"
                }, {
                    message: /Amount must be at least/
                }, {
                    message: /Amount must be at most/
                }, {
                    message: /The currency provided .* is invalid/
                }, {
                    message: "Link is not supported in your country."
                }, {
                    message: /The payment method type .* is not supported when creating a .*/
                }, {
                    message: /You cannot provide the .* parameter when using a SetupIntent with a/
                }, {
                    param: "deferred_intent.payment_method_types",
                    message: /Invalid amount/
                }, {
                    param: "deferred_intent.payment_method_types",
                    message: /The following payment method types .* can only be used with .* capture_method=automatic/
                }, {
                    code: "payment_method_unactivated"
                }, {
                    code: "charge_exceeds_transaction_limit"
                }, {
                    message: /The value provided for setup_future_usage .* is not supported for/
                }],
                o = [{
                    message: /^Invalid currency/
                }, {
                    param: "amount",
                    message: /^Invalid integer/
                }, {
                    message: /^No such on_behalf_of/
                }]
        },
        84490: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ay: function() {
                    return s
                },
                Fd: function() {
                    return i
                },
                Lb: function() {
                    return c
                },
                OJ: function() {
                    return l
                },
                Z_: function() {
                    return u
                },
                b$: function() {
                    return p
                },
                hE: function() {
                    return d
                },
                hI: function() {
                    return o
                }
            });
            var a = n(36617),
                o = document.referrer,
                r = (0, a.Ds)(o),
                i = r ? r.origin : "",
                u = r ? r.host : "",
                s = /^(2204|9487)$/.test(n.j) ? "https://api.stripe.com/edge-internal/" : null,
                l = 3179 == n.j ? "https://hooks.stripe.com/" : null,
                c = "‎",
                p = new RegExp("^(".concat(c, "?\\d{2}\\D{3})").concat(c, "?(\\d{1,4})?")),
                d = {
                    address: "title.address",
                    card: "title.card",
                    cardNumber: "title.cardNumber",
                    cardExpiry: "title.cardExpiry",
                    cardCvc: "title.cardCvc",
                    postalCode: "title.postalCode",
                    iban: "title.iban",
                    idealBank: "title.idealBank",
                    p24Bank: "title.p24Bank",
                    paymentRequestButton: "title.paymentRequestButton",
                    auBankAccount: "title.auBankAccount",
                    fpxBank: "title.fpxBank",
                    idealBankSecondary: "title.idealBankSecondary",
                    p24BankSecondary: "title.p24BankSecondary",
                    auBankAccountNumber: "title.auBankAccountNumber",
                    auBsb: "title.auBsb",
                    fpxBankSecondary: "title.fpxBankSecondary",
                    epsBank: "title.epsBank",
                    epsBankSecondary: "title.epsBankSecondary",
                    afterpayClearpayMessage: "title.afterpayClearpayMessage",
                    afterpayClearpayMessageModal: "title.afterpayClearpayMessageModal",
                    linkAuthentication: "title.authentication",
                    payment: "title.payment",
                    autocompleteSuggestions: "title.autocompleteSuggestions",
                    achBankSearchResults: "title.achBankSearchResults",
                    linkInfoModal: "title.linkInfoModal",
                    expressCheckout: "title.expressCheckout",
                    payButton: "title.payButton",
                    paymentMethodMessaging: "title.paymentMethodMessaging",
                    currencySelector: "title.currencySelector"
                }
        },
        66751: function(e, t, n) {
            "use strict";
            n.d(t, {
                u: function() {
                    return o
                }
            });
            var a = n(77007),
                o = function(e, t) {
                    window.onerror = function(n, o, r, i, u) {
                        var s = (0, a.n)({
                            name: null == u ? void 0 : u.name,
                            message: n,
                            fileName: o,
                            lineNumber: r,
                            columnNumber: i,
                            stack: null == u ? void 0 : u.stack,
                            iframe: !0,
                            element: e.controllerFor(),
                            elementHasLoaded: t()
                        });
                        return s && (e.report(s.eventName, s.eventData), e.reportError(u)), !1
                    }
                }
        },
        65835: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    Q: function() {
                        return u
                    }
                }), !/^(2204|2760|6364|8889)$/.test(n.j)) var a = n(62910);
            var o = n(12024),
                r = {},
                i = function(e, t) {
                    var n = (0, o.VO)(t).reduce((function(e, t) {
                            return e + t
                        }), 0),
                        r = Math.floor(parseInt((0, a.Z)(e).slice(0, 4), 16) / 65536 * n),
                        i = 0,
                        u = Object.keys(t),
                        s = (0, o.sE)(u, (function(e) {
                            return i += t[e], r < i
                        }));
                    return s ? [!0, s] : [!1, "control"]
                },
                u = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0,
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
                            treatment: 5,
                            control: 5
                        },
                        a = void 0 === t ? Math.random().toString() : t,
                        o = void 0 === t ? e : "".concat(e, ".").concat(t),
                        u = "".concat(e, ".").concat(a);
                    return r[o] || (r[o] = i(u, n)), r[o]
                }
        },
        97922: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    l: function() {
                        return s
                    }
                }), !/^(2204|2760|6364|8889)$/.test(n.j)) var a = n(1413);
            if (!/^(2204|2760|6364|8889)$/.test(n.j)) var o = n(93324);
            var r = n(65835),
                i = {},
                u = function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
                        u = arguments.length > 3 ? arguments[3] : void 0,
                        s = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {},
                        l = (0, r.Q)(t, n, u),
                        c = (0, o.Z)(l, 2),
                        p = c[0],
                        d = c[1];
                    return i["".concat(t).concat(n)] || (e("light_experiment_exposure", (0, a.Z)({
                        qualified: p,
                        variant: d,
                        experiment_name: t
                    }, s)), i["".concat(t).concat(n)] = !0), d
                },
                s = function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
                        a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {
                            treatment: 5,
                            control: 5
                        },
                        o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {};
                    return u(e, t, n, a, o)
                }
        },
        62910: function(e, t, n) {
            "use strict";

            function a(e) {
                var t, n, a, o, r, i, u, s, l, c = e,
                    p = function(e, t) {
                        return e << t | e >>> 32 - t
                    },
                    d = function(e) {
                        var t, n = "";
                        for (t = 7; t >= 0; t--) n += (e >>> 4 * t & 15).toString(16);
                        return n
                    },
                    m = new Array(80),
                    y = 1732584193,
                    _ = 4023233417,
                    b = 2562383102,
                    h = 271733878,
                    f = 3285377520,
                    g = (c = function(e) {
                        var t = e;
                        t = t.replace(/\r\n/g, "\n");
                        for (var n = "", a = 0; a < t.length; a++) {
                            var o = t.charCodeAt(a);
                            o < 128 ? n += String.fromCharCode(o) : o > 127 && o < 2048 ? (n += String.fromCharCode(o >> 6 | 192), n += String.fromCharCode(63 & o | 128)) : (n += String.fromCharCode(o >> 12 | 224), n += String.fromCharCode(o >> 6 & 63 | 128), n += String.fromCharCode(63 & o | 128))
                        }
                        return n
                    }(c)).length,
                    k = [];
                for (n = 0; n < g - 3; n += 4) a = c.charCodeAt(n) << 24 | c.charCodeAt(n + 1) << 16 | c.charCodeAt(n + 2) << 8 | c.charCodeAt(n + 3), k.push(a);
                switch (g % 4) {
                    case 0:
                        n = 2147483648;
                        break;
                    case 1:
                        n = c.charCodeAt(g - 1) << 24 | 8388608;
                        break;
                    case 2:
                        n = c.charCodeAt(g - 2) << 24 | c.charCodeAt(g - 1) << 16 | 32768;
                        break;
                    case 3:
                        n = c.charCodeAt(g - 3) << 24 | c.charCodeAt(g - 2) << 16 | c.charCodeAt(g - 1) << 8 | 128
                }
                for (k.push(n); k.length % 16 != 14;) k.push(0);
                for (k.push(g >>> 29), k.push(g << 3 & 4294967295), t = 0; t < k.length; t += 16) {
                    for (n = 0; n < 16; n++) m[n] = k[t + n];
                    for (n = 16; n <= 79; n++) m[n] = p(m[n - 3] ^ m[n - 8] ^ m[n - 14] ^ m[n - 16], 1);
                    for (o = y, r = _, i = b, u = h, s = f, n = 0; n <= 19; n++) l = p(o, 5) + (r & i | ~r & u) + s + m[n] + 1518500249 & 4294967295, s = u, u = i, i = p(r, 30), r = o, o = l;
                    for (n = 20; n <= 39; n++) l = p(o, 5) + (r ^ i ^ u) + s + m[n] + 1859775393 & 4294967295, s = u, u = i, i = p(r, 30), r = o, o = l;
                    for (n = 40; n <= 59; n++) l = p(o, 5) + (r & i | r & u | i & u) + s + m[n] + 2400959708 & 4294967295, s = u, u = i, i = p(r, 30), r = o, o = l;
                    for (n = 60; n <= 79; n++) l = p(o, 5) + (r ^ i ^ u) + s + m[n] + 3395469782 & 4294967295, s = u, u = i, i = p(r, 30), r = o, o = l;
                    y = y + o & 4294967295, _ = _ + r & 4294967295, b = b + i & 4294967295, h = h + u & 4294967295, f = f + s & 4294967295
                }
                return (d(y) + d(_) + d(b) + d(h) + d(f)).toLowerCase()
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        53568: function(e, t, n) {
            "use strict";
            n.d(t, {
                p: function() {
                    return a
                }
            });
            var a = "stripe-origin-frame"
        },
        40860: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    Q: function() {
                        return i
                    }
                }), !/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j)) var a = n(64007);
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j)) var o = n(54469);
            var r = n(43534),
                i = function(e) {
                    var t = e.fingerprintedPath,
                        n = e.name,
                        i = e.onLoad,
                        u = e.queryStringOptions,
                        s = e.referrerPolicy || "no-referrer",
                        l = document.createElement("iframe");
                    i && l.addEventListener("load", (function() {
                        i(l)
                    })), l.setAttribute("frameborder", "0"), l.setAttribute("allowTransparency", "true"), l.setAttribute("scrolling", "no"), l.setAttribute("name", n), l.setAttribute("referrerpolicy", s), e.visible || (l.setAttribute("aria-hidden", "true"), l.setAttribute("tabIndex", "-1"));
                    var c = e.frameAttributes;
                    c && Object.keys(c).forEach((function(e) {
                        l.setAttribute(e, c[e])
                    }));
                    var p = (0, a.N)(e.DANGEROUS_BREAKS_ORIGIN_CHECKING_baseUrl, t);
                    if (u) {
                        var d = (0, o.q)(u);
                        l.src = "".concat(p, "#").concat(d)
                    } else l.src = p;
                    return e.visible || (0, r.SV)(l), l
                }
        },
        91111: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    s: function() {
                        return l
                    }
                }), !/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j)) var a = n(53568);
            var o = n(56274).Promise,
                r = window.location.hash.indexOf("debugMode=true") >= 0,
                i = function() {
                    var e = window.parent.frames;
                    try {
                        return e[a.p] || null
                    } catch (e) {
                        return null
                    }
                },
                u = function() {
                    return new o((function(e) {
                        var t = setInterval((function() {
                            var n = i();
                            if (n) {
                                var a = !1;
                                try {
                                    a = "function" == typeof n.isValidStripeFrameOrigin
                                } catch (e) {
                                    a = !1
                                }
                                a && (r && console.log("[originFrameReady] ready"), clearInterval(t), e())
                            }
                        }), 1)
                    }))
                },
                s = null,
                l = function(e, t) {
                    s = s || u();
                    var n = new o((function(e) {
                        setTimeout((function() {
                            return e(!0)
                        }), t)
                    }));
                    return o.race([s, n]).then((function(t) {
                        if (t) return !1;
                        var n = i(),
                            a = null == n ? void 0 : n.isValidStripeFrameOrigin;
                        if (!a) throw new Error("Origin frame reported ready, but does not exist?!");
                        return a(e)
                    }))
                }
        },
        29641: function(e, t, n) {
            "use strict";
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j)) var a = n(1413);
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j)) var o = n(15671);
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j)) var r = n(43144);
            var i = n(40860);
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j)) var u = n(18935);
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j)) var s = n(76466);
            var l = n(43534),
                c = n(56274).Promise,
                p = /^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j) ? null : function() {
                    function e(t) {
                        var n = this;
                        (0, o.Z)(this, e), this.createListener = function() {
                            window.addEventListener("message", n.receiveMessageFromChild)
                        }, this.parsePostMessage = function(e) {
                            var t, a;
                            if (e.source !== (null === (t = n.frame) || void 0 === t ? void 0 : t.contentWindow) || "string" != typeof e.data) return null;
                            try {
                                a = JSON.parse(e.data)
                            } catch (e) {
                                return null
                            }
                            return a.channel !== n.channel ? null : a
                        }, this.receiveMessageFromChild = function(e) {
                            var t = n.parsePostMessage(e);
                            if (t) {
                                if (!("initMessage" in t)) {
                                    var a = n.getClientHandler(t);
                                    if (a) {
                                        var o = function(e) {
                                            var a = n.frame,
                                                o = n.frameOrigin;
                                            if (!a) throw new Error("Cannot communicate with frame before calling mount().");
                                            var r = a.contentWindow;
                                            if (!r || !o) throw new Error("frame window is not ready");
                                            var i = {
                                                type: t.type,
                                                id: t.id,
                                                channel: t.channel,
                                                body: e
                                            };
                                            r.postMessage(JSON.stringify(i), o)
                                        };
                                        n.initialized ? a(t.body, o) : new c((function(e) {
                                            n.messageQueue.push((function() {
                                                return e({
                                                    body: t.body,
                                                    sendReplyToChild: o
                                                })
                                            }))
                                        })).then((function() {
                                            a(t.body, o)
                                        }))
                                    }
                                }
                                if ("initMessage" in t) {
                                    for (n.frameOrigin = e.origin; n.messageQueue.length > 0;) {
                                        var r = n.messageQueue.shift();
                                        r && r()
                                    }
                                    n.initialized = !0, n.frame && (n.frame.dataset.initialized = "true")
                                } else {
                                    var i = n.resolver.getResolverAndDelete(t);
                                    i && i(t.body)
                                }
                            }
                        }, this.channel = t.channel, this.fingerprintedPath = t.fingerprintedPath, this.frame = null, this.frameOrigin = null, this.frameQueryParams = t.frameQueryParams, this.frameAttributes = t.frameAttributes, this.initialized = !1, this.messageQueue = [], this.resolver = new u.Z, this.on = "on" in t ? t.on : {}, this.createListener()
                    }
                    return (0, r.Z)(e, [{
                        key: "isLoaded",
                        value: function() {
                            return this.initialized
                        }
                    }, {
                        key: "mount",
                        value: function(e, t) {
                            if (!this.frame) {
                                if (!this.fingerprintedPath) throw new Error("Passed in an invalid path for frame client with channel: ".concat(this.channel));
                                var n = (0, i.Q)({
                                    fingerprintedPath: this.fingerprintedPath,
                                    name: this.channel,
                                    queryStringOptions: (0, a.Z)((0, a.Z)({}, this.frameQueryParams), {}, {
                                        parentOrigin: window.location.origin
                                    }),
                                    referrerPolicy: "no-referrer",
                                    frameAttributes: this.frameAttributes,
                                    visible: !(null == t || !t.visible),
                                    DANGEROUS_BREAKS_ORIGIN_CHECKING_baseUrl: null == t ? void 0 : t.DANGEROUS_BREAKS_ORIGIN_CHECKING_baseUrl
                                });
                                null != t && t.inlineCss && (0, l.yq)(n, t.inlineCss), e.appendChild(n), this.frame = n
                            }
                        }
                    }, {
                        key: "isMounted",
                        value: function() {
                            return document.contains(this.frame)
                        }
                    }, {
                        key: "sendMessageToChild",
                        value: function(e, t) {
                            var n = this;
                            return this.initialized ? this.postMessageToChild(e, t) : new c((function(a) {
                                n.messageQueue.push((function() {
                                    return a({
                                        type: e,
                                        body: t
                                    })
                                }))
                            })).then((function() {
                                return n.postMessageToChild(e, t)
                            }))
                        }
                    }, {
                        key: "postMessageToChild",
                        value: function(e, t) {
                            var n = this,
                                a = this.frame,
                                o = this.frameOrigin;
                            if (!a) throw new Error("Cannot communicate with frame before calling mount().");
                            var r = a.contentWindow;
                            if (!r || !o) throw new Error("frame window is not ready");
                            var i = this.resolver.getNextRequestId(),
                                u = {
                                    channel: this.channel,
                                    type: e,
                                    id: i,
                                    body: t
                                };
                            return new c((function(t) {
                                n.resolver.setResolver(e, i, t), r.postMessage(JSON.stringify(u), o)
                            }))
                        }
                    }, {
                        key: "getClientHandler",
                        value: function(e) {
                            var t = this.on[e.type];
                            return t ? function(e, n) {
                                var a = t(e);
                                (0, s.t)(a) ? a.then((function(e) {
                                    n(e)
                                })): void 0 !== a && n(a)
                            } : null
                        }
                    }]), e
                }();
            t.Z = /^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j) ? null : p
        },
        11190: function(e, t, n) {
            "use strict";
            n(91111), n(56274).Promise
        },
        43248: function(e, t, n) {
            "use strict";
            n.d(t, {
                K: function() {
                    return a.Z
                }
            });
            var a = n(29641);
            n(11190)
        },
        18935: function(e, t, n) {
            "use strict";
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j)) var a = n(15671);
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j)) var o = n(43144);
            var r = /^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j) ? null : function() {
                function e() {
                    (0, a.Z)(this, e), this.lastId = 0, this.resolverMap = {}
                }
                return (0, o.Z)(e, [{
                    key: "getNextRequestId",
                    value: function() {
                        var e = this.lastId + 1;
                        return this.lastId = e, e
                    }
                }, {
                    key: "setResolver",
                    value: function(e, t, n) {
                        this.resolverMap[e] = this.resolverMap[e] || {};
                        var a = this.resolverMap[e];
                        a && (a[t] = n)
                    }
                }, {
                    key: "getResolverAndDelete",
                    value: function(e) {
                        var t = e.type,
                            n = this.resolverMap[t];
                        if (n && n[e.id]) {
                            var a = n[e.id];
                            return delete n[e.id], a
                        }
                        return null
                    }
                }]), e
            }();
            t.Z = /^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|7297|9171)$/.test(n.j) ? null : r
        },
        31522: function(e, t, n) {
            "use strict";
            n.d(t, {
                y: function() {
                    return y
                }
            });
            var a = n(1413),
                o = n(93324),
                r = n(15671),
                i = n(43144),
                u = n(30307),
                s = n(12024),
                l = n(81592),
                c = n(24245),
                p = function() {
                    function e() {
                        (0, r.Z)(this, e), this.ofType = (0, c.HP)((function(e) {
                            return new d(e)
                        })), this.dataDrivenOfType = (0, c.HP)((function(e) {
                            return new m(e)
                        }))
                    }
                    return (0, i.Z)(e, [{
                        key: "supportsType",
                        value: function(e) {
                            return (0, l.K)().hasOwnProperty(e)
                        }
                    }, {
                        key: "supportsDataDrivenType",
                        value: function(e) {
                            return this.allDataDriven.hasOwnProperty(e)
                        }
                    }, {
                        key: "clientSpecsByType",
                        get: function() {
                            return (0, s.Rb)((0, l.K)(), "paymentMethodSpec")
                        }
                    }, {
                        key: "supportedByCheckout",
                        get: function() {
                            return (0, s.iO)((0, l.K)(), (function() {
                                return !0
                            }))
                        }
                    }, {
                        key: "typesSupportingPaymentElement",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "paymentElementUiConfiguration"),
                                t = (0, s.Nn)(e, void 0);
                            return (0, s.Ke)(t)
                        }
                    }, {
                        key: "paymentElementPaymentMethodLabel",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "paymentElementUiConfiguration.messageKeys.name");
                            return (0, s.Nn)(e, void 0)
                        }
                    }, {
                        key: "typesWithLuxeServerSpec",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "paymentMethodSpec.hasLuxeServerSpec"),
                                t = (0, s.ve)(e, !0);
                            return (0, s.Ke)(t)
                        }
                    }, {
                        key: "submittableToHostedUi",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "hostedPaymentUiConfiguration.features.isSubmittable");
                            return (0, s.ve)(e, !0)
                        }
                    }, {
                        key: "withIconSvgs",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "hostedPaymentUiConfiguration.iconSvgs");
                            return (0, s.iO)((0, s.Nn)(e, void 0), (function() {
                                return !0
                            }))
                        }
                    }, {
                        key: "noTrialOrSetupModeHeaderMessages",
                        get: function() {
                            return (0, s.Rb)((0, l.K)(), "hostedPaymentUiConfiguration.messageKeys.noTrialOrSetupModeHeader")
                        }
                    }, {
                        key: "withDefaultReducer",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "hostedPaymentUiConfiguration.features.hasCustomReducers"),
                                t = (0, s.Nn)(e, !0);
                            return (0, s.iO)(t, (function(e, t) {
                                return (0, l.K)()[t].paymentMethodSpec
                            }))
                        }
                    }, {
                        key: "hasDefaultReducerPaymentMethod",
                        value: function(e) {
                            return this.withDefaultReducer.hasOwnProperty(e)
                        }
                    }, {
                        key: "allDataDriven",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "hostedPaymentUiConfiguration.dataDrivenConfig"),
                                t = (0, s.Nn)(e, void 0);
                            return (0, s.iO)(t, (function() {
                                return !0
                            }))
                        }
                    }, {
                        key: "_existingDemosByType",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "paymentElementUiConfiguration.combinedDemos");
                            return (0, s.Nn)(e, void 0)
                        }
                    }, {
                        key: "allCombinedDemoSettings",
                        value: function(e) {
                            var t = {};
                            return (0, s.qh)(this._existingDemosByType).forEach((function(n) {
                                var a, r, i = (0, o.Z)(n, 2),
                                    s = i[0],
                                    c = i[1],
                                    p = null === (a = e[s]) || void 0 === a ? void 0 : a.keys;
                                if (!p) throw new Error("Keys for merchants are not yet defined for ".concat(s));
                                var d = null === (r = (0, l.K)()[s].jsApiConfig) || void 0 === r ? void 0 : r.betaFlags;
                                c.forEach((function(e) {
                                    t[e.id] = {
                                        id: e.id,
                                        name: e.name,
                                        keys: {
                                            publicKey: p.publishable,
                                            secretKey: p.secret,
                                            beta: d || null,
                                            apiVersion: null,
                                            header: null
                                        },
                                        initialMode: u.N[e.initialMode]
                                    }
                                }))
                            })), t
                        }
                    }, {
                        key: "allDemoProps",
                        get: function() {
                            return (0, s.qh)(this._existingDemosByType).flatMap((function(e) {
                                var t = (0, o.Z)(e, 2),
                                    n = t[0];
                                return t[1].map((function(e) {
                                    return (0, a.Z)((0, a.Z)({}, e), {}, {
                                        paymentMethodType: (0, l.K)()[n].paymentMethodSpec.type
                                    })
                                }))
                            }))
                        }
                    }, {
                        key: "typesSupportingFinalizedInvoice",
                        get: function() {
                            return (0, s.Ke)((0, l.K)())
                        }
                    }, {
                        key: "bySortPrioritizedLanguage",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "hostedPaymentUiConfiguration.sortOrder.prioritizedLanguages"),
                                t = {};
                            return (0, s.qh)(e).forEach((function(e) {
                                var n = (0, o.Z)(e, 2),
                                    a = n[0];
                                n[1].forEach((function(e) {
                                    t[e] = (t[e] || []).concat([a])
                                }))
                            })), t
                        }
                    }, {
                        key: "bySortPrioritizedCountry",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "hostedPaymentUiConfiguration.sortOrder.prioritizedCountries"),
                                t = {};
                            return (0, s.qh)(e).forEach((function(e) {
                                var n = (0, o.Z)(e, 2),
                                    a = n[0];
                                n[1].forEach((function(e) {
                                    t[e] = (t[e] || []).concat([a])
                                }))
                            })), t
                        }
                    }, {
                        key: "typesByType",
                        get: function() {
                            return (0, s.Rb)((0, l.K)(), "paymentMethodSpec.type")
                        }
                    }, {
                        key: "allBetaFlags",
                        get: function() {
                            var e = (0, s.Rb)((0, l.K)(), "jsApiConfig.betaFlags"),
                                t = (0, s.Nn)(e, void 0),
                                n = {};
                            return (0, s.VO)(t).forEach((function(e) {
                                e.forEach((function(e) {
                                    n[e] = e
                                }))
                            })), n
                        }
                    }]), e
                }(),
                d = function() {
                    function e(t) {
                        (0, r.Z)(this, e), this._paymentMethodType = t
                    }
                    return (0, i.Z)(e, [{
                        key: "spec",
                        get: function() {
                            return this._config.paymentMethodSpec
                        }
                    }, {
                        key: "iconConfig",
                        get: function() {
                            var e = "iconSize" in this._hostedPaymentUiConfiguration ? {
                                iconSize: this._hostedPaymentUiConfiguration.iconSize
                            } : null;
                            return (0, a.Z)({
                                iconName: this.spec.type
                            }, e)
                        }
                    }, {
                        key: "iconSvgLight",
                        get: function() {
                            return this._hostedPaymentUiConfiguration.iconSvgs.lightThemeSvg
                        }
                    }, {
                        key: "iconSvgDark",
                        get: function() {
                            return "darkThemeSvg" in this._hostedPaymentUiConfiguration.iconSvgs ? this._hostedPaymentUiConfiguration.iconSvgs.darkThemeSvg : null
                        }
                    }, {
                        key: "headlineMessageKey",
                        get: function() {
                            return this._hostedPaymentUiConfiguration.messageKeys.headline
                        }
                    }, {
                        key: "paymentMethodNameLabelKey",
                        get: function() {
                            return this._hostedPaymentUiConfiguration.messageKeys.name
                        }
                    }, {
                        key: "messageKeys",
                        get: function() {
                            return this._hostedPaymentUiConfiguration.messageKeys
                        }
                    }, {
                        key: "excludeFromOverflowIconRotation",
                        get: function() {
                            return this._hostedPaymentUiConfiguration.features.excludeFromOverflowIconRotation
                        }
                    }, {
                        key: "_config",
                        get: function() {
                            return (0, l.K)()[this._paymentMethodType]
                        }
                    }, {
                        key: "_hostedPaymentUiConfiguration",
                        get: function() {
                            return this._config.hostedPaymentUiConfiguration
                        }
                    }]), e
                }(),
                m = function() {
                    function e(t) {
                        (0, r.Z)(this, e), this._paymentMethodType = t
                    }
                    return (0, i.Z)(e, [{
                        key: "paymentMethodCategory",
                        get: function() {
                            return this._config.hostedPaymentUiConfiguration.dataDrivenConfig.paymentMethodCategory
                        }
                    }, {
                        key: "submitPaymentOptions",
                        value: function(e) {
                            var t = this._config.paymentMethodSpec;
                            return {
                                submitMode: "payment_method_data",
                                paymentType: t.type,
                                data: {
                                    type: t.type,
                                    paymentMethodData: {
                                        billing_details: e
                                    }
                                }
                            }
                        }
                    }, {
                        key: "_config",
                        get: function() {
                            return (0, l.K)()[this._paymentMethodType]
                        }
                    }]), e
                }(),
                y = new p
        },
        49006: function(e, t, n) {
            "use strict";
            n.d(t, {
                h: function() {
                    return a
                }
            });
            var a = function(e) {
                return e
            }
        },
        68485: function(e, t, n) {
            "use strict";
            n.d(t, {
                C: function() {
                    return a
                }
            });
            var a = (0, n(49006).h)({
                paymentMethodSpec: {
                    type: "billie",
                    polling: !1,
                    redirect: !0,
                    paymentScreens: [{
                        type: "billie",
                        step: "initial"
                    }],
                    alwaysCollectFullBillingAddress: !1,
                    alwaysCollectCountry: !1,
                    alwaysCollectTaxInformation: !1,
                    allowedCountries: ["DE", "FR", "NL"],
                    defaultCountry: "DE",
                    taxCountry: null,
                    supportsOffSession: !1,
                    fieldLabels: null,
                    hasLuxeServerSpec: !0
                },
                hostedPaymentUiConfiguration: {
                    messageKeys: {
                        name: "payment.selector.label.billie",
                        headline: "payment.headline.billie",
                        noTrialOrSetupModeHeader: "payment.headline.billie"
                    },
                    iconSvgs: {
                        lightThemeSvg: "https://js.stripe.com/v3/fingerprinted/img/payment-methods/icon-pm-billie-ce797ab9d9419d7f283c2edbabc4a0b9.svg",
                        darkThemeSvg: "https://js.stripe.com/v3/fingerprinted/img/payment-methods/icon-pm-billie_dark-96f0fe8684ec4bb7175c217a8447cad9.svg"
                    },
                    features: {
                        excludeFromOverflowIconRotation: !1,
                        isSubmittable: !0,
                        hasSpecificNotice: !1,
                        hasCustomReducers: !1,
                        supportsSetupMode: !1,
                        supportsSubscription: !1,
                        isMissingE2ETests: !0
                    },
                    dataDrivenConfig: {
                        paymentMethodCategory: "simple_redirect"
                    },
                    sortOrder: {
                        prioritizedCountries: ["de", "fr", "nl"],
                        prioritizedLanguages: ["de-de", "fr-fr", "nl-nl"]
                    },
                    iconSize: "md"
                },
                paymentElementUiConfiguration: {
                    messageKeys: {
                        name: "upe.methods.billie"
                    },
                    combinedDemos: [{
                        id: "paymentElementBillie",
                        name: "Payment Element + Billie",
                        amount: 100,
                        currency: "eur",
                        supportedModes: ["PI"],
                        initialMode: "PI",
                        type: "redirect"
                    }]
                },
                jsApiConfig: {
                    betaFlags: ["billie_pm_beta_1"]
                }
            })
        },
        39834: function(e, t, n) {
            "use strict";
            n.d(t, {
                C: function() {
                    return a
                }
            });
            var a = (0, n(49006).h)({
                paymentMethodSpec: {
                    type: "capchase_pay",
                    polling: !1,
                    redirect: !0,
                    paymentScreens: [{
                        type: "capchase_pay",
                        step: "initial"
                    }],
                    alwaysCollectFullBillingAddress: !1,
                    alwaysCollectCountry: !1,
                    alwaysCollectTaxInformation: !1,
                    allowedCountries: ["US", "GB", "ES", "SE", "BE", "NL", "CA", "FI", "DK"],
                    defaultCountry: "US",
                    taxCountry: null,
                    supportsOffSession: !1,
                    fieldLabels: null,
                    hasLuxeServerSpec: !0
                },
                hostedPaymentUiConfiguration: {
                    messageKeys: {
                        name: "payment.selector.label.capchase_pay",
                        headline: "payment.headline.capchase_pay",
                        noTrialOrSetupModeHeader: "payment.headline.capchase_pay"
                    },
                    iconSvgs: {
                        lightThemeSvg: "https://js.stripe.com/v3/fingerprinted/img/payment-methods/icon-pm-capchase_pay-da19ef6ea868e9f9504a258d756a2bf1.svg"
                    },
                    features: {
                        excludeFromOverflowIconRotation: !1,
                        isSubmittable: !0,
                        hasSpecificNotice: !1,
                        hasCustomReducers: !1,
                        supportsSetupMode: !1,
                        supportsSubscription: !1,
                        isMissingE2ETests: !1
                    },
                    dataDrivenConfig: {
                        paymentMethodCategory: "simple_redirect"
                    },
                    sortOrder: {
                        prioritizedCountries: ["us", "gb", "nl", "ca"],
                        prioritizedLanguages: ["en-us", "en-gb", "es-es", "sv-se", "nl-nl", "fr-ca", "fi-fi", "da-dk"]
                    },
                    iconSize: "md"
                },
                paymentElementUiConfiguration: {
                    messageKeys: {
                        name: "upe.methods.capchase_pay"
                    },
                    combinedDemos: [{
                        id: "paymentElementCapchasePay",
                        name: "Payment Element + Capchase Pay",
                        amount: 3e5,
                        currency: "usd",
                        supportedModes: ["PI"],
                        initialMode: "PI",
                        type: "redirect"
                    }]
                },
                jsApiConfig: {
                    betaFlags: ["capchase_pay_pm_beta_1"]
                }
            })
        },
        81592: function(e, t, n) {
            "use strict";
            n.d(t, {
                K: function() {
                    return c
                }
            });
            var a = n(68485),
                o = n(39834),
                r = n(29915),
                i = n(85493),
                u = n(92752),
                s = n(89105),
                l = {
                    billie: a.C,
                    capchase_pay: o.C,
                    kriya: r.C,
                    mondu: i.C,
                    samsung_pay: u.C,
                    sequra: s.C
                },
                c = function() {
                    return l
                }
        },
        29915: function(e, t, n) {
            "use strict";
            n.d(t, {
                C: function() {
                    return a
                }
            });
            var a = (0, n(49006).h)({
                paymentMethodSpec: {
                    type: "kriya",
                    polling: !1,
                    redirect: !0,
                    paymentScreens: [{
                        type: "kriya",
                        step: "initial"
                    }],
                    alwaysCollectFullBillingAddress: !1,
                    alwaysCollectCountry: !1,
                    alwaysCollectTaxInformation: !1,
                    allowedCountries: ["GB", "IE", "BE", "NL", "ES", "CY", "DK", "FI", "PL", "SE", "CH"],
                    defaultCountry: "GB",
                    taxCountry: null,
                    supportsOffSession: !1,
                    fieldLabels: null,
                    hasLuxeServerSpec: !0
                },
                hostedPaymentUiConfiguration: {
                    messageKeys: {
                        name: "payment.selector.label.kriya",
                        headline: "payment.headline.kriya",
                        noTrialOrSetupModeHeader: "payment.headline.kriya"
                    },
                    iconSvgs: {
                        lightThemeSvg: "https://js.stripe.com/v3/fingerprinted/img/payment-methods/icon-pm-kriya-2fc48d982927bee3db081ff546890ab1.svg"
                    },
                    features: {
                        excludeFromOverflowIconRotation: !1,
                        isSubmittable: !0,
                        hasSpecificNotice: !1,
                        hasCustomReducers: !1,
                        supportsSetupMode: !1,
                        supportsSubscription: !1,
                        isMissingE2ETests: !0
                    },
                    dataDrivenConfig: {
                        paymentMethodCategory: "simple_redirect"
                    },
                    sortOrder: {
                        prioritizedCountries: ["gb", "ie", "be", "nl", "es", "cy", "dk", "fi", "pl", "se", "ch"],
                        prioritizedLanguages: ["en-gb", "en-ie", "nl-be", "fr-be", "nl-nl", "es-es", "el-cy", "da-dk", "fi-fi", "pl-pl", "sv-se", "de-ch", "fr-ch", "it-ch"]
                    },
                    iconSize: "md"
                },
                paymentElementUiConfiguration: {
                    messageKeys: {
                        name: "upe.methods.kriya"
                    },
                    combinedDemos: [{
                        id: "paymentElementKriya",
                        name: "Payment Element + Kriya",
                        amount: 2500,
                        currency: "gbp",
                        supportedModes: ["PI"],
                        initialMode: "PI",
                        type: "redirect"
                    }]
                },
                jsApiConfig: {
                    betaFlags: ["kriya_pm_beta_1"]
                }
            })
        },
        85493: function(e, t, n) {
            "use strict";
            n.d(t, {
                C: function() {
                    return a
                }
            });
            var a = (0, n(49006).h)({
                paymentMethodSpec: {
                    type: "mondu",
                    polling: !1,
                    redirect: !0,
                    paymentScreens: [{
                        type: "mondu",
                        step: "initial"
                    }],
                    alwaysCollectFullBillingAddress: !1,
                    alwaysCollectCountry: !1,
                    alwaysCollectTaxInformation: !1,
                    allowedCountries: ["NL", "DE", "GB", "FR", "CH", "BE"],
                    defaultCountry: "DE",
                    taxCountry: null,
                    supportsOffSession: !1,
                    fieldLabels: null,
                    hasLuxeServerSpec: !0
                },
                hostedPaymentUiConfiguration: {
                    messageKeys: {
                        name: "payment.selector.label.mondu",
                        headline: "payment.headline.mondu",
                        noTrialOrSetupModeHeader: "payment.headline.mondu"
                    },
                    iconSvgs: {
                        lightThemeSvg: "https://js.stripe.com/v3/fingerprinted/img/payment-methods/icon-pm-mondu-0410ce9097dff459c456de81de61811c.svg"
                    },
                    features: {
                        excludeFromOverflowIconRotation: !1,
                        isSubmittable: !0,
                        hasSpecificNotice: !1,
                        hasCustomReducers: !1,
                        supportsSetupMode: !1,
                        supportsSubscription: !1,
                        isMissingE2ETests: !1
                    },
                    dataDrivenConfig: {
                        paymentMethodCategory: "simple_redirect"
                    },
                    sortOrder: {
                        prioritizedCountries: ["de", "fr", "nl", "gb", "ch", "be"],
                        prioritizedLanguages: ["de-de", "fr-fr", "nl-nl", "en-gb", "de-ch", "fr-ch", "it-ch", "nl-be", "fr-be"]
                    },
                    iconSize: "md"
                },
                paymentElementUiConfiguration: {
                    messageKeys: {
                        name: "upe.methods.mondu"
                    },
                    combinedDemos: [{
                        id: "paymentElementMondu",
                        name: "Payment Element + Mondu",
                        amount: 2500,
                        currency: "eur",
                        supportedModes: ["PI"],
                        initialMode: "PI",
                        type: "redirect"
                    }]
                },
                jsApiConfig: {
                    betaFlags: ["mondu_pm_beta_1"]
                }
            })
        },
        92752: function(e, t, n) {
            "use strict";
            n.d(t, {
                C: function() {
                    return a
                }
            });
            var a = (0, n(49006).h)({
                paymentMethodSpec: {
                    type: "samsung_pay",
                    polling: !1,
                    redirect: !0,
                    paymentScreens: [{
                        type: "samsung_pay",
                        step: "initial"
                    }],
                    alwaysCollectFullBillingAddress: !1,
                    alwaysCollectCountry: !1,
                    alwaysCollectTaxInformation: !1,
                    allowedCountries: ["US"],
                    defaultCountry: "US",
                    taxCountry: null,
                    supportsOffSession: !1,
                    fieldLabels: null,
                    hidePaymentMethodDescription: !0,
                    hasLuxeServerSpec: !0,
                    redirectMessage: "upe.redirectMessage.samsung_pay",
                    redirectMessageLinks: {
                        terms_link: {
                            url: "https://support.stripe.com/questions/nicepayments-customer-terms",
                            text: "upe.redirectMessage.samsung_pay.link_text",
                            linkType: "terms"
                        }
                    }
                },
                hostedPaymentUiConfiguration: {
                    messageKeys: {
                        name: "payment.selector.label.samsung_pay",
                        headline: "payment.headline.samsung_pay",
                        noTrialOrSetupModeHeader: "payment.headline.samsung_pay",
                        redirectMessage: "payment.samsung_pay.hosted_instructions_notice.text",
                        redirectMessageLinks: {
                            terms_link: {
                                url: "https://support.stripe.com/questions/nicepayments-customer-terms",
                                text: "payment.samsung_pay.hosted_instructions_notice.link_text"
                            }
                        }
                    },
                    iconSvgs: {
                        lightThemeSvg: "https://js.stripe.com/v3/fingerprinted/img/payment-methods/icon-pm-samsungpay-ea57f885d8b777960d41a4eefc4972f8.svg",
                        darkThemeSvg: "https://js.stripe.com/v3/fingerprinted/img/payment-methods/icon-pm-samsungpay_dark-535de9ca969b1968a4a9af7503e39047.svg"
                    },
                    features: {
                        excludeFromOverflowIconRotation: !1,
                        isSubmittable: !0,
                        hasSpecificNotice: !1,
                        hasCustomReducers: !1,
                        supportsSetupMode: !1,
                        supportsSubscription: !1,
                        isMissingE2ETests: !1
                    },
                    dataDrivenConfig: {
                        paymentMethodCategory: "simple_redirect"
                    },
                    sortOrder: {
                        prioritizedCountries: ["us"],
                        prioritizedLanguages: ["ko-kr"]
                    },
                    iconSize: "md"
                },
                paymentElementUiConfiguration: {
                    messageKeys: {
                        name: "upe.methods.samsung_pay"
                    }
                }
            })
        },
        89105: function(e, t, n) {
            "use strict";
            n.d(t, {
                C: function() {
                    return a
                }
            });
            var a = (0, n(49006).h)({
                paymentMethodSpec: {
                    type: "sequra",
                    polling: !1,
                    redirect: !0,
                    paymentScreens: [{
                        type: "sequra",
                        step: "initial"
                    }],
                    alwaysCollectFullBillingAddress: !1,
                    alwaysCollectCountry: !1,
                    alwaysCollectTaxInformation: !1,
                    allowedCountries: ["ES"],
                    defaultCountry: "ES",
                    taxCountry: null,
                    supportsOffSession: !1,
                    fieldLabels: null,
                    hasLuxeServerSpec: !0
                },
                hostedPaymentUiConfiguration: {
                    messageKeys: {
                        name: "payment.selector.label.sequra",
                        headline: "payment.headline.sequra",
                        noTrialOrSetupModeHeader: "payment.headline.sequra"
                    },
                    iconSvgs: {
                        lightThemeSvg: "https://js.stripe.com/v3/fingerprinted/img/payment-methods/icon-pm-sequra-783a26313c95faf606c21836956bde93.svg"
                    },
                    features: {
                        excludeFromOverflowIconRotation: !1,
                        isSubmittable: !0,
                        hasSpecificNotice: !1,
                        hasCustomReducers: !1,
                        supportsSetupMode: !1,
                        supportsSubscription: !1,
                        isMissingE2ETests: !0
                    },
                    dataDrivenConfig: {
                        paymentMethodCategory: "simple_redirect"
                    },
                    sortOrder: {
                        prioritizedCountries: ["es"],
                        prioritizedLanguages: ["es-es"]
                    },
                    iconSize: "md"
                },
                paymentElementUiConfiguration: {
                    messageKeys: {
                        name: "upe.methods.sequra"
                    },
                    combinedDemos: [{
                        id: "paymentElementSequra",
                        name: "Payment Element + Sequra",
                        amount: 6e4,
                        currency: "eur",
                        supportedModes: ["PI"],
                        initialMode: "PI",
                        type: "redirect"
                    }]
                },
                jsApiConfig: {
                    betaFlags: ["sequra_pm_beta_1"]
                }
            })
        },
        30307: function(e, t, n) {
            "use strict";
            n.d(t, {
                N: function() {
                    return a
                }
            });
            var a = {
                PI: "paymentIntent",
                SI: "setupIntent",
                PI_SFU: "paymentIntent w/ SFU"
            }
        },
        17948: function(e, t, n) {
            "use strict";
            n.d(t, {
                d: function() {
                    return o
                },
                h: function() {
                    return a
                }
            });
            var a = {
                    UNKNOWN_MODE: 0,
                    IFRAME: 1,
                    POPUP: 2,
                    REDIRECT: 3,
                    ANDROID_NATIVE: 4,
                    PAYMENT_HANDLER: 5
                },
                o = 4505 == n.j ? ["UNKNOWN_MODE", "IFRAME", "POPUP", "REDIRECT", "ANDROID_NATIVE", "PAYMENT_HANDLER"] : null
        },
        91493: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    AH: function() {
                        return f
                    },
                    Mj: function() {
                        return p
                    },
                    PW: function() {
                        return b
                    },
                    XM: function() {
                        return m
                    },
                    _t: function() {
                        return _
                    },
                    t5: function() {
                        return h
                    }
                }), 4505 == n.j) var a = n(1413);
            var o = n(71873),
                r = n(56241),
                i = n(47934),
                u = n(24643),
                s = n(35918),
                l = 4505 == n.j ? ["PAN_ONLY", "CRYPTOGRAM_3DS"] : null,
                c = "09511744644598700896",
                p = function(e, t, n) {
                    var a = (0, r.mo)(n),
                        o = a.unitSize,
                        i = a.fractionDigits,
                        u = e * o;
                    return window.Intl ? new Intl.NumberFormat(t, {
                        style: "currency",
                        currency: n
                    }).format(u) : u.toFixed(i)
                },
                d = function(e) {
                    return e ? (0, u.ZP)(e, u.b6) : u.b6
                },
                m = function(e) {
                    var t = d(null == e ? void 0 : e.__minGooglePayVersion);
                    return {
                        apiVersion: t.major,
                        apiVersionMinor: t.minor,
                        existingPaymentMethodRequired: !0,
                        allowedPaymentMethods: [{
                            type: "CARD",
                            parameters: {
                                allowedAuthMethods: l,
                                allowedCardNetworks: (0, i.vp)(e.country, e.jcbEnabled || !1, e.blockedCardBrands || [])
                            }
                        }],
                        activityModeRequired: !e.__isCheckout
                    }
                },
                y = function(e) {
                    return (0, a.Z)({
                        merchantId: c,
                        merchantOrigin: e.origin
                    }, e.name ? {
                        merchantName: e.name
                    } : {})
                },
                _ = function(e, t) {
                    var n = d(null == e ? void 0 : e.__minGooglePayVersion);
                    return (0, a.Z)((0, a.Z)({
                        apiVersion: n.major,
                        apiVersionMinor: n.minor,
                        merchantInfo: y(t),
                        allowedPaymentMethods: [{
                            type: "CARD",
                            parameters: (0, a.Z)({
                                allowedAuthMethods: l,
                                allowedCardNetworks: (0, i.vp)(e.country, e.jcbEnabled || !1, e.blockedCardBrands || [])
                            }, !0 === e.requestPayerName || !0 === e.requestPayerPhone ? {
                                billingAddressRequired: !0,
                                billingAddressParameters: {
                                    format: "MIN",
                                    phoneNumberRequired: !0 === e.requestPayerPhone
                                }
                            } : {}),
                            tokenizationSpecification: {
                                type: "PAYMENT_GATEWAY",
                                parameters: {
                                    gateway: "stripe",
                                    gatewayMerchantId: c,
                                    "stripe:version": "Stripe.js/GooglePayDummyAPIVersion",
                                    "stripe:publishableKey": t.accountId ? "".concat(t.apiKey, "/").concat(t.accountId) : t.apiKey
                                }
                            }
                        }],
                        transactionInfo: (0, a.Z)((0, a.Z)({
                            currencyCode: e.currency.toUpperCase()
                        }, e.displayItems && e.displayItems.length ? {
                            displayItems: e.displayItems.map((function(t) {
                                return {
                                    price: (0, r.Fe)(t.amount, e.currency, "google"),
                                    label: t.label,
                                    type: "LINE_ITEM",
                                    status: !0 === t.pending ? "PENDING" : "FINAL"
                                }
                            }))
                        } : {}), {}, {
                            totalPrice: (0, r.Fe)(e.total.amount, e.currency, "google"),
                            totalPriceLabel: e.total.label,
                            totalPriceStatus: !0 === e.total.pending ? "ESTIMATED" : "FINAL"
                        }),
                        emailRequired: !0 === e.requestPayerEmail
                    }, !0 === e.requestShipping ? {
                        callbackIntents: ["SHIPPING_ADDRESS", "SHIPPING_OPTION", "PAYMENT_AUTHORIZATION"],
                        shippingAddressRequired: !0,
                        shippingOptionRequired: !0
                    } : {
                        callbackIntents: ["PAYMENT_AUTHORIZATION"]
                    }), e.shippingOptions && e.shippingOptions.length ? {
                        shippingOptionParameters: {
                            defaultSelectedOptionId: e.shippingOptions[0].id,
                            shippingOptions: e.shippingOptions.map((function(t) {
                                return {
                                    id: t.id,
                                    label: 0 === t.amount ? t.label : "".concat(t.label, " (").concat(p(t.amount, e.country, e.currency), ")"),
                                    description: t.detail
                                }
                            }))
                        }
                    } : {})
                },
                b = {
                    PAYMENT_AUTHORIZATION: {
                        fail: {
                            reason: "PAYMENT_DATA_INVALID",
                            message: "errors.payment_request.failed_to_process_payment",
                            intent: "PAYMENT_AUTHORIZATION"
                        },
                        invalid_payer_name: {
                            reason: "PAYMENT_DATA_INVALID",
                            message: "errors.payment_request.invalid_billing_address",
                            intent: "PAYMENT_AUTHORIZATION"
                        },
                        invalid_payer_email: {
                            reason: "PAYMENT_DATA_INVALID",
                            message: "errors.payment_request.invalid_payer_email",
                            intent: "PAYMENT_AUTHORIZATION"
                        },
                        invalid_payer_phone: {
                            reason: "PAYMENT_DATA_INVALID",
                            message: "errors.payment_request.invalid_payer_phone",
                            intent: "PAYMENT_AUTHORIZATION"
                        },
                        invalid_payer_zip: {
                            reason: "PAYMENT_DATA_INVALID",
                            message: "errors.payment_request.invalid_billing_address",
                            intent: "PAYMENT_AUTHORIZATION"
                        },
                        invalid_shipping_address: {
                            reason: "SHIPPING_ADDRESS_INVALID",
                            message: "errors.payment_request.invalid_shipping_address_short",
                            intent: "PAYMENT_AUTHORIZATION"
                        },
                        invalid_coupon_code: {
                            reason: "PAYMENT_DATA_INVALID",
                            message: "errors.payment_request.failed_to_process_payment",
                            intent: "PAYMENT_AUTHORIZATION"
                        },
                        expired_coupon_code: {
                            reason: "PAYMENT_DATA_INVALID",
                            message: "errors.payment_request.failed_to_process_payment",
                            intent: "PAYMENT_AUTHORIZATION"
                        }
                    },
                    SHIPPING_ADDRESS: {
                        fail: {
                            reason: "OTHER_ERROR",
                            message: "errors.payment_request.invalid_shipping_address_short",
                            intent: "SHIPPING_ADDRESS"
                        },
                        invalid_shipping_address: {
                            reason: "SHIPPING_ADDRESS_INVALID",
                            message: "errors.payment_request.invalid_shipping_address_short",
                            intent: "SHIPPING_ADDRESS"
                        }
                    },
                    SHIPPING_OPTION: {
                        fail: {
                            reason: "OTHER_ERROR",
                            message: "errors.payment_request.shipping_option_unavailable",
                            intent: "SHIPPING_OPTION"
                        },
                        invalid_shipping_option: {
                            reason: "SHIPPING_OPTION_INVALID",
                            message: "errors.payment_request.shipping_option_unavailable",
                            intent: "SHIPPING_OPTION"
                        }
                    }
                },
                h = function(e, t) {
                    var n = function(e, t) {
                        switch (e) {
                            case "PAYMENT_AUTHORIZATION":
                                return b.PAYMENT_AUTHORIZATION[t];
                            case "SHIPPING_ADDRESS":
                                return "invalid_shipping_address" === t ? b.SHIPPING_ADDRESS.invalid_shipping_address : b.SHIPPING_ADDRESS.fail;
                            case "SHIPPING_OPTION":
                                return b.SHIPPING_OPTION.fail;
                            default:
                                return (0, o.Rz)(e)
                        }
                    }(e, t);
                    return (0, a.Z)((0, a.Z)({}, n), {}, {
                        message: (0, s.Yo)("auto", n.message)
                    })
                },
                f = function(e) {
                    return "success" === e ? {
                        transactionState: "SUCCESS"
                    } : {
                        transactionState: "ERROR",
                        error: h("PAYMENT_AUTHORIZATION", e)
                    }
                }
        },
        63630: function(e, t, n) {
            "use strict";
            var a = n(15671),
                o = n(43144),
                r = n(97326),
                i = n(60136),
                u = n(29388),
                s = n(80755),
                l = n(49924),
                c = n(97412),
                p = n(56274).Promise,
                d = function(e) {
                    function t(e) {
                        var o;
                        return (0, a.Z)(this, t), (o = n.call(this, e, {
                            element: "paymentRequest"
                        }))._events = o._defineEvents({
                            show: new s.zS("show", (0, r.Z)(o)),
                            abort: new s.o9("abort", (0, r.Z)(o)),
                            update: new s.zS("update", (0, r.Z)(o)),
                            initialize: new s.LP("initialize", (0, r.Z)(o))
                        }), o._prCallbacks = {}, o
                    }(0, i.Z)(t, e);
                    var n = (0, u.Z)(t);
                    return (0, o.Z)(t, [{
                        key: "_handleAppMessage",
                        value: function(e, t) {
                            var n = e.message;
                            switch (n.action) {
                                case "stripe-pr-show":
                                    this._events.show.emit(n.payload.data);
                                    break;
                                case "stripe-pr-abort":
                                    this._events.abort.emit();
                                    break;
                                case "stripe-pr-update":
                                    this._events.update.emit(n.payload.data);
                                    break;
                                case "stripe-pr-initialize":
                                    this._events.initialize.emit(n.payload.data, t);
                                    break;
                                case "stripe-pr-callback-complete":
                                    var a = n.payload.nonce;
                                    (0, this._prCallbacks[a].resolve)(n.payload.data)
                            }
                        }
                    }, {
                        key: "waitForCallback",
                        value: function(e, t) {
                            var n = this,
                                a = (0, c.To)(e);
                            return new p((function(o, r) {
                                n._prCallbacks[a] = {
                                    resolve: o,
                                    reject: r
                                }, n.event("pr-callback", {
                                    event: e,
                                    nonce: a,
                                    options: t
                                })
                            }))
                        }
                    }]), t
                }(l.Z);
            t.Z = /^(4505|7297)$/.test(n.j) ? d : null
        },
        40939: function(e, t, n) {
            "use strict";
            n.d(t, {
                S: function() {
                    return r
                }
            });
            var a = n(39294),
                o = n(47792),
                r = function(e) {
                    return !(!e || !(0, o.uN)(e, o.M4.google_pay_beta_1)) || !a.sV
                }
        },
        81743: function(e, t, n) {
            "use strict";
            n.d(t, {
                Tw: function() {
                    return o
                },
                Uz: function() {
                    return s
                },
                WN: function() {
                    return c
                },
                aH: function() {
                    return i
                },
                kB: function() {
                    return r
                },
                qp: function() {
                    return l
                },
                yv: function() {
                    return p
                }
            });
            var a = n(1413),
                o = "40px",
                r = {
                    invalid_coupon_code: "invalid_coupon_code",
                    expired_coupon_code: "expired_coupon_code",
                    invalid_payer_zip: "invalid_payer_zip"
                },
                i = (0, a.Z)({
                    success: "success",
                    fail: "fail",
                    invalid_shipping_address: "invalid_shipping_address"
                }, r),
                u = (0, a.Z)({
                    fail: "fail",
                    invalid_payer_name: "invalid_payer_name",
                    invalid_payer_email: "invalid_payer_email",
                    invalid_payer_phone: "invalid_payer_phone",
                    invalid_shipping_address: "invalid_shipping_address"
                }, r),
                s = {
                    shipping: "shipping",
                    delivery: "delivery",
                    pickup: "pickup"
                },
                l = (0, a.Z)({
                    success: "success"
                }, u),
                c = {
                    merchantCapabilities: ["supports3DS"],
                    displayItems: []
                },
                p = {
                    auto: "auto",
                    available: "available",
                    unavailableItemIneligible: "unavailableItemIneligible",
                    unavailableRecurringTransaction: "unavailableRecurringTransaction"
                }
        },
        24643: function(e, t, n) {
            "use strict";
            n.d(t, {
                Df: function() {
                    return u
                },
                ZP: function() {
                    return i
                },
                b6: function() {
                    return r
                }
            });
            var a = n(56274).Promise,
                o = null,
                r = {
                    major: 2,
                    minor: 0
                },
                i = function(e, t) {
                    return e.major < t.major ? t : e.major > t.major || e.minor >= t.minor ? e : t
                },
                u = function(e) {
                    return null !== o ? a.resolve(o) : e().then((function(e) {
                        return o = e
                    }))
                }
        },
        47934: function(e, t, n) {
            "use strict";
            n.d(t, {
                vp: function() {
                    return p
                }
            });
            var a, o, r = n(4942),
                i = n(60276),
                u = (a = {}, (0, r.Z)(a, i.rM.VISA, "visa"), (0, r.Z)(a, i.rM.MASTERCARD, "masterCard"), (0, r.Z)(a, i.rM.AMEX, "amex"), (0, r.Z)(a, i.rM.DISCOVER, "discover"), (0, r.Z)(a, i.rM.JCB, "jcb"), (0, r.Z)(a, i.rM.UNIONPAY, "chinaUnionPay"), (0, r.Z)(a, i.rM.DINERS, null), (0, r.Z)(a, i.ZJ.MAESTRO, "maestro"), (0, r.Z)(a, i.ZJ.CARTES_BANCAIRES, "cartesBancaires"), (0, r.Z)(a, i.ZJ.INTERAC, "interac"), o = {}, (0, r.Z)(o, i.rM.VISA, "VISA"), (0, r.Z)(o, i.rM.MASTERCARD, "MASTERCARD"), (0, r.Z)(o, i.rM.AMEX, "AMEX"), (0, r.Z)(o, i.rM.DISCOVER, "DISCOVER"), (0, r.Z)(o, i.rM.JCB, "JCB"), (0, r.Z)(o, i.rM.DINERS, null), (0, r.Z)(o, i.ZJ.CARTES_BANCAIRES, null), (0, r.Z)(o, i.ZJ.INTERAC, null), o),
                s = /^(4505|5075|7297)$/.test(n.j) ? ["AT", "AU", "BE", "CA", "CH", "DE", "DK", "EE", "ES", "FI", "FR", "GB", "GR", "HK", "IE", "IT", "JP", "LT", "LU", "LV", "MX", "NL", "NO", "NZ", "PL", "PT", "SE", "SG", "US"] : null,
                l = /^(4505|5075|7297)$/.test(n.j) ? ["AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GI", "GR", "HR", "HU", "IE", "IT", "LI", "LT", "LU", "LV", "MT", "NL", "NO", "PL", "PT", "RO", "SE", "SI", "SK", "GB", "HK", "SG", "CH", "US"] : null,
                c = function(e, t, n, a, o, r) {
                    var u = [];
                    return a && -1 !== a.indexOf(i.ZJ.CARTES_BANCAIRES) && "eur" === o && r && u.push(i.ZJ.CARTES_BANCAIRES), -1 !== s.indexOf(e) && u.push(i.rM.AMEX), (-1 !== ["GB", "CA", "JP", "US"].indexOf(e) || t) && u.push.apply(u, [i.rM.DISCOVER, i.rM.DINERS]), (-1 !== l.indexOf(e) || t) && u.push(i.rM.JCB), u.push.apply(u, [i.rM.MASTERCARD, i.rM.VISA]), u.filter((function(e) {
                        return -1 === n.indexOf(e)
                    }))
                },
                p = function(e, t, n) {
                    return c(e, t, n).reduce((function(e, t) {
                        var n = u[t];
                        return n && e.push(n), e
                    }), [])
                }
        },
        939: function(e, t, n) {
            "use strict";
            n.d(t, {
                F4: function() {
                    return E
                }
            });
            var a = n(1413),
                o = n(89062),
                r = n(71873),
                i = n(97412),
                u = n(81743),
                s = (n(47792), n(60276)),
                l = n(48229),
                c = (0, r.mC)({
                    amount: r.MZ,
                    label: r.Z_,
                    pending: (0, r.jt)(r.Xg)
                }),
                p = (0, r.mC)({
                    amount: r.Bi,
                    label: r.Z_,
                    pending: (0, r.jt)(r.Xg)
                }),
                d = ((0, r.mC)({
                    isEligible: r.Xg,
                    type: r.kw.apply(void 0, (0, o.Z)(l.mY))
                }), (0, r.mC)({
                    amount: r.Bi,
                    label: r.Z_,
                    pending: (0, r.jt)(r.Xg),
                    id: (0, r.Wc)(r.Z_, (function() {
                        return (0, i.To)("shippingOption")
                    })),
                    detail: (0, r.Wc)(r.Z_, (function() {
                        return ""
                    }))
                })),
                m = ((0, r.mC)({
                    major: r.Rx,
                    minor: r.Rx
                }), r.kw.apply(void 0, (0, o.Z)(Object.keys(u.Uz))), (0, r.mC)({
                    origin: r.Z_,
                    name: r.Z_,
                    accountId: (0, r.jt)(r.Z_),
                    applePayIdentifierAccount: (0, r.jt)(r.Z_)
                })),
                y = (0, r.mC)({
                    amount: r.Bi,
                    label: r.Z_,
                    pending: (0, r.jt)(r.Xg),
                    recurringPaymentStartDate: (0, r.jt)(r.Kr),
                    recurringPaymentEndDate: (0, r.jt)(r.Kr),
                    recurringPaymentIntervalCount: (0, r.jt)(r.Rx),
                    recurringPaymentIntervalUnit: (0, r.jt)((0, r.kw)("year", "month", "day", "hour", "minute"))
                }),
                _ = Object.freeze({
                    paymentDescription: r.Z_,
                    managementURL: r.Z_,
                    automaticReloadBilling: (0, r.mC)({
                        amount: r.MZ,
                        label: r.Z_,
                        automaticReloadPaymentThresholdAmount: r.MZ
                    })
                }),
                b = (0, r.ci)(_),
                h = (0, r.mC)({
                    paymentDescription: r.Z_,
                    managementURL: r.Z_,
                    deferredBilling: (0, r.mC)({
                        amount: r.MZ,
                        label: r.Z_,
                        deferredPaymentDate: r.Kr
                    }),
                    freeCancellationDate: (0, r.jt)(r.Kr),
                    freeCancellationDateTimeZone: (0, r.jt)(r.Z_),
                    billingAgreement: (0, r.jt)(r.Z_)
                }),
                f = Object.freeze({
                    paymentDescription: r.Z_,
                    managementURL: r.Z_,
                    regularBilling: y,
                    trialBilling: (0, r.jt)(y),
                    billingAgreement: (0, r.jt)(r.Z_)
                }),
                g = (0, r.ci)(f),
                k = Object.keys(u.yv),
                v = (0, r.jt)(r.kw.apply(void 0, k)),
                w = (0, r.mC)({
                    automaticReloadPaymentRequest: (0, r.jt)(b),
                    deferredPaymentRequest: (0, r.jt)(h),
                    recurringPaymentRequest: (0, r.jt)(g)
                }),
                A = (0, r.mC)({
                    automaticReloadPaymentRequest: (0, r.jt)((0, r.AG)((0, r.mC)((0, a.Z)((0, a.Z)({}, _), {}, {
                        billingAgreement: (0, r.jt)(r.Z_)
                    })))),
                    deferredPaymentRequest: (0, r.jt)((0, r.AG)(h)),
                    recurringPaymentRequest: (0, r.jt)((0, r.AG)((0, r.mC)((0, a.Z)((0, a.Z)({}, f), {}, {
                        billingAgreement: (0, r.jt)(r.Z_)
                    })))),
                    applePayLaterAvailability: v
                }),
                P = ((0, r.ci)({
                    __merchantDetails: (0, r.jt)(m),
                    __supportsCouponCode: (0, r.jt)(r.Xg),
                    __couponCode: (0, r.jt)(r.Z_),
                    __billingDetailsEmailOverride: (0, r.jt)(r.Z_),
                    applePay: (0, r.jt)(A),
                    country: (0, r.jt)(r.hN),
                    currency: (0, r.jt)(r.cV),
                    displayItems: (0, r.jt)((0, r.CT)(p)),
                    shippingOptions: (0, r.jt)((0, r.uw)("id")((0, r.CT)(d))),
                    total: (0, r.jt)(c),
                    blockedCardBrands: (0, r.jt)((0, r.CT)(r.kw.apply(void 0, (0, o.Z)(s.iw)))),
                    capabilityEnabledCardNetworks: (0, r.jt)((0, r.CT)(r.kw.apply(void 0, (0, o.Z)(s.P4)))),
                    isConnectPlatform: (0, r.jt)(r.Xg)
                }), Object.keys(u.kB)),
                E = (0, r.mC)({
                    displayItems: (0, r.jt)((0, r.CT)(p)),
                    shippingOptions: (0, r.jt)((0, r.uw)("id")((0, r.CT)(d))),
                    total: (0, r.jt)(c),
                    status: function(e, t, n) {
                        if (-1 !== P.indexOf(e)) return r.kw.apply(void 0, P)(e, t, n);
                        var a = Object.keys(u.aH).filter((function(e) {
                            return -1 === P.indexOf(e)
                        }));
                        return r.kw.apply(void 0, (0, o.Z)(a))(-1 !== ["invalid_payer_name", "invalid_payer_email", "invalid_payer_phone"].indexOf(e) ? "fail" : e, t, n)
                    },
                    errorMessage: (0, r.jt)(r.Z_),
                    applePay: (0, r.jt)(w)
                })
        },
        12141: function(e, t, n) {
            "use strict";
            n.d(t, {
                J$: function() {
                    return a.J
                }
            });
            var a = n(44832)
        },
        44832: function(e, t, n) {
            "use strict";
            n.d(t, {
                J: function() {
                    return o
                }
            });
            var a = {
                    AE: "AE",
                    AT: "AT",
                    AU: "AU",
                    BE: "BE",
                    BG: "BG",
                    BR: "BR",
                    CA: "CA",
                    CH: "CH",
                    CI: "CI",
                    CR: "CR",
                    CY: "CY",
                    CZ: "CZ",
                    DE: "DE",
                    DK: "DK",
                    DO: "DO",
                    EE: "EE",
                    ES: "ES",
                    FI: "FI",
                    FR: "FR",
                    GB: "GB",
                    GI: "GI",
                    GR: "GR",
                    GT: "GT",
                    HK: "HK",
                    HR: "HR",
                    HU: "HU",
                    ID: "ID",
                    IE: "IE",
                    IN: "IN",
                    IT: "IT",
                    JP: "JP",
                    LI: "LI",
                    LT: "LT",
                    LU: "LU",
                    LV: "LV",
                    MT: "MT",
                    MX: "MX",
                    MY: "MY",
                    NL: "NL",
                    NO: "NO",
                    NZ: "NZ",
                    PE: "PE",
                    PH: "PH",
                    PL: "PL",
                    PT: "PT",
                    RO: "RO",
                    SE: "SE",
                    SG: "SG",
                    SI: "SI",
                    SK: "SK",
                    SN: "SN",
                    TH: "TH",
                    TT: "TT",
                    US: "US",
                    UY: "UY"
                },
                o = Object.keys(a)
        },
        73419: function(e, t, n) {
            "use strict";
            n.d(t, {
                L: function() {
                    return r
                }
            });
            var a = n(12024),
                o = n(71873),
                r = function e(t) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                    return (0, a.VS)(Object.keys(t || {}), (function(a) {
                        var r = n ? "".concat(n, "[").concat(a, "]") : a;
                        return "object" != typeof t[a] || null == t[a] ? [r] : (0, o.rX)(t[a]) ? [] : Array.isArray(t[a]) && !t[a].length ? [r] : e(t[a], r)
                    }))
                }
        },
        3644: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    Wj: function() {
                        return y
                    }
                }), !/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j)) var a = n(45987);
            var o = n(74165);
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j)) var r = n(1413);
            var i = n(15861),
                u = n(73419),
                s = n(45894),
                l = n(352),
                c = /^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j) ? null : ["merchantParams", "expectedErrors", "log", "extraLogData", "key", "debug"],
                p = !1,
                d = function(e, t) {
                    return t.some((function(t) {
                        return 0 === t.indexOf(e)
                    }))
                },
                m = function(e, t) {
                    return t.some((function(t) {
                        var n, a, o = t.code,
                            r = t.param,
                            i = t.message;
                        return (o || r || i) && (!o || e.code === o) && (!r || e.param === r) && (!i || (n = e.message, "string" == typeof(a = i) ? n === a : n && a.test(n)))
                    }))
                },
                y = function(e, t, n, y, _) {
                    var b = null != y ? y : {},
                        h = b.merchantParams,
                        f = b.expectedErrors,
                        g = b.log,
                        k = b.extraLogData,
                        v = b.key,
                        w = b.debug,
                        A = (0, a.Z)(b, c);
                    return function(e) {
                        var t = e.log,
                            n = void 0 === t ? l.kg.log : t,
                            a = e.extraLogData,
                            c = e.key,
                            y = e.merchantParams,
                            _ = void 0 === y ? {} : y,
                            b = e.expectedErrors,
                            h = void 0 === b ? [] : b,
                            f = e.debug,
                            g = void 0 !== f && f,
                            k = (0, u.L)(_),
                            v = -1 === c.indexOf("pk_test_") ? "live" : "test";
                        return function() {
                            var e = (0, i.Z)((0, o.Z)().mark((function e(t, i) {
                                var u, l, y, _, b, f, w, A, P, E = arguments;
                                return (0, o.Z)().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            for (u = E.length, l = new Array(u > 2 ? u - 2 : 0), y = 2; y < u; y++) l[y - 2] = E[y];
                                            return e.next = 3, s.Nv.apply(void 0, [t, i].concat(l));
                                        case 3:
                                            _ = e.sent;
                                            try {
                                                "error" !== _.type || 400 !== _.error.status && "invalid_request_error" !== _.error.type || (b = _.error, f = b.code, w = b.message, A = b.param, P = b.type, !A || d(A, k) || m(_.error, h) || p || (n(g ? "debug.api.unexpected_400" : "api.unexpected_400", (0, r.Z)({
                                                    method: i,
                                                    req_id: _.requestId,
                                                    error_type: P,
                                                    error_code: f,
                                                    error_message: w,
                                                    error_param: A,
                                                    merchant_params: k,
                                                    key: c,
                                                    key_mode: v
                                                }, a)), p = !0))
                                            } catch (e) {
                                                n("api.unexpected_400", {
                                                    error: e,
                                                    key: c,
                                                    key_mode: v
                                                }), p = !0
                                            }
                                            return e.abrupt("return", _);
                                        case 6:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })));
                            return function(t, n) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }({
                        log: g,
                        extraLogData: k,
                        key: v,
                        merchantParams: h,
                        expectedErrors: f,
                        debug: w
                    })(e, t, n, _, A)
                }
        },
        81248: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    Nv: function() {
                        return _
                    },
                    YN: function() {
                        return h
                    },
                    lC: function() {
                        return d
                    },
                    nW: function() {
                        return b
                    },
                    qO: function() {
                        return m
                    }
                }), !/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j)) var a = n(1413);
            var o = n(52303),
                r = n(60276),
                i = n(36617),
                u = n(69792),
                s = n(24245),
                l = n(49800),
                c = r.L$,
                p = function() {},
                d = function(e) {
                    var t = (0, i.xs)(e);
                    return !(t !== r.L$ && ((0, i.U5)(e), 1)) && (c = t, !0)
                },
                m = function(e) {
                    p = e
                },
                y = Object.freeze({}),
                _ = function e(t, n, i) {
                    var d = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : y,
                        m = arguments.length > 4 ? arguments[4] : void 0;
                    p();
                    var _, b = new u.E;
                    switch (null == m ? void 0 : m.server) {
                        case "bapi_v2":
                            _ = "".concat(c.replace("/v1/", "/v2/")).concat(t);
                            break;
                        case "merchant-ui-api":
                            _ = "".concat(r.Dw).concat(t);
                            break;
                        default:
                            _ = "".concat(c).concat(t)
                    }
                    return null != m && m.retries && (d.includeErrorStatus = !0), (0, o.W)(_, n, i, (0, a.Z)({
                        logResult: function(e) {
                            (0, l.Z)(b, _, i, e)
                        }
                    }, d)).then((function(o) {
                        var r;
                        return "error" === o.type && null != m && m.retries && m.retries.maxAttempts > 1 && m.retries.shouldRetry(o.error) ? (0, s._v)((null === (r = m.retries) || void 0 === r ? void 0 : r.delay) || 1e3).then((function() {
                            return e(t, n, i, d, (0, a.Z)((0, a.Z)({}, m), m.retries && {
                                retries: (0, a.Z)((0, a.Z)({}, m.retries), {}, {
                                    maxAttempts: m.retries.maxAttempts - 1
                                })
                            }))
                        })) : o
                    }))
                },
                b = function(e, t) {
                    return function(n) {
                        return _(e, "POST", n, {}, t)
                    }
                },
                h = function(e) {
                    return !e.code || !1 !== e.shouldRetry && (!0 === e.shouldRetry || (409 === e.status || !!(e.status && e.status >= 500)))
                }
        },
        45894: function(e, t, n) {
            "use strict";
            n.d(t, {
                Nv: function() {
                    return a.Nv
                },
                YN: function() {
                    return a.YN
                },
                lC: function() {
                    return a.lC
                },
                nW: function() {
                    return a.nW
                },
                qO: function() {
                    return a.qO
                }
            });
            var a = n(81248)
        },
        49800: function(e, t, n) {
            "use strict";
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j)) var a = n(1413);
            var o = n(12024),
                r = n(69792),
                i = n(72292),
                u = n(352),
                s = /^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j) ? null : ["startTime", "duration", "redirectStart", "redirectEnd", "fetchStart", "domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "secureConnectionStart", "requestStart", "responseStart", "responseEnd"],
                l = function(e) {
                    if (e && window.performance && window.performance.getEntriesByName) {
                        var t = window.performance.getEntriesByName(e);
                        return t && 0 !== t.length ? function(e) {
                            var t = e;
                            return (0, o.ei)(t, s)
                        }(t[t.length - 1]) : {
                            errorMsg: "No resource timing entries found"
                        }
                    }
                };
            t.Z = /^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j) ? null : function(e, t, n, o, s) {
                if (o.getResponseHeader && o.responseURL) {
                    var c, p = function(e) {
                            return e.hasOwnProperty("card") ? "card" : e.hasOwnProperty("bank_account") ? "bank_account" : e.hasOwnProperty("pii") ? "pii" : e.hasOwnProperty("apple_pay") ? "apple_pay" : "unknown"
                        }(n),
                        d = new r.E,
                        m = l(o.responseURL);
                    if (!s) try {
                        c = o.getResponseHeader("Request-Id")
                    } catch (e) {}
                    u.kg.log("rum.stripejs", (0, a.Z)((0, a.Z)({
                        requestId: c,
                        tokenType: p,
                        url: t,
                        status: o.status,
                        start: e.getAsPosixTime(),
                        end: d.getAsPosixTime()
                    }, (_ = "resourceTiming", b = {}, (y = m) ? (function e(t) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                        Object.keys(t).forEach((function(a) {
                            var o = "".concat(n, "[").concat(a, "]").replace(/^-/, ""),
                                r = t[a];
                            if (null != r) switch (typeof r) {
                                case "object":
                                    e(r, o);
                                    break;
                                case "number":
                                    b[o] = Math.round(1e3 * r) / 1e3;
                                    break;
                                default:
                                    b[o] = r
                            }
                        }))
                    }(y, _), b) : b)), {}, {
                        version: 3,
                        paymentUserAgent: i.GD
                    }), {
                        prefix: ""
                    })
                }
                var y, _, b
            }
        },
        44659: function(e, t, n) {
            "use strict";
            n.d(t, {
                HX: function() {
                    return l
                },
                Lv: function() {
                    return i
                },
                M4: function() {
                    return r
                },
                uN: function() {
                    return s
                }
            });
            var a = n(1413),
                o = n(31522),
                r = (0, a.Z)((0, a.Z)({}, o.y.allBetaFlags), {}, {
                    checkout_beta_2: "checkout_beta_2",
                    checkout_beta_3: "checkout_beta_3",
                    checkout_beta_4: "checkout_beta_4",
                    checkout_beta_testcards: "checkout_beta_testcards",
                    payment_intent_beta_1: "payment_intent_beta_1",
                    payment_intent_beta_2: "payment_intent_beta_2",
                    payment_intent_beta_3: "payment_intent_beta_3",
                    google_pay_beta_1: "google_pay_beta_1",
                    acss_debit_beta_1: "acss_debit_beta_1",
                    acss_debit_beta_2: "acss_debit_beta_2",
                    afterpay_clearpay_setup_intents_beta: "afterpay_clearpay_setup_intents_beta",
                    bacs_debit_beta: "bacs_debit_beta",
                    fpx_bank_beta_1: "fpx_bank_beta_1",
                    ideal_pm_beta_1: "ideal_pm_beta_1",
                    line_items_beta_1: "line_items_beta_1",
                    oxxo_pm_beta_1: "oxxo_pm_beta_1",
                    gopay_pm_beta_1: "gopay_pm_beta_1",
                    shopeepay_pm_beta_1: "shopeepay_pm_beta_1",
                    qris_pm_beta_1: "qris_pm_beta_1",
                    kr_card_pm_beta_1: "kr_card_pm_beta_1",
                    naver_pay_pm_beta_1: "naver_pay_pm_beta_1",
                    kakao_pay_pm_beta_1: "kakao_pay_pm_beta_1",
                    payco_pm_beta_1: "payco_pm_beta_1",
                    kr_market_pm_beta_1: "kr_market_pm_beta_1",
                    ng_market_pm_beta_1: "ng_market_pm_beta_1",
                    sepa_pm_beta_1: "sepa_pm_beta_1",
                    deferred_intent_blik_beta_1: "deferred_intent_blik_beta_1",
                    klarna_pm_beta_1: "klarna_pm_beta_1",
                    tax_product_beta_1: "tax_product_beta_1",
                    wechat_pay_pm_beta_1: "wechat_pay_pm_beta_1",
                    wechat_pay_pm_beta_2: "wechat_pay_pm_beta_2",
                    checkout_beta_locales: "checkout_beta_locales",
                    stripe_js_beta_locales: "stripe_js_beta_locales",
                    upi_beta_1: "upi_beta_1",
                    upi_beta_2: "upi_beta_2",
                    issuing_elements_1: "issuing_elements_1",
                    issuing_elements_2: "issuing_elements_2",
                    return_intents_beta_1: "return_intents_beta_1",
                    netbanking_beta_1: "netbanking_beta_1",
                    netbanking_bank_beta_1: "netbanking_bank_beta_1",
                    instant_debits_beta_1: "instant_debits_beta_1",
                    link_beta_1: "link_beta_1",
                    link_beta_2: "link_beta_2",
                    link_beta_3: "link_beta_3",
                    link_default_integration_beta_1: "link_default_integration_beta_1",
                    link_default_integration_beta_2: "link_default_integration_beta_2",
                    payment_element_beta_1: "payment_element_beta_1",
                    elements_customers_beta_1: "elements_customers_beta_1",
                    elements_spm_sfu_off_session_override_beta_1: "elements_spm_sfu_off_session_override_beta_1",
                    card_country_event_beta_1: "card_country_event_beta_1",
                    id_bank_transfer_beta_1: "id_bank_transfer_beta_1",
                    id_bank_transfer_beta_2: "id_bank_transfer_beta_2",
                    us_bank_account_beta_2: "us_bank_account_beta_2",
                    cup_apple_pay_beta_1: "cup_apple_pay_beta_1",
                    nz_bank_account_beta_1: "nz_bank_account_beta_1",
                    nz_bank_account_beta_2: "nz_bank_account_beta_2",
                    payment_element_apple_pay_beta_1: "payment_element_apple_pay_beta_1",
                    link_autofill_modal_beta_1: "link_autofill_modal_beta_1",
                    shipping_address_element_beta_1: "shipping_address_element_beta_1",
                    process_order_beta_1: "process_order_beta_1",
                    server_side_confirmation_beta_1: "server_side_confirmation_beta_1",
                    pay_by_bank_beta_1: "pay_by_bank_beta_1",
                    blocked_card_brands_beta_1: "blocked_card_brands_beta_1",
                    blocked_card_brands_beta_2: "blocked_card_brands_beta_2",
                    payment_element_disable_card_country_zip_validations_beta_1: "payment_element_disable_card_country_zip_validations_beta_1",
                    affirm_in_context_beta_1: "affirm_in_context_beta_1",
                    ume_beta_1: "ume_beta_1",
                    ume_beta_2: "ume_beta_2",
                    ume_beta_3: "ume_beta_3",
                    payment_method_messaging_autopm_beta_1: "payment_method_messaging_autopm_beta_1",
                    networks_change_1: "networks_change_1",
                    express_checkout_element_beta_1: "express_checkout_element_beta_1",
                    pay_button_element_beta_1: "pay_button_element_beta_1",
                    link_in_card_element_beta_1: "link_in_card_element_beta_1",
                    sunbit_pm_beta_1: "sunbit_pm_beta_1",
                    satispay_pm_beta_1: "satispay_pm_beta_1",
                    ng_bank_pm_beta_1: "ng_bank_pm_beta_1",
                    ng_bank_transfer_pm_beta_1: "ng_bank_transfer_pm_beta_1",
                    ng_card_pm_beta_1: "ng_card_pm_beta_1",
                    ng_ussd_pm_beta_1: "ng_ussd_pm_beta_1",
                    financial_connections_on_event_beta_1: "financial_connections_on_event_beta_1",
                    elements_enable_deferred_intent_beta_1: "elements_enable_deferred_intent_beta_1",
                    elements_enable_deferred_intent_beta_2: "elements_enable_deferred_intent_beta_2",
                    enable_stripe_update_api_key_beta_0: "enable_stripe_update_api_key_beta_0",
                    cartes_bancaires_apple_pay_beta_1: "cartes_bancaires_apple_pay_beta_1",
                    interac_apple_pay_beta_1: "interac_apple_pay_beta_1",
                    payment_request_button_two_button_beta_1: "payment_request_button_two_button_beta_1",
                    custom_checkout_beta_1: "custom_checkout_beta_1",
                    custom_checkout_beta_2: "custom_checkout_beta_2",
                    custom_checkout_beta_3: "custom_checkout_beta_3",
                    custom_checkout_beta_4: "custom_checkout_beta_4",
                    custom_checkout_internal_dev_beta: "custom_checkout_internal_dev_beta",
                    custom_checkout_adaptive_pricing_1: "custom_checkout_adaptive_pricing_1",
                    custom_checkout_server_updates_1: "custom_checkout_server_updates_1",
                    custom_domain_checkout: "custom_domain_checkout",
                    deferred_intent_pe_optional_amount_beta_0: "deferred_intent_pe_optional_amount_beta_0",
                    south_korea_market_beta_1: "south_korea_market_beta_1",
                    ece_apple_pay_deferred_payment_card_funding_beta_1: "ece_apple_pay_deferred_payment_card_funding_beta_1",
                    ece_apple_pay_payment_request_passthrough_1: "ece_apple_pay_payment_request_passthrough_1",
                    ece_temp_prevent_default_beta_1: "ece_temp_prevent_default_beta_1",
                    ece_temp_click_shape_changes_beta_1: "ece_temp_click_shape_changes_beta_1",
                    disable_link_passthrough_beta_1: "disable_link_passthrough_beta_1",
                    payto_pm_beta_1: "payto_pm_beta_1",
                    elements_enable_sessions_edge: "elements_enable_sessions_edge",
                    multibanco_pm_beta_1: "multibanco_pm_beta_1",
                    disable_deferred_intent_client_validation_beta_1: "disable_deferred_intent_client_validation_beta_1",
                    rechnung_pm_beta_1: "rechnung_pm_beta_1",
                    embedded_checkout_byol_beta_1: "embedded_checkout_byol_beta_1",
                    change_event_improvements_beta_1: "change_event_improvements_beta_1",
                    mb_way_pm_beta_1: "mb_way_pm_beta_1",
                    currency_selector_element_beta_1: "currency_selector_element_beta_1",
                    payment_element_custom_payment_methods_beta_1: "payment_element_custom_payment_methods_beta_1"
                }),
                i = Object.keys(r),
                u = {},
                s = function e(t, n) {
                    if (Array.isArray(n)) return n.some((function(n) {
                        return e(t, n)
                    }));
                    var a = u[n];
                    return (null == t ? void 0 : t.indexOf(n)) > -1 || !!a && (null == t ? void 0 : t.indexOf(a)) > -1
                },
                l = function(e) {
                    return s(e, r.express_checkout_element_beta_1) || s(e, r.pay_button_element_beta_1) || s(e, r.elements_enable_sessions_edge)
                }
        },
        98846: function(e, t, n) {
            "use strict";
            n.d(t, {
                u: function() {
                    return l
                }
            });
            var a = n(89062),
                o = n(36617),
                r = n(71873),
                i = n(44659),
                u = window.location.hash.substring(1).split("?")[0],
                s = (0, r.ld)((0, r.mC)({
                    betas: (0, r.Wc)((0, r.CT)(r.kw.apply(void 0, (0, a.Z)(i.Lv))), (function() {
                        return []
                    }))
                }), (0, o.vB)(u), "internal"),
                l = "valid" === s.type ? s.value.betas : []
        },
        47792: function(e, t, n) {
            "use strict";
            n.d(t, {
                HX: function() {
                    return o.HX
                },
                Lv: function() {
                    return o.Lv
                },
                M4: function() {
                    return o.M4
                },
                P3: function() {
                    return r.P3
                },
                uN: function() {
                    return o.uN
                },
                ub: function() {
                    return a.u
                }
            });
            var a = n(98846),
                o = n(44659),
                r = (n(87450), n(16608))
        },
        87450: function(e, t, n) {
            "use strict";
            n(44659)
        },
        16608: function(e, t, n) {
            "use strict";
            n.d(t, {
                P3: function() {
                    return r
                }
            });
            var a, o = n(44659),
                r = [];
            a = r
        },
        74071: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ah: function() {
                    return T
                },
                D$: function() {
                    return K
                },
                D1: function() {
                    return z
                },
                G9: function() {
                    return D
                },
                Gn: function() {
                    return L
                },
                Gx: function() {
                    return J
                },
                JC: function() {
                    return W
                },
                JW: function() {
                    return C
                },
                M0: function() {
                    return H
                },
                NK: function() {
                    return $
                },
                PB: function() {
                    return F
                },
                Wt: function() {
                    return q
                },
                ZR: function() {
                    return V
                },
                aS: function() {
                    return G
                },
                cE: function() {
                    return Y
                },
                d4: function() {
                    return ae
                },
                fL: function() {
                    return X
                },
                gm: function() {
                    return B
                },
                gq: function() {
                    return oe
                },
                j3: function() {
                    return Z
                },
                jX: function() {
                    return v
                },
                pn: function() {
                    return O
                },
                q: function() {
                    return ne
                },
                q$: function() {
                    return x
                },
                s$: function() {
                    return M
                },
                sV: function() {
                    return I
                },
                tS: function() {
                    return N
                },
                x5: function() {
                    return ee
                },
                x_: function() {
                    return te
                },
                xz: function() {
                    return R
                },
                yA: function() {
                    return U
                },
                yv: function() {
                    return j
                }
            });
            var a, o = n(56274).Promise,
                r = function(e) {
                    var t, n;
                    return function() {
                        for (var a = arguments.length, o = new Array(a), r = 0; r < a; r++) o[r] = arguments[r];
                        return n && o.length === n.length && o.every((function(e, t) {
                            return e === n[t]
                        })) ? t : (n = o, t = e.apply(void 0, o))
                    }
                },
                i = r((function(e) {
                    return e ? e.toLowerCase() : ""
                })),
                u = function(e, t) {
                    return !!e && -1 !== e.indexOf(t)
                },
                s = r((function(e) {
                    return u(i(e), "edge/")
                })),
                l = function(e) {
                    return u(i(e), "edg/")
                },
                c = r((function(e) {
                    return (u(i(e), "msie") || u(i(e), "trident")) && /(MSIE ([0-9]{1,}[.0-9]{0,})|Trident\/)/i.test(e)
                })),
                p = function(e) {
                    return u(e, "SamsungBrowser")
                },
                d = function(e, t) {
                    return (u(i(e), "iphone") || m(e, t)) && !c(e)
                },
                m = function(e, t) {
                    return (u(i(e), "ipad") || u(i(e), "macintosh") && (t > 0 || "ontouchstart" in window)) && !c(e)
                },
                y = r((function(e) {
                    return u(i(e), "macintosh") || u(i(e), "iphone") || u(i(e), "ipad")
                })),
                _ = function(e, t) {
                    return y(e) && u(e, "like") && (/(iPhone|iPod|iPad).*AppleWebKit((?!.*Safari)|(.*\([^)]*like[^)]*Safari[^)]*\)))/i.test(e) || /(Macintosh).*AppleWebKit((?!.*Safari)|(.*\([^)]*like[^)]*Safari[^)]*\)))/i.test(e) && m(e, t))
                },
                b = r((function(e) {
                    return k(e) && /wv|Version\/\d+\.\d+/.test(e) && !h(e)
                })),
                h = function(e) {
                    return u(i(e), "opera mini")
                },
                f = r((function(e) {
                    return y(e) && !w(e) && /^((?!chrome|android).)*safari/i.test(e) && !p(e)
                })),
                g = function(e) {
                    return u(i(e), "firefox")
                },
                k = function(e) {
                    return u(i(e), "android") && !c(e)
                },
                v = function(e, t) {
                    return d(e, t) || k(e)
                },
                w = r((function(e) {
                    return u(i(e), "chrome/")
                })),
                A = r((function(e) {
                    return w(e) && /Chrome\/(7[4-9]|[8-9]\d+|[1-9]\d{2,})/i.test(e)
                })),
                P = "undefined" != typeof window,
                E = P ? window.navigator.maxTouchPoints : 0,
                S = P ? window.navigator.userAgent : "",
                L = (P && window.navigator.platform, s(S), l(S), s(a = S) && /Edge\/((1[0-6]\.)|0\.)/i.test(a)),
                C = c(S),
                N = function(e) {
                    return u(i(e), "msie") && /MSIE ([0-9]{1,}[.0-9]{0,})/i.test(e)
                }(S),
                T = d(S, E),
                x = (m(S, E), v(S, E)),
                I = k(S),
                B = (b(S), function(e) {
                    return u(i(e), "android 4.") && !u(i(e), "chrome") && k(e)
                }(S)),
                j = _(S, E),
                M = f(S),
                O = (function(e, t) {
                    var n = d(e, t) && /OS (1[7-9]|[2-9]\d+|[1-9]\d{2,})/i.test(e);
                    f(e) && /Version\/(1[7-9]|[2-9]\d+|[1-9]\d{2,})/i.test(e)
                }(S, E), function(e) {
                    f(e) && /Version\/(1[8-9]|[2-9]\d+|[1-9]\d{2,})/i.test(e)
                }(S), function(e, t) {
                    return f(e) && !d(e, t)
                }(S, E)),
                z = g(S),
                R = (function(e) {
                    g(e) && /Firefox\/(50|51|[0-4]?\d)([^\d]|$)/i.test(e)
                }(S), p(S)),
                D = w(S),
                U = function(e) {
                    return w(e) && (A(e) || /Chrome\/(6[6-9]|[7-9]\d+|[1-9]\d{2,})/i.test(e))
                }(S),
                q = (A(S), function(e) {
                    return u(i(e), "applewebkit/") && !u(i(e), "chrome") && !s(e) && !c(e)
                }(S)),
                Z = function(e) {
                    return u(i(e), "chrome") && !s(e)
                }(S),
                H = function(e) {
                    return u(i(e), "crios")
                }(S),
                G = function(e) {
                    return u(i(e), "fxios")
                }(S),
                F = function(e) {
                    return u(i(e), "edgios")
                }(S),
                K = function(e) {
                    return u(i(e), "electron")
                }(S),
                Y = h(S),
                V = function(e) {
                    return y(e) && !w(e) && /Macintosh.*AppleWebKit(?!.*Safari)/i.test(e)
                }(S),
                W = function(e) {
                    return u(i(e), "safari line")
                }(S),
                $ = function(e) {
                    return u(i(e), "pinterest/ios")
                }(S),
                J = (function(e) {
                    /OS 16_((\d+_?){1,2})/i.test(e)
                }(S), function(e) {
                    /OS 18_0/i.test(e)
                }(S), r((function() {
                    return M && "download" in document.createElement("a")
                }))),
                X = P && !!window.navigator.brave && "function" == typeof window.navigator.brave.isBrave,
                Q = function() {
                    return P && window.navigator && "standalone" in window.navigator && window.navigator.standalone
                },
                ee = r((function() {
                    return _(S, E) || b(S) || function(e) {
                        return u(e, "FBAN") || u(e, "FBAV")
                    }(S) || Q()
                })),
                te = r((function() {
                    return Q() || !!window.matchMedia && window.matchMedia("(display-mode: standalone)").matches
                })),
                ne = r((function() {
                    return function(e, t) {
                        return new o((function(n) {
                            if (P && f(e) && void 0 !== t) {
                                var a = "__stripe_private_mode_test";
                                try {
                                    var o = window.indexedDB && window.indexedDB.open && window.indexedDB.open(a, 1);
                                    o.onupgradeneeded = function() {
                                        var e = o.result;
                                        try {
                                            e.createObjectStore("test", {
                                                autoIncrement: !0
                                            }).put(new Blob), n(!1)
                                        } catch (e) {
                                            var t = e instanceof Error ? e.message : e;
                                            if ("string" == typeof t) {
                                                var r = /BlobURLs are not yet supported/.test(t);
                                                n(r)
                                            } else n(!1)
                                        } finally {
                                            e.close(), window.indexedDB && window.indexedDB.deleteDatabase && window.indexedDB.deleteDatabase(a)
                                        }
                                    }
                                } catch (e) {
                                    n(!1)
                                }
                            } else n(!1)
                        }))
                    }(S, E)
                })),
                ae = r((function(e) {
                    var t = i(e);
                    return u(t, "windows") ? "Windows" : u(t, "android") ? "Android" : u(t, "iphone") || u(t, "ipad") ? "iOS" : u(t, "mac os") ? "MacOS" : u(t, "cros") ? "ChromeOS" : u(t, "linux") ? "Linux" : "Other"
                })),
                oe = r((function(e) {
                    var t = i(e);
                    return p(e) ? "SamsungBrowser" : u(t, "instagram") ? "Instagram" : u(t, "firefox") ? "Firefox" : s(e) || l(e) ? "IE Edge" : c(e) ? "IE" : u(t, "fb_iab") || u(t, "fban") || u(t, "fbav") ? "Facebook" : u(t, "chrome") ? "Chrome" : u(t, "safari") ? "Safari" : "Other"
                }));
            D && ae(S)
        },
        39294: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ah: function() {
                    return a.Ah
                },
                D$: function() {
                    return a.D$
                },
                D1: function() {
                    return a.D1
                },
                Eu: function() {
                    return i.E
                },
                G9: function() {
                    return a.G9
                },
                Gn: function() {
                    return a.Gn
                },
                Gx: function() {
                    return a.Gx
                },
                JC: function() {
                    return a.JC
                },
                JW: function() {
                    return a.JW
                },
                M0: function() {
                    return a.M0
                },
                NK: function() {
                    return a.NK
                },
                PB: function() {
                    return a.PB
                },
                UT: function() {
                    return r.U
                },
                Wt: function() {
                    return a.Wt
                },
                ZR: function() {
                    return a.ZR
                },
                aS: function() {
                    return a.aS
                },
                cE: function() {
                    return a.cE
                },
                d4: function() {
                    return a.d4
                },
                fL: function() {
                    return a.fL
                },
                gG: function() {
                    return o.g
                },
                gm: function() {
                    return a.gm
                },
                gq: function() {
                    return a.gq
                },
                j3: function() {
                    return a.j3
                },
                jX: function() {
                    return a.jX
                },
                lE: function() {
                    return i.l
                },
                pn: function() {
                    return a.pn
                },
                q: function() {
                    return a.q
                },
                q$: function() {
                    return a.q$
                },
                s$: function() {
                    return a.s$
                },
                sV: function() {
                    return a.sV
                },
                tS: function() {
                    return a.tS
                },
                x5: function() {
                    return a.x5
                },
                x_: function() {
                    return a.x_
                },
                xz: function() {
                    return a.xz
                },
                yA: function() {
                    return a.yA
                },
                yv: function() {
                    return a.yv
                }
            });
            var a = n(74071),
                o = n(89949);
            if (!/^(24(00|17)|3081|3179|8022|8384)$/.test(n.j)) var r = n(65395);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var i = n(90874)
        },
        90874: function(e, t, n) {
            "use strict";
            n.d(t, {
                E: function() {
                    return a
                },
                l: function() {
                    return o
                }
            });
            var a = function() {
                    try {
                        var e, t, n;
                        return (null === (e = window) || void 0 === e || null === (t = e.navigator) || void 0 === t || null === (n = t.connection) || void 0 === n ? void 0 : n.type) || "unknown"
                    } catch (e) {
                        return "unknown"
                    }
                },
                o = function() {
                    try {
                        var e, t, n = null === (e = window) || void 0 === e || null === (t = e.navigator) || void 0 === t ? void 0 : t.connection;
                        return {
                            effectiveType: n.effectiveType,
                            rtt: n.rtt,
                            downlink: n.downlink
                        }
                    } catch (e) {
                        return {}
                    }
                }
        },
        65395: function(e, t, n) {
            "use strict";
            n.d(t, {
                U: function() {
                    return a
                }
            });
            var a = function() {
                return (window.navigator.languages || [])[0] || window.navigator.userLanguage || window.navigator.language || ""
            }
        },
        89949: function(e, t, n) {
            "use strict";
            n.d(t, {
                g: function() {
                    return o
                }
            });
            var a = n(39294),
                o = function() {
                    return !((0, a.x5)() || a.D$ || a.ZR || a.fL || a.NK || a.JC || a.PB || a.cE || window.crossOriginIsolated)
                }
        },
        12024: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    $D: function() {
                        return z
                    },
                    CE: function() {
                        return I
                    },
                    D9: function() {
                        return N
                    },
                    G: function() {
                        return s
                    },
                    Ke: function() {
                        return m
                    },
                    MR: function() {
                        return L
                    },
                    Nn: function() {
                        return x
                    },
                    Nw: function() {
                        return O
                    },
                    PM: function() {
                        return q
                    },
                    Q8: function() {
                        return k
                    },
                    RP: function() {
                        return j
                    },
                    Rb: function() {
                        return w
                    },
                    Sm: function() {
                        return h
                    },
                    TS: function() {
                        return U
                    },
                    VJ: function() {
                        return Z
                    },
                    VO: function() {
                        return y
                    },
                    VS: function() {
                        return E
                    },
                    Xy: function() {
                        return d
                    },
                    cx: function() {
                        return c
                    },
                    dq: function() {
                        return b
                    },
                    ei: function() {
                        return C
                    },
                    iO: function() {
                        return v
                    },
                    jj: function() {
                        return H
                    },
                    kg: function() {
                        return u
                    },
                    l2: function() {
                        return A
                    },
                    qh: function() {
                        return _
                    },
                    rx: function() {
                        return f
                    },
                    sE: function() {
                        return l
                    },
                    sq: function() {
                        return P
                    },
                    uu: function() {
                        return M
                    },
                    vM: function() {
                        return S
                    },
                    ve: function() {
                        return T
                    },
                    zG: function() {
                        return g
                    }
                }), /^(1580|2627|9487)$/.test(n.j)) var a = n(89062);
            var o = n(87462);
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j)) var r = n(84506);
            if (/^(2(204|449|627)|5(075|592|663)|1580|3092|3379|9487)$/.test(n.j)) var i = n(93324);
            n(56274).Promise;
            var u = function(e, t) {
                    if (e <= 0) return [];
                    for (var n = [t]; n.length < e / 2;) n = n.concat(n);
                    return n.concat(n.slice(0, e - n.length))
                },
                s = function(e, t) {
                    for (var n = -1, a = null == e ? 0 : e.length; ++n < a;)
                        if (t(e[n])) return !0;
                    return !1
                },
                l = function(e, t) {
                    for (var n = 0; n < e.length; n++)
                        if (t(e[n])) return e[n]
                },
                c = function(e, t) {
                    for (var n = 0; n < e.length; n++)
                        if (t(e[n])) return n;
                    return -1
                },
                p = "[object Object]",
                d = function e(t, n) {
                    if ("object" != typeof t || "object" != typeof n) return t === n;
                    if (null === t || null === n) return t === n;
                    var a = Array.isArray(t);
                    if (a !== Array.isArray(n)) return !1;
                    var o = Object.prototype.toString.call(t) === p;
                    if (o !== (Object.prototype.toString.call(n) === p)) return !1;
                    if (!o && !a) return !1;
                    var r = Object.keys(t),
                        i = Object.keys(n);
                    if (r.length !== i.length) return !1;
                    for (var u = {}, s = 0; s < r.length; s++) u[r[s]] = !0;
                    for (var l = 0; l < i.length; l++) u[i[l]] = !0;
                    var c = Object.keys(u);
                    if (c.length !== r.length) return !1;
                    var d = t,
                        m = n;
                    return c.every((function(t) {
                        return e(d[t], m[t])
                    }))
                },
                m = function(e) {
                    return Object.keys(e)
                },
                y = function(e) {
                    return Object.keys(e).map((function(t) {
                        return e[t]
                    }))
                },
                _ = function(e) {
                    return m(e).map((function(t) {
                        return [t, e[t]]
                    }))
                },
                b = function(e, t) {
                    for (var n = {}, a = 0; a < t.length; a++) n[t[a]] = !0;
                    for (var o = [], r = 0; r < e.length; r++) n[e[r]] && o.push(e[r]);
                    return o
                },
                h = function(e) {
                    for (var t = 0, n = 0; n < e.length; n++) t += e[n];
                    return t
                },
                f = function(e, t) {
                    for (var n = "", a = 0; a < t; a++) n += e;
                    return n
                },
                g = function(e) {
                    return e.reduce((function(e, t) {
                        return e.concat(t)
                    }), [])
                },
                k = function(e, t) {
                    for (var n = {}, a = Object.keys(e), o = 0; o < a.length; o++) n[a[o]] = t(e[a[o]], a[o]);
                    return n
                },
                v = function(e, t) {
                    return k(e, t)
                },
                w = function(e, t) {
                    var n = t.split(".");
                    return k(e, (function(e) {
                        for (var t = e, a = 0; a < n.length; a++) {
                            var o = n[a];
                            if ("object" != typeof t) return;
                            t = t[o]
                        }
                        return t
                    }))
                },
                A = function e(t, n) {
                    if (Array.isArray(t)) {
                        for (var a = new Array(t.length), o = 0; o < t.length; o++) a[o] = B(t[o]) ? e(t[o], n) : n(o, t[o]);
                        return a
                    }
                    for (var r = {}, i = Object.keys(t), u = 0; u < i.length; u++) r[i[u]] = B(t[i[u]]) ? e(t[i[u]], n) : n(i[u], t[i[u]]);
                    return r
                },
                P = function(e) {
                    for (var t = {}, n = 0; n < e.length; n++) {
                        var a = (0, i.Z)(e[n], 2),
                            o = a[0],
                            r = a[1];
                        t[o] = r
                    }
                    return t
                },
                E = function(e, t) {
                    return e.map(t).reduce((function(e, t) {
                        return e.concat(t)
                    }), [])
                },
                S = function(e, t) {
                    return e.reduce((function(e, n) {
                        var a = t(n);
                        return e.hasOwnProperty(a) ? e[a].push(n) : e[a] = [n], e
                    }), {})
                },
                L = function(e, t) {
                    return e.sort((function(e, n) {
                        var a = t(e),
                            o = t(n);
                        return a > o ? 1 : o > a ? -1 : 0
                    }))
                },
                C = function(e, t) {
                    for (var n = {}, a = 0; a < t.length; a++) void 0 !== e[t[a]] && (n[t[a]] = e[t[a]]);
                    return n
                },
                N = function(e, t) {
                    for (var n = {}, a = Object.keys(e), o = 0; o < a.length; o++) t(a[o], e[a[o]]) && (n[a[o]] = e[a[o]]);
                    return n
                },
                T = function(e, t) {
                    return N(e, (function(e, n) {
                        return n === t
                    }))
                },
                x = function(e, t) {
                    return N(e, (function(e, n) {
                        return n !== t
                    }))
                },
                I = function(e, t) {
                    return N(e, (function(e) {
                        return -1 === t.indexOf(e)
                    }))
                },
                B = function(e) {
                    return e && "object" == typeof e && (e.constructor === Array || e.constructor === Object)
                },
                j = function(e) {
                    return "" === e ? [e] : e.replace(/\[/g, ".").replace(/\]/g, "").split(".")
                },
                M = function e(t, n) {
                    var a = "string" == typeof n ? j(n) : n;
                    if (!a.length) return t;
                    if (null != t) {
                        var o = (0, r.Z)(a),
                            i = o[0],
                            u = o.slice(1);
                        return e(t[i], u)
                    }
                },
                O = function e(t, n, a) {
                    var o = "string" == typeof a ? j(a) : a;
                    if (0 === o.length) return t;
                    if (1 === o.length) return t[a[0]] = n, t;
                    var i = (0, r.Z)(o),
                        u = i[0],
                        s = i.slice(1);
                    return t[u] = e(t[u] || {}, n, s), t
                },
                z = function e(t, n) {
                    var a = "string" == typeof n ? j(n) : n,
                        o = (0, r.Z)(a),
                        i = o[0],
                        u = o.slice(1);
                    return !!t && (1 === a.length && t.hasOwnProperty(i) ? (delete t[i], !0) : !!(a.length > 1 && t.hasOwnProperty(i)) && e(t[i], u))
                },
                R = function(e) {
                    return B(e) ? Array.isArray(e) ? e.slice(0, e.length) : (0, o.Z)({}, e) : e
                },
                D = function e(t) {
                    return function() {
                        for (var n = arguments.length, a = new Array(n), o = 0; o < n; o++) a[o] = arguments[o];
                        if (Array.isArray(a[0]) && t) return R(a[0]);
                        var r = Array.isArray(a[0]) ? [] : {};
                        return a.forEach((function(n) {
                            n && Object.keys(n).forEach((function(a) {
                                var o = r[a],
                                    i = n[a],
                                    u = B(o) && !(t && Array.isArray(o));
                                "object" == typeof i && u ? r[a] = e(t)(o, R(i)) : void 0 !== i ? r[a] = B(i) ? e(t)(i) : R(i) : void 0 !== o && (r[a] = o)
                            }))
                        })), r
                    }
                },
                U = D(!1),
                q = D(!0),
                Z = function(e) {
                    return k(e, (function(e) {
                        return "string" == typeof e ? e.trim() : e
                    }))
                },
                H = function(e, t) {
                    return e.reduce((function(e, n) {
                        var o = e.accum,
                            r = e.seen,
                            i = t ? t(n) : n;
                        return -1 !== r.indexOf(i) ? {
                            accum: o,
                            seen: r
                        } : {
                            accum: [].concat((0, a.Z)(o), [n]),
                            seen: [].concat((0, a.Z)(r), [i])
                        }
                    }), {
                        seen: [],
                        accum: []
                    }).accum
                }
        },
        95305: function(e, t, n) {
            "use strict";
            n.d(t, {
                Y: function() {
                    return a
                }
            });
            var a = {
                card: "card",
                cardNumber: "cardNumber",
                cardExpiry: "cardExpiry",
                cardCvc: "cardCvc",
                postalCode: "postalCode",
                iban: "iban",
                idealBank: "idealBank",
                p24Bank: "p24Bank",
                paymentRequestButton: "paymentRequestButton",
                auBankAccount: "auBankAccount",
                fpxBank: "fpxBank",
                netbankingBank: "netbankingBank",
                epsBank: "epsBank",
                affirmMessage: "affirmMessage",
                afterpayClearpayMessage: "afterpayClearpayMessage",
                unifiedMessage: "unifiedMessage",
                paymentMethodMessaging: "paymentMethodMessaging",
                linkAuthentication: "linkAuthentication",
                payment: "payment",
                shippingAddress: "shippingAddress",
                address: "address",
                expressCheckout: "expressCheckout",
                payButton: "payButton",
                currencySelector: "currencySelector",
                idealBankSecondary: "idealBankSecondary",
                p24BankSecondary: "p24BankSecondary",
                auBankAccountNumber: "auBankAccountNumber",
                auBsb: "auBsb",
                fpxBankSecondary: "fpxBankSecondary",
                netbankingBankSecondary: "netbankingBankSecondary",
                issuingCardNumberDisplay: "issuingCardNumberDisplay",
                issuingCardCopyButton: "issuingCardCopyButton",
                issuingCardCvcDisplay: "issuingCardCvcDisplay",
                issuingCardExpiryDisplay: "issuingCardExpiryDisplay",
                issuingCardPinDisplay: "issuingCardPinDisplay",
                epsBankSecondary: "epsBankSecondary",
                affirmMessageModal: "affirmMessageModal",
                afterpayClearpayMessageModal: "afterpayClearpayMessageModal",
                paymentMethodMessagingLegacyModal: "paymentMethodMessagingLegacyModal",
                paymentMethodMessagingModal: "paymentMethodMessagingModal",
                autocompleteSuggestions: "autocompleteSuggestions",
                achBankSearchResults: "achBankSearchResults",
                linkInfoModal: "linkInfoModal",
                loaderUi: "loaderUi",
                linkPurchaseProtectionModal: "linkPurchaseProtectionModal",
                linkModal: "linkModal",
                prbWarningModal: "prbWarningModal"
            }
        },
        45214: function(e, t, n) {
            "use strict";
            n.d(t, {
                U: function() {
                    return a
                }
            });
            var a = ["US", "CA", "GB"]
        },
        63088: function(e, t, n) {
            "use strict";
            n.d(t, {
                s: function() {
                    return o
                }
            });
            var a = n(95305),
                o = [a.Y.card, a.Y.cardNumber, a.Y.cardExpiry, a.Y.cardCvc, a.Y.postalCode]
        },
        64233: function(e, t, n) {
            "use strict";
            var a = n(89062),
                o = n(45214);
            [].concat((0, a.Z)(o.U), ["IN", "UA"])
        },
        32631: function(e, t, n) {
            "use strict";
            n.d(t, {
                CU: function() {
                    return v
                },
                DU: function() {
                    return S
                },
                Dw: function() {
                    return g
                },
                Ft: function() {
                    return k
                },
                Gu: function() {
                    return A
                },
                Ht: function() {
                    return l
                },
                K8: function() {
                    return m
                },
                L$: function() {
                    return f
                },
                P4: function() {
                    return h
                },
                QL: function() {
                    return p
                },
                T2: function() {
                    return d
                },
                Wj: function() {
                    return E
                },
                Xk: function() {
                    return i
                },
                ZJ: function() {
                    return b
                },
                aj: function() {
                    return N
                },
                iw: function() {
                    return _
                },
                jQ: function() {
                    return s
                },
                kE: function() {
                    return c
                },
                kX: function() {
                    return C
                },
                nU: function() {
                    return w
                },
                oj: function() {
                    return L
                },
                rM: function() {
                    return y
                },
                yN: function() {
                    return P
                }
            });
            var a = n(1413),
                o = n(36617),
                r = n(95305),
                i = "https://js.stripe.com/v3/",
                u = (0, o.Ds)(i),
                s = u ? u.origin : "",
                l = 3097 == n.j ? "https://verify.stripe.com/" : null,
                c = {
                    PAYMENT_INTENT: "PAYMENT_INTENT",
                    SETUP_INTENT: "SETUP_INTENT"
                },
                p = {
                    family: "font-family",
                    src: "src",
                    unicodeRange: "unicode-range",
                    style: "font-style",
                    variant: "font-variant",
                    stretch: "font-stretch",
                    weight: "font-weight",
                    display: "font-display"
                },
                d = (Object.keys(p).reduce((function(e, t) {
                    return e[p[t]] = t, e
                }), {}), [r.Y.issuingCardCopyButton, r.Y.idealBank, r.Y.p24Bank, r.Y.netbankingBank, r.Y.idealBankSecondary, r.Y.p24BankSecondary, r.Y.netbankingBankSecondary, r.Y.fpxBank, r.Y.fpxBankSecondary, r.Y.epsBank, r.Y.epsBankSecondary]),
                m = Object.keys({
                    visa: "visa",
                    amex: "amex",
                    discover: "discover",
                    mastercard: "mastercard",
                    jcb: "jcb",
                    diners: "diners",
                    unionpay: "unionpay",
                    elo: "elo",
                    unknown: "unknown"
                }),
                y = {
                    VISA: "visa",
                    MASTERCARD: "mastercard",
                    AMEX: "amex",
                    DISCOVER: "discover",
                    JCB: "jcb",
                    DINERS: "diners",
                    UNIONPAY: "unionpay",
                    ELO: "elo"
                },
                _ = Object.keys(y).map((function(e) {
                    return y[e]
                })),
                b = (0, a.Z)((0, a.Z)({}, y), {}, {
                    MAESTRO: "maestro",
                    CARTES_BANCAIRES: "cartes_bancaires",
                    INTERAC: "interac"
                }),
                h = Object.keys(b).map((function(e) {
                    return b[e]
                })),
                f = /^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j) ? null : "https://api.stripe.com/v1/",
                g = /^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j) ? null : "https://merchant-ui-api.stripe.com/",
                k = /^(1580|2627|9487)$/.test(n.j) ? "https://ppm.stripe.com/" : null,
                v = /^[^\s<>@]+@[^\s<>@.]+(\.[a-zA-Z0-9-]+)+$/,
                w = /^(2449|7047|9487)$/.test(n.j) ? ["gmail.com", "hotmail.com", "yahoo.com", "hotmail.co.uk", "icloud.com", "outlook.com", "live.com", "comcast.net", "yahoo.co.uk", "aol.com", "hotmail.fr", "yahoo.com.br", "outook.com", "email.com", "provlst.com", "orange.fr", "btinternet.com", "googlemail.com", "me.com", "yahoo.fr", "naver.com", "libero.it", "hotmail.it", "live.co.uk", "mail.ru", "yahoo.co.jp", "msn.com", "wp.pl", "gmx.de", "qq.com", "sky.com", "web.de", "docomo.ne.jp", "wanadoo.fr", "seznam.cz", "ezweb.ne.jp", "free.fr", "ymail.com", "yahoo.it", "outlook.fr", "live.fr", "yandex.ru", "mac.com", "laposte.net", "protonmail.com", "i.softbank.jp", "yahoo.com.hk", "sbcglobal.net", "o2.pl", "t-online.de", "yahoo.com.sg", "hey.com", "stripe.com", "att.net", "bigpond.com", "verizon.net", "bellsouth.net", "cox.net", "gmx.at", "bluewin.ch", "yahoo.ca", "rocketmail.com", "op.pl", "onet.pl", "interia.pl"] : null,
                A = /^(2449|9487)$/.test(n.j) ? ["ai"] : null,
                P = {
                    com: !0,
                    "co.uk": !0,
                    net: !0,
                    fr: !0,
                    edu: !0,
                    org: !0,
                    it: !0,
                    de: !0,
                    ru: !0,
                    ca: !0,
                    "co.jp": !0,
                    "appleid.com": !0,
                    pl: !0,
                    es: !0,
                    cz: !0,
                    "ne.jp": !0,
                    se: !0,
                    ch: !0,
                    ie: !0,
                    "com.au": !0,
                    "com.br": !0,
                    "com.mx": !0,
                    "com.sg": !0,
                    "com.tw": !0,
                    "com.ar": !0,
                    "com.hk": !0
                },
                E = 5,
                S = 5,
                L = function(e) {
                    return e.ECB = "ecb", e
                }({}),
                C = .02,
                N = 2
        },
        64624: function(e, t, n) {
            "use strict";
            n.d(t, {
                Cm: function() {
                    return s
                },
                D3: function() {
                    return i
                },
                Jl: function() {
                    return l
                },
                Lt: function() {
                    return u
                },
                R8: function() {
                    return a
                },
                Sw: function() {
                    return r
                },
                wE: function() {
                    return o
                }
            });
            var a = "Experiment control",
                o = "Not In Experiment",
                r = "Non Link related error",
                i = {
                    elements_session: "elements_session",
                    elements_assignment: "elements_assignment"
                },
                u = {
                    elements_session: 432e5,
                    elements_assignment: 7776e6
                },
                s = "elements_mulberry_purchase_protections",
                l = 2204 == n.j ? ["distinctly_link_payment_element_m1"] : null
        },
        60276: function(e, t, n) {
            "use strict";
            n.d(t, {
                CU: function() {
                    return i.CU
                },
                Cm: function() {
                    return u.Cm
                },
                D3: function() {
                    return u.D3
                },
                DU: function() {
                    return i.DU
                },
                Dw: function() {
                    return i.Dw
                },
                Ft: function() {
                    return i.Ft
                },
                Gu: function() {
                    return i.Gu
                },
                Ht: function() {
                    return i.Ht
                },
                Jl: function() {
                    return u.Jl
                },
                K8: function() {
                    return i.K8
                },
                L$: function() {
                    return i.L$
                },
                Lt: function() {
                    return u.Lt
                },
                P4: function() {
                    return i.P4
                },
                QL: function() {
                    return i.QL
                },
                R8: function() {
                    return u.R8
                },
                Sw: function() {
                    return u.Sw
                },
                T2: function() {
                    return i.T2
                },
                UQ: function() {
                    return r.U
                },
                Wj: function() {
                    return i.Wj
                },
                Xk: function() {
                    return i.Xk
                },
                Yj: function() {
                    return a.Y
                },
                ZJ: function() {
                    return i.ZJ
                },
                aj: function() {
                    return i.aj
                },
                iw: function() {
                    return i.iw
                },
                jQ: function() {
                    return i.jQ
                },
                kE: function() {
                    return i.kE
                },
                kX: function() {
                    return i.kX
                },
                nU: function() {
                    return i.nU
                },
                oj: function() {
                    return i.oj
                },
                rM: function() {
                    return i.rM
                },
                sL: function() {
                    return o.s
                },
                wE: function() {
                    return u.wE
                },
                yN: function() {
                    return i.yN
                }
            });
            var a = n(95305),
                o = n(63088);
            if (/^(1(180|283|789)|2(204|29|449)|5(194|592|815|941)|94(11|87)|3033|3607|4110|4784|8285|8308)$/.test(n.j)) var r = n(45214);
            n(64233);
            var i = n(32631),
                u = n(64624)
        },
        24020: function(e, t, n) {
            "use strict";
            n.d(t, {
                Fe: function() {
                    return u
                },
                li: function() {
                    return r
                },
                mo: function() {
                    return i
                }
            });
            var a = {
                    bif: 1,
                    clp: 1,
                    djf: 1,
                    gnf: 1,
                    jpy: 1,
                    kmf: 1,
                    krw: 1,
                    mga: 1,
                    pyg: 1,
                    rwf: 1,
                    vnd: 1,
                    vuv: 1,
                    xaf: 1,
                    xof: 1,
                    xpf: 1,
                    bhd: 1e3,
                    jod: 1e3,
                    kwd: 1e3,
                    omr: 1e3,
                    tnd: 1e3
                },
                o = /^(4505|5075|7297)$/.test(n.j) ? ["cop", "idr", "lbp", "pkr"] : null,
                r = function(e) {
                    return Boolean(a[e])
                },
                i = function(e) {
                    var t = a[e.toLowerCase()] || 100;
                    return {
                        unitSize: 1 / t,
                        fractionDigits: Math.ceil(Math.log(t) / Math.log(10))
                    }
                },
                u = function(e, t, n) {
                    var a = function(e, t) {
                            var n = i(t);
                            return {
                                result: e * n.unitSize,
                                fractionDigits: n.fractionDigits
                            }
                        }(e, t),
                        r = a.result,
                        u = a.fractionDigits;
                    return "apple" === n && -1 !== o.indexOf(t) ? Math.ceil(r).toString() : "google" === n ? r.toFixed(u > 2 ? 2 : u) : r.toFixed(u)
                }
        },
        56241: function(e, t, n) {
            "use strict";
            n.d(t, {
                Fe: function() {
                    return a.Fe
                },
                QT: function() {
                    return o.Q
                },
                li: function() {
                    return a.li
                },
                mo: function() {
                    return a.mo
                }
            });
            var a = n(24020),
                o = n(60462)
        },
        60462: function(e, t, n) {
            "use strict";
            n.d(t, {
                Q: function() {
                    return o
                }
            });
            var a = {
                    aed: "aed",
                    afn: "afn",
                    all: "all",
                    amd: "amd",
                    ang: "ang",
                    aoa: "aoa",
                    ars: "ars",
                    aud: "aud",
                    awg: "awg",
                    azn: "azn",
                    bam: "bam",
                    bbd: "bbd",
                    bdt: "bdt",
                    bgn: "bgn",
                    bhd: "bhd",
                    bif: "bif",
                    bmd: "bmd",
                    bnd: "bnd",
                    bob: "bob",
                    brl: "brl",
                    bsd: "bsd",
                    btn: "btn",
                    bwp: "bwp",
                    byn: "byn",
                    byr: "byr",
                    bzd: "bzd",
                    cad: "cad",
                    cdf: "cdf",
                    chf: "chf",
                    clf: "clf",
                    clp: "clp",
                    cny: "cny",
                    cop: "cop",
                    crc: "crc",
                    cuc: "cuc",
                    cup: "cup",
                    cve: "cve",
                    czk: "czk",
                    djf: "djf",
                    dkk: "dkk",
                    dop: "dop",
                    dzd: "dzd",
                    egp: "egp",
                    ern: "ern",
                    etb: "etb",
                    eur: "eur",
                    fjd: "fjd",
                    fkp: "fkp",
                    gbp: "gbp",
                    gel: "gel",
                    ghs: "ghs",
                    gip: "gip",
                    gmd: "gmd",
                    gnf: "gnf",
                    gtq: "gtq",
                    gyd: "gyd",
                    hkd: "hkd",
                    hnl: "hnl",
                    htg: "htg",
                    huf: "huf",
                    idr: "idr",
                    ils: "ils",
                    inr: "inr",
                    iqd: "iqd",
                    irr: "irr",
                    isk: "isk",
                    jmd: "jmd",
                    jod: "jod",
                    jpy: "jpy",
                    kes: "kes",
                    kgs: "kgs",
                    khr: "khr",
                    kmf: "kmf",
                    kpw: "kpw",
                    krw: "krw",
                    kwd: "kwd",
                    kyd: "kyd",
                    kzt: "kzt",
                    lak: "lak",
                    lbp: "lbp",
                    lkr: "lkr",
                    lrd: "lrd",
                    lsl: "lsl",
                    ltl: "ltl",
                    lvl: "lvl",
                    lyd: "lyd",
                    mad: "mad",
                    mdl: "mdl",
                    mga: "mga",
                    mkd: "mkd",
                    mmk: "mmk",
                    mnt: "mnt",
                    mop: "mop",
                    mro: "mro",
                    mur: "mur",
                    mvr: "mvr",
                    mwk: "mwk",
                    mxn: "mxn",
                    myr: "myr",
                    mzn: "mzn",
                    nad: "nad",
                    ngn: "ngn",
                    nio: "nio",
                    nok: "nok",
                    npr: "npr",
                    nzd: "nzd",
                    omr: "omr",
                    pab: "pab",
                    pen: "pen",
                    pgk: "pgk",
                    php: "php",
                    pkr: "pkr",
                    pln: "pln",
                    pyg: "pyg",
                    qar: "qar",
                    ron: "ron",
                    rsd: "rsd",
                    rub: "rub",
                    rwf: "rwf",
                    sar: "sar",
                    sbd: "sbd",
                    scr: "scr",
                    sdg: "sdg",
                    sek: "sek",
                    sgd: "sgd",
                    shp: "shp",
                    skk: "skk",
                    sll: "sll",
                    sos: "sos",
                    srd: "srd",
                    ssp: "ssp",
                    std: "std",
                    svc: "svc",
                    syp: "syp",
                    szl: "szl",
                    thb: "thb",
                    tjs: "tjs",
                    tmt: "tmt",
                    tnd: "tnd",
                    top: "top",
                    try: "try",
                    ttd: "ttd",
                    twd: "twd",
                    tzs: "tzs",
                    uah: "uah",
                    ugx: "ugx",
                    usd: "usd",
                    uyu: "uyu",
                    uzs: "uzs",
                    vef: "vef",
                    vnd: "vnd",
                    vuv: "vuv",
                    wst: "wst",
                    xaf: "xaf",
                    xag: "xag",
                    xau: "xau",
                    xcd: "xcd",
                    xdr: "xdr",
                    xof: "xof",
                    xpf: "xpf",
                    yer: "yer",
                    zar: "zar",
                    zmk: "zmk",
                    zmw: "zmw",
                    btc: "btc",
                    jep: "jep",
                    eek: "eek",
                    ghc: "ghc",
                    mtl: "mtl",
                    tmm: "tmm",
                    yen: "yen",
                    zwd: "zwd",
                    zwl: "zwl",
                    zwn: "zwn",
                    zwr: "zwr"
                },
                o = Object.keys(a)
        },
        11696: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    B: function() {
                        return i
                    }
                }), !/^(2760|6364|8889)$/.test(n.j)) var a = n(15671);
            if (!/^(2760|6364|8889)$/.test(n.j)) var o = n(43144);
            var r = n(56274).Promise,
                i = /^(2760|6364|8889)$/.test(n.j) ? null : function() {
                    function e() {
                        var t = this;
                        (0, a.Z)(this, e), this._state = "pending", this._state = "pending", this.promise = new r((function(e, n) {
                            t._resolve = e, t._reject = n
                        })), this.promise.then((function() {
                            t._state = "resolved"
                        }), (function() {
                            t._state = "rejected"
                        }))
                    }
                    return (0, o.Z)(e, [{
                        key: "resolve",
                        value: function(e) {
                            this._resolve(e)
                        }
                    }, {
                        key: "reject",
                        value: function(e) {
                            this._reject(e)
                        }
                    }, {
                        key: "isResolved",
                        value: function() {
                            return "resolved" === this._state
                        }
                    }, {
                        key: "isRejected",
                        value: function() {
                            return "rejected" === this._state
                        }
                    }, {
                        key: "isPending",
                        value: function() {
                            return "pending" === this._state
                        }
                    }]), e
                }()
        },
        4663: function(e, t, n) {
            "use strict";
            n.d(t, {
                B: function() {
                    return a.B
                }
            });
            var a = n(11696)
        },
        30133: function(e, t, n) {
            "use strict";
            n.d(t, {
                rt: function() {
                    return u
                }
            });
            n(24245), n(12024);
            if (/^(2449|3092|3379|9487)$/.test(n.j)) var a = n(48357);
            var o = "a[href], area[href], input:not([disabled]),\n  select:not([disabled]), textarea:not([disabled]), button:not([disabled]),\n  object, embed, *[tabindex], *[contenteditable]",
                r = "".concat(o, ', iframe[name^="__privateStripeFrame"]'),
                i = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = e.includeStripeIframes;
                    return Array.prototype.slice.call(document.querySelectorAll(t ? r : o)).filter((function(e) {
                        if ("IFRAME" === e.tagName && e === document.activeElement) return !1;
                        var t = e.getAttribute("tabindex"),
                            n = !t || parseInt(t, 10) >= 0,
                            o = e.getBoundingClientRect(),
                            r = (0, a.D)(e),
                            i = o.width > 0 && o.height > 0 && r && "hidden" !== r.getPropertyValue("visibility");
                        return n && i
                    }))
                },
                u = function() {
                    return i().filter((function(e) {
                        return ["input", "textarea", "select"].indexOf(e.nodeName.toLowerCase()) > -1 && -1 === ["checkbox", "radio"].indexOf((e.getAttribute("type") || "").toLowerCase())
                    }))
                }
        },
        67855: function(e, t, n) {
            "use strict";
            n.d(t, {
                T: function() {
                    return r
                }
            });
            var a = n(36617),
                o = n(43534),
                r = function(e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "self";
                    if ("https" !== (0, a.Ev)(e)) throw new Error("Invalid form URL.");
                    var r = document.createElement("form");
                    r.setAttribute("method", "POST"), r.setAttribute("action", e), r.setAttribute("target", n), Object.keys(t).forEach((function(e) {
                        var n = document.createElement("input");
                        n.setAttribute("type", "hidden"), n.setAttribute("name", e), n.setAttribute("value", t[e]), r.appendChild(n)
                    }));
                    var i = (0, o.Xq)();
                    i.appendChild(r), r.submit(), i.removeChild(r)
                }
        },
        43534: function(e, t, n) {
            "use strict";
            n.d(t, {
                Hb: function() {
                    return u
                },
                Ql: function() {
                    return l
                },
                SV: function() {
                    return i
                },
                Xq: function() {
                    return s
                },
                yq: function() {
                    return o
                }
            });
            var a = n(18812),
                o = (n(24245), function(e, t) {
                    e.style.cssText = Object.keys(t).map((function(e) {
                        return "".concat(e, ": ").concat(t[e], " !important;")
                    })).join(" ")
                }),
                r = {
                    border: "none",
                    margin: "0",
                    padding: "0",
                    width: "1px",
                    "min-width": "100%",
                    overflow: "hidden",
                    display: "block",
                    visibility: "hidden",
                    position: "fixed",
                    height: "1px",
                    "pointer-events": "none",
                    "user-select": "none"
                },
                i = function(e) {
                    o(e, r)
                },
                u = function(e) {
                    try {
                        return window.parent.frames[e]
                    } catch (e) {
                        return null
                    }
                },
                s = function() {
                    if (!document.body) throw new a.No("Stripe.js requires that your page has a <body> element.");
                    return document.body
                },
                l = function(e) {
                    return setTimeout(e, 16)
                }
        },
        32583: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    Dx: function() {
                        return i.D
                    },
                    Hb: function() {
                        return u.Hb
                    },
                    Ql: function() {
                        return u.Ql
                    },
                    TT: function() {
                        return r.T
                    },
                    Tf: function() {
                        return a.Tf
                    },
                    jN: function() {
                        return s.j
                    },
                    rt: function() {
                        return o.rt
                    },
                    yq: function() {
                        return u.yq
                    }
                }), /^(1(180|283|789)|5(194|815|941)|229|3033|3607|4110|4784|8285|8308|9411)$/.test(n.j)) var a = n(89608);
            var o = n(30133),
                r = n(67855);
            if (/^(5(075|592|663)|1580|2449|2627|3092|3379|9487)$/.test(n.j)) var i = n(48357);
            var u = n(43534),
                s = (n(23765), n(2723), n(54544))
        },
        54544: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    j: function() {
                        return o
                    }
                }), /^(2449|6364|9487)$/.test(n.j)) var a = n(93324);
            var o = function(e, t) {
                    if (!IntersectionObserver) return t(!1),
                        function() {};
                    var n = new IntersectionObserver((function(e) {
                        var n, o = (0, a.Z)(e, 1)[0];
                        n = "isVisible" in o && (o.isVisible && o.isIntersecting), t(n)
                    }), r);
                    n.observe(e);
                    return function() {
                        n.unobserve(e)
                    }
                },
                r = {
                    root: null,
                    rootMargin: "0px",
                    threshold: 0,
                    trackVisibility: !0,
                    delay: 500
                }
        },
        39987: function(e, t, n) {
            "use strict";
            n.d(t, {
                E: function() {
                    return a
                }
            });
            var a = function(e) {
                "complete" === document.readyState || "interactive" === document.readyState ? setTimeout(e, 1) : document.addEventListener("DOMContentLoaded", e)
            }
        },
        23765: function(e, t, n) {
            "use strict";
            n(24245), n(43534), n(39294)
        },
        2723: function(e, t, n) {
            "use strict";
            n(56274).Promise
        },
        57947: function(e, t, n) {
            "use strict";
            n.d(t, {
                e: function() {
                    return r
                },
                o: function() {
                    return i
                }
            });
            var a, o = n(4942),
                r = {
                    DEFAULT: "DEFAULT",
                    ELEMENTS: "ELEMENTS",
                    CONTROLLER: "CONTROLLER",
                    SDK: "SDK",
                    WEBAUTHN: "WEBAUTHN",
                    CONNECTIONS: "CONNECTIONS"
                },
                i = (a = {}, (0, o.Z)(a, r.DEFAULT, "https://e473f68ec35a484cb7f83899ae4f576d@errors.stripe.com/976"), (0, o.Z)(a, r.ELEMENTS, "https://198453e0cdc24c5ca470767075dba88d@errors.stripe.com/977"), (0, o.Z)(a, r.CONTROLLER, "https://76b49ff5e43c4910b429f557acde2bfd@errors.stripe.com/978"), (0, o.Z)(a, r.SDK, "https://c736ae64298f402f97218af93e3e0989@errors.stripe.com/914"), (0, o.Z)(a, r.WEBAUTHN, "https://20f53591733d415ea088036b8e8ad0e3@errors.stripe.com/980"), (0, o.Z)(a, r.CONNECTIONS, "https://0413044039f446ed806d8c6805dbbd83@errors.stripe.com/1206"), a)
        },
        70136: function(e, t, n) {
            "use strict";
            n.d(t, {
                QO: function() {
                    return a.e
                },
                Tb: function() {
                    return o.T
                },
                uT: function() {
                    return o.u
                }
            });
            var a = n(57947),
                o = n(80538)
        },
        80538: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    T: function() {
                        return l
                    },
                    u: function() {
                        return c
                    }
                }), /^(2204|4928|7047|805)$/.test(n.j)) var a = n(73423);
            var o = n(57947),
                r = n(56274).Promise,
                i = function(e) {
                    return o.o[e]
                },
                u = {},
                s = function(e) {
                    return u[e] ? r.resolve(u[e]) : r.all([n.e(1072), n.e(2897)]).then(n.bind(n, 53562)).then((function(t) {
                        var n = new t.BrowserClient({
                                dsn: e,
                                release: a.l,
                                environment: "prod",
                                defaultIntegrations: !1,
                                integrations: [new t.UserAgent]
                            }),
                            o = new t.Hub(n);
                        return u[e] = o, o
                    }))
                },
                l = function(e) {
                    var t = e.app,
                        n = e.exception,
                        a = e.hint;
                    return new r((function(e) {
                        return s(i(t)).then((function(t) {
                            return t.run((function(t) {
                                return e(t.captureException(n, a))
                            }))
                        })).catch((function() {
                            return e(void 0)
                        }))
                    }))
                },
                c = function(e) {
                    var t = e.app,
                        n = e.message,
                        a = e.level,
                        o = e.hint;
                    return new r((function(e) {
                        return s(i(t)).then((function(t) {
                            return t.run((function(t) {
                                return e(t.captureMessage(n, a, o))
                            }))
                        })).catch((function() {
                            return e(void 0)
                        }))
                    }))
                }
        },
        54086: function(e, t, n) {
            "use strict";
            n.d(t, {
                k: function() {
                    return u
                }
            });
            var a = n(43144),
                o = n(15671),
                r = n(60136),
                i = n(29388),
                u = function(e) {
                    function t(e, a) {
                        var r;
                        return (0, o.Z)(this, t), (r = n.call(this)).name = "FetchError", r.type = "fetch_error", r.message = "Error fetching ".concat(a), r.requestUrl = a, "string" == typeof e ? r.message += ": ".concat(e) : (r.originalError = e, r.message += ": ".concat(e.message)), r
                    }(0, r.Z)(t, e);
                    var n = (0, i.Z)(t);
                    return (0, a.Z)(t)
                }((0, n(7112).Z)(Error))
        },
        83973: function(e, t, n) {
            "use strict";
            n.d(t, {
                N: function() {
                    return s
                }
            });
            var a = n(43144),
                o = n(15671),
                r = n(97326),
                i = n(60136),
                u = n(29388),
                s = function(e) {
                    function t(e) {
                        var a;
                        return (0, o.Z)(this, t), a = n.call(this, e), window.__stripeElementsController && window.__stripeElementsController.reportIntegrationError(e), a.name = "IntegrationError", Object.defineProperty((0, r.Z)(a), "message", {
                            value: a.message,
                            enumerable: !0
                        }), a
                    }(0, i.Z)(t, e);
                    var n = (0, u.Z)(t);
                    return (0, a.Z)(t)
                }((0, n(7112).Z)(Error))
        },
        28102: function(e, t, n) {
            "use strict";
            var a = n(43144),
                o = n(15671),
                r = n(60136),
                i = n(29388);
            Error
        },
        60051: function(e, t, n) {
            "use strict";
            n.d(t, {
                F: function() {
                    return u
                }
            });
            var a = n(43144),
                o = n(15671),
                r = n(60136),
                i = n(29388),
                u = function(e) {
                    function t(e) {
                        var a;
                        return (0, o.Z)(this, t), (a = n.call(this, e)).name = "NetworkError", a.type = "network_error", a.requestUrl = e, a
                    }(0, r.Z)(t, e);
                    var n = (0, i.Z)(t);
                    return (0, a.Z)(t)
                }((0, n(7112).Z)(Error))
        },
        18812: function(e, t, n) {
            "use strict";
            n.d(t, {
                F7: function() {
                    return r.F
                },
                No: function() {
                    return o.N
                },
                kp: function() {
                    return a.k
                }
            });
            var a = n(54086),
                o = n(83973),
                r = (n(28102), n(60051))
        },
        75005: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    h: function() {
                        return i
                    }
                }), !/^(2(400|417|675)|4(2|505|928)|8(022|161|218|384)|3081|3179|7297)$/.test(n.j)) var a = n(1413);
            var o = n(37647),
                r = n(96024),
                i = function(e) {
                    var t = e.data,
                        n = e.url,
                        i = e.method,
                        u = t && (0, o.tM)(t, {
                            boundaryType: "network",
                            url: n,
                            method: i
                        }, {
                            logOnly: !0
                        });
                    return (0, r.h)((0, a.Z)({
                        data: u
                    }, e))
                }
        },
        94217: function(e, t, n) {
            "use strict";
            n.d(t, {
                h: function() {
                    return a.h
                }
            });
            var a = n(75005)
        },
        96024: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    h: function() {
                        return c
                    }
                }), !/^(2400|3081|3179|8022|8384)$/.test(n.j)) var a = n(1413);
            var o = n(36617),
                r = n(18812),
                i = n(56274).Promise,
                u = function(e) {
                    var t = e.data,
                        n = e.contentType,
                        a = void 0 === n ? "application/x-www-form-urlencoded" : n,
                        r = e.method,
                        i = e.url,
                        u = "";
                    return t && "application/x-www-form-urlencoded" === a ? u = (0, o.qC)(t) : t && "application/json" === a && (u = JSON.stringify(t)), {
                        requestUrl: "GET" === r && u ? "".concat(i, "?").concat(u) : i,
                        requestData: "GET" === r ? "" : u,
                        contentType: a
                    }
                },
                s = function(e) {
                    return new i((function(t, n) {
                        var o = e.method,
                            s = e.headers,
                            l = e.withCredentials,
                            p = u(e),
                            d = p.requestUrl,
                            m = p.requestData,
                            y = p.contentType,
                            _ = new XMLHttpRequest;
                        l && (_.withCredentials = l), _.open(o, d, !0), _.setRequestHeader("Accept", "application/json"), _.setRequestHeader("Content-Type", y), _.json = function() {
                            return new i((function(e, t) {
                                try {
                                    e(JSON.parse(_.responseText))
                                } catch (e) {
                                    t(new r.kp(e, d))
                                }
                            }))
                        }, s && Object.keys(s).forEach((function(e) {
                            var t = s[e];
                            "string" == typeof t && _.setRequestHeader(e, t)
                        })), _.onreadystatechange = function() {
                            4 === _.readyState && (_.onreadystatechange = function() {}, 0 === _.status ? l ? n(new r.F7(d)) : c((0, a.Z)((0, a.Z)({}, e), {}, {
                                withCredentials: !0
                            })).then(t, n) : t(_))
                        };
                        try {
                            _.send(m)
                        } catch (e) {
                            n(new r.kp(e, d))
                        }
                    }))
                },
                l = function e(t) {
                    return new i((function(n, o) {
                        var s = t.method,
                            l = t.headers,
                            c = void 0 === l ? {} : l,
                            p = t.keepalive,
                            d = t.withCredentials,
                            m = t.priority,
                            y = void 0 === m ? "auto" : m,
                            _ = u(t),
                            b = _.requestUrl,
                            h = _.requestData,
                            f = {
                                Accept: "application/json",
                                "Content-Type": _.contentType
                            };
                        c && Object.keys(c).forEach((function(e) {
                            var t = c[e];
                            "string" == typeof t && (f[e] = t)
                        })), window.fetch(b, {
                            method: s,
                            keepalive: p,
                            headers: f,
                            body: h || void 0,
                            mode: "cors",
                            credentials: d ? "include" : "omit",
                            priority: y
                        }).then((function(u) {
                            if (0 === u.status) {
                                if (!d) return e((0, a.Z)((0, a.Z)({}, t), {}, {
                                    withCredentials: !0
                                })).then(n, o);
                                o(new r.F7(b))
                            }
                            return u.text().then((function(e) {
                                n({
                                    responseURL: u.url,
                                    status: u.status,
                                    json: function() {
                                        return i.resolve(JSON.parse(e))
                                    },
                                    getResponseHeader: function(e) {
                                        return u.headers.get(e) || ""
                                    },
                                    responseText: e
                                })
                            }))
                        })).catch((function(e) {
                            o(new r.kp(e, b))
                        }))
                    }))
                },
                c = function(e) {
                    return "function" == typeof window.fetch ? l(e) : s(e)
                }
        },
        90753: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    U: function() {
                        return l
                    }
                }), !/^(2760|6364|8889)$/.test(n.j)) var a = n(93324);
            if (!/^(2760|6364|8889)$/.test(n.j)) var o = n(43144);
            if (!/^(2760|6364|8889)$/.test(n.j)) var r = n(15671);
            var i = n(12024),
                u = n(4663),
                s = n(61252),
                l = /^(2760|6364|8889)$/.test(n.j) ? null : (0, o.Z)((function e(t) {
                    var n = this,
                        o = t.me,
                        l = t.otherFrame,
                        c = t.targetOrigin,
                        p = t.uniqueMessengerBindingKey,
                        d = t.sendableEvents,
                        m = t.receivableEvents,
                        y = t.requestTypes,
                        _ = t.handlers,
                        b = t.setupConfig;
                    (0, r.Z)(this, e), this.postMessenger = new s.c({
                        me: o,
                        otherFrame: l,
                        targetOrigin: c,
                        uniqueMessengerBindingKey: p
                    });
                    var h = new u.B;
                    this.loaded = h.promise;
                    var f, g, k, v = this.postMessenger.onEvent("ready", (function() {
                        h.resolve(), n.postMessenger.sendEvent("ready"), v()
                    }));
                    try {
                        this.postMessenger.sendEvent("ready")
                    } catch (e) {}
                    this.events = (f = {}, d.forEach((function(e) {
                        f[e] = function(t) {
                            n.loaded.then((function() {
                                return n.postMessenger.sendEvent(e, t)
                            }))
                        }
                    })), f), this.on = (g = {}, m.forEach((function(e) {
                        g[e] = function(t) {
                            return n.postMessenger.onEvent(e, t)
                        }
                    })), null != b && b.persistentReadyListener && (g.ready = n.postMessenger.onEvent("ready", (function() {
                        n.postMessenger.sendEvent("ready")
                    }))), g), this.commands = (k = {}, y.forEach((function(e) {
                        k[e] = function(t) {
                            return n.loaded.then((function() {
                                return n.postMessenger.sendRequest(e, t)
                            }))
                        }
                    })), k), (0, i.qh)(_).forEach((function(e) {
                        var t = (0, a.Z)(e, 2),
                            o = t[0],
                            r = t[1];
                        n.postMessenger.setRequestHandler(o, r)
                    }))
                }))
        },
        61252: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    c: function() {
                        return l
                    }
                }), !/^(2760|6364|8889)$/.test(n.j)) var a = n(43144);
            if (!/^(2760|6364|8889)$/.test(n.j)) var o = n(15671);
            var r = n(4663),
                i = n(38714),
                u = n(97412),
                s = n(56274).Promise,
                l = /^(2760|6364|8889)$/.test(n.j) ? null : (0, a.Z)((function e(t) {
                    var n = this,
                        a = t.me,
                        l = t.otherFrame,
                        c = t.uniqueMessengerBindingKey,
                        p = t.targetOrigin,
                        d = t.acceptMessage;
                    (0, o.Z)(this, e), this.eventCbs = {}, this.requestCbs = {}, this.responseCbs = {}, this.getFrame = function() {
                        return n.otherFrame.type === i.r.OUTER ? window.parent : (n.me.type === i.r.OUTER ? window.frames : window.parent.frames)[n.otherFrame.frameId]
                    }, this.sendEvent = function(e, t) {
                        var a = n.getFrame();
                        a.location.origin === n.targetOrigin && a.postMessage({
                            __stripeJsV3Message: "event",
                            messenger: n.uniqueMessengerBindingKey,
                            action: e,
                            payload: t
                        }, n.targetOrigin)
                    }, this.onEvent = function(e, t) {
                        var a;
                        return (a = n.eventCbs)[e] || (a[e] = []), n.eventCbs[e].push(t),
                            function() {
                                n.eventCbs[e] = n.eventCbs[e].filter((function(e) {
                                    return e !== t
                                }))
                            }
                    }, this.sendRequest = function(e, t) {
                        var a = (0, u.Vj)();
                        n.getFrame().postMessage({
                            __stripeJsV3Message: "request",
                            messenger: n.uniqueMessengerBindingKey,
                            nonce: a,
                            action: e,
                            request: t
                        }, n.targetOrigin);
                        var o = new r.B;
                        return n.responseCbs[a] = function(e) {
                            o.resolve(e), delete n.responseCbs[a]
                        }, o.promise
                    }, this.setRequestHandler = function(e, t) {
                        n.requestCbs[e] = function(e, a) {
                            s.resolve(t(a)).then((function(t) {
                                n.getFrame().postMessage({
                                    __stripeJsV3Message: "response",
                                    messenger: n.uniqueMessengerBindingKey,
                                    nonce: e,
                                    response: t
                                }, n.targetOrigin)
                            }))
                        }
                    }, this.me = a, this.otherFrame = l, this.uniqueMessengerBindingKey = c, this.targetOrigin = p, window.addEventListener("message", (function(e) {
                        var t;
                        if (e.data.__stripeJsV3Message && n.uniqueMessengerBindingKey === e.data.messenger && (!d || d(e))) switch (e.data.__stripeJsV3Message) {
                            case "event":
                                null === (t = n.eventCbs[e.data.action]) || void 0 === t || t.forEach((function(t) {
                                    return t(e.data.payload)
                                }));
                                break;
                            case "request":
                                n.requestCbs[e.data.action](e.data.nonce, e.data.request);
                                break;
                            case "response":
                                n.responseCbs[e.data.nonce](e.data.response)
                        }
                    }))
                }))
        },
        75336: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    J_: function() {
                        return l
                    },
                    t1: function() {
                        return p
                    }
                }), !/^(2760|6364|8889)$/.test(n.j)) var a = n(43144);
            if (!/^(2760|6364|8889)$/.test(n.j)) var o = n(15671);
            var r = n(60276),
                i = n(90753),
                u = n(38714),
                s = /^(2204|2760|6364|8889)$/.test(n.j) ? null : [],
                l = /^(2204|2760|6364|8889)$/.test(n.j) ? null : (0, a.Z)((function e(t) {
                    var n = t.controllerAppFrameId,
                        a = t.innerFrameId,
                        l = t.handlers;
                    (0, o.Z)(this, e);
                    var c = new i.U({
                        me: {
                            type: u.r.INNER,
                            frameId: a
                        },
                        otherFrame: {
                            type: u.r.INNER,
                            frameId: n
                        },
                        targetOrigin: r.jQ,
                        uniqueMessengerBindingKey: "controller-inner-".concat(a),
                        sendableEvents: [],
                        receivableEvents: [],
                        requestTypes: s,
                        handlers: l,
                        setupConfig: {
                            persistentReadyListener: !0
                        }
                    });
                    this.events = {}, this.on = {}, this.commands = c.commands
                })),
                c = 2204 == n.j ? ["requestState"] : null,
                p = 2204 == n.j ? (0, a.Z)((function e(t) {
                    var n = t.controllerAppFrameId,
                        a = t.innerFrameId,
                        s = t.handlers;
                    (0, o.Z)(this, e);
                    var l = new i.U({
                        me: {
                            type: u.r.INNER,
                            frameId: n
                        },
                        otherFrame: {
                            type: u.r.INNER,
                            frameId: a
                        },
                        targetOrigin: r.jQ,
                        uniqueMessengerBindingKey: "controller-inner-".concat(a),
                        sendableEvents: [],
                        receivableEvents: [],
                        requestTypes: c,
                        handlers: s
                    });
                    this.events = {}, this.on = {}, this.commands = l.commands
                })) : null
        },
        38714: function(e, t, n) {
            "use strict";
            n.d(t, {
                r: function() {
                    return a
                }
            });
            var a = {
                OUTER: "outer",
                INNER: "inner"
            }
        },
        36528: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    LP: function() {
                        return l
                    },
                    o9: function() {
                        return u
                    },
                    zS: function() {
                        return s
                    }
                }), !/^(2204|2760|6364|8889)$/.test(n.j)) var a = n(15671);
            if (!/^(2204|2760|6364|8889)$/.test(n.j)) var o = n(43144);
            if (!/^(2204|2760|6364|8889)$/.test(n.j)) var r = n(9554),
                i = n.n(r);
            var u = /^(2204|2760|6364|8889)$/.test(n.j) ? null : function() {
                    function e(t, n, o) {
                        (0, a.Z)(this, e), this.type = t, this.parent = n, this.maxReplayCacheSize = null != o ? o : 0, this.queuedMessages = 0
                    }
                    return (0, o.Z)(e, [{
                        key: "on",
                        value: function(e) {
                            var t = this.parent._on(this.type, e);
                            return i()(new Array(this.queuedMessages), 0).forEach((function() {
                                e()
                            })), t
                        }
                    }, {
                        key: "off",
                        value: function(e) {
                            return this.parent._off(this.type, e)
                        }
                    }, {
                        key: "emit",
                        value: function() {
                            return this.queuedMessages < this.maxReplayCacheSize && this.queuedMessages++, this.parent._emit(this.type)
                        }
                    }]), e
                }(),
                s = /^(2204|2760|6364|8889)$/.test(n.j) ? null : function() {
                    function e(t, n, o) {
                        (0, a.Z)(this, e), this.type = t, this.parent = n, this.maxReplayCacheSize = null != o ? o : 0, this.queuedMessages = []
                    }
                    return (0, o.Z)(e, [{
                        key: "on",
                        value: function(e) {
                            var t = this.parent._on(this.type, e);
                            return this.queuedMessages.forEach((function(t) {
                                e(t)
                            })), t
                        }
                    }, {
                        key: "off",
                        value: function(e) {
                            return this.parent._off(this.type, e)
                        }
                    }, {
                        key: "emit",
                        value: function(e) {
                            return this.maxReplayCacheSize && (this.queuedMessages.length >= this.maxReplayCacheSize && this.queuedMessages.shift(), this.queuedMessages.push(e)), this.parent._emit(this.type, e)
                        }
                    }]), e
                }(),
                l = /^(2204|2760|6364|8889)$/.test(n.j) ? null : function() {
                    function e(t, n, o) {
                        (0, a.Z)(this, e), this.type = t, this.parent = n, this.maxReplayCacheSize = null != o ? o : 0, this.queuedMessages = []
                    }
                    return (0, o.Z)(e, [{
                        key: "on",
                        value: function(e) {
                            var t = this.parent._on(this.type, e);
                            return this.queuedMessages.forEach((function(t) {
                                var n = t.a,
                                    a = t.b;
                                e(n, a)
                            })), t
                        }
                    }, {
                        key: "off",
                        value: function(e) {
                            return this.parent._off(this.type, e)
                        }
                    }, {
                        key: "emit",
                        value: function(e, t) {
                            return this.maxReplayCacheSize && (this.queuedMessages.length >= this.maxReplayCacheSize && this.queuedMessages.shift(), this.queuedMessages.push({
                                a: e,
                                b: t
                            })), this.parent._emit(this.type, e, t)
                        }
                    }]), e
                }()
        },
        12445: function(e, t, n) {
            "use strict";
            n.d(t, {
                N: function() {
                    return a
                }
            });
            var a = {
                CARD_ELEMENT_COMBINED: "CARD_ELEMENT_COMBINED",
                CARD_ELEMENT_SPLIT: "CARD_ELEMENT_SPLIT",
                CONTROLLER: "CONTROLLER",
                CONTROLLER_WITH_PRECONNECT: "CONTROLLER_WITH_PRECONNECT",
                METRICS_CONTROLLER: "METRICS_CONTROLLER",
                OUTER_LOGGER_CONTROLLER: "OUTER_LOGGER_CONTROLLER",
                PAYMENT_REQUEST_ELEMENT: "PAYMENT_REQUEST_ELEMENT",
                PAYMENT_REQUEST_BROWSER: "PAYMENT_REQUEST_BROWSER",
                PAYMENT_REQUEST_GOOGLE_PAY: "PAYMENT_REQUEST_GOOGLE_PAY",
                IBAN_ELEMENT: "IBAN_ELEMENT",
                IDEAL_BANK_ELEMENT: "IDEAL_BANK_ELEMENT",
                P24_BANK_ELEMENT: "P24_BANK_ELEMENT",
                AUTHORIZE_WITH_URL: "AUTHORIZE_WITH_URL",
                STRIPE_3DS2_CHALLENGE: "STRIPE_3DS2_CHALLENGE",
                STRIPE_3DS2_FINGERPRINT: "STRIPE_3DS2_FINGERPRINT",
                AU_BANK_ACCOUNT_ELEMENT: "AU_BANK_ACCOUNT_ELEMENT",
                FPX_BANK_ELEMENT: "FPX_BANK_ELEMENT",
                LIGHTBOX_APP: "LIGHTBOX_APP",
                ISSUING_CARD_NUMBER_DISPLAY_ELEMENT: "ISSUING_CARD_NUMBER_DISPLAY_ELEMENT",
                ISSUING_CARD_COPY_BUTTON_ELEMENT: "ISSUING_CARD_COPY_BUTTON_ELEMENT",
                ISSUING_CARD_CVC_DISPLAY_ELEMENT: "ISSUING_CARD_CVC_DISPLAY_ELEMENT",
                ISSUING_CARD_EXPIRY_DISPLAY_ELEMENT: "ISSUING_CARD_EXPIRY_DISPLAY_ELEMENT",
                ISSUING_CARD_PIN_DISPLAY_ELEMENT: "ISSUING_CARD_PIN_DISPLAY_ELEMENT",
                EPS_BANK_ELEMENT: "EPS_BANK_ELEMENT",
                HCAPTCHA_APP: "HCAPTCHA_APP",
                CARD_DETAILS_RECOLLECTION_MODAL: "CARD_DETAILS_RECOLLECTION_MODAL",
                NETBANKING_BANK_ELEMENT: "NETBANKING_BANK_ELEMENT",
                AFFIRM_MESSAGE_ELEMENT: "AFFIRM_MESSAGE_ELEMENT",
                AFFIRM_MESSAGE_MODAL_ELEMENT: "AFFIRM_MESSAGE_MODAL_ELEMENT",
                AFTERPAY_MESSAGE_MODAL_ELEMENT: "AFTERPAY_MESSAGE_MODAL_ELEMENT",
                PAYMENT_METHOD_MESSAGING_MODAL_ELEMENT: "PAYMENT_METHOD_MESSAGING_MODAL_ELEMENT",
                AUTOCOMPLETE_SUGGESTIONS_ELEMENT: "AUTOCOMPLETE_SUGGESTIONS_ELEMENT",
                ACH_BANK_SEARCH_RESULTS_ELEMENT: "ACH_BANK_SEARCH_RESULTS_ELEMENT",
                LINK_AUTHENTICATION_ELEMENT: "LINK_AUTHENTICATION_ELEMENT",
                PAYMENT_ELEMENT: "PAYMENT_ELEMENT",
                PAYMENT_API_INNER: "PAYMENT_API_INNER",
                LINKED_ACCOUNTS_INNER: "LINKED_ACCOUNTS_INNER",
                WECHAT_PAY_INNER: "WECHAT_PAY_INNER",
                PAYNOW_INNER: "PAYNOW_INNER",
                BLIK_INNER: "BLIK_INNER",
                PIX_INNER: "PIX_INNER",
                PROMPTPAY_INNER: "PROMPTPAY_INNER",
                ADDRESS_ELEMENT: "ADDRESS_ELEMENT",
                ADDRESS_ELEMENT_SHIPPING: "ADDRESS_ELEMENT_SHIPPING",
                ADDRESS_ELEMENT_BILLING: "ADDRESS_ELEMENT_BILLING",
                LINK_AUTOFILL_MODAL: "LINK_AUTOFILL_MODAL",
                LINK_INFO_MODAL: "LINK_INFO_MODAL",
                LINK_MODAL: "LINK_MODAL",
                GOOGLE_MAPS_APP: "GOOGLE_MAPS_APP",
                LOADER_UI_APP: "LOADER_UI_APP",
                LOADER_UI_APP_WITH_FASTPATH: "LOADER_UI_APP_WITH_FASTPATH",
                LOADER_UI_APP_WITH_FASTPATH_CONTROL: "LOADER_UI_APP_WITH_FASTPATH_CONTROL",
                BACS_MANDATE_CONFIRMATION_APP: "BACS_MANDATE_CONFIRMATION_APP",
                BACS_CONFIRMATION_INNER: "BACS_CONFIRMATION_INNER",
                SEPA_DEBIT_MICRODEPOSITS_CONFIRMATION_APP: "SEPA_DEBIT_MICRODEPOSITS_CONFIRMATION_APP",
                SEPA_DEBIT_CONFIRMATION_INNER: "SEPA_DEBIT_CONFIRMATION_INNER",
                EXPRESS_CHECKOUT_ELEMENT: "EXPRESS_CHECKOUT_ELEMENT",
                LINK_BUTTON_FOR_CARD_ELEMENT: "LINK_BUTTON_FOR_CARD_ELEMENT",
                PAYMENT_METHOD_MESSAGING_ELEMENT: "PAYMENT_METHOD_MESSAGING_ELEMENT",
                LINK_PURCHASE_PROTECTION_MODAL: "LINK_PURCHASE_PROTECTION_MODAL",
                IN_CONTEXT_INNER: "IN_CONTEXT_INNER",
                SMTC_COLLECTION_INNER: "SMTC_COLLECTION_INNER",
                CURRENCY_SELECTOR_ELEMENT: "CURRENCY_SELECTOR_ELEMENT",
                PRB_WARNING_MODAL: "PRB_WARNING_MODAL"
            }
        },
        60262: function(e, t, n) {
            "use strict";
            n(39294), n(12445)
        },
        80755: function(e, t, n) {
            "use strict";
            n.d(t, {
                $G: function() {
                    return r.$G
                },
                LP: function() {
                    return o.LP
                },
                NC: function() {
                    return a.N
                },
                o9: function() {
                    return o.o9
                },
                oi: function() {
                    return r.oi
                },
                zS: function() {
                    return o.zS
                }
            });
            n(60262);
            var a = n(12445);
            if (!/^(2204|2760|6364|8889)$/.test(n.j)) var o = n(36528);
            var r = n(65311);
            n(86810)
        },
        65311: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    $G: function() {
                        return c
                    },
                    oi: function() {
                        return l
                    }
                }), !/^(2760|8889)$/.test(n.j)) var a = n(1413);
            var o, r = n(71873),
                i = n(60276),
                u = n(32583),
                s = (n(19543), !1),
                l = function(e) {
                    var t, n = e.targetOrigin,
                        l = e.type,
                        c = n;
                    switch (l) {
                        case "sibling":
                            t = (0, u.Hb)(e.targetFrameId);
                            break;
                        case "child":
                            if (!(t = window.frames[e.targetFrameId])) {
                                var p = document.querySelector('iframe[name="'.concat(e.targetFrameId, '"]'));
                                p && (t = p.contentWindow, o && !s && (s = !0, o("post_message.iframe_fallback_lookup.success")))
                            }
                            break;
                        case "parent":
                            c = c || "*", t = window.parent;
                            break;
                        default:
                            (0, r.Rz)(l)
                    }
                    if (c = c || i.jQ, t && "function" == typeof t.postMessage) {
                        var d = e.message.delegate ? {
                            targetOrigin: c,
                            delegate: e.message.delegate
                        } : c;
                        t.postMessage(JSON.stringify((0, a.Z)((0, a.Z)({}, e), {}, {
                            __stripeJsV3: !0
                        })), d)
                    }
                },
                c = function(e) {
                    try {
                        var t = "string" == typeof e ? JSON.parse(e) : e;
                        return t.__stripeJsV3 ? t : null
                    } catch (e) {
                        return null
                    }
                }
        },
        86810: function(e, t, n) {
            "use strict";
            n(60276)
        },
        53048: function(e, t, n) {
            "use strict";
            n.d(t, {
                H: function() {
                    return r
                }
            });
            var a = n(39294),
                o = n(24245),
                r = function(e) {
                    var t, n, r = e.inputSelector,
                        i = e.inputType,
                        u = void 0 === i ? "text" : i,
                        s = e.inputMode,
                        l = e.delay,
                        c = void 0 === l ? 0 : l;
                    if ("INPUT" !== (null === (t = document.activeElement) || void 0 === t ? void 0 : t.tagName) && a.Ah && (null === (n = window.visualViewport) || void 0 === n ? void 0 : n.height) === document.documentElement.clientHeight) return (0, o.$M)((function() {}));
                    var p = document.createElement("input");
                    p.type = u, s && (p.inputMode = s), p.style.position = "fixed", p.style.top = "50%", p.style.left = "20px", p.style.opacity = "0", p.style.pointerEvents = "none", p.style.fontSize = "16px", p.ariaHidden = "true", document.body.appendChild(p), p.focus();
                    var d = (0, o.$M)((function() {
                            clearTimeout(m), document.body.removeChild(p)
                        })),
                        m = setTimeout((function() {
                            var e = document.querySelector(r);
                            null == e || e.focus(), d()
                        }), c);
                    return d
                }
        },
        9617: function(e, t, n) {
            "use strict";
            n.d(t, {
                $M: function() {
                    return s
                },
                Ds: function() {
                    return r
                },
                HP: function() {
                    return i
                },
                ZT: function() {
                    return o
                },
                e4: function() {
                    return c
                },
                pA: function() {
                    return u
                },
                qe: function() {
                    return l
                }
            });
            n(18812);
            var a = n(56274).Promise,
                o = function() {},
                r = function(e, t, n) {
                    var a, o;
                    return function() {
                        for (var r = this, i = arguments.length, u = new Array(i), s = 0; s < i; s++) u[s] = arguments[s];
                        window.clearTimeout(a), a = window.setTimeout((function() {
                            window.clearTimeout(o), e.apply(r, u)
                        }), t), n && !o && (o = window.setTimeout((function() {
                            window.clearTimeout(a), e.apply(r, u)
                        }), n))
                    }
                },
                i = function(e) {
                    var t = {},
                        n = {};
                    return function(a) {
                        var o = "_".concat(a);
                        if ("string" == typeof a && void 0 !== t[o]) return t[o];
                        if ("number" == typeof a && void 0 !== n[o]) return n[o];
                        var r = e(a);
                        return "string" == typeof a && (t[o] = r), "number" == typeof a && (n[o] = r), r
                    }
                },
                u = function(e) {
                    var t = -1,
                        n = null;
                    return function() {
                        var o = e.apply(void 0, arguments),
                            r = ++t;
                        return n = new a((function(e, a) {
                            return o.then((function(e) {
                                return r === t ? e : n
                            }), (function(e) {
                                if (r === t) throw e;
                                return n
                            })).then(e, a)
                        }))
                    }
                },
                s = function(e) {
                    var t = e;
                    return function() {
                        t && (t.apply(void 0, arguments), t = null)
                    }
                },
                l = function(e) {
                    var t, n;
                    return function() {
                        for (var a = arguments.length, o = new Array(a), r = 0; r < a; r++) o[r] = arguments[r];
                        return n && o.length === n.length && o.every((function(e, t) {
                            return e === n[t]
                        })) ? t : (n = o, t = e.apply(void 0, o))
                    }
                },
                c = function(e, t) {
                    var n = 0;
                    return function() {
                        ++n === e && t()
                    }
                }
        },
        36940: function(e, t, n) {
            "use strict";
            n.d(t, {
                Kn: function() {
                    return i
                },
                P5: function() {
                    return r
                },
                _v: function() {
                    return o
                }
            });
            var a = n(56274).Promise,
                o = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                    return new a((function(t) {
                        return setTimeout(t, e)
                    }))
                },
                r = function(e) {
                    return parseFloat(e) * (/\ds$/i.test(e) ? 1e3 : 1)
                },
                i = function(e) {
                    return null !== e && "object" == typeof e && !Array.isArray(e)
                }
        },
        24245: function(e, t, n) {
            "use strict";
            n.d(t, {
                $M: function() {
                    return a.$M
                },
                $l: function() {
                    return o.$
                },
                BI: function() {
                    return u.BI
                },
                Ds: function() {
                    return a.Ds
                },
                HL: function() {
                    return s.H
                },
                HP: function() {
                    return a.HP
                },
                Kh: function() {
                    return u.Kh
                },
                Kn: function() {
                    return i.Kn
                },
                O8: function() {
                    return u.O8
                },
                P5: function() {
                    return i.P5
                },
                XD: function() {
                    return r.X
                },
                ZT: function() {
                    return a.ZT
                },
                _v: function() {
                    return i._v
                },
                do: function() {
                    return u.do
                },
                e4: function() {
                    return a.e4
                },
                g0: function() {
                    return l.g
                },
                i3: function() {
                    return u.i3
                },
                pA: function() {
                    return a.pA
                },
                pM: function() {
                    return u.pM
                },
                pX: function() {
                    return u.pX
                },
                qe: function() {
                    return a.qe
                },
                wX: function() {
                    return u.wX
                }
            });
            var a = n(9617),
                o = n(60807),
                r = (n(16103), n(29220)),
                i = n(36940);
            if (!/^(2(15|400|417|675|760)|3(097|179|58)|4(2|505|520|928)|8(022|161|218|384|889)|(166|704|729)7|6364|9171)$/.test(n.j)) var u = n(68148);
            var s = n(53048),
                l = n(1749)
        },
        60807: function(e, t, n) {
            "use strict";
            n.d(t, {
                $: function() {
                    return o
                }
            });
            var a = n(56274).Promise,
                o = function(e, t, n, o) {
                    var r = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
                        i = o - 1,
                        u = function a(o, u) {
                            return e().then((function(e) {
                                if (t(e)) o(e);
                                else if (i) {
                                    i--;
                                    var s = "function" == typeof n ? n() : n;
                                    setTimeout(a, s, o, u)
                                } else r ? o(e) : u(new Error("condition was not met"))
                            }), (function(e) {
                                u(e)
                            }))
                        };
                    return new a(u)
                }
        },
        16103: function(e, t, n) {
            "use strict";
            n(56274).Promise
        },
        29220: function(e, t, n) {
            "use strict";
            n.d(t, {
                X: function() {
                    return o
                }
            });
            var a = n(56274).Promise,
                o = function e(t) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 3,
                        o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 250;
                    return new a((function(a, r) {
                        t().then(a).catch((function(i) {
                            1 === n ? r(i) : setTimeout((function() {
                                e(t, n - 1, o).then(a, r)
                            }), o)
                        }))
                    }))
                }
        },
        1749: function(e, t, n) {
            "use strict";
            n.d(t, {
                g: function() {
                    return o
                }
            });
            var a = n(39294),
                o = function(e) {
                    if (e.focus(), document.activeElement !== e && a.s$ && (e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement)) {
                        var t = "" === e.value;
                        t && (e.value = " ");
                        var n = e.selectionStart,
                            o = e.selectionEnd;
                        e.setSelectionRange(0, 0), e.setSelectionRange(n, o), t && (e.value = "")
                    }
                }
        },
        76664: function(e, t, n) {
            "use strict";
            n.d(t, {
                z: function() {
                    return o
                }
            });
            var a = new(0, n(56274).Promise)((function(e) {
                    if (document.body) e();
                    else {
                        document.addEventListener("DOMContentLoaded", (function() {
                            document.body && e()
                        })), window.addEventListener("load", (function() {
                            document.body && e()
                        }));
                        var t = 1,
                            n = setInterval((function() {
                                (document.body || t >= 600) && (clearInterval(n), e()), t++
                            }), 100)
                    }
                })),
                o = function() {
                    return a.then((function() {
                        return document.body
                    }))
                }
        },
        21487: function(e, t, n) {
            "use strict";
            n.d(t, {
                z: function() {
                    return a.z
                }
            });
            var a = n(76664)
        },
        69803: function(e, t, n) {
            "use strict";
            n.d(t, {
                T: function() {
                    return r
                },
                V: function() {
                    return i
                }
            });
            var a = "00".concat(Math.floor(1e3 * Math.random())).slice(-3),
                o = 0,
                r = function(e) {
                    return "".concat(e).concat(a).concat(o++)
                },
                i = function e() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return t ? (parseInt(t, 10) ^ 16 * Math.random() >> parseInt(t, 10) / 4).toString(16) : "00000000-0000-4000-8000-000000000000".replace(/[08]/g, e)
                }
        },
        97412: function(e, t, n) {
            "use strict";
            n.d(t, {
                To: function() {
                    return a.T
                },
                Vj: function() {
                    return a.V
                }
            });
            var a = n(69803)
        },
        40414: function(e, t, n) {
            "use strict";
            n.d(t, {
                w: function() {
                    return i
                }
            });
            var a = n(94217),
                o = n(56274).Promise,
                r = {},
                i = function(e, t) {
                    var n = t[e];
                    if (n && e in r) return r[e];
                    if (n) {
                        var i = {
                            url: n,
                            method: "GET"
                        };
                        return r[e] = (0, a.h)(i).then((function(e) {
                            return JSON.parse(e.responseText)
                        })), r[e]
                    }
                    return o.reject(new Error("Could not load locale data for ".concat(e, ".")))
                }
        },
        69662: function(e, t, n) {
            "use strict";
            n.d(t, {
                H: function() {
                    return o.H
                },
                w: function() {
                    return a.w
                }
            });
            var a = n(40414),
                o = n(81793)
        },
        81793: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    H: function() {
                        return c
                    }
                }), !/^(2(4(00|17|49)|627|675)|3([13]79|081|092)|4(2|505|928)|5(075|592|663)|8(022|05|161|218|384)|(704|729|948)7|1580)$/.test(n.j)) var a = n(1413);
            var o = n(40414),
                r = n(29757),
                i = n(56274).Promise,
                u = {},
                s = function(e) {
                    var t = document.querySelector("html");
                    t instanceof HTMLHtmlElement && t.setAttribute("lang", e)
                },
                l = {},
                c = function(e, t) {
                    var n = r.hG[e],
                        c = t[e];
                    return c ? u[c] ? (s(e), u[c]) : (u[c] = (0, o.w)(e, t).then((function(t) {
                        try {
                            s(e);
                            var n = r.hG[e],
                                o = (0, a.Z)((0, a.Z)({}, n), t);
                            return (0, r.b9)(e, o), l[e] = !0, o
                        } catch (e) {
                            throw e
                        }
                    })), u[c]) : n ? (s(e), i.resolve(n)) : i.reject(new Error("Could not load locale data for ".concat(e, ".")))
                }
        },
        7633: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return a.Z
                }
            });
            var a = n(91646)
        },
        62860: function(e, t, n) {
            "use strict";
            n.d(t, {
                Lk: function() {
                    return a.Lk
                },
                Qy: function() {
                    return a.Qy
                }
            });
            var a = n(80433)
        },
        80433: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    Lk: function() {
                        return u
                    },
                    Qy: function() {
                        return s
                    }
                }), !/^(2(400|417|760)|3(081|092|179|58)|8(022|05|384|889)|5663)$/.test(n.j)) var a = n(16284);
            var o = n(29757),
                r = n(7633),
                i = n(39294),
                u = function(e, t, n) {
                    var a = s(e, t, n);
                    return null != a ? a : t
                },
                s = function(e, t, n) {
                    var a = o.hG[e] || {},
                        i = o.hG[r.Z],
                        u = a[t] || i[t];
                    if (u) return l(e, u, n)
                },
                l = function e(t, n, o) {
                    if (!o || 0 === Object.keys(o).length) return n;
                    if ("auto" === t) return e((0, i.UT)(), n, o);
                    try {
                        return new a.C(n, t).format(o)
                    } catch (e) {
                        return n
                    }
                }
        },
        29757: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    b9: function() {
                        return r
                    },
                    hG: function() {
                        return o
                    },
                    y_: function() {
                        return i
                    }
                }), !/^(24(00|17)|8(022|05|384)|3081|3179)$/.test(n.j)) var a = n(87462);
            var o = {},
                r = function(e, t) {
                    o[e] = t
                },
                i = function(e) {
                    return (0, a.Z)(o, e)
                }
        },
        91646: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var a = "en"
        },
        69620: function(e, t, n) {
            "use strict";
            n.d(t, {
                Kl: function() {
                    return a.Kl
                },
                YW: function() {
                    return o.Y
                },
                cx: function() {
                    return a.cx
                },
                lO: function() {
                    return a.lO
                }
            });
            var a = n(11834),
                o = n(87049)
        },
        11834: function(e, t, n) {
            "use strict";
            n.d(t, {
                Kl: function() {
                    return a
                },
                cx: function() {
                    return r
                },
                lO: function() {
                    return o
                }
            });
            n(18812);
            var a = {
                    live: "live",
                    test: "test",
                    unknown: "unknown"
                },
                o = function(e) {
                    return e ? /^pk_test_/.test(e) ? a.test : /^pk_live_/.test(e) ? a.live : a.unknown : a.unknown
                },
                r = function(e) {
                    var t = o(e);
                    return t === a.live || t !== a.test && null
                }
        },
        87049: function(e, t, n) {
            "use strict";
            n.d(t, {
                Y: function() {
                    return l
                }
            });
            n(18812);
            var a = "publishable",
                o = "secret",
                r = "ephemeral",
                i = "restricted",
                u = "unknown",
                s = function(e) {
                    switch (e.split("_", 1)[0]) {
                        case "pk":
                            return a;
                        case "sk":
                            return o;
                        case "ek":
                            return r;
                        case "rk":
                            return i;
                        default:
                            return u
                    }
                },
                l = function(e) {
                    return s(e) !== u
                }
        },
        87655: function(e, t, n) {
            "use strict";
            n.d(t, {
                X: function() {
                    return a
                }
            });
            var a = function() {
                try {
                    var e = window.localStorage;
                    return e || null
                } catch (e) {
                    return null
                }
            }
        },
        40758: function(e, t, n) {
            "use strict";
            n.d(t, {
                N: function() {
                    return a
                }
            });
            var a = function(e) {
                var t = e.split("-"),
                    n = t[0],
                    a = null,
                    o = null,
                    r = null;
                if (t.length > 1 && (4 === t[1].length ? o = t[1] : 2 === t[1].length || 3 === t[1].length ? a = t[1] : r = t[1]), t.length > 2 && (2 === t[2].length || 3 === t[2].length ? a = t[2] : r = t[2]), t.length > 3 && (r = t[3]), 2 !== n.length && 3 !== n.length) throw new Error("invalid locale ".concat(e));
                var i = n.toLowerCase(),
                    u = a ? a.toUpperCase() : null,
                    s = o ? "".concat(o[0].toUpperCase()).concat(o.substring(1).toLowerCase()) : null;
                return {
                    locale: i + (s ? "-".concat(s) : "") + (u ? "-".concat(u) : "") + (r ? "-".concat(r) : ""),
                    language: i,
                    region: u,
                    script: s,
                    variant: r
                }
            }
        },
        74188: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    Y: function() {
                        return k
                    }
                }), !/^(2400|3081|3179|8022|8384)$/.test(n.j)) var a = n(89062);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var o = n(87462);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var r = n(15671);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var i = n(43144);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var u = n(1413);
            var s = n(39294),
                l = n(97412),
                c = n(96024),
                p = n(60276);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var d = n(73423);
            var m = n(81732);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var y = n(67734);
            var _ = function(e) {
                    if (!(e in window)) return !1;
                    var t = window[e];
                    return -1 !== String(t).indexOf("[native code]")
                },
                b = function() {
                    return _("Promise") || _("__nativePromise") ? _("fetch") ? "modern" : "lts" : "legacy"
                },
                h = !/^(2400|3081|3179|8022|8384)$/.test(n.j) || null,
                f = function() {
                    return (0, c.h)({
                        url: "".concat(p.Xk, ".deploy_status_henson.json"),
                        method: "GET"
                    }).then((function(e) {
                        if (200 !== e.status && 304 !== e.status) throw new Error("could not fetch .deploy_status_henson.json; status=".concat(e.status));
                        return e.json().then((function(t) {
                            return t ? (0, u.Z)((0, u.Z)({}, t || {}), function(e) {
                                var t, n, a = e.getResponseHeader("Server");
                                if (!a) {
                                    if (304 !== e.status || !e.getResponseHeader("X-Served-By")) return;
                                    a = "Fastly"
                                }
                                switch (a) {
                                    case "Cloudfront":
                                        return {
                                            cdnName: a,
                                            cdnPopDc: null === (t = e.getResponseHeader("X-Amz-Cf-Pop")) || void 0 === t ? void 0 : t.substring(0, 3)
                                        };
                                    case "Fastly":
                                        return {
                                            cdnName: a,
                                            cdnPopDc: null === (n = e.getResponseHeader("X-Served-By")) || void 0 === n ? void 0 : n.split(", ").map((function(e) {
                                                var t = e.split("-");
                                                return t[t.length - 1]
                                            })).join(", ")
                                        };
                                    default:
                                        return
                                }
                            }(e)) : t
                        }))
                    }))
                },
                g = function() {
                    try {
                        var e = (0, s.lE)();
                        return {
                            connection_rtt: e.rtt,
                            connection_downlink: e.downlink,
                            connection_effective_type: e.effectiveType
                        }
                    } catch (e) {
                        return {}
                    }
                },
                k = /^(2400|3081|3179|8022|8384)$/.test(n.j) ? null : function() {
                    function e(t, n) {
                        var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
                            o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : d.X;
                        (0, r.Z)(this, e), this.transports = [], this.prefix = "", this.deployStatusFetch = {
                            state: "initial"
                        }, this.queue = [], this.setTransports(t), this.eventCount = 0, this.releaseVersion = o, this.baseParams = (0, u.Z)({
                            deploy_status: "unknown",
                            browserClassification: b()
                        }, g()), n && this.updateParams({
                            running_tests: !0
                        }), this.fetchDeployStatus = h ? f : a || null
                    }
                    return (0, i.Z)(e, [{
                        key: "updateParams",
                        value: function(e) {
                            (0, o.Z)(this.baseParams, e)
                        }
                    }, {
                        key: "getParams",
                        value: function() {
                            return (0, u.Z)({}, this.baseParams)
                        }
                    }, {
                        key: "setDefaultPrefix",
                        value: function(e) {
                            this.prefix = e
                        }
                    }, {
                        key: "setTransports",
                        value: function(e) {
                            this.transports = e
                        }
                    }, {
                        key: "log",
                        value: function(e) {
                            var t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                                a = arguments.length > 2 ? arguments[2] : void 0;
                            if (!s.fL)
                                if ("initial" === this.deployStatusFetch.state && this.fetchAndSetDeployStatus(), "loading" !== this.deployStatusFetch.state) {
                                    var o = null !== (t = null == a ? void 0 : a.prefix) && void 0 !== t ? t : this.prefix,
                                        r = (0, u.Z)((0, u.Z)({
                                            event_count: ++this.eventCount,
                                            timestamp: Date.now(),
                                            os: (0, s.d4)(navigator.userAgent),
                                            browserFamily: (0, s.gq)(navigator.userAgent),
                                            version: this.releaseVersion,
                                            event_id: (0, l.Vj)()
                                        }, this.baseParams), n),
                                        i = new m.L("".concat(o).concat(e), r, null == a ? void 0 : a.priority);
                                    this.transports.forEach((function(e) {
                                        e.send(i)
                                    }))
                                } else this.queue.push([e, n, a])
                        }
                    }, {
                        key: "flushQueue",
                        value: function() {
                            for (var e = this.queue.shift(); e;) this.log.apply(this, (0, a.Z)(e)), e = this.queue.shift()
                        }
                    }, {
                        key: "fetchAndSetDeployStatus",
                        value: function() {
                            var e = this;
                            if (this.fetchDeployStatus) {
                                this.deployStatusFetch = {
                                    state: "loading"
                                }, setTimeout((function() {
                                    if ("loading" === e.deployStatusFetch.state) {
                                        var t = "unable to fetch the deploy status within ".concat(2600, " ms");
                                        e.deployStatusFetch = {
                                            state: "failed",
                                            errorMessage: t
                                        }, e.updateParams({
                                            deploy_status_fetch_failed: !0,
                                            deploy_status_fetch_failed_message: t
                                        }), e.flushQueue()
                                    }
                                }), 2600);
                                var t = Date.now(),
                                    n = null;
                                this.fetchDeployStatus().then((function(a) {
                                    n = Date.now() - t, (0, y.w)(a), e.deployStatusFetch = {
                                        state: "ready",
                                        deployStatus: a
                                    }, e.updateParams({
                                        deploy_status: (0, y.I)(a, e.releaseVersion),
                                        deploy_status_time_to_fetch_ms: n,
                                        deploy_status_fetch_failed: !1,
                                        deploy_status_fetch_failed_message: null,
                                        cdn_name: a.cdnName,
                                        cdn_pop_dc: a.cdnPopDc
                                    }), e.flushQueue()
                                })).catch((function(t) {
                                    e.deployStatusFetch = {
                                        state: "failed",
                                        errorMessage: String(t)
                                    }, e.updateParams({
                                        deploy_status_fetch_failed: !0,
                                        deploy_status_fetch_failed_message: String(t)
                                    }), e.flushQueue()
                                }))
                            }
                        }
                    }]), e
                }()
        },
        81732: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    L: function() {
                        return i
                    }
                }), !/^(2400|3081|3179|8022|8384)$/.test(n.j)) var a = n(43144);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var o = n(15671);
            var r = n(66232),
                i = /^(2400|3081|3179|8022|8384)$/.test(n.j) ? null : (0, a.Z)((function e(t) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        a = arguments.length > 2 ? arguments[2] : void 0;
                    (0, o.Z)(this, e), this.name = t, this.params = (0, r.x)(n), this.priority = a
                }))
        },
        33482: function(e, t, n) {
            "use strict";
            n.d(t, {
                h: function() {
                    return r
                }
            });
            var a = n(68340),
                o = (n(19543), n(23729), n(74188)),
                r = function() {
                    var e = [];
                    e.push(new a.X({
                        useBatching: !0,
                        maxBatchSize: 5
                    }));
                    var t = Boolean(!1);
                    return new o.Y(e, t)
                }
        },
        67734: function(e, t, n) {
            "use strict";

            function a(e) {
                var t = e;
                if ("number" != typeof(null == t ? void 0 : t.canaryPercentage)) throw new Error('"'.concat(e, '" is not a deploy status'))
            }
            n.d(t, {
                I: function() {
                    return o
                },
                w: function() {
                    return a
                }
            });
            var o = function(e, t) {
                e.canaryPercentage;
                var n, a, o = e.canaryRevision,
                    r = e.deployedRevisions;
                return 0 === (null == o ? void 0 : o.indexOf(t)) ? "canary" : 0 === (null == r || null === (n = r[0]) || void 0 === n ? void 0 : n.indexOf(t)) ? "main" : 0 === (null == r || null === (a = r[1]) || void 0 === a ? void 0 : a.indexOf(t)) ? "previous" : "other"
            }
        },
        66232: function(e, t, n) {
            "use strict";
            n.d(t, {
                Q: function() {
                    return i
                },
                x: function() {
                    return o
                }
            });
            var a = n(74355),
                o = function(e) {
                    var t = {};
                    return function e(n) {
                        var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                        Object.keys(n).forEach((function(o) {
                            var r = "".concat(a, "-").concat(o).replace(/^-/, ""),
                                i = n[o];
                            if (null != i) switch (typeof i) {
                                case "object":
                                    Array.isArray(i) ? t[r] = i.join(" ") : e(i, r);
                                    break;
                                case "number":
                                case "boolean":
                                case "string":
                                    t[r] = i;
                                    break;
                                default:
                                    t[r] = String(i)
                            } else t[r] = i
                        }))
                    }(e), t
                },
                r = {
                    account_holder_id: !0,
                    amount: !0,
                    arb_id: !0,
                    controller: !0,
                    controller_init_delay: !0,
                    controller_load_time: !0,
                    cumulative_layout_shift: !0,
                    dom_complete: !0,
                    dom_interactive: !0,
                    dom_loading: !0,
                    duration: !0,
                    eid: !0,
                    elapsed_time: !0,
                    elements_assignment_id: !0,
                    elements_session_id: !0,
                    end: !0,
                    event_count: !0,
                    event_id: !0,
                    event: !0,
                    features: !0,
                    first_contentful_paint: !0,
                    frame_width: !0,
                    funnel_event_elapsed_time: !0,
                    key: !0,
                    largest_contentful_paint: !0,
                    latency: !0,
                    load_timestamp: !0,
                    logger_id: !0,
                    metric_value: !0,
                    navigation_fetch_start: !0,
                    payment_page_id: !0,
                    paymentUserAgent: !0,
                    request_start: !0,
                    resource_timings: !0,
                    response_end: !0,
                    search_session: !0,
                    searchSession: !0,
                    session_id: !0,
                    shownDuration: !0,
                    since_create: !0,
                    since_fetch: !0,
                    since_group_create: !0,
                    since_mount: !0,
                    since_sjs_load: !0,
                    since_stripe_create: !0,
                    since_wrapper_create: !0,
                    since_store: !0,
                    since_link_consumer_session_ready: !0,
                    since_link_default_integration_ready: !0,
                    since_parent_visible: !0,
                    source_id: !0,
                    start_time: !0,
                    start: !0,
                    stripe_create_duration: !0,
                    stripe_js_id: !0,
                    stripe_js_init_duration: !0,
                    stripe_js_load_duration: !0,
                    time_from_confirm_to_poll_start: !0,
                    time_from_pm_to_confirm: !0,
                    time_polling_hook: !0,
                    time_polling_success: !0,
                    time_to_create_pm: !0,
                    time_to_first_byte: !0,
                    time_waiting_on_captcha: !0,
                    timeline: !0,
                    timestamp: !0,
                    timestamps: !0,
                    token_id: !0,
                    until_first_create: !0,
                    until_first_load: !0,
                    until_first_mount: !0,
                    version: !0
                },
                i = function(e, t) {
                    if ("string" == typeof e && e.length > 8e3 && "timeline" !== t) return "<toolong>";
                    if ("string" == typeof e && e.length > 61440 && "timeline" === t) return "<toolong>";
                    if (0 === t.indexOf("resourceTiming[")) return e;
                    if (r[t.split("-")[0]]) return e;
                    var n = (0, a.vG)(e),
                        o = (0, a.Xd)(n);
                    return (0, a.Og)(o)
                }
        },
        352: function(e, t, n) {
            "use strict";
            n.d(t, {
                hu: function() {
                    return a.h
                },
                kg: function() {
                    return o
                }
            });
            var a = n(33482),
                o = (n(74188), n(81732), n(68340), function() {
                    var e = (0, a.h)();
                    return {
                        setDefaultPrefix: function(t) {
                            return e.setDefaultPrefix(t)
                        },
                        setTransports: function(t) {
                            return e.setTransports(t)
                        },
                        updateParams: function(t) {
                            return e.updateParams(t)
                        },
                        getParams: function() {
                            return e.getParams()
                        },
                        log: function(t, n, a) {
                            return e.log(t, n, a)
                        }
                    }
                }())
        },
        23729: function(e, t, n) {
            "use strict";
            n(66232)
        },
        19543: function(e, t, n) {
            "use strict";
            n(66232)
        },
        68340: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    X: function() {
                        return v
                    }
                }), !/^(2400|3081|3179|8022|8384)$/.test(n.j)) var a = n(45987);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var o = n(93324);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var r = n(1413);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var i = n(89062);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var u = n(15671);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var s = n(43144);
            var l = n(39294),
                c = n(36617),
                p = n(96024),
                d = n(12024),
                m = n(66232),
                y = /^(2400|3081|3179|8022|8384)$/.test(n.j) ? null : ["client_id"],
                _ = /^(2400|3081|3179|8022|8384)$/.test(n.j) ? null : "https://r.stripe.com/0",
                b = /^(2400|3081|3179|8022|8384)$/.test(n.j) ? null : "https://r.stripe.com/b",
                h = l.D1 && "function" == typeof navigator.sendBeacon,
                f = new Set(["stripe-js", "stripe-js-one-click-authn", "stripe-js-linked-accounts", "crypto-onramp"]),
                g = function(e) {
                    return new Blob([(0, c.qC)(e)]).size
                },
                k = /^(2400|3081|3179|8022|8384)$/.test(n.j) ? null : function() {
                    function e(t) {
                        var n = this,
                            a = t.clientId,
                            o = t.maxBatchSize;
                        (0, u.Z)(this, e), this.bufferedLogs = [], this.batchTimer = null, this.fetchQueue = [], this.inFlightBytes = 0, this.clientId = a, this.maxBatchSize = o, document.addEventListener("visibilitychange", (function() {
                            "hidden" === document.visibilityState && n.flushImmediately("visibilitystate")
                        })), window.addEventListener("beforeunload", (function() {
                            n.flushImmediately("beforeunload")
                        }))
                    }
                    return (0, s.Z)(e, [{
                        key: "queue",
                        value: function(e, t) {
                            var n = this;
                            try {
                                this.willOverflowBufferSize(e) && this.flush()
                            } catch (e) {}
                            this.bufferedLogs.push(e), "high" === t || this.bufferedLogs.length >= this.maxBatchSize ? this.flush(t) : this.batchTimer || (this.batchTimer = setTimeout((function() {
                                n.flush()
                            }), 1e3))
                        }
                    }, {
                        key: "getBatchPayload",
                        value: function() {
                            return {
                                client_id: this.clientId,
                                num_requests: this.bufferedLogs.length,
                                events: (0, i.Z)(this.bufferedLogs)
                            }
                        }
                    }, {
                        key: "resetBuffer",
                        value: function() {
                            this.bufferedLogs = [], this.batchTimer && (clearTimeout(this.batchTimer), this.batchTimer = null)
                        }
                    }, {
                        key: "flushImmediately",
                        value: function(e) {
                            var t = this.getBatchPayload();
                            t.events = t.events.map((function(t) {
                                return (0, r.Z)((0, r.Z)({}, t), {}, {
                                    event_flush_reason: e
                                })
                            }));
                            var n = this.prepareBatchPayloadForRequest(t);
                            if (0 !== t.num_requests)
                                if (this.resetBuffer(), this.isSendBeaconSupported() && this.requestWithBeacon(n))
                                    for (; this.fetchQueue.length > 0;) {
                                        var a = this.fetchQueue.shift();
                                        a && this.requestWithBeacon(a.payload)
                                    } else
                                        for (this.requestWithFetch({
                                                size: g(n),
                                                payload: n
                                            }); this.fetchQueue.length > 0;) {
                                            var o = this.fetchQueue.shift();
                                            o && this.requestWithFetch(o)
                                        }
                        }
                    }, {
                        key: "flush",
                        value: function(e) {
                            var t = this.prepareBatchPayloadForRequest(this.getBatchPayload());
                            0 !== t.num_requests && (this.resetBuffer(), this.send(t, e))
                        }
                    }, {
                        key: "send",
                        value: function(e, t) {
                            l.D1 && this.isSendBeaconSupported() && this.requestWithBeacon(e) || this.queueFetch(e, t)
                        }
                    }, {
                        key: "prepareBatchPayloadForRequest",
                        value: function(e) {
                            try {
                                var t = JSON.stringify(e.events);
                                return (0, r.Z)((0, r.Z)({}, e), {}, {
                                    events: t
                                })
                            } catch (e) {
                                throw this.resetBuffer(), e
                            }
                        }
                    }, {
                        key: "isSendBeaconSupported",
                        value: function() {
                            return navigator && "function" == typeof navigator.sendBeacon
                        }
                    }, {
                        key: "willOverflowBufferSize",
                        value: function(e) {
                            if (0 === this.bufferedLogs.length) return !1;
                            var t = [].concat((0, i.Z)(this.bufferedLogs), [e]),
                                n = {
                                    client_id: this.clientId,
                                    num_requests: t.length,
                                    events: t
                                };
                            return g(this.prepareBatchPayloadForRequest(n)) >= 32e3
                        }
                    }, {
                        key: "requestWithBeacon",
                        value: function(e) {
                            try {
                                if (window.navigator.sendBeacon && window.navigator.sendBeacon.bind) {
                                    var t = navigator.sendBeacon.bind(navigator),
                                        n = new Blob([(0, c.qC)(e)], {
                                            type: "application/x-www-form-urlencoded"
                                        });
                                    return t(b, n)
                                }
                            } catch (e) {
                                return !1
                            }
                            return !1
                        }
                    }, {
                        key: "queueFetch",
                        value: function(e, t) {
                            var n = g(e);
                            this.fetchQueue.push({
                                size: n,
                                payload: e
                            }), this.emptyFetchQueue(t)
                        }
                    }, {
                        key: "emptyFetchQueue",
                        value: function(e) {
                            for (; this.fetchQueue.length > 0 && (0 === this.inFlightBytes || this.inFlightBytes + this.fetchQueue[0].size < 5e4);) {
                                var t = this.fetchQueue.shift();
                                t && this.requestWithFetch(t, e)
                            }
                        }
                    }, {
                        key: "requestWithFetch",
                        value: function(e, t) {
                            var n = this,
                                a = e.size,
                                o = e.payload;
                            this.inFlightBytes += a, (0, p.h)({
                                url: b,
                                method: "POST",
                                data: o,
                                keepalive: !l.D1 || void 0,
                                withCredentials: !1,
                                priority: "high" === t ? "auto" : "low"
                            }).finally((function() {
                                n.inFlightBytes -= a, n.emptyFetchQueue()
                            }))
                        }
                    }]), e
                }(),
                v = /^(2400|3081|3179|8022|8384)$/.test(n.j) ? null : function() {
                    function e() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            n = t.useBatching,
                            a = t.useBatchingForTestMode,
                            o = t.maxBatchSize;
                        (0, u.Z)(this, e), this.clientQueues = {}, this.request = function(e, t) {
                            if (h) {
                                var n = new Blob([(0, c.qC)(e)], {
                                    type: "application/x-www-form-urlencoded"
                                });
                                navigator.sendBeacon(_, n)
                            } else(0, p.h)({
                                url: _,
                                method: "POST",
                                data: e,
                                keepalive: !0,
                                withCredentials: !1,
                                priority: "high" === t ? "auto" : "low"
                            })
                        }, this.useBatching = null != n && n, this.useBatchingForTestMode = null != a && a, this.maxBatchSize = null != o ? o : 5
                    }
                    return (0, s.Z)(e, [{
                        key: "send",
                        value: function(e) {
                            var t = e.name,
                                n = e.params,
                                a = e.priority;
                            if (void 0 === n.client_id || "string" == typeof n.client_id) {
                                var o = n.client_id || "stripe-js",
                                    r = this.shouldBatchEvent(o, n),
                                    i = {
                                        event_name: t,
                                        client_id: o,
                                        created: n.timestamp,
                                        batching_enabled: r
                                    };
                                Object.keys(n).forEach((function(e) {
                                    if ("timestamp" !== e && "client_id" !== e) {
                                        var t = n[e];
                                        null != t && (i[e] = (0, m.Q)(t, e))
                                    }
                                })), r ? this.queueEvent(i, a) : this.request(i)
                            }
                        }
                    }, {
                        key: "getClientQueuedEvents",
                        value: function() {
                            var e = {};
                            return (0, d.qh)(this.clientQueues).forEach((function(t) {
                                var n = (0, o.Z)(t, 2),
                                    a = n[0],
                                    r = n[1];
                                e[a] = r.getBatchPayload().events
                            })), e
                        }
                    }, {
                        key: "shouldBatchEvent",
                        value: function(e, t) {
                            return !!f.has(e) && (!("test" !== t.key_mode || !this.useBatchingForTestMode) || this.useBatching)
                        }
                    }, {
                        key: "getOrCreateClientQueue",
                        value: function(e) {
                            return this.clientQueues[e] || (this.clientQueues[e] = new k({
                                clientId: e,
                                maxBatchSize: this.maxBatchSize
                            })), this.clientQueues[e]
                        }
                    }, {
                        key: "queueEvent",
                        value: function(e, t) {
                            var n = e.client_id,
                                o = (0, a.Z)(e, y);
                            this.getOrCreateClientQueue(n).queue(o, t)
                        }
                    }]), e
                }()
        },
        66680: function(e, t, n) {
            "use strict";
            n.d(t, {
                x5: function() {
                    return i
                },
                pt: function() {
                    return r
                }
            });
            var a = n(71873),
                o = {
                    guid: a.Z_,
                    muid: a.Z_,
                    sid: a.Z_
                },
                r = (0, a.mC)(o),
                i = function(e) {
                    return !(!e || !(e.guid && "NA" !== e.guid || e.sid && "NA" !== e.sid || e.muid && "NA" !== e.muid))
                }
        },
        72292: function(e, t, n) {
            "use strict";
            n.d(t, {
                AJ: function() {
                    return y
                },
                CD: function() {
                    return p
                },
                GD: function() {
                    return r
                },
                I1: function() {
                    return _
                },
                JE: function() {
                    return d
                },
                Kf: function() {
                    return v
                },
                Kp: function() {
                    return i
                },
                QO: function() {
                    return s
                },
                R3: function() {
                    return k
                },
                VR: function() {
                    return h
                },
                Wb: function() {
                    return l
                },
                _Z: function() {
                    return c
                },
                gE: function() {
                    return m
                },
                q3: function() {
                    return f
                },
                s8: function() {
                    return u
                },
                wN: function() {
                    return b
                },
                wl: function() {
                    return g
                }
            });
            var a = n(73423),
                o = "stripe.js/".concat(a.X),
                r = "".concat(o, "; stripe-js-v3/").concat(a.X),
                i = "".concat(r, "; raw-card"),
                u = "".concat(r, "; raw-stripe-js-api"),
                s = "".concat(r, "; create-source-card-data"),
                l = "checkout",
                c = ("".concat(r, "; ").concat(l), "payment-link"),
                p = ("".concat(r, "; ").concat(c, "; ").concat(l), "".concat(r, "; hip"), "".concat(r, "; payment-element")),
                d = "".concat(p, "; deferred-intent"),
                m = "".concat(r, "; card-element"),
                y = "".concat(r, "; split-card-element"),
                _ = "".concat(r, "; lpm-element"),
                b = "".concat(r, "; payment-request-button"),
                h = "".concat(r, "; express-checkout-element"),
                f = "".concat(h, "; deferred-intent"),
                g = "hip",
                k = ["dashboard", g],
                v = "autopm"
        },
        10680: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return o
                }
            });
            var a = /^(2760|6364|8889)$/.test(n.j) ? null : [],
                o = function() {
                    a.forEach((function(e) {
                        return performance.mark(e.name, {
                            startTime: e.startTime
                        })
                    }))
                }
        },
        12876: function(e, t, n) {
            "use strict";
            n.d(t, {
                D: function() {
                    return a
                },
                j: function() {
                    return o
                }
            });
            var a = "element_mount",
                o = "stripe.js:"
        },
        31777: function(e, t, n) {
            "use strict";
            n.d(t, {
                K: function() {
                    return a
                }
            });
            var a = function(e) {
                if ("/v3" === e || "/v3/" === e) return e;
                if (0 !== e.indexOf("/v3/") && 0 !== e.indexOf("/fingerprinted/")) return e;
                var t = e.split("/");
                return t[t.length - 1].replace(/-[a-f0-9]{32}/, "")
            }
        },
        73341: function(e, t, n) {
            "use strict";
            n.d(t, {
                IR: function() {
                    return a.I
                },
                L8: function() {
                    return a.L
                },
                nq: function() {
                    return o.n
                }
            });
            var a = n(4380),
                o = n(64098)
        },
        4380: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    I: function() {
                        return l
                    },
                    L: function() {
                        return c
                    }
                }), !/^(2760|6364|8889)$/.test(n.j)) var a = n(89062);
            var o = n(69792);
            if (!/^(2760|6364|8889)$/.test(n.j)) var r = n(12876);
            if (!/^(2760|6364|8889)$/.test(n.j)) var i = n(31777);
            if (!/^(2760|6364|8889)$/.test(n.j)) var u = n(50138);
            var s = function(e) {
                    return e.map((function(e) {
                        var t, n = e.domainLookupStart;
                        n === e.startTime && (n = void 0), n && (n = Math.round(n));
                        var a = e.name;
                        0 === a.indexOf(r.j) && (a = a.substring(r.j.length));
                        try {
                            a = new URL(a).pathname
                        } catch (e) {}
                        if ("longtask" === e.entryType) {
                            a = "lt-".concat(a);
                            try {
                                var o = e.attribution;
                                t = o[0].containerName || (0, i.K)(o[0].containerSrc) || void 0
                            } catch (e) {}
                        }
                        if ("long-animation-frame" === e.entryType) try {
                            a = "laf", t = function(e) {
                                var t = e.scripts;
                                if (t && 0 !== t.length) {
                                    var n = t[0].invoker;
                                    if (/^https?:\/\//.test(n)) try {
                                        return (0, i.K)(new URL(n).pathname)
                                    } catch (e) {
                                        return
                                    }
                                    try {
                                        return "".concat((0, i.K)(new URL(t[0].sourceURL).pathname), "::").concat(n)
                                    } catch (e) {
                                        return n
                                    }
                                }
                            }(e)
                        } catch (e) {}
                        return {
                            t: Math.round(e.startTime),
                            d: Math.round(e.duration),
                            n: a,
                            f: n,
                            i: t
                        }
                    }))
                },
                l = function(e) {
                    var t = e.types,
                        n = e.reporter,
                        o = e.resourcePrefixFilter;
                    try {
                        if (!window.performance || !window.performance.getEntriesByType || !("PerformanceObserver" in window)) return;
                        var i, l = t.filter((function(e) {
                            return -1 !== PerformanceObserver.supportedEntryTypes.indexOf(e)
                        }));
                        l.push("mark"), (0, u.Dx)();
                        var c = [],
                            p = function(e, t) {
                                var u = function(e, t, n) {
                                    return "resource" === e && n ? t.filter((function(e) {
                                        return 0 === e.name.indexOf(n)
                                    })) : "mark" === e ? t.filter((function(e) {
                                        return 0 === e.name.indexOf(r.j)
                                    })) : t
                                }(e, t, o);
                                0 !== u.length && (clearTimeout(i), c.push.apply(c, (0, a.Z)(s(u))), i = setTimeout((function() {
                                    n(c.splice(0))
                                }), 100))
                            };
                        l.forEach((function(e) {
                            new PerformanceObserver((function(t) {
                                p(e, t.getEntries())
                            })).observe({
                                type: e,
                                buffered: !0
                            })
                        }))
                    } catch (e) {}
                },
                c = function(e, t, n) {
                    if ((0, u.JO)() && window.performance && t.mount) {
                        var a = o.E.fromPosixTime(t.mount),
                            i = a.getElapsedTime(e),
                            s = a.getElapsedTime(new o.E);
                        n.innerAction("RECORD_ELEMENTS_PERFORMANCE_TIMELINE", {
                            entries: [{
                                t: Math.round(performance.now() - s),
                                d: i,
                                n: "".concat(n.controllerFor(), "_").concat(r.D)
                            }],
                            frameSrc: location.href
                        })
                    }
                }
        },
        64098: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    n: function() {
                        return p
                    }
                }), 2204 == n.j) var a = n(1413);
            if (2204 == n.j) var o = n(89062);
            if (2204 == n.j) var r = n(15671);
            if (2204 == n.j) var i = n(43144);
            var u = n(12024);
            if (2204 == n.j) var s = n(31777);
            if (2204 == n.j) var l = n(50138);
            if (2204 == n.j) var c = n(12876);
            var p = 2204 == n.j ? function() {
                function e(t) {
                    (0, r.Z)(this, e), this.lastReported = new Date, this.lastReceived = new Date, this.outer = [], this.inner = {}, this.mountDurations = {}, this.hasUnreportedMountEvent = !1, this.log = t
                }
                return (0, i.Z)(e, [{
                    key: "recordEntries",
                    value: function(e, t) {
                        var n = this;
                        if ((0, l.JO)())
                            if (e.length > 1e3)(0, l.fu)();
                            else try {
                                if (t) {
                                    var a;
                                    this.inner[t] || (this.inner[t] = []), (a = this.inner[t]).push.apply(a, (0, o.Z)(e));
                                    var r = e.filter((function(e) {
                                        return -1 !== e.n.indexOf(c.D)
                                    }));
                                    r.length > 0 && (this.hasUnreportedMountEvent = !0, r.forEach((function(e) {
                                        n.mountDurations[e.n] = e.d
                                    })))
                                } else {
                                    var i;
                                    (i = this.outer).push.apply(i, (0, o.Z)(e))
                                }
                                this.lastReceived = new Date, this.hasUnreportedMountEvent && (clearTimeout(this.scheduleTimeoutId), this.scheduleTimeoutId = setTimeout((function() {
                                    n.report()
                                }), 500))
                            } catch (e) {
                                (0, l.fu)()
                            }
                    }
                }, {
                    key: "report",
                    value: function() {
                        clearTimeout(this.scheduleTimeoutId);
                        var e = this.lastReceived,
                            t = this.lastReported,
                            n = this.outer,
                            r = this.inner,
                            i = this.mountDurations;
                        if (!(t > e)) {
                            var l = n.map((function(e) {
                                return (0, a.Z)((0, a.Z)({}, e), {}, {
                                    n: (0, s.K)(e.n),
                                    e: "outer"
                                })
                            }));
                            Object.keys(r).forEach((function(e) {
                                var t = e;
                                try {
                                    t = new URL(e).pathname
                                } catch (e) {}
                                var i = (0, u.sE)(n, (function(e) {
                                    return e.n === t
                                }));
                                i && l.push.apply(l, (0, o.Z)(r[e].map((function(e) {
                                    return (0, a.Z)((0, a.Z)({}, e), {}, {
                                        n: (0, s.K)(e.n),
                                        t: e.t + i.t,
                                        f: e.f ? e.f + i.t : void 0,
                                        e: (0, s.K)(t)
                                    })
                                }))))
                            })), this.lastReported = new Date, l.length > 0 && (this.hasUnreportedMountEvent = !1, this.log("performance_timeline", (0, a.Z)({
                                timeline: JSON.stringify(l)
                            }, i)))
                        }
                    }
                }]), e
            }() : null
        },
        50138: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    Dx: function() {
                        return i
                    },
                    JO: function() {
                        return r
                    },
                    fu: function() {
                        return u
                    }
                }), !/^(2760|6364|8889)$/.test(n.j)) var a = n(10680);
            var o = !1,
                r = function() {
                    return o
                },
                i = function() {
                    o || (o = !0, (0, a.Z)())
                },
                u = function() {
                    o = !1
                }
        },
        56274: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                Promise: function() {
                    return u
                },
                default: function() {
                    return s
                }
            });
            var a, o = n(21803),
                r = n.n(o),
                i = (n(78029), window.Promise),
                u = i && null != i && null !== (a = i.prototype) && void 0 !== a && a.finally ? i : r(),
                s = null
        },
        37647: function(e, t, n) {
            "use strict";
            n.d(t, {
                tM: function() {
                    return a.t
                }
            });
            var a = n(92486);
            n(91077)
        },
        91077: function(e, t, n) {
            "use strict";
            n.d(t, {
                k: function() {
                    return i
                }
            });
            var a = n(33482),
                o = n(36617),
                r = null,
                i = {
                    log: function(e, t, n) {
                        (0, o.Qg)(window.location.origin) && (r || (r = (0, a.h)()).setDefaultPrefix("v3_redact."), r.log(e, t, {
                            prefix: n
                        }))
                    }
                }
        },
        92486: function(e, t, n) {
            "use strict";
            n.d(t, {
                t: function() {
                    return i
                }
            });
            var a = n(91077),
                o = /^(2(400|417|675)|4(2|505|928)|8(022|161|218|384)|3081|3179|7297)$/.test(n.j) ? null : [/"ascs_[a-zA-Z0-9]+"/g, /"uscs_[a-zA-Z0-9]+"/g, /"pscs_[a-zA-Z0-9]+"/g],
                r = {
                    network: [function(e) {
                        return /\/wallet-config/.test(e.url)
                    }, function(e) {
                        return /\/consumers\/sessions\/lookup/.test(e.url)
                    }, function(e) {
                        return /\/consumers\/sessions\/extend/.test(e.url)
                    }, function(e) {
                        return /\/set-cookie/.test(e.url)
                    }, function(e) {
                        return /\/networked_accounts/.test(e.url)
                    }, function(e) {
                        return /\/share_networked_account/.test(e.url)
                    }, function(e) {
                        return /\/onramp_session\/update/.test(e.url)
                    }],
                    postMessage: [function(e) {
                        return "outer" !== e.postMessageType
                    }],
                    logger: []
                },
                i = function(e, t, n) {
                    try {
                        if (! function(e) {
                                for (var t = r[e.boundaryType], n = 0; n < t.length; n++)
                                    if (t[n](e)) return !1;
                                return !0
                            }(t)) return e;
                        var i = JSON.stringify(e);
                        return o.forEach((function(e) {
                            var o = i.replace(e, '"[redacted]"');
                            i !== o && (i = o, a.k.log(null != n && n.logOnly ? "redaction.identified" : "redaction.performed", t))
                        })), null != n && n.logOnly ? e : JSON.parse(i)
                    } catch (n) {
                        return a.k.log("redaction.error", t), e
                    }
                }
        },
        73423: function(e, t, n) {
            "use strict";
            n.d(t, {
                X: function() {
                    return a
                },
                l: function() {
                    return o
                }
            });
            var a = /^(2400|3081|3179|8022|8384)$/.test(n.j) ? null : /*! STRIPE_JS_BUILD_SALT 803162f903*/ "803162f903",
                o = /^(2204|4928|7047|805)$/.test(n.j) ? /*! STRIPE_JS_BUILD_SALT 803162f903*/ "803162f903febcf286dcbf74134cd57e904175ba" : null
        },
        52303: function(e, t, n) {
            "use strict";
            n.d(t, {
                T: function() {
                    return a.T
                },
                W: function() {
                    return a.W
                }
            });
            var a = n(13362)
        },
        13362: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    T: function() {
                        return r
                    },
                    W: function() {
                        return u
                    }
                }), !/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j)) var a = n(1413);
            var o = n(94217),
                r = function(e) {
                    var t, n = e.result,
                        a = e.error,
                        o = "error" === (null == n ? void 0 : n.type) && (null == n || null === (t = n.error) || void 0 === t ? void 0 : t.status) || (null == a ? void 0 : a.status);
                    return !!o && o >= 500 && o < 600
                },
                i = Object.freeze({}),
                u = function(e, t, n) {
                    var r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : i;
                    return (0, o.h)({
                        url: e,
                        method: t,
                        data: n,
                        headers: r.headers,
                        contentType: r.contentType,
                        withCredentials: r.withCredentials,
                        priority: r.priority
                    }).then((function(e) {
                        var t;
                        r.logResult && r.logResult(e);
                        var n, o = {};
                        if (r.includeRequestId && e.getResponseHeader) try {
                            t = e.getResponseHeader("Request-Id")
                        } catch (e) {}
                        if (r.includeErrorStatus && e.getResponseHeader) try {
                            switch (e.getResponseHeader("Stripe-Should-Retry")) {
                                case "false":
                                    n = !1;
                                    break;
                                case "true":
                                    n = !0;
                                    break;
                                default:
                                    n = void 0
                            }
                        } catch (e) {}
                        try {
                            o = JSON.parse(e.responseText)
                        } catch (i) {
                            return o.error = {
                                message: "client generated error: could not parse responseText",
                                status: null
                            }, (0, a.Z)({
                                type: "error",
                                error: r.includeErrorStatus ? (0, a.Z)((0, a.Z)({}, o.error), {}, {
                                    status: e.status || 0
                                }, void 0 !== n ? {
                                    shouldRetry: n
                                } : null) : o.error
                            }, t ? {
                                requestId: t
                            } : null)
                        }
                        return 200 === e.status ? (0, a.Z)({
                            type: "object",
                            object: o
                        }, t ? {
                            requestId: t
                        } : null) : (0, a.Z)({
                            type: "error",
                            error: r.includeErrorStatus ? (0, a.Z)((0, a.Z)({}, o.error), {}, {
                                status: e.status || 0
                            }, void 0 !== n ? {
                                shouldRetry: n
                            } : null) : o.error
                        }, t ? {
                            requestId: t
                        } : null)
                    }))
                }
        },
        74355: function(e, t, n) {
            "use strict";
            n.d(t, {
                Am: function() {
                    return a.Am
                },
                Og: function() {
                    return a.Og
                },
                Xd: function() {
                    return a.Xd
                },
                vG: function() {
                    return a.vG
                }
            });
            var a = n(5268)
        },
        5268: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    Am: function() {
                        return d
                    },
                    Og: function() {
                        return p
                    },
                    Xd: function() {
                        return l
                    },
                    vG: function() {
                        return c
                    }
                }), 2204 == n.j) var a = n(1413);
            if (2204 == n.j) var o = n(4942);
            var r = function(e) {
                    return null != e && "function" == typeof e.toString ? e.toString() : ""
                },
                i = "(\\d\\s*\\+*%*){6}[\\d\\s+%]+",
                u = "((?:password|pass|pwd)[^=]*=)[^&]*",
                s = "((?:sk|rk|ek))_[\\w\\d]*",
                l = (new RegExp("".concat(i, "|").concat(u, "|").concat(s), "gi"), function(e) {
                    return r(e).replace(new RegExp(i, "g"), "<sanitized>")
                }),
                c = function(e) {
                    return r(e).replace(new RegExp(u, "gi"), "$1<sanitized>")
                },
                p = function(e) {
                    return r(e).replace(new RegExp(s, "gi"), "$1_<sanitized>")
                },
                d = function(e) {
                    if (!e || "object" != typeof e || !e.type && !e.code) return e;
                    var t = function(t) {
                        return e[t] && "string" == typeof e[t] ? (0, o.Z)({}, "".concat(t, "_id"), e[t]) : e[t] && "object" == typeof e[t] && "string" == typeof e[t].id ? (0, o.Z)({}, "".concat(t, "_id"), e[t].id) : null
                    };
                    return (0, a.Z)((0, a.Z)((0, a.Z)((0, a.Z)({
                        type: e.type,
                        code: e.code,
                        param: e.param
                    }, t("payment_intent")), t("setup_intent")), t("payment_method")), t("source"))
                }
        },
        60063: function(e, t, n) {
            "use strict";
            var a = [EvalError, RangeError, ReferenceError, SyntaxError, TypeError, URIError, window.DOMException].filter(Boolean).map((function(e) {
                    return [e.name, e]
                })),
                o = new Map(a);
            t.Z = 6364 != n.j ? o : null
        },
        45791: function(e, t, n) {
            "use strict";

            function a(e) {
                var t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    a = n.maxDepth,
                    o = void 0 === a ? Number.POSITIVE_INFINITY : a,
                    r = n.useToJSON,
                    i = void 0 === r || r;
                return "object" == typeof e && null !== e ? f({
                    from: e,
                    seen: [],
                    forceEnumerable: !0,
                    maxDepth: o,
                    depth: 0,
                    useToJSON: i,
                    serialize: !0
                }) : "function" == typeof e ? "[Function: ".concat(null !== (t = e.name) && void 0 !== t ? t : "anonymous", "]") : e
            }

            function o(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    n = t.maxDepth,
                    a = void 0 === n ? Number.POSITIVE_INFINITY : n;
                if (e instanceof Error) return e;
                if (i(e)) {
                    var o = h(e.name);
                    return f({
                        from: e,
                        seen: [],
                        to: new o,
                        maxDepth: a,
                        depth: 0,
                        serialize: !1
                    })
                }
                return new y(e)
            }

            function r(e) {
                return Boolean(e) && "object" == typeof e && "name" in e && "message" in e && "stack" in e
            }

            function i(e) {
                return Boolean(e) && "object" == typeof e && "message" in e && !Array.isArray(e)
            }
            if (n.d(t, {
                    Fq: function() {
                        return o
                    },
                    Xy: function() {
                        return a
                    }
                }), 6364 != n.j) var u = n(89062);
            var s = n(15671),
                l = n(43144),
                c = n(60136),
                p = n(29388),
                d = n(7112),
                m = n(60063),
                y = function(e) {
                    function t(e) {
                        var a;
                        return (0, s.Z)(this, t), (a = n.call(this, t._prepareSuperMessage(e))).name = "NonError", a
                    }(0, c.Z)(t, e);
                    var n = (0, p.Z)(t);
                    return (0, l.Z)(t, null, [{
                        key: "_prepareSuperMessage",
                        value: function(e) {
                            try {
                                return JSON.stringify(e)
                            } catch (t) {
                                return String(e)
                            }
                        }
                    }]), t
                }((0, d.Z)(Error)),
                _ = [{
                    property: "name",
                    enumerable: !1
                }, {
                    property: "message",
                    enumerable: !1
                }, {
                    property: "stack",
                    enumerable: !1
                }, {
                    property: "code",
                    enumerable: !0
                }, {
                    property: "cause",
                    enumerable: !1
                }],
                b = Symbol(".toJSON was called"),
                h = function(e) {
                    var t;
                    return null !== (t = m.Z.get(e)) && void 0 !== t ? t : Error
                },
                f = function e(t) {
                    var n = t.from,
                        a = t.seen,
                        o = t.to,
                        i = t.forceEnumerable,
                        s = t.maxDepth,
                        l = t.depth,
                        c = t.useToJSON,
                        p = t.serialize;
                    if (!o)
                        if (Array.isArray(n)) o = [];
                        else if (!p && r(n)) {
                        o = new(h(n.name))
                    } else o = {};
                    if (a.push(n), l >= s) return o;
                    if (c && "function" == typeof n.toJSON && !0 !== n[b]) return function(e) {
                        e[b] = !0;
                        var t = e.toJSON();
                        return delete e[b], t
                    }(n);
                    for (var d = function(t) {
                            return e({
                                from: t,
                                seen: (0, u.Z)(a),
                                forceEnumerable: i,
                                maxDepth: s,
                                depth: l,
                                useToJSON: c,
                                serialize: p
                            })
                        }, m = 0, y = Object.keys(n); m < y.length; m++) {
                        var f = y[m],
                            g = n[f];
                        null === g || "object" != typeof g || "function" != typeof g.pipe ? "function" != typeof g && (g && "object" == typeof g ? a.includes(n[f]) ? o[f] = "[Circular]" : (l++, o[f] = d(n[f])) : o[f] = g) : o[f] = "[object Stream]"
                    }
                    for (var k = 0, v = _; k < v.length; k++) {
                        var w = v[k],
                            A = w.property,
                            P = w.enumerable;
                        void 0 !== n[A] && null !== n[A] && Object.defineProperty(o, A, {
                            value: r(n[A]) ? d(n[A]) : n[A],
                            enumerable: !!i || P,
                            configurable: !0,
                            writable: !0
                        })
                    }
                    return o
                }
        },
        69792: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    E: function() {
                        return s
                    },
                    m: function() {
                        return r
                    }
                }), !/^(2(400|417|675)|30(81|97)|4(2|505|520|928)|8(022|161|218|384)|1667|6364|7297)$/.test(n.j)) var a = n(15671);
            if (!/^(2(400|417|675)|30(81|97)|4(2|505|520|928)|8(022|161|218|384)|1667|6364|7297)$/.test(n.j)) var o = n(43144);
            var r = Date.now ? function() {
                    return Date.now()
                } : function() {
                    return (new Date).getTime()
                },
                i = r(),
                u = window.performance && window.performance.now ? function() {
                    return window.performance.now()
                } : function() {
                    return r() - i
                },
                s = /^(2(400|417|675)|30(81|97)|4(2|505|520|928)|8(022|161|218|384)|1667|6364|7297)$/.test(n.j) ? null : function() {
                    function e(t) {
                        (0, a.Z)(this, e), this.timestampValue = null != t ? t : u()
                    }
                    return (0, o.Z)(e, [{
                        key: "getAsPosixTime",
                        value: function() {
                            return r() - this.getElapsedTime()
                        }
                    }, {
                        key: "getElapsedTime",
                        value: function(e) {
                            return Math.round((e ? e.timestampValue : u()) - this.timestampValue)
                        }
                    }, {
                        key: "valueOf",
                        value: function() {
                            return Math.round(this.timestampValue)
                        }
                    }], [{
                        key: "fromPosixTime",
                        value: function(t) {
                            return new e(t - r() + u())
                        }
                    }]), e
                }()
        },
        41216: function(e, t, n) {
            "use strict";
            n.d(t, {
                AM: function() {
                    return o
                },
                Dz: function() {
                    return r
                },
                td: function() {
                    return i
                },
                tp: function() {
                    return u
                }
            });
            var a = (0, n(36617).Ds)("https://payments.stripe.com"),
                o = a ? a.origin : "",
                r = new Set(["https://checkout.stripe.com", "https://checkout.link.com", "https://buy.stripe.com", "https://book.stripe.com", "https://donate.stripe.com", "https://js.stripe.com"]),
                i = !/^(1(180|283|789)|22(04|9)|3(033|58|607)|5(194|815|941)|8(05|285|308)|4110|4784|7047|9411)$/.test(n.j) && null,
                u = "https://pay-by-bank.stripe.com"
        },
        47600: function(e, t, n) {
            "use strict";
            n.d(t, {
                v: function() {
                    return o
                }
            });
            var a = function(e, t) {
                    return Object.prototype.hasOwnProperty.call(e, t)
                },
                o = function(e) {
                    var t = {};
                    return e.replace(/\+/g, " ").split("&").forEach((function(e) {
                        var n, o = e.split("="),
                            r = decodeURIComponent(o[0]),
                            i = t,
                            u = 0,
                            s = r.split("]["),
                            l = s.length - 1;
                        if (/\[/.test(s[0]) && /\]$/.test(s[l]) ? (s[l] = s[l].replace(/\]$/, ""), l = (s = s.shift().split("[").concat(s)).length - 1) : l = 0, !(s.indexOf("__proto__") >= 0))
                            if (2 === o.length)
                                if (n = decodeURIComponent(o[1]), l)
                                    for (; u <= l; u++) {
                                        if (r = "" === s[u] ? i.length : s[u], !a(i, r) && i[r]) return;
                                        i[r] = u < l ? i[r] || (s[u + 1] && isNaN(s[u + 1]) ? {} : []) : n, i = i[r]
                                    } else if (Array.isArray(t[r])) t[r].push(n);
                                    else if (void 0 !== t[r]) {
                            if (!a(t, r)) return;
                            t[r] = [t[r], n]
                        } else t[r] = n;
                        else r && (t[r] = "")
                    })), t
                }
        },
        36617: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ds: function() {
                    return r.Ds
                },
                Ev: function() {
                    return r.Ev
                },
                Je: function() {
                    return i.Je
                },
                K7: function() {
                    return i.K7
                },
                MX: function() {
                    return i.MX
                },
                P$: function() {
                    return r.P$
                },
                Qg: function() {
                    return i.Qg
                },
                U5: function() {
                    return i.U5
                },
                gm: function() {
                    return r.gm
                },
                kg: function() {
                    return r.kg
                },
                pZ: function() {
                    return r.pZ
                },
                qC: function() {
                    return o.q
                },
                sD: function() {
                    return r.sD
                },
                tl: function() {
                    return i.tl
                },
                uW: function() {
                    return i.uW
                },
                vB: function() {
                    return a.v
                },
                v_: function() {
                    return r.v_
                },
                vo: function() {
                    return i.vo
                },
                w0: function() {
                    return r.w0
                },
                xs: function() {
                    return r.xs
                }
            });
            var a = n(47600);
            if (!/^(2400|3081|3179|8022|8384)$/.test(n.j)) var o = n(54469);
            var r = n(13745),
                i = n(57306)
        },
        57306: function(e, t, n) {
            "use strict";
            n.d(t, {
                Je: function() {
                    return p
                },
                K7: function() {
                    return d
                },
                MX: function() {
                    return i
                },
                Qg: function() {
                    return l
                },
                U5: function() {
                    return r
                },
                tl: function() {
                    return c
                },
                uW: function() {
                    return u
                },
                vo: function() {
                    return s
                }
            });
            var a = n(13745),
                o = n(41216),
                r = function(e) {
                    var t = (0, a.Ds)(e),
                        n = t ? t.host : "";
                    return "stripe.com" === n || !!n.match(/\.stripe\.(com|me)$/)
                },
                i = function(e) {
                    var t, n = (0, a.Ds)(e),
                        o = n ? n.host : "";
                    return o === ((null === (t = (0, a.Ds)("https://checkout.link.com/")) || void 0 === t ? void 0 : t.host) || "checkout.link.com") || "link.com" === o || !!o.match(/\.link\.(com)$/)
                },
                u = function(e, t) {
                    var n = (0, a.Ds)(e),
                        o = (0, a.Ds)(t);
                    return !(!n || !o) && n.origin === o.origin
                },
                s = function(e) {
                    return u(e, "https://js.stripe.com/v3/")
                },
                l = function(e) {
                    return s(e) || r(e) || i(e)
                },
                c = function(e) {
                    return o.Dz.has(e)
                },
                p = function(e) {
                    return u(o.AM, e) || u(o.tp, e)
                },
                d = function(e) {
                    return -1 !== ["https://pay.openai.com", "https://app.verticaldiscounts.com", "https://billing.midjourney.com", "https://checkout.runwayml.com", "https://checkout.runpod.io", "https://checkout.traceup.com", "https://stripe.perplexity.ai", "https://checkout.ruby.com", "https://checkout.qogita.com", "https://stripe.checkout.clove.jp", "https://checkout.bubble.io", "https://checkout.zpos.co.uk", "https://billing.gamma.app", "https://pay.opus.pro", "https://checkout.bluebottlecoffee.com", "https://billing.synthesia.io", "https://payments.europeanwatch.com", "https://pay.mill.com", "https://checkout.usaservicedogs.org", "https://billing.kinderpedia.co", "https://pay.lumalabs.ai", "https://billing.joinhampton.com", "https://pay.parentapp.ca", "https://checkout.quimbee.com", "https://pay.leaseend.com", "https://checkout.contrarianthinking.co", "https://checkout.atlasearth.com", "https://pay.joinsherpa.com", "https://secure.aftershoot.com", "https://checkout.roaradx.com", "https://checkout.doctorsim.com", "https://pay.d-id.com", "https://pay.buffer.com", "https://checkout.trymeasured.com", "https://pay.halal.ad", "https://checkout.bookis.com", "https://pay.namebadge.com", "https://pay.eterneva.com", "https://payments.positiveintelligence.com", "https://checkout.makevisible.com", "https://payment.garrisonflood.com", "https://pay.rello.co", "https://buy.ispeedtolead.com", "https://checkout.wakingup.com", "https://billing.biggerpockets.com", "https://checkout.aaptiv.com", "https://checkout.biorender.com", "https://pay.thefloorbox.ca", "https://pay.bendpak.cloud", "https://checkout.posh.com", "https://payment.udio.com", "https://checkout.samharris.org", "https://pay.salvagedata.com", "https://checkout.firstbase.io", "https://checkout.mysterytacklebox.com", "https://checkout.kudoboard.com", "https://pay.typeset.io", "https://checkout.wander.com", "https://pay.firnal.com", "https://billing.vyro.ai", "https://pay.ucharts.com", "https://pay.mileiq.com", "https://checkout.journeyclinical.com", "https://checkout.myiee.org", "https://checkout.dgfantasy.com", "https://checkout.you.com", "https://pay.allsecurityequipment.com", "https://checkout.ducapp.com", "https://checkout.thriva.co", "https://pay.chartmetric.com", "https://pay.krea.ai", "https://payments.scoreapp.com", "https://billing.syftanalytics.com", "https://billing.mob.co.uk", "https://pro.neetcode.io", "https://checkout.exhibitionarchitect.co.uk", "https://billing.fxnutrition.com", "https://pay.dent.global", "https://payments.databox.com", "https://checkout.thesqua.re", "https://pay.chatbase.co", "https://payments.carrot.com", "https://pay.zix.com", "https://billing.healthcoachinstitute.com", "https://subscribe.betterteam.com", "https://pay.belevechad.nyc", "https://checkout.hopupairsoft.com", "https://checkout.sonix.ai", "https://checkout.avaskgroup.com", "https://payments.murf.ai", "https://checkout.storyy.co", "https://checkout.applydesign.io", "https://stripe.caktus.ai", "https://billing.kodekloud.com", "https://pay.kahunas.io", "https://pay.vivoaquatics.com", "https://membership.painacademy.net", "https://pay.photoroom.com", "https://book.homemove.com", "https://inversion.citruspatrimonial.com", "https://pay.lepetitchef.com", "https://billing.preflect.com", "https://pay.dealmachine.com", "https://checkout.caredge.com", "https://payment.victoriaplum.com", "https://billing.modal.com", "https://subscriptions.charlottetilbury.com", "https://billing.milanote.com", "https://checkout.beaconstac.com", "https://facturacion.barkibu.com", "https://billing.omnisend.com", "https://pay.sklum.com", "https://pay.mac.bid", "https://subscriptions-us.charlottetilbury.com", "https://buy.getbarcart.com", "https://billing.beehiiv.com", "https://checkout.docker.com", "https://payments.instrumentl.com", "https://uk.checkout.travelzoo.com", "https://buy.bigcartel.com", "https://checkout.brilliant.org", "https://payments-de.finn.auto", "https://billing.wonkybox.nz", "https://checkout.inman.com", "https://billing.volusion.com", "https://checkout.cerebral.com", "https://payment.roughtrade.com", "https://de.checkout.travelzoo.com", "https://payments.get-licensed.co.uk", "https://checkout.neumi.com", "https://pay.lokalise.com", "https://checkout.rathcommunications.com", "https://checkout.1nce.shop", "https://pay.ramseysolutions.com", "https://access.amboss.com", "https://pay.doit.com", "https://pay.luxuryflooringandfurnishings.co.uk", "https://pay.cenversa.com.au", "https://secure.megaplextheatres.com", "https://checkout.apparatusstudio.com", "https://checkout.junglescout.com", "https://checkout.hypeboost.com", "https://stripe.insurance-checkout.com", "https://checkout.crossmint.com", "https://checkout.hunter.io", "https://checkout.airtalkwireless.com", "https://checkout.box.co.uk", "https://checkout.maxx.sg", "https://account-billing.myfitnesspal.com", "https://checkout.ungrandjour.com", "https://pay.atom.com", "https://pay.reutersevents.com", "https://payments.finqle.com", "https://checkout.laptopoutlet.co.uk", "https://careplan.happyhealthypets.com", "https://pay.iticket.co.nz", "https://membership.switchyards.com", "https://pay.nianticlabs.com", "https://checkout.petpay.com"].indexOf(e)
                }
        },
        54469: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    q: function() {
                        return o
                    }
                }), !/^(2400|3081|3179|8022|8384)$/.test(n.j)) var a = n(89062);
            var o = function e(t, n) {
                var o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
                if (o > 20) return "";
                var r = [];
                return Object.keys(t).forEach((function(i) {
                    var u = t[i],
                        s = n ? "".concat(n, "[").concat(i, "]") : i;
                    if (u && "object" == typeof u) {
                        var l = e(u, s, o + 1);
                        "" !== l && (r = [].concat((0, a.Z)(r), [l]))
                    } else null != u && (r = [].concat((0, a.Z)(r), ["".concat(s, "=").concat(encodeURIComponent(String(u)))]))
                })), r.join("&").replace(/%20/g, "+")
            }
        },
        13745: function(e, t, n) {
            "use strict";
            n.d(t, {
                Ds: function() {
                    return s
                },
                Ev: function() {
                    return i
                },
                P$: function() {
                    return l
                },
                gm: function() {
                    return r
                },
                kg: function() {
                    return c
                },
                pZ: function() {
                    return u
                },
                sD: function() {
                    return o
                },
                v_: function() {
                    return p
                },
                w0: function() {
                    return m
                },
                xs: function() {
                    return d
                }
            });
            var a = /^(http(s)?):\/\//,
                o = function(e) {
                    return a.test(e)
                },
                r = function(e) {
                    return /^\/\//.test(e)
                },
                i = function(e) {
                    var t = e.match(a);
                    return t && t.length ? t[1] : null
                },
                u = function(e) {
                    return /^data:/.test(e)
                },
                s = function(e) {
                    if (!o(e)) return null;
                    var t;
                    try {
                        t = new URL(e)
                    } catch (n) {
                        (t = document.createElement("a")).href = e
                    }
                    var n = t.protocol,
                        a = t.host,
                        r = t.pathname,
                        i = t.hash,
                        u = /:80$/,
                        s = /:443$/;
                    return "http:" === n && u.test(a) ? a = a.replace(u, "") : "https:" === n && s.test(a) && (a = a.replace(s, "")), {
                        host: a,
                        protocol: n,
                        origin: "".concat(n, "//").concat(a),
                        pathname: r,
                        hash: i
                    }
                },
                l = function(e) {
                    var t = s(e);
                    return t ? t.origin : null
                },
                c = function(e) {
                    var t = l(e);
                    if (!t) throw new Error('Invalid URL: "'.concat(e, '"'));
                    return t
                },
                p = function(e, t) {
                    if ("/" === t[0]) {
                        var n = s(e);
                        return n ? "".concat(n.origin).concat(t) : t
                    }
                    var a = e.replace(/\/[^/]*$/, "/");
                    return "".concat(a).concat(t)
                },
                d = function(e) {
                    return e.replace(/\/$|$/, "/")
                },
                m = function(e) {
                    return e.split("?")[0].split("#")[0]
                }
        },
        92580: function(e, t, n) {
            "use strict";
            n.d(t, {
                Rq: function() {
                    return l
                },
                Rz: function() {
                    return s
                },
                fv: function() {
                    return c
                }
            });
            var a = n(43144),
                o = n(15671),
                r = n(60136),
                i = n(29388),
                u = n(7112),
                s = function() {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "absurd";
                    throw new Error(e)
                },
                l = function(e) {
                    function t(e) {
                        var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "absurd";
                        return (0, o.Z)(this, t), n.call(this, a)
                    }(0, r.Z)(t, e);
                    var n = (0, i.Z)(t);
                    return (0, a.Z)(t)
                }((0, u.Z)(Error)),
                c = function() {}
        },
        49605: function(e, t, n) {
            "use strict";
            n.d(t, {
                rX: function() {
                    return r
                }
            });
            var a = n(87974),
                o = (0, a.p5)("an Element", {
                    _componentName: a.Z_,
                    _groupId: a.Z_,
                    _implementation: (0, a.mC)({
                        _frame: (0, a.mC)({
                            id: a.Z_
                        })
                    })
                }),
                r = function(e) {
                    var t = (0, a.ld)(o, e, "");
                    return "error" === t.type ? null : t.value
                };
            (0, a.p5)("an Elements group", {
                _elements: (0, a.CT)(o),
                _id: a.Z_,
                _isSubmitting: a.Xg,
                _commonOptions: (0, a.$N)({
                    paymentMethodCreation: (0, a.jt)((0, a.kw)("manual")),
                    payment_method_types: (0, a.jt)((0, a.AG)((0, a.CT)(a.Z_))),
                    paymentMethodTypes: (0, a.jt)((0, a.AG)((0, a.CT)(a.Z_))),
                    clientSecret: (0, a.jt)((0, a.AG)((0, a.$N)({
                        id: a.Z_,
                        clientSecret: a.Z_,
                        type: a.Z_
                    }))),
                    mode: (0, a.jt)((0, a.AG)(a.Z_))
                }),
                _controller: (0, a.$N)({
                    _id: a.Z_
                })
            })
        },
        71873: function(e, t, n) {
            "use strict";
            n.d(t, {
                $3: function() {
                    return u.$3
                },
                $6: function() {
                    return u.$6
                },
                $N: function() {
                    return u.$N
                },
                AG: function() {
                    return u.AG
                },
                Ao: function() {
                    return u.Ao
                },
                Bi: function() {
                    return u.Bi
                },
                CT: function() {
                    return u.CT
                },
                Cz: function() {
                    return u.Cz
                },
                DM: function() {
                    return u.DM
                },
                Ec: function() {
                    return u.Ec
                },
                FL: function() {
                    return u.FL
                },
                Fy: function() {
                    return u.Fy
                },
                Gu: function() {
                    return u.Gu
                },
                HM: function() {
                    return u.HM
                },
                Ji: function() {
                    return s.Ji
                },
                Kr: function() {
                    return u.Kr
                },
                M2: function() {
                    return u.M2
                },
                M4: function() {
                    return u.M4
                },
                MZ: function() {
                    return u.MZ
                },
                O: function() {
                    return u.O
                },
                Q_: function() {
                    return u.Q_
                },
                Rq: function() {
                    return a.Rq
                },
                Rx: function() {
                    return u.Rx
                },
                Ry: function() {
                    return u.Ry
                },
                Rz: function() {
                    return a.Rz
                },
                Sl: function() {
                    return s.Sl
                },
                TX: function() {
                    return u.TX
                },
                Wc: function() {
                    return u.Wc
                },
                Wq: function() {
                    return i.W
                },
                Xg: function() {
                    return u.Xg
                },
                Xs: function() {
                    return u.Xs
                },
                Z_: function() {
                    return u.Z_
                },
                bv: function() {
                    return l.b
                },
                cV: function() {
                    return u.cV
                },
                ci: function() {
                    return u.ci
                },
                eH: function() {
                    return s.eH
                },
                eu: function() {
                    return u.eu
                },
                fv: function() {
                    return a.fv
                },
                gy: function() {
                    return u.gy
                },
                hN: function() {
                    return u.hN
                },
                ig: function() {
                    return u.ig
                },
                jt: function() {
                    return u.jt
                },
                kG: function() {
                    return r.k
                },
                kw: function() {
                    return u.kw
                },
                ld: function() {
                    return u.ld
                },
                mC: function() {
                    return u.mC
                },
                or: function() {
                    return u.or
                },
                p3: function() {
                    return u.p3
                },
                qQ: function() {
                    return s.qQ
                },
                rS: function() {
                    return u.rS
                },
                rX: function() {
                    return o.rX
                },
                ui: function() {
                    return u.ui
                },
                uw: function() {
                    return u.uw
                },
                uz: function() {
                    return u.uz
                },
                vC: function() {
                    return u.vC
                },
                x4: function() {
                    return u.x4
                },
                xe: function() {
                    return u.xe
                },
                yv: function() {
                    return u.yv
                },
                z$: function() {
                    return u.z$
                },
                zS: function() {
                    return u.zS
                }
            });
            var a = n(92580),
                o = n(49605);
            if (/^(704|948)7$/.test(n.j)) var r = n(39096);
            if (3033 == n.j) var i = n(80962);
            var u = n(87974);
            if (!/^(2(15|400|417|675|760)|3(081|097|179)|4(2|505|520|928)|8(022|161|218|384|889)|1667|6364|7297|9171)$/.test(n.j)) var s = n(34693);
            if (2675 == n.j) var l = n(82755)
        },
        87974: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    $3: function() {
                        return f
                    },
                    $6: function() {
                        return ie
                    },
                    $N: function() {
                        return pe
                    },
                    AG: function() {
                        return v
                    },
                    Ao: function() {
                        return _
                    },
                    Bi: function() {
                        return V
                    },
                    CT: function() {
                        return ee
                    },
                    Cz: function() {
                        return D
                    },
                    DM: function() {
                        return w
                    },
                    Ec: function() {
                        return B
                    },
                    FL: function() {
                        return ae
                    },
                    Fy: function() {
                        return te
                    },
                    Gu: function() {
                        return ye
                    },
                    HM: function() {
                        return M
                    },
                    Kr: function() {
                        return $
                    },
                    M2: function() {
                        return F
                    },
                    M4: function() {
                        return G
                    },
                    MZ: function() {
                        return W
                    },
                    O: function() {
                        return H
                    },
                    Q_: function() {
                        return X
                    },
                    Rx: function() {
                        return R
                    },
                    Ry: function() {
                        return J
                    },
                    TX: function() {
                        return de
                    },
                    Wc: function() {
                        return O
                    },
                    Xg: function() {
                        return z
                    },
                    Xs: function() {
                        return ne
                    },
                    Z_: function() {
                        return j
                    },
                    cV: function() {
                        return I
                    },
                    ci: function() {
                        return le
                    },
                    eu: function() {
                        return P
                    },
                    gy: function() {
                        return Z
                    },
                    hN: function() {
                        return x
                    },
                    ig: function() {
                        return q
                    },
                    jt: function() {
                        return k
                    },
                    kw: function() {
                        return N
                    },
                    ld: function() {
                        return me
                    },
                    mC: function() {
                        return se
                    },
                    or: function() {
                        return E
                    },
                    p3: function() {
                        return K
                    },
                    p5: function() {
                        return ce
                    },
                    rS: function() {
                        return U
                    },
                    ui: function() {
                        return C
                    },
                    uw: function() {
                        return oe
                    },
                    uz: function() {
                        return Q
                    },
                    vC: function() {
                        return A
                    },
                    x4: function() {
                        return b
                    },
                    xe: function() {
                        return L
                    },
                    yv: function() {
                        return re
                    },
                    z$: function() {
                        return T
                    },
                    zS: function() {
                        return h
                    }
                }), !/^(2(15|400|417|675|760)|3(097|179|58)|4(2|505|520|928)|8(022|05|161|218|384|889)|(166|704|729)7|6364|9171)$/.test(n.j)) var a = n(4942);
            var o = n(1413),
                r = n(89062),
                i = n(18812),
                u = n(12024),
                s = n(56241),
                l = n(12141),
                c = n(69620),
                p = n(36617),
                d = n(92580),
                m = ["card number", "name"],
                y = ["address", "billingDetails", "name", "postal_code", "postalCode", "phone"],
                _ = function(e, t, n, a) {
                    var o = a.reduce((function(e, t, n) {
                        return 0 === n ? t : 0 === t.indexOf(".") ? "".concat(e, '["').concat(t, '"]') : "".concat(e, ".").concat(t)
                    }), "");
                    return "undefined" === t ? "Missing value for ".concat(n.label, ": ").concat(o || "value", " should be ").concat(e, ".") : "Invalid value for ".concat(n.label, ": ").concat(o || "value", " should be ").concat(e, ". You specified: ").concat(t, ".")
                },
                b = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
                    return {
                        type: "valid",
                        value: e,
                        warnings: t
                    }
                },
                h = function(e) {
                    return {
                        error: e,
                        errorType: "full",
                        type: "error"
                    }
                },
                f = function(e, t, n, a) {
                    return {
                        expected: e,
                        actual: function(e, t) {
                            var n = typeof e;
                            switch (n) {
                                case "undefined":
                                case "boolean":
                                    return "".concat(e);
                                case "object":
                                    if (!e) return "".concat(e);
                                    var a = Object.keys(e);
                                    if (0 === a.length) return JSON.stringify(e);
                                    if (t) return "object with keys: [".concat(a, "]");
                                    try {
                                        return JSON.stringify(e)
                                    } catch (e) {
                                        return "object with keys: [".concat(a, "]")
                                    }
                                default:
                                    var o = "".concat(e);
                                    return t && (o = "".concat(n, ": ").concat(function(e) {
                                        if (e.length <= 3) return "[redacted]";
                                        var t = e[0],
                                            n = e[e.length - 1];
                                        return t + "*".repeat(e.length - 2) + n
                                    }(o))), o
                            }
                        }(t, !y.every((function(e) {
                            return -1 === a.indexOf(e)
                        })) || !m.every((function(e) {
                            return -1 === n.label.indexOf(e)
                        }))),
                        options: n,
                        errorType: "mismatch",
                        type: "error",
                        path: a
                    }
                },
                g = function(e, t) {
                    return [].concat((0, r.Z)(e), [t])
                },
                k = function(e) {
                    return function(t, n, a) {
                        return void 0 === t ? b(t) : e(t, n, a)
                    }
                },
                v = function(e) {
                    return function(t, n, a) {
                        return null === t ? b(t) : e(t, n, a)
                    }
                },
                w = function(e) {
                    return function(t) {
                        return function(n, a, o) {
                            return -1 === e.indexOf(a.element) ? void 0 === n ? b(n) : b(void 0, ["Invalid value for ".concat(a.label, ": The '").concat(a.element, "' Element does not support the '").concat(o.join("."), "' option")]) : t(n, a, o)
                        }
                    }
                },
                A = function(e, t) {
                    return function(n) {
                        return function(a, o, r) {
                            if (-1 !== e.indexOf(o.element)) {
                                var u = t || "The '".concat(o.element, "' Element does not support the '").concat(o.label, "' option");
                                return h(new i.No(u))
                            }
                            return n(a, o, r)
                        }
                    }
                },
                P = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                    return function(n) {
                        return function(a, o, r) {
                            if (-1 !== e.indexOf(o.element)) {
                                var i = "The '".concat(o.element, "' Element does not support the '").concat(r.join("."), "' option. ").concat(t);
                                return b(void 0, [i])
                            }
                            return n(a, o, r)
                        }
                    }
                },
                E = function(e, t) {
                    return function(n, a, o) {
                        var r = function(e) {
                                var t = e.path.join(".") || "value";
                                return {
                                    error: "".concat(t, " should be ").concat(e.expected),
                                    actual: "".concat(t, " as ").concat(e.actual)
                                }
                            },
                            u = function(e, t, n) {
                                return h(new i.No("Invalid value for ".concat(e, ": ").concat(t, ". You specified ").concat(n, ".")))
                            },
                            s = e(n, a, o),
                            l = t(n, a, o);
                        if ("error" === s.type && "error" === l.type) {
                            if ("mismatch" === s.errorType && "mismatch" === l.errorType) {
                                var c = r(s),
                                    p = c.error,
                                    d = c.actual,
                                    m = r(l),
                                    y = m.error,
                                    _ = m.actual;
                                return u(a.label, p === y ? p : "".concat(p, " or ").concat(y), d === _ ? d : "".concat(d, " and ").concat(_))
                            }
                            if ("mismatch" === s.errorType) {
                                var b = r(s),
                                    f = b.error,
                                    g = b.actual;
                                return u(a.label, f, g)
                            }
                            if ("mismatch" === l.errorType) {
                                var k = r(l),
                                    v = k.error,
                                    w = k.actual;
                                return u(a.label, v, w)
                            }
                            return h(s.error)
                        }
                        return "valid" === s.type ? s : l
                    }
                },
                S = function(e, t) {
                    return function(n, a, o) {
                        var r = (0, u.sE)(e, (function(e) {
                            return e === n
                        }));
                        if (void 0 === r) {
                            var i = t ? "a recognized string" : "one of the following strings: ".concat(e.join(", "));
                            return f(i, n, a, o)
                        }
                        return b(r)
                    }
                },
                L = function(e) {
                    return function(t, n, a) {
                        return "string" == typeof t && 0 === t.indexOf(e) ? b(t) : f("a string starting with ".concat(e), t, n, a)
                    }
                },
                C = function(e, t) {
                    return function(n, a, o) {
                        return "string" == typeof n && n.length >= e && n.length <= t ? b(n) : f(e === t ? "a string of ".concat(e, " characters") : "a string with ".concat(e, " to ").concat(t, " characters"), n, a, o)
                    }
                },
                N = function() {
                    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    return S(t, !1)
                },
                T = function() {
                    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    return S(t, !0)
                },
                x = N.apply(void 0, (0, r.Z)(l.J$)),
                I = N.apply(void 0, (0, r.Z)(s.QT)),
                B = N.apply(void 0, (0, r.Z)(Object.keys(c.Kl))),
                j = function(e, t, n) {
                    return "string" == typeof e ? b(e) : f("a string", e, t, n)
                },
                M = function(e, t, n) {
                    return "true" === e ? b(!0) : "false" === e ? b(!1) : f("a boolean", "" === e ? '""' : e, t, n)
                },
                O = function(e, t) {
                    return function(n, a, o) {
                        return void 0 === n ? b(t()) : e(n, a, o)
                    }
                },
                z = function(e, t, n) {
                    return "boolean" == typeof e ? b(e) : f("a boolean", e, t, n)
                },
                R = function(e, t, n) {
                    return "number" == typeof e ? b(e) : f("a number", e, t, n)
                },
                D = function(e, t, n) {
                    var a = j(e, t, n);
                    if ("error" === a.type) return a;
                    var o = Number(a.value);
                    return isNaN(o) ? f("a numeric string", e, t, n) : b(o)
                },
                U = function(e, t) {
                    return function(n, a, o) {
                        var r = j(n, a, o);
                        if ("error" === r.type) return r;
                        var i = Number(r.value);
                        return "string" == typeof n && i >= e && i <= t ? b(i) : f("a number from ".concat(e, " to ").concat(t), n, a, o)
                    }
                },
                q = function(e) {
                    return function(t, n, a) {
                        var o = j(t, n, a);
                        if ("error" === o.type) return o;
                        var r = Number(o.value);
                        return "string" == typeof t && r > e ? b(r) : f("a number greater than ".concat(e), t, n, a)
                    }
                },
                Z = function(e) {
                    return function(t, n, a) {
                        var o = j(t, n, a);
                        if ("error" === o.type) return o;
                        var r = Number(o.value);
                        return "string" == typeof t && r >= e ? b(r) : f("a number greater than or equal to ".concat(e), t, n, a)
                    }
                },
                H = function(e, t) {
                    return function(n, a, o) {
                        return "number" == typeof n && n >= e && n <= t ? b(n) : f("a number from ".concat(e, " to ").concat(t), n, a, o)
                    }
                },
                G = function(e) {
                    return function(t, n, a) {
                        return "number" == typeof t && t > e ? b(t) : f("a number greater than ".concat(e), t, n, a)
                    }
                },
                F = function(e) {
                    return function(t, n, a) {
                        return "number" == typeof t && t >= e ? b(t) : f("a number greater than or equal to ".concat(e), t, n, a)
                    }
                },
                K = function(e, t) {
                    return function(n, a, o) {
                        return n === e ? b(e) : f(t || String(e), n, a, o)
                    }
                },
                Y = function(e) {
                    return function(t, n, a) {
                        return "number" == typeof t && t === parseInt(t, 10) && (!e || t >= 0) ? b(t) : f(e ? "a positive amount in the currency's subunit" : "an amount in the currency's subunit", t, n, a)
                    }
                },
                V = function(e, t, n) {
                    return Y(!1)(e, t, n)
                },
                W = function(e, t, n) {
                    return Y(!0)(e, t, n)
                },
                $ = function e(t, n, a) {
                    if (t) {
                        if ("string" == typeof t) try {
                            var o = new Date(t);
                            if ("object" == typeof o && o.toISOString() === t) return e(o, n, a)
                        } catch (e) {}
                        if ("object" == typeof t) {
                            var r = t;
                            if ("function" == typeof r.getTime && r.getTime() >= Date.now() - 1e3) return b(r)
                        }
                    }
                    return f("a future Date", t, n, a)
                },
                J = function(e, t, n) {
                    return e && "object" == typeof e ? b(e) : f("an object", e, t, n)
                },
                X = function(e, t, n) {
                    var a, o = (a = "https", function(e, t, n) {
                        var o = j(e, t, n);
                        if ("error" === o.type) return o;
                        var r = (0, p.Ev)(o.value);
                        return a === r ? b(o.value) : f("an '".concat(a, "://' URL"), o.value, t, n)
                    })(e, t, n);
                    return "error" === o.type ? o : (0, p.U5)(o.value) ? b(o.value) : f("a valid HTTPS stripe.com URL", o.value, t, n)
                },
                Q = function(e, t, n) {
                    return "function" == typeof e ? b(e) : f("function", e, t, n)
                },
                ee = function(e) {
                    return function(t, n, a) {
                        return Array.isArray(t) ? t.map((function(t, o) {
                            return e(t, n, g(a, String(o)))
                        })).reduce((function(e, t) {
                            return "error" === e.type ? e : "error" === t.type ? t : b([].concat((0, r.Z)(e.value), [t.value]), [].concat((0, r.Z)(e.warnings), (0, r.Z)(t.warnings)))
                        }), b([])) : f("array", t, n, a)
                    }
                },
                te = function(e, t) {
                    return function(n, a, o) {
                        var r = ee(e)(n, a, o);
                        return "error" === r.type ? r : r.value.length < t ? b(n) : f("an array of size less than ".concat(t), n, a, o)
                    }
                },
                ne = function(e) {
                    return function(t, n, a) {
                        var o = ee(e)(t, n, a);
                        if ("error" === o.type) return o;
                        var r = o.value;
                        return b(r)
                    }
                },
                ae = function(e) {
                    return function(t, n, i) {
                        return !t || "object" != typeof t || Array.isArray(t) ? f("object", t, n, i) : Object.keys(t).reduce((function(u, s) {
                            if ("error" === u.type) return u;
                            var l = e(t[s], n, g(i, s));
                            return "error" === l.type ? l : b((0, o.Z)((0, o.Z)({}, u.value), {}, (0, a.Z)({}, s, l.value)), [].concat((0, r.Z)(u.warnings), (0, r.Z)(l.warnings)))
                        }), b({}))
                    }
                },
                oe = function(e) {
                    return function(t) {
                        return function(n, a, o) {
                            if (Array.isArray(n)) {
                                var r = t(n, a, o);
                                if ("valid" === r.type)
                                    for (var u = {}, s = 0; s < r.value.length; s += 1) {
                                        var l = r.value[s];
                                        if ("object" == typeof l && l && "string" == typeof l[e]) {
                                            var c = l[e],
                                                p = "_".concat(c);
                                            if (u[p]) return h(new i.No("Duplicate value for ".concat(e, ": ").concat(c, ". The property '").concat(e, "' of '").concat(o.join("."), "' has to be unique.")));
                                            u[p] = !0
                                        }
                                    }
                                return r
                            }
                            return f("array", n, a, o)
                        }
                    }
                },
                re = function(e) {
                    return function(t, n, a) {
                        return void 0 === t ? b(void 0) : f("used in ".concat(e, " instead"), t, n, a)
                    }
                },
                ie = function(e) {
                    return function(t, n, a) {
                        return (0, e[n.element])(t, n, a)
                    }
                },
                ue = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = t.unrecognizedKeyBehavior,
                        a = t.name;
                    return function(t, s, l) {
                        var c = null != n ? n : "warn";
                        if (t && "object" == typeof t && !Array.isArray(t)) {
                            var p = t,
                                d = (0, u.sE)(Object.keys(p), (function(t) {
                                    return !e[t]
                                }));
                            if (d && "error" === c) return h(new i.No("Invalid ".concat(s.label, " parameter: ").concat([].concat((0, r.Z)(l), [d]).join("."), " is not an accepted parameter.")));
                            var m = Object.keys(p),
                                y = b("passthrough" === c ? (0, o.Z)({}, t) : {});
                            return d && "warn" === c && (y = m.reduce((function(t, n) {
                                return e[n] ? t : b(t.value, [].concat((0, r.Z)(t.warnings), ["Unrecognized ".concat(s.label, " parameter: ").concat([].concat((0, r.Z)(l), [n]).join("."), " is not a recognized parameter. This may cause issues with your integration in the future.")]))
                            }), y)), Object.keys(e).reduce((function(n, o) {
                                if ("error" === n.type) return n;
                                var r = (0, e[o])(p[o], s, g(l, o));
                                return "valid" === r.type && void 0 !== r.value ? (n.value[o] = r.value, r.warnings.forEach((function(e) {
                                    n.warnings.push(e)
                                })), n) : "valid" === r.type ? (r.warnings.forEach((function(e) {
                                    n.warnings.push(e)
                                })), n) : a ? f(a, t, s, l) : r
                            }), y)
                        }
                        return f(null != a ? a : "an object", t, s, l)
                    }
                },
                se = function(e) {
                    return ue(e, {
                        unrecognizedKeyBehavior: "warn"
                    })
                },
                le = function(e) {
                    return ue(e, {
                        unrecognizedKeyBehavior: "error"
                    })
                },
                ce = function(e, t) {
                    return ue(t, {
                        unrecognizedKeyBehavior: "ignore",
                        name: e
                    })
                },
                pe = function(e) {
                    return ue(e, {
                        unrecognizedKeyBehavior: "ignore"
                    })
                },
                de = function(e) {
                    return ue(e, {
                        unrecognizedKeyBehavior: "passthrough"
                    })
                },
                me = function(e, t, n, a) {
                    var o = a || {},
                        r = o.path || [],
                        u = e(t, {
                            authenticatedOrigin: o.authenticatedOrigin || "",
                            element: o.element || "",
                            label: n
                        }, r);
                    return "valid" === u.type || "full" === u.errorType ? u : {
                        type: "error",
                        errorType: "full",
                        error: new i.No(_(u.expected, u.actual, u.options, u.path))
                    }
                },
                ye = function(e, t, n, a) {
                    var o = me(e, t, n, a);
                    switch (o.type) {
                        case "valid":
                            return {
                                value: o.value,
                                warnings: o.warnings
                            };
                        case "error":
                            throw o.error;
                        default:
                            return (0, d.Rz)(o)
                    }
                }
        },
        35918: function(e, t, n) {
            "use strict";
            n.d(t, {
                HO: function() {
                    return a.H
                },
                Yo: function() {
                    return o.Y
                },
                cg: function() {
                    return r.cg
                },
                jt: function() {
                    return r.jt
                },
                pY: function() {
                    return o.p
                }
            });
            var a = n(66666),
                o = n(27245),
                r = n(23600)
        },
        66666: function(e, t, n) {
            "use strict";
            n.d(t, {
                H: function() {
                    return u
                }
            });
            var a = n(69662),
                o = n(29757),
                r = n(27490),
                i = n(54379);
            (0, o.y_)(i.R);
            var u = function(e) {
                var t = (0, r.jR)(e);
                return (0, a.H)(t, i.$)
            }
        },
        27245: function(e, t, n) {
            "use strict";
            n.d(t, {
                Y: function() {
                    return r
                },
                p: function() {
                    return i
                }
            });
            var a = n(27490),
                o = n(62860),
                r = function(e, t) {
                    var n = (0, a.jR)(e);
                    return (0, o.Lk)(n, t)
                },
                i = function(e, t) {
                    var n = (0, a.jR)(e);
                    return (0, o.Qy)(n, t)
                }
        },
        23600: function(e, t, n) {
            "use strict";
            n.d(t, {
                cg: function() {
                    return i
                },
                jt: function() {
                    return r
                }
            });
            var a = n(27490),
                o = n(62860),
                r = function(e, t, n) {
                    var r = (0, a.jR)(e);
                    return (0, o.Lk)(r, t, n)
                },
                i = function(e, t, n) {
                    var r = (0, a.jR)(e);
                    return (0, o.Qy)(r, t, n)
                }
        },
        54379: function(e, t, n) {
            "use strict";
            n.d(t, {
                $: function() {
                    return At
                },
                R: function() {
                    return wt
                }
            });
            var a = n(83666),
                o = n(9373),
                r = n(90945),
                i = n(82736),
                u = n(21969),
                s = n(82697),
                l = n(40950),
                c = n(57410),
                p = n(21858),
                d = n(32126),
                m = n(9450),
                y = n(17705),
                _ = n(70395),
                b = n(81546),
                h = n(12693),
                f = n(33946),
                g = n(20129),
                k = n(24407),
                v = n(36549),
                w = n(90404),
                A = n(23344),
                P = n(32557),
                E = n(21377),
                S = n(22435),
                L = n(95139),
                C = n(379),
                N = n(42619),
                T = n(80385),
                x = n(30228),
                I = n(75764),
                B = n(29138),
                j = n(41605),
                M = n(51001),
                O = n(69114),
                z = n(1256),
                R = n(70424),
                D = n(59091),
                U = n(79550),
                q = n(46089),
                Z = n(28609),
                H = n(70445),
                G = n(88359),
                F = n(55504),
                K = n(43657),
                Y = n.n(K),
                V = n(65873),
                W = n.n(V),
                $ = n(57128),
                J = n.n($),
                X = n(63645),
                Q = n.n(X),
                ee = n(44460),
                te = n.n(ee),
                ne = n(30085),
                ae = n.n(ne),
                oe = n(97480),
                re = n.n(oe),
                ie = n(12623),
                ue = n.n(ie),
                se = n(91084),
                le = n.n(se),
                ce = n(62638),
                pe = n.n(ce),
                de = n(977),
                me = n.n(de),
                ye = n(28185),
                _e = n.n(ye),
                be = n(38501),
                he = n.n(be),
                fe = n(78963),
                ge = n.n(fe),
                ke = n(86802),
                ve = n.n(ke),
                we = n(6771),
                Ae = n.n(we),
                Pe = n(22844),
                Ee = n.n(Pe),
                Se = n(61579),
                Le = n.n(Se),
                Ce = n(52392),
                Ne = n.n(Ce),
                Te = n(98801),
                xe = n.n(Te),
                Ie = n(10903),
                Be = n.n(Ie),
                je = n(28496),
                Me = n.n(je),
                Oe = n(64225),
                ze = n.n(Oe),
                Re = n(8973),
                De = n.n(Re),
                Ue = n(8946),
                qe = n.n(Ue),
                Ze = n(18780),
                He = n.n(Ze),
                Ge = n(36023),
                Fe = n.n(Ge),
                Ke = n(78086),
                Ye = n.n(Ke),
                Ve = n(5525),
                We = n.n(Ve),
                $e = n(37322),
                Je = n.n($e),
                Xe = n(61909),
                Qe = n.n(Xe),
                et = n(42413),
                tt = n.n(et),
                nt = n(69226),
                at = n.n(nt),
                ot = n(60640),
                rt = n.n(ot),
                it = n(51038),
                ut = n.n(it),
                st = n(81301),
                lt = n.n(st),
                ct = n(79992),
                pt = n.n(ct),
                dt = n(8177),
                mt = n.n(dt),
                yt = n(94126),
                _t = n.n(yt),
                bt = n(53166),
                ht = n.n(bt),
                ft = n(70934),
                gt = n.n(ft),
                kt = n(99770),
                vt = n.n(kt),
                wt = {
                    ar: a,
                    bg: o,
                    cs: r,
                    da: i,
                    de: u,
                    en: l,
                    "en-GB": c,
                    "en-NL": c,
                    el: s,
                    es: p,
                    "es-419": d,
                    et: m,
                    fi: y,
                    fil: _,
                    fr: b,
                    "fr-CA": h,
                    he: f,
                    hr: g,
                    hu: k,
                    id: v,
                    it: w,
                    ja: A,
                    ko: P,
                    lt: E,
                    lv: S,
                    ms: L,
                    mt: C,
                    nb: x,
                    nl: N,
                    "nl-BE": T,
                    no: x,
                    pl: I,
                    pt: B,
                    "pt-BR": j,
                    ru: O,
                    ro: M,
                    sk: z,
                    sl: R,
                    sv: D,
                    th: U,
                    tr: q,
                    vi: Z,
                    zh: H,
                    "zh-HK": G,
                    "zh-TW": F
                },
                At = {
                    ar: Y(),
                    bg: W(),
                    cs: J(),
                    da: Q(),
                    de: te(),
                    el: ae(),
                    "en-GB": ue(),
                    "en-NL": ue(),
                    es: re(),
                    "es-419": le(),
                    et: pe(),
                    fi: me(),
                    fil: _e(),
                    fr: he(),
                    "fr-CA": ge(),
                    he: ve(),
                    hr: Ae(),
                    hu: Ee(),
                    id: Le(),
                    it: Ne(),
                    ja: xe(),
                    ko: Be(),
                    lt: Me(),
                    lv: ze(),
                    ms: De(),
                    mt: qe(),
                    nb: Ye(),
                    nl: He(),
                    "nl-BE": Fe(),
                    no: Ye(),
                    pl: We(),
                    pt: Je(),
                    "pt-BR": Qe(),
                    ru: at(),
                    ro: tt(),
                    sk: rt(),
                    sl: ut(),
                    sv: lt(),
                    th: pt(),
                    tr: mt(),
                    vi: _t(),
                    zh: ht(),
                    "zh-HK": gt(),
                    "zh-TW": vt()
                }
        },
        83920: function(e, t, n) {
            "use strict";
            n.d(t, {
                n: function() {
                    return i
                }
            });
            var a = n(36617);
            if (!/^(2760|6364|8889)$/.test(n.j)) var o = n(77985);
            var r = /^(2760|6364|8889)$/.test(n.j) ? null : ["Page already has an active payment session.", "ResizeObserver loop limit exceeded", "ResizeObserver loop completed with undelivered notifications."],
                i = function(e) {
                    var t, n, i, u;
                    if (function(e) {
                            return e._isUserError || "string" == typeof e.message && -1 !== r.indexOf(e.message) || "string" == typeof e.message && /Failed to execute\W*querySelectorAll\W*on\W*Document.*is not a valid selector/.test(e.message)
                        }(e)) return null;
                    var s = "string" == typeof e.fileName ? (0, a.w0)(e.fileName) : null,
                        l = "string" == typeof e.stack ? (0, o.H)(e.stack) : null,
                        c = !!s && -1 !== s.indexOf("https://js.stripe.com/v3/"),
                        p = function(e) {
                            return function(e) {
                                return "Script error." === e.message || "string" == typeof e.fileName && (0 === e.fileName.indexOf("chrome://") || 0 === e.fileName.indexOf("chrome-extension://"))
                            }(e) ? "uncaught_third_party_error" : "IntegrationError" === e.name ? "integration_error" : "fatal.uncaught_error"
                        }(e);
                    return {
                        eventName: p,
                        eventData: {
                            name: "string" == typeof e.name ? e.name : null,
                            message: "string" == typeof e.message ? e.message : null,
                            fileName: s,
                            lineNumber: "number" == typeof e.lineNumber ? e.lineNumber : null,
                            columnNumber: "number" == typeof e.columnNumber ? e.columnNumber : null,
                            stack: l,
                            iframe: e.iframe,
                            inPromise: null !== (t = e.inPromise) && void 0 !== t ? t : null,
                            element: null !== (n = e.element) && void 0 !== n ? n : null,
                            elementHasLoaded: null !== (i = e.elementHasLoaded) && void 0 !== i ? i : null,
                            apiMethodName: null !== (u = e.apiMethodName) && void 0 !== u ? u : null,
                            isStripeOrigin: c
                        }
                    }
                }
        },
        77007: function(e, t, n) {
            "use strict";
            n.d(t, {
                n: function() {
                    return a.n
                }
            });
            var a = n(83920)
        },
        77985: function(e, t, n) {
            "use strict";
            n.d(t, {
                H: function() {
                    return o
                }
            });
            var a = /https?:\/\/([^/]*)\/[^:]*/g,
                o = function(e) {
                    var t = e,
                        n = e.match(a);
                    return n && n.forEach((function(e) {
                        -1 === e.indexOf("https://js.stripe.com") && (t = t.replace(e, "<external url>"))
                    })), t.substring(0, 1e3)
                }
        },
        34627: function(e, t, n) {
            "use strict";
            if (n.d(t, {
                    V: function() {
                        return i
                    },
                    v: function() {
                        return o
                    }
                }), !/^(24(00|17)|8(022|05|384)|3081|3179)$/.test(n.j)) var a = n(40758);
            var o = "en",
                r = {
                    "es-HN": "es-419",
                    "es-MX": "es-419",
                    "es-US": "es-419"
                },
                i = function(e) {
                    try {
                        var t = (0, a.N)(e),
                            n = t.locale,
                            i = t.language,
                            u = [n];
                        return r[n] && u.push(r[n]), n !== i && u.push(i), u.push(o), u
                    } catch (t) {
                        return [e, o]
                    }
                }
        },
        27490: function(e, t, n) {
            "use strict";
            n.d(t, {
                Nj: function() {
                    return r.Nj
                },
                R7: function() {
                    return a.R7
                },
                RF: function() {
                    return a.RF
                },
                Vk: function() {
                    return o.V
                },
                jR: function() {
                    return r.jR
                },
                ud: function() {
                    return a.ud
                },
                vS: function() {
                    return o.v
                }
            });
            var a = n(56093),
                o = n(34627),
                r = n(72478)
        },
        72478: function(e, t, n) {
            "use strict";
            n.d(t, {
                Nj: function() {
                    return s
                },
                jR: function() {
                    return u
                }
            });
            var a = n(39294),
                o = n(47792),
                r = n(56093),
                i = n(34627),
                u = function(e) {
                    return function(e) {
                        for (var t = (0, i.V)(e), n = 0; n < t.length; n++) {
                            var a = t[n];
                            if (r.zK[a]) {
                                var u = r.zK[a];
                                if ((0, o.uN)(o.ub, o.M4.stripe_js_beta_locales) || -1 === o.P3.indexOf(u)) return u
                            }
                        }
                        return "en"
                    }("auto" === e ? (0, a.UT)() : e)
                },
                s = function(e) {
                    return u(e || "auto")
                }
        },
        56093: function(e, t, n) {
            "use strict";
            n.d(t, {
                R7: function() {
                    return i
                },
                RF: function() {
                    return a
                },
                ud: function() {
                    return o
                },
                zK: function() {
                    return r
                }
            });
            var a = {
                    ar: "ar",
                    bg: "bg",
                    cs: "cs",
                    da: "da",
                    de: "de",
                    el: "el",
                    en: "en",
                    "en-GB": "en-GB",
                    "en-NL": "en-NL",
                    es: "es",
                    "es-419": "es-419",
                    et: "et",
                    fi: "fi",
                    fil: "fil",
                    fr: "fr",
                    "fr-CA": "fr-CA",
                    he: "he",
                    hr: "hr",
                    hu: "hu",
                    id: "id",
                    it: "it",
                    ja: "ja",
                    ko: "ko",
                    lt: "lt",
                    lv: "lv",
                    ms: "ms",
                    mt: "mt",
                    nb: "nb",
                    nl: "nl",
                    "nl-BE": "nl-BE",
                    no: "no",
                    pl: "pl",
                    pt: "pt",
                    "pt-BR": "pt-BR",
                    ru: "ru",
                    ro: "ro",
                    sk: "sk",
                    sl: "sl",
                    sv: "sv",
                    th: "th",
                    tr: "tr",
                    vi: "vi",
                    zh: "zh",
                    "zh-HK": "zh-HK",
                    "zh-TW": "zh-TW"
                },
                o = /^(1(180|283|789)|5(194|815|941)|229|3033|3607|4110|4784|8285|8308|9411)$/.test(n.j) ? ["ar", "he"] : null,
                r = (Object.keys(a), /^(24(00|17)|8(022|05|384)|3081|3179)$/.test(n.j) ? null : a),
                i = function(e) {
                    return a[e] || "en"
                }
        },
        70655: function(e, t, n) {
            "use strict";

            function a(e, t) {
                function n() {
                    this.constructor = e
                }
                if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                L(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            }

            function o(e, t) {
                var n = {};
                for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && t.indexOf(a) < 0 && (n[a] = e[a]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                    var o = 0;
                    for (a = Object.getOwnPropertySymbols(e); o < a.length; o++) t.indexOf(a[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, a[o]) && (n[a[o]] = e[a[o]])
                }
                return n
            }

            function r(e, t, n, a) {
                var o, r = arguments.length,
                    i = r < 3 ? t : null === a ? a = Object.getOwnPropertyDescriptor(t, n) : a;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, n, a);
                else
                    for (var u = e.length - 1; u >= 0; u--)(o = e[u]) && (i = (r < 3 ? o(i) : r > 3 ? o(t, n, i) : o(t, n)) || i);
                return r > 3 && i && Object.defineProperty(t, n, i), i
            }

            function i(e, t) {
                return function(n, a) {
                    t(n, a, e)
                }
            }

            function u(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t)
            }

            function s(e, t, n, a) {
                return new(n || (n = S))((function(o, r) {
                    function i(e) {
                        try {
                            s(a.next(e))
                        } catch (e) {
                            r(e)
                        }
                    }

                    function u(e) {
                        try {
                            s(a.throw(e))
                        } catch (e) {
                            r(e)
                        }
                    }

                    function s(e) {
                        var t;
                        e.done ? o(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                            e(t)
                        }))).then(i, u)
                    }
                    s((a = a.apply(e, t || [])).next())
                }))
            }

            function l(e, t) {
                function n(n) {
                    return function(i) {
                        return function(n) {
                            if (a) throw new TypeError("Generator is already executing.");
                            for (; u;) try {
                                if (a = 1, o && (r = 2 & n[0] ? o.return : n[0] ? o.throw || ((r = o.return) && r.call(o), 0) : o.next) && !(r = r.call(o, n[1])).done) return r;
                                switch (o = 0, r && (n = [2 & n[0], r.value]), n[0]) {
                                    case 0:
                                    case 1:
                                        r = n;
                                        break;
                                    case 4:
                                        return u.label++, {
                                            value: n[1],
                                            done: !1
                                        };
                                    case 5:
                                        u.label++, o = n[1], n = [0];
                                        continue;
                                    case 7:
                                        n = u.ops.pop(), u.trys.pop();
                                        continue;
                                    default:
                                        if (!(r = u.trys, (r = r.length > 0 && r[r.length - 1]) || 6 !== n[0] && 2 !== n[0])) {
                                            u = 0;
                                            continue
                                        }
                                        if (3 === n[0] && (!r || n[1] > r[0] && n[1] < r[3])) {
                                            u.label = n[1];
                                            break
                                        }
                                        if (6 === n[0] && u.label < r[1]) {
                                            u.label = r[1], r = n;
                                            break
                                        }
                                        if (r && u.label < r[2]) {
                                            u.label = r[2], u.ops.push(n);
                                            break
                                        }
                                        r[2] && u.ops.pop(), u.trys.pop();
                                        continue
                                }
                                n = t.call(e, u)
                            } catch (e) {
                                n = [6, e], o = 0
                            } finally {
                                a = r = 0
                            }
                            if (5 & n[0]) throw n[1];
                            return {
                                value: n[0] ? n[1] : void 0,
                                done: !0
                            }
                        }([n, i])
                    }
                }
                var a, o, r, i, u = {
                    label: 0,
                    sent: function() {
                        if (1 & r[0]) throw r[1];
                        return r[1]
                    },
                    trys: [],
                    ops: []
                };
                return i = {
                    next: n(0),
                    throw: n(1),
                    return: n(2)
                }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                    return this
                }), i
            }

            function c(e, t) {
                for (var n in e) "default" === n || Object.prototype.hasOwnProperty.call(t, n) || N(t, e, n)
            }

            function p(e) {
                var t = "function" == typeof Symbol && Symbol.iterator,
                    n = t && e[t],
                    a = 0;
                if (n) return n.call(e);
                if (e && "number" == typeof e.length) return {
                    next: function() {
                        return e && a >= e.length && (e = void 0), {
                            value: e && e[a++],
                            done: !e
                        }
                    }
                };
                throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
            }

            function d(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, r = n.call(e),
                    i = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = r.next()).done;) i.push(a.value)
                } catch (e) {
                    o = {
                        error: e
                    }
                } finally {
                    try {
                        a && !a.done && (n = r.return) && n.call(r)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return i
            }

            function m() {
                for (var e = [], t = 0; t < arguments.length; t++) e = e.concat(d(arguments[t]));
                return e
            }

            function y() {
                for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
                var a = Array(e),
                    o = 0;
                for (t = 0; t < n; t++)
                    for (var r = arguments[t], i = 0, u = r.length; i < u; i++, o++) a[o] = r[i];
                return a
            }

            function _(e, t, n) {
                if (n || 2 === arguments.length)
                    for (var a, o = 0, r = t.length; o < r; o++) !a && o in t || (a || (a = Array.prototype.slice.call(t, 0, o)), a[o] = t[o]);
                return e.concat(a || Array.prototype.slice.call(t))
            }

            function b(e) {
                return this instanceof b ? (this.v = e, this) : new b(e)
            }

            function h(e, t, n) {
                function a(e) {
                    l[e] && (s[e] = function(t) {
                        return new S((function(n, a) {
                            c.push([e, t, n, a]) > 1 || o(e, t)
                        }))
                    })
                }

                function o(e, t) {
                    try {
                        (n = l[e](t)).value instanceof b ? S.resolve(n.value.v).then(r, i) : u(c[0][2], n)
                    } catch (e) {
                        u(c[0][3], e)
                    }
                    var n
                }

                function r(e) {
                    o("next", e)
                }

                function i(e) {
                    o("throw", e)
                }

                function u(e, t) {
                    e(t), c.shift(), c.length && o(c[0][0], c[0][1])
                }
                if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
                var s, l = n.apply(e, t || []),
                    c = [];
                return s = {}, a("next"), a("throw"), a("return"), s[Symbol.asyncIterator] = function() {
                    return this
                }, s
            }

            function f(e) {
                function t(t, o) {
                    n[t] = e[t] ? function(n) {
                        return (a = !a) ? {
                            value: b(e[t](n)),
                            done: "return" === t
                        } : o ? o(n) : n
                    } : o
                }
                var n, a;
                return n = {}, t("next"), t("throw", (function(e) {
                    throw e
                })), t("return"), n[Symbol.iterator] = function() {
                    return this
                }, n
            }

            function g(e) {
                function t(t) {
                    n[t] = e[t] && function(n) {
                        return new S((function(a, o) {
                            (function(e, t, n, a) {
                                S.resolve(a).then((function(t) {
                                    e({
                                        value: t,
                                        done: n
                                    })
                                }), t)
                            })(a, o, (n = e[t](n)).done, n.value)
                        }))
                    }
                }
                if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
                var n, a = e[Symbol.asyncIterator];
                return a ? a.call(e) : (e = p(e), n = {}, t("next"), t("throw"), t("return"), n[Symbol.asyncIterator] = function() {
                    return this
                }, n)
            }

            function k(e, t) {
                return Object.defineProperty ? Object.defineProperty(e, "raw", {
                    value: t
                }) : e.raw = t, e
            }

            function v(e) {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e)
                    for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && N(t, e, n);
                return T(t, e), t
            }

            function w(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }

            function A(e, t, n, a) {
                if ("a" === n && !a) throw new TypeError("Private accessor was defined without a getter");
                if ("function" == typeof t ? e !== t || !a : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
                return "m" === n ? a : "a" === n ? a.call(e) : a ? a.value : t.get(e)
            }

            function P(e, t, n, a, o) {
                if ("m" === a) throw new TypeError("Private method is not writable");
                if ("a" === a && !o) throw new TypeError("Private accessor was defined without a setter");
                if ("function" == typeof t ? e !== t || !o : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
                return "a" === a ? o.call(e, n) : o ? o.value = n : t.set(e, n), n
            }

            function E(e, t) {
                if (null === t || "object" != typeof t && "function" != typeof t) throw new TypeError("Cannot use 'in' operator on non-object");
                return "function" == typeof e ? t === e : e.has(t)
            }
            n.r(t), n.d(t, {
                __assign: function() {
                    return C
                },
                __asyncDelegator: function() {
                    return f
                },
                __asyncGenerator: function() {
                    return h
                },
                __asyncValues: function() {
                    return g
                },
                __await: function() {
                    return b
                },
                __awaiter: function() {
                    return s
                },
                __classPrivateFieldGet: function() {
                    return A
                },
                __classPrivateFieldIn: function() {
                    return E
                },
                __classPrivateFieldSet: function() {
                    return P
                },
                __createBinding: function() {
                    return N
                },
                __decorate: function() {
                    return r
                },
                __exportStar: function() {
                    return c
                },
                __extends: function() {
                    return a
                },
                __generator: function() {
                    return l
                },
                __importDefault: function() {
                    return w
                },
                __importStar: function() {
                    return v
                },
                __makeTemplateObject: function() {
                    return k
                },
                __metadata: function() {
                    return u
                },
                __param: function() {
                    return i
                },
                __read: function() {
                    return d
                },
                __rest: function() {
                    return o
                },
                __spread: function() {
                    return m
                },
                __spreadArray: function() {
                    return _
                },
                __spreadArrays: function() {
                    return y
                },
                __values: function() {
                    return p
                }
            });
            var S = n(56274).Promise,
                L = function(e, t) {
                    return L = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    }, L(e, t)
                },
                C = function() {
                    return C = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, C.apply(this, arguments)
                },
                N = Object.create ? function(e, t, n, a) {
                    void 0 === a && (a = n);
                    var o = Object.getOwnPropertyDescriptor(t, n);
                    o && !("get" in o ? !t.__esModule : o.writable || o.configurable) || (o = {
                        enumerable: !0,
                        get: function() {
                            return t[n]
                        }
                    }), Object.defineProperty(e, a, o)
                } : function(e, t, n, a) {
                    void 0 === a && (a = n), e[a] = t[n]
                },
                T = Object.create ? function(e, t) {
                    Object.defineProperty(e, "default", {
                        enumerable: !0,
                        value: t
                    })
                } : function(e, t) {
                    e.default = t
                }
        },
        30907: function(e, t, n) {
            "use strict";

            function a(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, a = new Array(t); n < t; n++) a[n] = e[n];
                return a
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        83878: function(e, t, n) {
            "use strict";

            function a(e) {
                if (Array.isArray(e)) return e
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        45057: function(e, t, n) {
            "use strict";

            function a(e) {
                if (Array.isArray(e)) return (0, o.Z)(e)
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var o = n(30907)
        },
        97326: function(e, t, n) {
            "use strict";

            function a(e) {
                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        15861: function(e, t, n) {
            "use strict";

            function a(e, t, n, a, o, i, u) {
                try {
                    var s = e[i](u),
                        l = s.value
                } catch (e) {
                    return void n(e)
                }
                s.done ? t(l) : r.resolve(l).then(a, o)
            }

            function o(e) {
                return function() {
                    var t = this,
                        n = arguments;
                    return new r((function(o, r) {
                        function i(e) {
                            a(s, o, r, i, u, "next", e)
                        }

                        function u(e) {
                            a(s, o, r, i, u, "throw", e)
                        }
                        var s = e.apply(t, n);
                        i(void 0)
                    }))
                }
            }
            n.d(t, {
                Z: function() {
                    return o
                }
            });
            var r = n(56274).Promise
        },
        15671: function(e, t, n) {
            "use strict";

            function a(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        5647: function(e, t, n) {
            "use strict";

            function a() {
                return a = (0, r.Z)() ? Reflect.construct.bind() : function(e, t, n) {
                    var a = [null];
                    a.push.apply(a, t);
                    var r = new(Function.bind.apply(e, a));
                    return n && (0, o.Z)(r, n.prototype), r
                }, a.apply(null, arguments)
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var o = n(89611),
                r = n(78814)
        },
        43144: function(e, t, n) {
            "use strict";

            function a(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var a = t[n];
                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                }
            }

            function o(e, t, n) {
                return t && a(e.prototype, t), n && a(e, n), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), e
            }
            n.d(t, {
                Z: function() {
                    return o
                }
            })
        },
        29388: function(e, t, n) {
            "use strict";

            function a(e) {
                var t = (0, r.Z)();
                return function() {
                    var n, a = (0, o.Z)(e);
                    if (t) {
                        var r = (0, o.Z)(this).constructor;
                        n = Reflect.construct(a, arguments, r)
                    } else n = a.apply(this, arguments);
                    return (0, i.Z)(this, n)
                }
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var o = n(61120),
                r = n(78814),
                i = n(82963)
        },
        4942: function(e, t, n) {
            "use strict";

            function a(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        87462: function(e, t, n) {
            "use strict";

            function a() {
                return a = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a])
                    }
                    return e
                }, a.apply(this, arguments)
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        61120: function(e, t, n) {
            "use strict";

            function a(e) {
                return a = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                }, a(e)
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        60136: function(e, t, n) {
            "use strict";

            function a(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && (0, o.Z)(e, t)
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var o = n(89611)
        },
        48989: function(e, t, n) {
            "use strict";

            function a(e) {
                return -1 !== Function.toString.call(e).indexOf("[native code]")
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        78814: function(e, t, n) {
            "use strict";

            function a() {
                if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" == typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                } catch (e) {
                    return !1
                }
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        59199: function(e, t, n) {
            "use strict";

            function a(e) {
                if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        31902: function(e, t, n) {
            "use strict";

            function a(e, t) {
                var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (null != n) {
                    var a, o, r = [],
                        i = !0,
                        u = !1;
                    try {
                        for (n = n.call(e); !(i = (a = n.next()).done) && (r.push(a.value), !t || r.length !== t); i = !0);
                    } catch (e) {
                        u = !0, o = e
                    } finally {
                        try {
                            i || null == n.return || n.return()
                        } finally {
                            if (u) throw o
                        }
                    }
                    return r
                }
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        25267: function(e, t, n) {
            "use strict";

            function a() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        42786: function(e, t, n) {
            "use strict";

            function a() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        36459: function(e, t, n) {
            "use strict";

            function a(e) {
                if (null == e) throw new TypeError("Cannot destructure undefined")
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        1413: function(e, t, n) {
            "use strict";

            function a(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    t && (a = a.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), n.push.apply(n, a)
                }
                return n
            }

            function o(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? a(Object(n), !0).forEach((function(t) {
                        (0, r.Z)(e, t, n[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }))
                }
                return e
            }
            n.d(t, {
                Z: function() {
                    return o
                }
            });
            var r = n(4942)
        },
        45987: function(e, t, n) {
            "use strict";

            function a(e, t) {
                if (null == e) return {};
                var n, a, r = (0, o.Z)(e, t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(e);
                    for (a = 0; a < i.length; a++) n = i[a], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n])
                }
                return r
            }
            if (n.d(t, {
                    Z: function() {
                        return a
                    }
                }), !/^(2400|3081|3179|8384)$/.test(n.j)) var o = n(63366)
        },
        63366: function(e, t, n) {
            "use strict";

            function a(e, t) {
                if (null == e) return {};
                var n, a, o = {},
                    r = Object.keys(e);
                for (a = 0; a < r.length; a++) n = r[a], t.indexOf(n) >= 0 || (o[n] = e[n]);
                return o
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        82963: function(e, t, n) {
            "use strict";

            function a(e, t) {
                if (t && ("object" === (0, o.Z)(t) || "function" == typeof t)) return t;
                if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
                return (0, r.Z)(e)
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var o = n(71002),
                r = n(97326)
        },
        74165: function(e, t, n) {
            "use strict";

            function a() {
                function e(e, t, n) {
                    return Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }

                function t(e, t, a, o) {
                    var r = t && t.prototype instanceof i ? t : i,
                        u = Object.create(r.prototype),
                        s = new y(o || []);
                    return u._invoke = function(e, t, a) {
                        var o = "suspendedStart";
                        return function(r, i) {
                            if ("executing" === o) throw new Error("Generator is already running");
                            if ("completed" === o) {
                                if ("throw" === r) throw i;
                                return b()
                            }
                            for (a.method = r, a.arg = i;;) {
                                var u = a.delegate;
                                if (u) {
                                    var s = p(u, a);
                                    if (s) {
                                        if (s === P) continue;
                                        return s
                                    }
                                }
                                if ("next" === a.method) a.sent = a._sent = a.arg;
                                else if ("throw" === a.method) {
                                    if ("suspendedStart" === o) throw o = "completed", a.arg;
                                    a.dispatchException(a.arg)
                                } else "return" === a.method && a.abrupt("return", a.arg);
                                o = "executing";
                                var l = n(e, t, a);
                                if ("normal" === l.type) {
                                    if (o = a.done ? "completed" : "suspendedYield", l.arg === P) continue;
                                    return {
                                        value: l.arg,
                                        done: a.done
                                    }
                                }
                                "throw" === l.type && (o = "completed", a.method = "throw", a.arg = l.arg)
                            }
                        }
                    }(e, a, s), u
                }

                function n(e, t, n) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, n)
                        }
                    } catch (e) {
                        return {
                            type: "throw",
                            arg: e
                        }
                    }
                }

                function i() {}

                function u() {}

                function s() {}

                function l(t) {
                    ["next", "throw", "return"].forEach((function(n) {
                        e(t, n, (function(e) {
                            return this._invoke(n, e)
                        }))
                    }))
                }

                function c(e, t) {
                    function a(r, i, u, s) {
                        var l = n(e[r], e, i);
                        if ("throw" !== l.type) {
                            var c = l.arg,
                                p = c.value;
                            return p && "object" == (0, o.Z)(p) && g.call(p, "__await") ? t.resolve(p.__await).then((function(e) {
                                a("next", e, u, s)
                            }), (function(e) {
                                a("throw", e, u, s)
                            })) : t.resolve(p).then((function(e) {
                                c.value = e, u(c)
                            }), (function(e) {
                                return a("throw", e, u, s)
                            }))
                        }
                        s(l.arg)
                    }
                    var r;
                    this._invoke = function(e, n) {
                        function o() {
                            return new t((function(t, o) {
                                a(e, n, t, o)
                            }))
                        }
                        return r = r ? r.then(o, o) : o()
                    }
                }

                function p(e, t) {
                    var a = e.iterator[t.method];
                    if (void 0 === a) {
                        if (t.delegate = null, "throw" === t.method) {
                            if (e.iterator.return && (t.method = "return", t.arg = void 0, p(e, t), "throw" === t.method)) return P;
                            t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return P
                    }
                    var o = n(a, e.iterator, t.arg);
                    if ("throw" === o.type) return t.method = "throw", t.arg = o.arg, t.delegate = null, P;
                    var r = o.arg;
                    return r ? r.done ? (t[e.resultName] = r.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, P) : r : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, P)
                }

                function d(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function m(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function y(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(d, this), this.reset(!0)
                }

                function _(e) {
                    if (e) {
                        var t = e[v];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var n = -1,
                                a = function t() {
                                    for (; ++n < e.length;)
                                        if (g.call(e, n)) return t.value = e[n], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return a.next = a
                        }
                    }
                    return {
                        next: b
                    }
                }

                function b() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                a = function() {
                    return h
                };
                var h = {},
                    f = Object.prototype,
                    g = f.hasOwnProperty,
                    k = "function" == typeof Symbol ? Symbol : {},
                    v = k.iterator || "@@iterator",
                    w = k.asyncIterator || "@@asyncIterator",
                    A = k.toStringTag || "@@toStringTag";
                try {
                    e({}, "")
                } catch (t) {
                    e = function(e, t, n) {
                        return e[t] = n
                    }
                }
                h.wrap = t;
                var P = {},
                    E = {};
                e(E, v, (function() {
                    return this
                }));
                var S = Object.getPrototypeOf,
                    L = S && S(S(_([])));
                L && L !== f && g.call(L, v) && (E = L);
                var C = s.prototype = i.prototype = Object.create(E);
                return u.prototype = s, e(C, "constructor", s), e(s, "constructor", u), u.displayName = e(s, A, "GeneratorFunction"), h.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === u || "GeneratorFunction" === (t.displayName || t.name))
                }, h.mark = function(t) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(t, s) : (t.__proto__ = s, e(t, A, "GeneratorFunction")), t.prototype = Object.create(C), t
                }, h.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, l(c.prototype), e(c.prototype, w, (function() {
                    return this
                })), h.AsyncIterator = c, h.async = function(e, n, a, o, i) {
                    void 0 === i && (i = r);
                    var u = new c(t(e, n, a, o), i);
                    return h.isGeneratorFunction(n) ? u : u.next().then((function(e) {
                        return e.done ? e.value : u.next()
                    }))
                }, l(C), e(C, A, "Generator"), e(C, v, (function() {
                    return this
                })), e(C, "toString", (function() {
                    return "[object Generator]"
                })), h.keys = function(e) {
                    var t = [];
                    for (var n in e) t.push(n);
                    return t.reverse(),
                        function n() {
                            for (; t.length;) {
                                var a = t.pop();
                                if (a in e) return n.value = a, n.done = !1, n
                            }
                            return n.done = !0, n
                        }
                }, h.values = _, y.prototype = {
                    constructor: y,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(m), !e)
                            for (var t in this) "t" === t.charAt(0) && g.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        function t(t, a) {
                            return r.type = "throw", r.arg = e, n.next = t, a && (n.method = "next", n.arg = void 0), !!a
                        }
                        if (this.done) throw e;
                        for (var n = this, a = this.tryEntries.length - 1; a >= 0; --a) {
                            var o = this.tryEntries[a],
                                r = o.completion;
                            if ("root" === o.tryLoc) return t("end");
                            if (o.tryLoc <= this.prev) {
                                var i = g.call(o, "catchLoc"),
                                    u = g.call(o, "finallyLoc");
                                if (i && u) {
                                    if (this.prev < o.catchLoc) return t(o.catchLoc, !0);
                                    if (this.prev < o.finallyLoc) return t(o.finallyLoc)
                                } else if (i) {
                                    if (this.prev < o.catchLoc) return t(o.catchLoc, !0)
                                } else {
                                    if (!u) throw new Error("try statement without catch or finally");
                                    if (this.prev < o.finallyLoc) return t(o.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                            var a = this.tryEntries[n];
                            if (a.tryLoc <= this.prev && g.call(a, "finallyLoc") && this.prev < a.finallyLoc) {
                                var o = a;
                                break
                            }
                        }
                        o && ("break" === e || "continue" === e) && o.tryLoc <= t && t <= o.finallyLoc && (o = null);
                        var r = o ? o.completion : {};
                        return r.type = e, r.arg = t, o ? (this.method = "next", this.next = o.finallyLoc, P) : this.complete(r)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), P
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), m(n), P
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var a = n.completion;
                                if ("throw" === a.type) {
                                    var o = a.arg;
                                    m(n)
                                }
                                return o
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: _(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = void 0), P
                    }
                }, h
            }
            if (n.d(t, {
                    Z: function() {
                        return a
                    }
                }), !/^(2760|6364|8889)$/.test(n.j)) var o = n(71002);
            var r = n(56274).Promise
        },
        89611: function(e, t, n) {
            "use strict";

            function a(e, t) {
                return a = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                }, a(e, t)
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        93324: function(e, t, n) {
            "use strict";

            function a(e, t) {
                return (0, o.Z)(e) || (0, r.Z)(e, t) || (0, i.Z)(e, t) || (0, u.Z)()
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var o = n(83878),
                r = n(31902),
                i = n(40181),
                u = n(25267)
        },
        89062: function(e, t, n) {
            "use strict";

            function a(e) {
                return (0, o.Z)(e) || (0, r.Z)(e) || (0, i.Z)(e) || (0, u.Z)()
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var o = n(45057),
                r = n(59199),
                i = n(40181),
                u = n(42786)
        },
        71002: function(e, t, n) {
            "use strict";

            function a(e) {
                return a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                }, a(e)
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            })
        },
        40181: function(e, t, n) {
            "use strict";

            function a(e, t) {
                if (e) {
                    if ("string" == typeof e) return (0, o.Z)(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? (0, o.Z)(e, t) : void 0
                }
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var o = n(30907)
        },
        7112: function(e, t, n) {
            "use strict";

            function a(e) {
                var t = "function" == typeof Map ? new Map : void 0;
                return a = function(e) {
                    function n() {
                        return (0, u.Z)(e, arguments, (0, o.Z)(this).constructor)
                    }
                    if (null === e || !(0, i.Z)(e)) return e;
                    if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
                    if (void 0 !== t) {
                        if (t.has(e)) return t.get(e);
                        t.set(e, n)
                    }
                    return n.prototype = Object.create(e.prototype, {
                        constructor: {
                            value: n,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }), (0, r.Z)(n, e)
                }, a(e)
            }
            n.d(t, {
                Z: function() {
                    return a
                }
            });
            var o = n(61120),
                r = n(89611),
                i = n(48989),
                u = n(5647)
        },
        40950: function(e) {
            "use strict";
            e.exports = JSON.parse('{"1click.button.enable_biometric":"Enable {biometricName}","1click.button.no_thanks":"No thanks","1click.button.opt_out":"Opt-out","1click.button.try_a_different_way":"Try a different way","1click.button.verify_with_biometric":"Confirm with {biometricName}","1click.label.call_to_action":"Please fill out the form below to uneroll your credentials","1click.label.enrollment_biometric_callout":"Use <strong>{biometricName}</strong> to confirm future payments with this card on supported websites.","1click.label.enrollment_headline":"Confirm your payments faster next time","1click.label.enrollment_security_callout":"The <strong>biometric data</strong> never leaves your device and will never be accessed by Stripe.","1click.label.error_message":"We were not able to verify your request at this time. Please try again later.","1click.label.fingerprint_or_face_scan":"fingerprint/face scan","1click.label.heading":"Stripe authentication opt-out","1click.label.legal_notice":"By selecting Enable, you agree that Stripe may store your payment method for your future use in accordance with its <privacyPolicyLink>Privacy Policy</privacyPolicyLink>. <optOutLink>You can opt-out at any time</optOutLink>. <learnMoreLink>Learn more</learnMoreLink>.","1click.label.opt_out":"Opt-out","1click.label.opted_out_cancel":"Cancel opt-out","1click.label.opted_out_disclaimer":"Stripe will delete the credentials associated with your card within two business days after a successful authentication with your issuer. <learnMoreLink>Learn more</learnMoreLink>.","1click.label.powered_by":"Powered by","1click.label.privacy_policy":"Privacy policy","1click.label.success_message":"You have successfully opted out of Stripe\'s authentication. If there were any credentials associated with your card, they will be removed within 2 business days.","1click.label.verify_payment_description":"Use <strong>{biometricName}</strong> to confirm the payment of <strong>{currency} {amount}</strong> to <strong>{merchant}</strong> with the card below.","1click.label.verify_payment_headline":"Confirm this payment","3ds.booking_variation.challenge_info_header":"Finalise your purchase","3ds.booking_variation.challenge_info_label":"Enter your code below to verify this purchase:","3ds.booking_variation.challenge_info_text_1":"We\'ve just sent you an SMS (to the mobile number ending in {last4}) with a code to authorise your transaction on {merchantName}.","3ds.booking_variation.challenge_info_text_2":"It\'s for {amount} to be paid on {date}.","3ds.cancel_button":"Cancel","3ds.cardholder_info.button":"OK","3ds.cardholder_info.headline":"Payment failed","3ds.cardholder_info.subtitle":"You haven\'t been charged.","3ds.challenge_info_header":"Purchase Authentication","3ds.challenge_info_label":"Enter your code below:","3ds.challenge_info_text_1":"We have sent you a text message with a code to your registered mobile number ending with {last4}.","3ds.challenge_info_text_2":"You are paying {merchantName} the amount {amount} on {date}.","3ds.loading_screen.message":"Redirecting you to your {lineBreak} card issuer\'s website...","3ds.resend_info_label":"Resend code","3ds.sms_message_test":"{{code}} is your verification code to confirm your payment with {merchantName}.","3ds.submit_authentication_label":"Submit","3ds.try_again":"The code you entered is incorrect. Please try again.","3ds.why_info_text":"Need some help?","acss.dialog_frame_title":"Link an ACSS Debit account","address.label.autocomplete.suggestions":"Suggestions powered by","address.label.manual_entry":"Enter address manually","address.labels.enterPhone":"Enter phone number","address.labels.firstName":"First name","address.labels.lastName":"Last name","address.labels.organizationName":"Organization name","address.labels.phone":"Phone number","address.labels.phone.optional":"Phone number (optional)","ap.currency_rate_label":"(includes {markupPercentage} conversion fee)","ap.currency_rate_with_markup_percentage":"{sellerCurrencyAmount} = {buyerCurrencyAmount} {markup}.","ap.currency_rate_with_markup_text_ecb":"This rate is {ecbMarkupPercentage} over the European Central Bank reference rate and includes a {markupPercentage} fee to guarantee the exchange rate during checkout.","ap.currency_rate_with_markup_text_mid_market":"This rate includes a {markupPercentage} fee to guarantee the exchange rate during checkout.","ap.seller_currency_warning":"Exchange rate and fees of your bank may apply.","ap.show_details":"Show details","ap.hide_details":"Hide details","apply":"Apply","ariaLabels.cardNumber":"Credit or debit card number","ariaLabels.cvc":"Credit or debit card CVC/CVV","ariaLabels.cvcDescription":"3-digit code on back of card","ariaLabels.cvcDescription_amex":"4-digit code on front of card","ariaLabels.expiry":"Credit or debit card expiration date","ariaLabels.loading":"Loading","ariaLive.results":"{count} results available","back_to_shopping":"Back to shopping","boleto.voucher_frame_title":"Boleto Voucher","button.afterpay.close_dialog":"Close Dialog","button.apple_pay.add_money":"Add Money with Apple Pay","button.apple_pay.book":"Book with Apple Pay","button.apple_pay.buy":"Buy with Apple Pay","button.apple_pay.check_out":"Check out with Apple Pay","button.apple_pay.contribute":"Contribute with Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Donate with Apple Pay","button.apple_pay.order":"Order with Apple Pay","button.apple_pay.reload":"Reload with Apple Pay","button.apple_pay.rent":"Rent with Apple Pay","button.apple_pay.subscribe":"Subscribe with Apple Pay","button.apple_pay.support":"Support with Apple Pay","button.apple_pay.tip":"Tip with Apple Pay","button.apple_pay.top_up":"Top Up with Apple Pay","button.cancel":"Cancel","button.change":"Change","button.google_pay.buy":"Buy with Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Donate with Google Pay","button.link.autofill":"Autofill","button.link.autofill_aria_label":"Autofill with Link","button.link.autofill_alt":"Use","button.link.card_clear":"Stop using Link and enter card details manually.","button.link.express_pay":"Express pay","button.link.manage":"Currently using Link with a card ending in {last4}. Choose a different payment method.","button.link.use_last_4_aria_label":"Autofill using Link with a card ending in {last4}","button.link.manage.cardCvc":"Currently using Link. Update the card\'s CVC code.","button.link.manage.cardExpiry":"Currently using Link with an expiry date of {expiry}. Update the card\'s expiry date.","button.link.manage.postalCode":"Currently using Link with a postal code of {postal}. Update the card\'s postal code.","button.link.pay_faster":"Pay faster","button.link.pay_faster_with":"Pay faster with {linkLogo}","button.link.pay_faster_with_link":"Pay faster with Link","button.link.pay_with":"Pay with {linkLogo}","button.link.pay_with_last_4":"Pay with ••{last4}","button.link.save_with":"Save with {linkLogo}","button.link.save_with_aria_label":"Save with Link","button.logout":"Log out","button.pay_with":"Pay with","button.payment_request.book":"Book now","button.payment_request.buy":"Buy now","button.payment_request.default":"Pay now","button.payment_request.donate":"Donate","button.prb_warning.badge_label":"Upgrade available","button.prb_warning.button_primary":"Upgrade now","button.prb_warning.button_secondary":"Dismiss for one week","button.prb_warning.description":"We noticed you\'re using the Payment Request Button. Upgrade to the {ece_link} for access to the latest features and optimizations.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Display multiple payment methods simultaneously, including: Amazon Pay, Link and PayPal (in EU only).","button.prb_warning.li2":"Cross-browser support for Google Pay and Apple Pay (iOS 18+).","button.prb_warning.li3":"Sort and display the most relevant express checkout options dynamically to your customers.","button.prb_warning.nav_header":"Test mode","button.prb_warning.title":"Upgrade your legacy one-click payment buttons","button.remove":"Remove","button.retry":"Retry","button.save":"Save","button.save_with":"Save with","button.see_more":"See more","button.update":"Update","captcha.error":"Oops, something went wrong. If you\'re using an adblocker please disable it and try again.","captcha.header":"One more step before you\'re done","captcha.instruction":"Select the checkbox below.","card_brand.accel":"Accel","card_brand.amex":"American Express","card_brand.carnet":"Carnet","card_brand.cartes_bancaires":"Cartes Bancaires","card_brand.diners":"Diners Club","card_brand.discover":"Discover","card_brand.eftpos_au":"eftpos Australia","card_brand.elo":"Elo","card_brand.girocard":"Girocard","card_brand.interac":"Interac","card_brand.jcb":"JCB","card_brand.mastercard":"Mastercard","card_brand.nyce":"NYCE","card_brand.pulse":"PULSE","card_brand.rupay":"RuPay","card_brand.star":"STAR","card_brand.unionpay":"UnionPay","card_brand.visa":"Visa","card_brand.unknown":"Unknown","check_out":"Check out","close":"Close","country.option.taiwan_china":"Taiwan, China","crypto.onramp.incentive":"Lowest fees","crypto_onramp.crypto.onramp.app.accept_and_pay":"Accept and pay","crypto_onramp.crypto.onramp.app.accept_price_update":"The price of {currency} updated. Please accept the new price to complete your purchase.","crypto_onramp.crypto.onramp.app.accept_price_update_generic":"The price of your order updated. Please accept the new price to complete your purchase.","crypto_onramp.crypto.onramp.app.ach_pm_reverification.bank_account_number":"Bank account number","crypto_onramp.crypto.onramp.app.ach_pm_reverification.confirm_your_bank_account":"Confirm your bank account","crypto_onramp.crypto.onramp.app.ach_pm_reverification.enter_bank_account_info":"Re-enter your full bank account for ••••{last4} to confirm that you are the rightful owner of this account.","crypto_onramp.crypto.onramp.app.add_address":"Add your home address","crypto_onramp.crypto.onramp.app.add_new_wallet":"Add a new wallet","crypto_onramp.crypto.onramp.app.add_payment_method":"Add a payment method","crypto_onramp.crypto.onramp.app.add_personal_info":"Add your personal info","crypto_onramp.crypto.onramp.app.add_wallet":"Add wallet","crypto_onramp.crypto.onramp.app.address_administrative_area":"Area","crypto_onramp.crypto.onramp.app.address_administrative_area.area":"Area","crypto_onramp.crypto.onramp.app.address_administrative_area.county":"County","crypto_onramp.crypto.onramp.app.address_administrative_area.department":"Department","crypto_onramp.crypto.onramp.app.address_administrative_area.district":"District","crypto_onramp.crypto.onramp.app.address_administrative_area.do_si":"Do Si","crypto_onramp.crypto.onramp.app.address_administrative_area.emirate":"Emirate","crypto_onramp.crypto.onramp.app.address_administrative_area.island":"Island","crypto_onramp.crypto.onramp.app.address_administrative_area.oblast":"Oblast","crypto_onramp.crypto.onramp.app.address_administrative_area.parish":"Parish","crypto_onramp.crypto.onramp.app.address_administrative_area.prefecture":"Prefecture","crypto_onramp.crypto.onramp.app.address_administrative_area.province":"Province","crypto_onramp.crypto.onramp.app.address_administrative_area.state":"State","crypto_onramp.crypto.onramp.app.address_country":"Country","crypto_onramp.crypto.onramp.app.address_invalid_postal_code":"Postal code is invalid","crypto_onramp.crypto.onramp.app.address_invalid_zip":"Zip code is invalid.","crypto_onramp.crypto.onramp.app.address_line_one":"Address line 1","crypto_onramp.crypto.onramp.app.address_line_two":"Address line 2","crypto_onramp.crypto.onramp.app.address_locality_city":"City","crypto_onramp.crypto.onramp.app.address_locality_district":"District","crypto_onramp.crypto.onramp.app.address_locality_post_town":"Town or city","crypto_onramp.crypto.onramp.app.address_locality_suburb":"Suburb","crypto_onramp.crypto.onramp.app.address_locality_suburb_or_city":"Suburb or city","crypto_onramp.crypto.onramp.app.address_po_box_prohibited":"PO boxes cannot be provided as an address.","crypto_onramp.crypto.onramp.app.address_postal_code.eircode":"Eircode","crypto_onramp.crypto.onramp.app.address_postal_code.pin":"PIN","crypto_onramp.crypto.onramp.app.address_postal_code.postal":"Postal code","crypto_onramp.crypto.onramp.app.address_postal_code.zip":"ZIP","crypto_onramp.crypto.onramp.app.address_validation_required":"This field is required","crypto_onramp.crypto.onramp.app.as_low_as":"as low as","crypto_onramp.crypto.onramp.app.bank_institution_block_error":"Unfortunately this bank account is not supported. Please try to pay using a different account or using your debit card.","crypto_onramp.crypto.onramp.app.business_suggested_wallet":"{businessName} suggested this wallet","crypto_onramp.crypto.onramp.app.buy":"Buy","crypto_onramp.crypto.onramp.app.buy_with":"Buy crypto with { allowedPaymentMethods }","crypto_onramp.crypto.onramp.app.by_stripe":"by Stripe","crypto_onramp.crypto.onramp.app.cancel":"Cancel","crypto_onramp.crypto.onramp.app.canceled_payment_intent_error":"There was an issue processing your order. Please start a new order.","crypto_onramp.crypto.onramp.app.capture_amount_too_high_error":"We\'re temporarily unable to process your order due to unusually high price volatility. Please start a new order.","crypto_onramp.crypto.onramp.app.card_issuer_block_warning":"Your card issuer may not allow crypto purchases. To avoid a failed payment, use a debit card.","crypto_onramp.crypto.onramp.app.card_issuer_fee_warning":"Your card issuer may charge a <CachAdvanceFeeLink>Cash Advance Fee</CachAdvanceFeeLink> for this purchase. To avoid this fee, use a debit card.","crypto_onramp.crypto.onramp.app.checkout_wallet_label":"{network} wallet","crypto_onramp.crypto.onramp.app.choose_another_wallet":"Choose another wallet","crypto_onramp.crypto.onramp.app.close":"Close","crypto_onramp.crypto.onramp.app.confirm_remove":"Are you sure you want to remove this wallet? You can always add it back later.","crypto_onramp.crypto.onramp.app.confirm_your_wallet":"Confirm your wallet","crypto_onramp.crypto.onramp.app.connect_wallet":"Connect wallet","crypto_onramp.crypto.onramp.app.continue":"Continue","crypto_onramp.crypto.onramp.app.currency.btc.bitcoin.asset_code":"BTC","crypto_onramp.crypto.onramp.app.currency.btc.bitcoin.asset_display_name":"Bitcoin","crypto_onramp.crypto.onramp.app.currency.btc.bitcoin.currency_network":"Bitcoin","crypto_onramp.crypto.onramp.app.currency.eth.ethereum.asset_code":"ETH","crypto_onramp.crypto.onramp.app.currency.eth.ethereum.asset_display_name":"Ethereum","crypto_onramp.crypto.onramp.app.currency.eth.ethereum.currency_network":"Ethereum","crypto_onramp.crypto.onramp.app.currency.eur.fiat.asset_code":"EUR","crypto_onramp.crypto.onramp.app.currency.eur.fiat.asset_display_name":"Euro","crypto_onramp.crypto.onramp.app.currency.eur.fiat.currency_network":"Fiat","crypto_onramp.crypto.onramp.app.currency.gbp.fiat.asset_code":"GBP","crypto_onramp.crypto.onramp.app.currency.gbp.fiat.asset_display_name":"British Pound","crypto_onramp.crypto.onramp.app.currency.gbp.fiat.currency_network":"Fiat","crypto_onramp.crypto.onramp.app.currency.matic.polygon.asset_code":"MATIC","crypto_onramp.crypto.onramp.app.currency.matic.polygon.asset_display_name":"Matic","crypto_onramp.crypto.onramp.app.currency.matic.polygon.currency_network":"Polygon","crypto_onramp.crypto.onramp.app.currency.sol.solana.asset_code":"SOL","crypto_onramp.crypto.onramp.app.currency.sol.solana.asset_display_name":"Solana","crypto_onramp.crypto.onramp.app.currency.sol.solana.currency_network":"Solana","crypto_onramp.crypto.onramp.app.currency.usd.fiat.asset_code":"USD","crypto_onramp.crypto.onramp.app.currency.usd.fiat.asset_display_name":"US Dollar","crypto_onramp.crypto.onramp.app.currency.usd.fiat.currency_network":"Fiat","crypto_onramp.crypto.onramp.app.currency.usdc.ethereum.asset_code":"USDC","crypto_onramp.crypto.onramp.app.currency.usdc.ethereum.asset_display_name":"USDC (Ethereum)","crypto_onramp.crypto.onramp.app.currency.usdc.ethereum.currency_network":"Ethereum","crypto_onramp.crypto.onramp.app.currency.usdc.polygon.asset_code":"USDC","crypto_onramp.crypto.onramp.app.currency.usdc.polygon.asset_display_name":"USDC (Polygon)","crypto_onramp.crypto.onramp.app.currency.usdc.polygon.currency_network":"Polygon","crypto_onramp.crypto.onramp.app.currency.usdc.solana.asset_code":"USDC","crypto_onramp.crypto.onramp.app.currency.usdc.solana.asset_display_name":"USDC (Solana)","crypto_onramp.crypto.onramp.app.currency.usdc.solana.currency_network":"Solana","crypto_onramp.crypto.onramp.app.currency.usdc.stellar.asset_code":"USDC","crypto_onramp.crypto.onramp.app.currency.usdc.stellar.asset_display_name":"USDC (Stellar)","crypto_onramp.crypto.onramp.app.currency.usdc.stellar.currency_network":"Stellar","crypto_onramp.crypto.onramp.app.currency.xlm.stellar.asset_code":"XLM","crypto_onramp.crypto.onramp.app.currency.xlm.stellar.asset_display_name":"Stellar","crypto_onramp.crypto.onramp.app.currency.xlm.stellar.currency_network":"Stellar","crypto_onramp.crypto.onramp.app.currency_may_not_be_available":"May not be available","crypto_onramp.crypto.onramp.app.currency_not_be_available":"Not available in your region","crypto_onramp.crypto.onramp.app.currency_to_wallet_description":"Your purchase of {currency} will be sent to this wallet","crypto_onramp.crypto.onramp.app.date_of_birth":"Date of birth","crypto_onramp.crypto.onramp.app.debit_card_fees_note":"Pay with a debit card to avoid additional fees.","crypto_onramp.crypto.onramp.app.debit_card_fees_note_with_savings":"Save up to {debitSavings} in fees when you pay with a debit card.","crypto_onramp.crypto.onramp.app.default_purchase_error":"There was an issue processing your payment.","crypto_onramp.crypto.onramp.app.delay_message":"We are currently experiencing issues. Your purchase will take a few hours for crypto to be delivered. You may continue or try again later.","crypto_onramp.crypto.onramp.app.document_collection.error":"An error occurred while performing identity verification.","crypto_onramp.crypto.onramp.app.document_collection.header":"Verify your identity to complete this purchase","crypto_onramp.crypto.onramp.app.document_collection.phone":"You\'ll need your phone to verify your identity.","crypto_onramp.crypto.onramp.app.document_collection.subheader":"You\'ll only be asked to provide this information once.","crypto_onramp.crypto.onramp.app.document_collection.verify":"Verify","crypto_onramp.crypto.onramp.app.email":"Email","crypto_onramp.crypto.onramp.app.email_address":"Email address","crypto_onramp.crypto.onramp.app.email_code_send_error":"An error occurred while sending you the code.","crypto_onramp.crypto.onramp.app.email_verification_testmode_hint":"The current session is in testmode and will not send an email. Enter <Bold>000000</Bold> as the 6-digit code.","crypto_onramp.crypto.onramp.app.enter_email_code_existing_user":"Enter the 6-digit code sent to your email <Bold>{ emailAddress }</Bold>","crypto_onramp.crypto.onramp.app.enter_email_code_new_user":"Enter the 6-digit code sent to <Bold>{ emailAddress }</Bold> to verify your email address.","crypto_onramp.crypto.onramp.app.error.looking_into_it":"We have been notified and will look into it. Please refresh the page to try again.","crypto_onramp.crypto.onramp.app.error.refunding_purchase":"If you\'ve been charged, your payment is being refunded. It can take up to 10 business days for the refund to arrive. Refresh this page to start over and retry your purchase.","crypto_onramp.crypto.onramp.app.error.something_wrong_with_purchase":"Something went wrong with your purchase","crypto_onramp.crypto.onramp.app.error.transaction_limit_reached":"Transaction limit reached","crypto_onramp.crypto.onramp.app.error.you_reached_your_transaction_limit":"You\'ve reached your transaction limit. Please try again later.","crypto_onramp.crypto.onramp.app.fees":"Fees","crypto_onramp.crypto.onramp.app.field_is_required":"{fieldName} is required","crypto_onramp.crypto.onramp.app.fields_are_required":"{fieldName} are required","crypto_onramp.crypto.onramp.app.first_name":"First name","crypto_onramp.crypto.onramp.app.fix_field_error":"Please fix the required fields","crypto_onramp.crypto.onramp.app.fulfillment.blockchain_explorer":"View on {explorer}","crypto_onramp.crypto.onramp.app.fulfillment.blockchain_explorer.bitcoin":"Bitcoin Explorer","crypto_onramp.crypto.onramp.app.fulfillment.blockchain_explorer.ethereum":"Etherscan","crypto_onramp.crypto.onramp.app.fulfillment.blockchain_explorer.polygon":"Polygonscan","crypto_onramp.crypto.onramp.app.fulfillment.blockchain_explorer.solana":"Solana Explorer","crypto_onramp.crypto.onramp.app.fulfillment.blockchain_explorer.stellar":"StellarExpert","crypto_onramp.crypto.onramp.app.fulfillment.complete":"Your purchase was successful","crypto_onramp.crypto.onramp.app.fulfillment.error":"There was an issue with your purchase","crypto_onramp.crypto.onramp.app.fulfillment.order_fulfilled":"A receipt has been emailed to you. Find previous purchases and manage your account on <Link>Link</Link>. You may return to your wallet now.","crypto_onramp.crypto.onramp.app.fulfillment.payment_confirmed":"Payment confirmed","crypto_onramp.crypto.onramp.app.fulfillment.processing":"Your purchase is processing","crypto_onramp.crypto.onramp.app.fulfillment.sending_error":"There was an issue sending {assetCode} to your wallet","crypto_onramp.crypto.onramp.app.fulfillment.sending_to_wallet":"Sending {amount} to your wallet","crypto_onramp.crypto.onramp.app.fulfillment.sent_to_wallet":"{amount} has been sent to your wallet","crypto_onramp.crypto.onramp.app.fulfillment.statement_explanation":"Payment for {currency} will appear as {statementDescriptor} on your statement.","crypto_onramp.crypto.onramp.app.fulfillment.temporary_authorization":"A temporary authorization for {amount} will be removed from your card within 7 days.","crypto_onramp.crypto.onramp.app.fulfillment.ten_minutes":"10 minutes","crypto_onramp.crypto.onramp.app.fulfillment.testmode":"The current session is in testmode, and testmode transaction amounts are overridden by our pre-decided limits.","crypto_onramp.crypto.onramp.app.fulfillment.three_minutes":"3 minutes","crypto_onramp.crypto.onramp.app.fulfillment.twenty_minutes":"20 minutes","crypto_onramp.crypto.onramp.app.fulfillment.two_minutes":"2 minutes","crypto_onramp.crypto.onramp.app.fulfillment.waiting_for_fulfillment":"It can take up to {duration} for {currency} to arrive in your wallet, and may take longer. You’ll receive an email once your purchase is complete.","crypto_onramp.crypto.onramp.app.full_name":"Full name","crypto_onramp.crypto.onramp.app.generic_error":"An unknown error occurred","crypto_onramp.crypto.onramp.app.geo_support_description":"You must be a US resident and located in the United States to complete your purchase.","crypto_onramp.crypto.onramp.app.home_address":"Home address","crypto_onramp.crypto.onramp.app.identification_number":"Identification number","crypto_onramp.crypto.onramp.app.identity_verification_description":"This information is used to verify your identity and for legal and regulatory purposes.","crypto_onramp.crypto.onramp.app.identity_verification_failed_can_retry":"Your identity verification failed. To complete your purchase you must verify your identity.","crypto_onramp.crypto.onramp.app.identity_verification_failed_error":"There was an issue with your identity verification.","crypto_onramp.crypto.onramp.app.identity_verification_failed_no_retry":"Your verification failed. If you believe this is an error, please contact support.","crypto_onramp.crypto.onramp.app.identity_verification_failed_retry":"Retry identity verification","crypto_onramp.crypto.onramp.app.identity_verification_partner_description":"Next, Link needs to collect a few personal details to verify your identity. This information is not shared with {partnerName}.","crypto_onramp.crypto.onramp.app.identity_verification_processing_error":"There was an issue processing your information.","crypto_onramp.crypto.onramp.app.identity_verification_standalone_description":"Next, Link needs to collect a few personal details to verify your identity","crypto_onramp.crypto.onramp.app.individual_tax_identification_number":"Individual Tax Identification Number","crypto_onramp.crypto.onramp.app.info_validation.empty_date":"Date of birth is required","crypto_onramp.crypto.onramp.app.info_validation.incomplete_address_line_one":"Address is required","crypto_onramp.crypto.onramp.app.info_validation.incomplete_country":"Country is required","crypto_onramp.crypto.onramp.app.info_validation.incomplete_date":"Date of birth is incomplete.","crypto_onramp.crypto.onramp.app.info_validation.incomplete_email":"Please enter a valid email address.","crypto_onramp.crypto.onramp.app.info_validation.incomplete_itin":"ITIN is required.","crypto_onramp.crypto.onramp.app.info_validation.incomplete_ssn":"SSN is required.","crypto_onramp.crypto.onramp.app.info_validation.incomplete_us_bank_account_account_number":"US bank account number is incomplete.","crypto_onramp.crypto.onramp.app.info_validation.incomplete_zip":"Zip code is required.","crypto_onramp.crypto.onramp.app.info_validation.invalid_address":"This address is not supported","crypto_onramp.crypto.onramp.app.info_validation.invalid_address_line_one_po_box":"PO boxes cannot be provided as an address.","crypto_onramp.crypto.onramp.app.info_validation.invalid_age":"Must be 18+.","crypto_onramp.crypto.onramp.app.info_validation.invalid_country":"Country must be United States","crypto_onramp.crypto.onramp.app.info_validation.invalid_day":"Date of birth day is invalid.","crypto_onramp.crypto.onramp.app.info_validation.invalid_email":"Please enter a valid email address.","crypto_onramp.crypto.onramp.app.info_validation.invalid_itin":"ITIN is invalid.","crypto_onramp.crypto.onramp.app.info_validation.invalid_month":"Date of birth month is invalid.","crypto_onramp.crypto.onramp.app.info_validation.invalid_ssn":"SSN is invalid.","crypto_onramp.crypto.onramp.app.info_validation.invalid_year":"Date of birth year is invalid.","crypto_onramp.crypto.onramp.app.info_validation.invalid_zip":"Zip code is invalid.","crypto_onramp.crypto.onramp.app.info_validation.is_itin":"Please select ITIN instead.","crypto_onramp.crypto.onramp.app.intervention":"Intervention","crypto_onramp.crypto.onramp.app.invalid_code_error":"Hmm, that code didn’t work. Double check it and try again.","crypto_onramp.crypto.onramp.app.last_name":"Last name","crypto_onramp.crypto.onramp.app.learn_more":"Learn more.","crypto_onramp.crypto.onramp.app.link_login_only_prompt":"Log back in to Link","crypto_onramp.crypto.onramp.app.link_security_description":"Link encrypts this data to keep it secure.","crypto_onramp.crypto.onramp.app.link_sign_up_error.general":"An error occurred while signing up for Link.","crypto_onramp.crypto.onramp.app.link_sign_up_error.login_with_prior_account":"Please login with the account that you previously used for this purchase.","crypto_onramp.crypto.onramp.app.link_sign_up_or_log_in_prompt":"Sign up or log in to Link","crypto_onramp.crypto.onramp.app.log_in":"Log in","crypto_onramp.crypto.onramp.app.log_out":"Log out","crypto_onramp.crypto.onramp.app.manual_intervention":"Sorry, it is taking longer than expected to transfer your {currencyAndAmountOrGenericCrypto} to your wallet. Our team is taking a look at it now; please head to <LinkSupportUrl>support.link.com/contact</LinkSupportUrl> to speak to our team about getting a refund.","crypto_onramp.crypto.onramp.app.manual_intervention.cryptocurrency":"cryptocurrency","crypto_onramp.crypto.onramp.app.metamask_wallet":"Metamask","crypto_onramp.crypto.onramp.app.national_identification_number":"Social Security Number (or tax identifier)","crypto_onramp.crypto.onramp.app.nationalities":"Nationalities","crypto_onramp.crypto.onramp.app.nav_menu.change":"Change","crypto_onramp.crypto.onramp.app.nav_menu.log_out":"Log out","crypto_onramp.crypto.onramp.app.nav_menu.log_out_modal.cancel":"Cancel","crypto_onramp.crypto.onramp.app.nav_menu.log_out_modal.content":"This will log you out of Link on this device. You will only be able to continue this purchase by logging back in to the same Link account. If you would like to use a different Link account, please start a new session.","crypto_onramp.crypto.onramp.app.nav_menu.log_out_modal.header":"Log out of Link?","crypto_onramp.crypto.onramp.app.nav_menu.log_out_modal.log_out":"Yes, log out","crypto_onramp.crypto.onramp.app.nav_menu.manage_link_account":"Manage Link account","crypto_onramp.crypto.onramp.app.nav_menu.purchase_history":"Purchase history","crypto_onramp.crypto.onramp.app.nav_menu.support":"Support","crypto_onramp.crypto.onramp.app.network_fee":"{ network } network fee","crypto_onramp.crypto.onramp.app.network_fee_description":"Network fees are required fees to validate your purchase on the blockchain. These are often referred to as \\"Gas fees\\" or \\"Blockchain fees\\".","crypto_onramp.crypto.onramp.app.network_wallet_address":"{network} wallet address","crypto_onramp.crypto.onramp.app.not_you":"Not you?","crypto_onramp.crypto.onramp.app.order_processing":"Your order is processing","crypto_onramp.crypto.onramp.app.paste_your_stellar_wallet_destination_tag":"Paste your Stellar wallet\'s destination tag","crypto_onramp.crypto.onramp.app.paste_your_wallet_address":"Paste your {network} wallet address","crypto_onramp.crypto.onramp.app.pay":"Pay","crypto_onramp.crypto.onramp.app.pay_with":"Pay with","crypto_onramp.crypto.onramp.app.pay_with_payment_methods":"Pay with { allowedPaymentMethods }","crypto_onramp.crypto.onramp.app.payment_method_issue_error":"There was an issue with your payment method.","crypto_onramp.crypto.onramp.app.paymentmethod.bank_account":"bank account","crypto_onramp.crypto.onramp.app.paymentmethod.credit":"credit","crypto_onramp.crypto.onramp.app.paymentmethod.debit":"debit","crypto_onramp.crypto.onramp.app.phone_number":"Phone number","crypto_onramp.crypto.onramp.app.place_of_birth_city":"Place of birth","crypto_onramp.crypto.onramp.app.place_of_birth_country":"Country of birth","crypto_onramp.crypto.onramp.app.please_contact_support":"If you believe this is an error, please contact support.","crypto_onramp.crypto.onramp.app.please_try_again_later":"Please try again later.","crypto_onramp.crypto.onramp.app.prefix_failed_payment_method_error":"There was an issue processing your payment and you have not been charged.","crypto_onramp.crypto.onramp.app.price_updates_in":"Price updates in {timeLeft}","crypto_onramp.crypto.onramp.app.price_updating":"Price updating","crypto_onramp.crypto.onramp.app.purchase_history.account_id":"Account ID: {accountID}","crypto_onramp.crypto.onramp.app.purchase_history.contact_support.error":"Cannot render contact support view without a selected transaction.","crypto_onramp.crypto.onramp.app.purchase_history.contact_support_title":"Contact support","crypto_onramp.crypto.onramp.app.purchase_history.crypto_purchases_title":"Crypto purchases","crypto_onramp.crypto.onramp.app.purchase_history.details.amount":"Amount","crypto_onramp.crypto.onramp.app.purchase_history.details.contact_support":"Contact support","crypto_onramp.crypto.onramp.app.purchase_history.details.exchange_rate":"Exchange rate","crypto_onramp.crypto.onramp.app.purchase_history.details.network_fee":"Network fee","crypto_onramp.crypto.onramp.app.purchase_history.details.payment":"Payment","crypto_onramp.crypto.onramp.app.purchase_history.details.processing_fee":"Processing fee","crypto_onramp.crypto.onramp.app.purchase_history.details.purchased_on":"Purchased on {date}","crypto_onramp.crypto.onramp.app.purchase_history.details.received_by_recipient":"Received by recipient","crypto_onramp.crypto.onramp.app.purchase_history.details.sent_to":"Sent to","crypto_onramp.crypto.onramp.app.purchase_history.details.subtotal":"Subtotal","crypto_onramp.crypto.onramp.app.purchase_history.details.summary":"Summary","crypto_onramp.crypto.onramp.app.purchase_history.details.total":"Total","crypto_onramp.crypto.onramp.app.purchase_history.details.transfer_recipient":"Transfer recipient","crypto_onramp.crypto.onramp.app.purchase_history.error":"Failed to load purchase history. Please try again.","crypto_onramp.crypto.onramp.app.purchase_history.link_by_stripe":"Link by Stripe","crypto_onramp.crypto.onramp.app.purchase_history.no_purchases":"No crypto purchases yet","crypto_onramp.crypto.onramp.app.purchase_history.no_purchases_subtitle":"Your purchases will show up here so they\'re easy to find when you need them.","crypto_onramp.crypto.onramp.app.purchase_history.stripe_address_line_1":"354 Oyster Point Blvd,","crypto_onramp.crypto.onramp.app.purchase_history.stripe_address_line_2":"South San Francisco, CA 94080","crypto_onramp.crypto.onramp.app.purchase_history.stripe_payments_co":"Stripe Payments Company","crypto_onramp.crypto.onramp.app.receive":"Receive","crypto_onramp.crypto.onramp.app.remove_wallet":"Remove wallet","crypto_onramp.crypto.onramp.app.remove_wallet_question":"Remove wallet?","crypto_onramp.crypto.onramp.app.review_order":"Review order","crypto_onramp.crypto.onramp.app.save_payment_information_description":"Save your payment information to check out safely at thousands of online retailers.","crypto_onramp.crypto.onramp.app.saved_network_wallets":"Saved {network} wallets","crypto_onramp.crypto.onramp.app.select_currency":"Select a currency","crypto_onramp.crypto.onramp.app.select_wallet":"Select a wallet","crypto_onramp.crypto.onramp.app.send_to":"Send to","crypto_onramp.crypto.onramp.app.service_unavailable":"Sorry, this service is currently unavailable","crypto_onramp.crypto.onramp.app.set_as_default":"Set as default","crypto_onramp.crypto.onramp.app.sign_up":"Sign Up","crypto_onramp.crypto.onramp.app.social_security_number":"Social Security Number","crypto_onramp.crypto.onramp.app.something_went_wrong":"Something went wrong","crypto_onramp.crypto.onramp.app.stage.login":"Log in","crypto_onramp.crypto.onramp.app.stage.pay":"Pay","crypto_onramp.crypto.onramp.app.stage.verify":"Verify","crypto_onramp.crypto.onramp.app.stale_code_error":"It looks like the verification code you provided is not valid anymore. We sent you a new one.","crypto_onramp.crypto.onramp.app.stellar_wallet_destination_tag":"Stellar wallet destination tag","crypto_onramp.crypto.onramp.app.stellar_wallet_destination_tag_if_applicable":"Stellar wallet destination tag (if applicable)","crypto_onramp.crypto.onramp.app.support":"Support","crypto_onramp.crypto.onramp.app.terms_of_service_agreement":"By continuing you agree to the <TermsOfServiceLink>Terms of Service</TermsOfServiceLink> and <PrivacyPolicyLink>Privacy Policy</PrivacyPolicyLink>.","crypto_onramp.crypto.onramp.app.total":"Total","crypto_onramp.crypto.onramp.app.transaction_amount_in_destination_currency":"Buy { amount } {currency}","crypto_onramp.crypto.onramp.app.transaction_amount_in_source_currency":"Buy { amount } of {currency}","crypto_onramp.crypto.onramp.app.transaction_fee":"Transaction fee","crypto_onramp.crypto.onramp.app.transaction_fee_description":"Transaction fee covers payment processing fees for your purchase of crypto.","crypto_onramp.crypto.onramp.app.transaction_fee_tip":"Pay with a bank account or debit card to get the lowest fee.","crypto_onramp.crypto.onramp.app.try_a_different_payment_method":"Please try a different payment method.","crypto_onramp.crypto.onramp.app.try_again":"Try again","crypto_onramp.crypto.onramp.app.trying_again_in":"Trying again in {timeLeft}","crypto_onramp.crypto.onramp.app.unsupported_currency.additional_cryptocurrency_support_coming_soon":"Support for more currencies in additional areas is coming soon.","crypto_onramp.crypto.onramp.app.unsupported_currency.choose_a_different_currency":"Choose a different currency","crypto_onramp.crypto.onramp.app.unsupported_currency.this_cryptocurrency":"this cryptocurrency","crypto_onramp.crypto.onramp.app.unsupported_currency.unavailable":"Sorry, {currency} isn\'t yet supported at your home address","crypto_onramp.crypto.onramp.app.unsupported_currency.unavailable_in_location":"Unavailable at your home address","crypto_onramp.crypto.onramp.app.unsupported_geo":"Sorry, this service is currently only available in <SupportedGeosLink>supported countries</SupportedGeosLink>","crypto_onramp.crypto.onramp.app.unsupported_geo.service_unavailable":"Sorry, this service isn\'t available in your area yet.","crypto_onramp.crypto.onramp.app.unsupported_geo.service_unavailable_expanding_soon":"Sorry, this service isn\'t available in your area yet. We\'ll be expanding support to more areas soon.","crypto_onramp.crypto.onramp.app.use_saved_wallet":"Use a saved wallet","crypto_onramp.crypto.onramp.app.use_this_wallet":"Use this wallet","crypto_onramp.crypto.onramp.app.verify_your_email":"Verify your email address","crypto_onramp.crypto.onramp.app.wallet_connect_suggestion":"You can try connecting a new wallet to {businessName}","crypto_onramp.crypto.onramp.app.wallet_connection_cancelled":"Connection cancelled","crypto_onramp.crypto.onramp.app.wallet_connection_connected":"Wallet connected","crypto_onramp.crypto.onramp.app.wallet_connection_connecting":"Wallet connecting","crypto_onramp.crypto.onramp.app.wallet_registration_error":"Unable to register your wallet: {fullErrorMessage}","crypto_onramp.crypto.onramp.app.wallet_validation_could_not_resolve_address":"Could not resolve {walletAddress}","crypto_onramp.crypto.onramp.app.wallet_validation_invalid_address":"Please enter a valid {network} wallet address.","crypto_onramp.crypto.onramp.app.wallet_validation_resolving_address":"Resolving {walletAddress}","crypto_onramp.crypto.onramp.app.wallet_validation_unsupported_bonfida":"Sorry, Bonfida addresses are not supported at this time. Please paste your full public address.","crypto_onramp.crypto.onramp.app.wallet_validation_valid":"Valid wallet","crypto_onramp.crypto.onramp.app.wallet_validation_valid_with_address":"Valid wallet: {walletAddress}","crypto_onramp.crypto.onramp.app.we_sent_you_an_email":"We sent you an email","crypto_onramp.crypto.onramp.app.web_authentication.device_hardware_authentication_note":"You\'ll be prompted to use your device\'s hardware authentication.","crypto_onramp.crypto.onramp.app.web_authentication.device_verified":"Device verified","crypto_onramp.crypto.onramp.app.web_authentication.errors.could_not_authenticate":"Link could not authenticate your device. Please try again.","crypto_onramp.crypto.onramp.app.web_authentication.errors.could_not_verify":"Your device could not be verified. Please try again","crypto_onramp.crypto.onramp.app.web_authentication.errors.failed_to_retrieve_challenge":"Failed to retrieve web authentication challenge.","crypto_onramp.crypto.onramp.app.web_authentication.verification_rationale":"By verifying your device, Link can better protect your information from being accessed or misused by any third parties.","crypto_onramp.crypto.onramp.app.web_authentication.verify_my_device":"Verify my device","crypto_onramp.crypto.onramp.app.web_authentication.verify_your_device":"Verify your device","crypto_onramp.crypto.onramp.app.web_authentication.verify_your_device_to_log_in":"Verify your device to log in","crypto_onramp.crypto.onramp.app.web_authentication.verifying_your_device":"Verifying your device...","crypto_onramp.crypto.onramp.app.whats_required":"What\'s required:","crypto_onramp.crypto.onramp.app.why_required":"Why is this information required","crypto_onramp.crypto.onramp.app.yes_remove":"Yes, remove","crypto_onramp.crypto.onramp.app.your_identity_is_being_verified":"Your identity is being verified. This should only take a moment.","crypto_onramp.crypto.onramp.app.your_identity_is_being_verified_email":"Your identity is being verified. We\'ll email you as soon as it\'s complete to finish your order. This can take up to 2 minutes.","crypto_onramp.crypto.onrmap.app.partner_terms":"Cryptocurrency Services powered by Zero Hash. By clicking pay you agree to the Zero Hash and Zero Hash Liquidity Services <UserAgreementLink>User Agreement</UserAgreementLink>, and you acknowledge you have read and understand the Zero Hash <PrivacyPolicyLink>Privacy Policy</PrivacyPolicyLink> and <RegulatoryDisclosuresLink>Regulatory Disclosures</RegulatoryDisclosuresLink>. You understand that the value of any cryptocurrency, including digital assets pegged to fiat currency, commodities, or any other asset, may go to zero. Orders may not be canceled or reversed once submitted by you. By submitting a withdrawal request, you are requesting an on-chain transaction that is not reversible or recallable. You are responsible for reviewing the recipient address and ensuring it is the correct address for the selected address for withdrawal.","display_bank_transfer_instructions.voucher_frame_title":"Bank Transfer Instructions","ece.business_day":"business day","ece.business_days":"business days","ece.billing_agreement.apple_pay.default":"By providing your card information, you allow {businessName} to charge your card for future payments in accordance with their terms.","ece.day":"day","ece.days":"days","ece.delivery_in":"Estimated delivery in {value} {unit}","ece.delivery_in_to":"Estimated delivery in {minValue} to {maxValue} {unit}","ece.delivery_in_to_units":"Estimated delivery in {minValue} {minUnit} to {maxValue} {maxUnit}","ece.delivery_within":"Estimated delivery within {value} {unit}","ece.hour":"hour","ece.hours":"hours","ece.month":"month","ece.months":"months","ece.open_notification":"Continue your purchase on {paymentMethod}.","ece.overlay":"Complete your payment in the open {paymentMethod} window, or close {paymentMethod} to continue paying another way.","ece.order_summary.coupon":"Coupon","ece.order_summary.tax.estimated":"Estimated tax","ece.payment.payment_request.test_mode_business_postfix":"(WON\'T BE CHARGED)","ece.product_summary.trial_duration":"{count, plural, one {1 day free} other {{count} days free}}","ece.see_more":"See more","ece.see_more_aria_label":"See more payment options","ece.total":"Total","ece.week":"week","ece.weeks":"weeks","error.code.no_results_found":"No results found","errors.code.amount_too_large":"The transaction amount is too high for this payment method. Please choose a different payment method and try again.","errors.code.apple_pay.session_creation_failed":"Something went wrong. Unable to checkout with Apple Pay. Please choose a different payment method and try again.","errors.code.google_pay.payment_exception":"Something went wrong. Unable to checkout with Google Pay. Please choose a different payment method and try again.","errors.code.card_brand_blocked":"{brand} is not accepted.","errors.code.card_declined":"Your card has been declined.","errors.code.card_declined_card_not_supported":"Your card is not supported.","errors.code.card_number_in_name_field":"Please make sure that the name field doesn\'t contain a card number.","errors.code.card_number_in_postal_code_field":"Please make sure that the postal code field doesn\'t contain a card number.","errors.code.civ_unexpected":"Something went wrong. Please choose a different payment method and try again.","errors.code.customer_canceled_authentication":"You must authenticate to complete this transaction.","errors.code.cvc_recollection_required":"For security, please re-enter your card’s security code.","errors.code.email_invalid":"Your email address is invalid.","errors.code.invalid_us_bank_account_email_length":"Invalid email address: must not exceed {maximum} characters.","errors.code.invalid_us_bank_account_name_length":"Invalid name: must not exceed {maximum} characters.","errors.code.empty_phone_number":"Please provide a mobile phone number.","errors.code.expired_card":"Your card has expired.","errors.code.fetch_updates.unexpected_status":"{object} in unexpected status","errors.code.financial_connections_session_cancelled":"stripe.collectFinancialCollectionsAccounts: financialConnectionsSession was cancelled before an account could be gathered.","errors.code.incomplete_address":"This field is incomplete.","errors.code.incomplete_au_bank_account_bsb":"The BSB you entered is incomplete.","errors.code.incomplete_au_bank_account_number":"The account number you entered is incomplete.","errors.code.incomplete_boleto_tax_id":"Your CPF/CNPJ is incomplete.","errors.code.incomplete_boleto_tax_id_cnpj_only":"Your CNPJ is incomplete.","errors.code.incomplete_br_tax_id":"Your CPF/CNPJ is incomplete.","errors.code.incomplete_br_tax_id_cnpj_only":"Your CNPJ is incomplete.","errors.code.incomplete_card":"Please fill in your card details.","errors.code.incomplete_card_name":"Please provide the name on your card.","errors.code.incomplete_cvc":"Your card\'s security code is incomplete.","errors.code.incomplete_email":"Your email address is incomplete.","errors.code.incomplete_expiry":"Your card\'s expiration date is incomplete.","errors.code.incomplete_first_name":"Please provide your first name.","errors.code.incomplete_iban":"The IBAN you entered is incomplete.","errors.code.incomplete_id_bank_transfer_bank":"Please select your bank.","errors.code.incomplete_last_name":"Please provide your last name.","errors.code.incomplete_mandate_checkbox":"Please agree by ticking this checkbox.","errors.code.incomplete_name":"Please provide your full name.","errors.code.incomplete_number":"Your card number is incomplete.","errors.code.incomplete_nz_bank_account_account_number":"Incomplete.","errors.code.incomplete_nz_bank_account_bank_code":"Incomplete.","errors.code.incomplete_nz_bank_account_branch_code":"Incomplete.","errors.code.incomplete_nz_bank_account_suffix":"Incomplete.","errors.code.incomplete_nz_bank_name":"Please provide the bank name where your account is held.","errors.code.incomplete_organization_name":"Please provide your organization name.","errors.code.incomplete_payment_details":"Please provide complete payment details.","errors.code.incomplete_payment_method":"Please select a payment method to pay with.","errors.code.incomplete_phone_number":"Your mobile phone number is incomplete.","errors.code.incomplete_us_bank_account_account_number":"Account number is required.","errors.code.incomplete_us_bank_account_confirm_account_number":"Confirm the account number.","errors.code.incomplete_us_bank_account_routing_number":"Please enter 9 digits for your routing number.","errors.code.incomplete_zip":"Your postal code is incomplete.","errors.code.incorrect_cvc":"Your card\'s security code is incorrect.","errors.code.incorrect_number":"Your card number is incorrect.","errors.code.incorrect_zip":"Your card could not be authorized using the postal code provided. Please update the postal code, or contact your card issuer for further details.","errors.code.instant_verification_incomplete":"No account connected","errors.code.instant_verification_initialization":"There was a problem connecting your account. Please try again, or try a different payment method.","errors.code.invalid_address_view.update":"Please finish updating your billing details.","errors.code.invalid_au_bank_account_bsb":"The BSB you entered is invalid.","errors.code.invalid_au_bank_account_bsb_livemode":"The BSB number {number} is invalid in livemode.","errors.code.invalid_au_bank_account_bsb_testmode":"Your BSB number is invalid in testmode. Please use 000-000.","errors.code.invalid_au_bank_account_number_testmode":"The account number you entered is not valid in testmode.","errors.code.invalid_bank_account_account_number":"Your account number is invalid.","errors.code.invalid_bank_account_routing_number":"Your sort code is invalid.","errors.code.invalid_blik_code":"Your BLIK code is invalid","errors.code.invalid_cvc":"Your card\'s security code is invalid.","errors.code.invalid_expiry_month":"Your card\'s expiration date is invalid.","errors.code.invalid_expiry_month_past":"Your card\'s expiration date is in the past.","errors.code.invalid_expiry_year":"Your card\'s expiration year is invalid.","errors.code.invalid_expiry_year_past":"Your card\'s expiration year is in the past.","errors.code.invalid_iban":"The IBAN you entered is invalid.","errors.code.invalid_iban_country_code":"The IBAN you entered is invalid, “{code}” is not a supported country code.","errors.code.unsupported_non_sepa_iban_country_code":"The IBAN you entered is invalid, “{code}” is not a supported country code. Only SEPA IBANs are currently supported at this time; if needed, please reach out to the merchant for further assistance","errors.code.invalid_iban_start":"Your IBAN should start with a two-letter country code.","errors.code.invalid_country_for_pm":"{paymentMethod} in the selected billing country: {country} only supports payments in {currency}. Please select a different payment method.","errors.code.unsupported_country_for_pm":"{paymentMethod} in the selected billing country: {country} is not currently supported. Please select a different payment method.","errors.code.unsupported_country_for_recurring_pm":"{paymentMethod} in the selected billing country: {country} does not support recurring payments. Please select a different payment method.","errors.code.unsupported_country_for_recurring_pm_merchant_country":"{paymentMethod} for recurring payments is only supported by the merchant in the following countries: {validCountries}. Please select a different payment method.","errors.code.invalid_number":"Your card number is invalid.","errors.code.invalid_nz_bank_account_number":"Invalid","errors.code.invalid_nz_bank_account_number_bank_code":"Invalid","errors.code.invalid_nz_bank_account_number_branch_code":"Invalid","errors.code.invalid_payment_view.add":"Please finish adding a new payment method or select a saved payment method.","errors.code.invalid_payment_view.remove":"Please finish removing your saved payment method.","errors.code.invalid_payment_view.update":"Please finish updating your saved payment method.","errors.code.invalid_phone_number":"Your mobile phone number is invalid.","errors.code.invalid_phone_number_prefix":"Please enter a valid country code starting with a \'+\'.","errors.code.invalid_postal_code":"Your postal code is invalid.","errors.code.invalid_rechnung_date":"Please enter a valid birthdate using the format dd/mm/yyyy.","errors.code.invalid_rechnung_birthdate_too_old":"You must be 124 or younger to use this payment method.","errors.code.invalid_rechnung_birthdate_too_young":"You must be 18 or older to use this payment method.","errors.code.invalid_upi_vpa":"Invalid VPA.","errors.code.invalid_payid":"Invalid PayID.","errors.code.invalid_zip":"Your ZIP is invalid.","errors.code.link_verification.api_error":"Sorry, something went wrong while verifying your code.","errors.code.link_verification.expired_session":"The provided verification code has expired.","errors.code.link_verification.generic_error":"Sorry, something went wrong while verifying your code. Please try again in a few minutes.","errors.code.link_verification.generic_webauthn_error":"There was an issue logging in with your passkey.","errors.code.link_verification.invalid_code":"That code didn\'t work. Try again.","errors.code.link_verification.max_attempts_exceeded":"Too many attempts. Please try again in a few minutes.","errors.code.link_verification.get_webauthn_credential_generic_error":"There was an issue logging in with your passkey.","errors.code.mismatch_us_bank_account_account_number":"Your account numbers don’t match.","errors.code.modify_bacs_debit_bank_details":"Please correct your bank account details","errors.code.sepa_debit_microdeposits_unconfirmed":"SEPA Debit micro-deposits verification unconfirmed","errors.code.nz_bank_account_invalid_account_number_length":"Your bank account number is incomplete.","errors.code.payment_intent_authentication_failure":"We are unable to authenticate your payment method. Please choose a different payment method and try again.","errors.code.payment_intent_unexpected_state":"A processing error occurred.","errors.code.payment_method_invalid_parameter":"The payment details you provided are invalid.","errors.code.payment_method_microdeposit_verification_amounts_invalid":"You must provide two different micro-deposit amounts.","errors.code.payment_method_microdeposit_verification_amounts_mismatch":"The amounts provided do not match the amounts that were sent to the bank account.","errors.code.payment_method_microdeposit_verification_attempts_exceeded":"You have exceeded the number of allowed verification attempts.","errors.code.po_box_prohibited":"PO Box is prohibited.","errors.code.postal_code_recollection_required":"Your card number and postal code do not match.","errors.code.process_error_intransient":"An error occurred while processing your card.","errors.code.processing_error":"An error occurred while processing your card. Try again in a little bit.","errors.code.processing_error_intransient":"Something went wrong. Please try again later.","errors.code.setup_intent_authentication_failure":"We are unable to authenticate your payment method. Please choose a different payment method and try again.","errors.code.setup_intent_unexpected_state":"A processing error occurred.","errors.code.unexpected":"An unexpected error occurred.","errors.declines.affirm_checkout_canceled":"Affirm checkout session canceled.","errors.declines.affirm_payment_declined":"Payment declined by Affirm.","errors.declines.call_issuer":"Your card was declined. You can call your bank for details.","errors.declines.card_not_supported":"Your card is not supported.","errors.declines.card_velocity_exceeded":"Your card was declined for making repeated attempts too frequently.","errors.declines.currency_not_supported":"Your card is not supported for this currency.","errors.declines.fake_merchant_test_card":"This verification trigger card was declined. This card must be used for a Custom account created in testmode.","errors.declines.generic_decline":"Your card was declined.","errors.declines.generic_decline_link":"Your payment method was declined.","errors.declines.generic_decline_non_cards":"Your payment was declined.","errors.declines.incorrect_pin":"Incorrect PIN.","errors.declines.insufficient_funds":"Your card has insufficient funds.","errors.declines.invalid_account":"Invalid account.","errors.declines.invalid_amount":"Invalid amount.","errors.declines.live_mode_test_card":"Your card was declined. Your request was in live mode, but used a known test card.","errors.declines.not_permitted":"Cardmember not enrolled / not permitted","errors.declines.pin_try_exceeded":"Allowable number of PIN tries exceeded.","errors.declines.test_mode_live_card":"Your card was declined. Your request was in test mode, but used a non test card. For a list of valid test cards, visit: https://stripe.com/docs/testing.","errors.declines.transaction_not_allowed":"Your card does not support this type of purchase.","errors.payment_request.failed_to_process_payment":"There was an error processing your order.","errors.payment_request.invalid_billing_address":"Invalid billing address.","errors.payment_request.invalid_payer_email":"Invalid email address.","errors.payment_request.invalid_payer_phone":"Invalid phone number.","errors.payment_request.invalid_shipping_address":"Sorry, no shipping options are available for the selected address.","errors.payment_request.invalid_shipping_address_short":"Invalid shipping address.","errors.payment_request.shipping_option_unavailable":"Sorry, the selected shipping option is unavailable.","errors.type.api_connection_error":"We are experiencing issues connecting to our payments provider. Please check your internet connection.","errors.wallet_show_error":"Something went wrong. Unable to show {wallet}. Please choose a different payment method and try again.","estimated_shipping":"Estimated Shipping","estimated_total":"Estimated Total","fpx.offlineBank":"Offline","free":"Free","hosted_qr_code_instructions.luxe.frame_title":"QR Code Instructions","hosted_qr_code_instructions.cashapp.frame_title":"Cash App Pay Instructions","hosted_qr_code_instructions.paynow.frame_title":"Paynow Instructions","hosted_qr_code_instructions.promptpay.frame_title":"PromptPay Instructions","hosted_qr_code_instructions.swish.frame_title":"Swish Instructions","hosted_qr_code_instructions.wechat_pay.frame_title":"WeChat Pay Instructions","hosted_qr_code_instructions.wechat_pay.product_name":"WeChat Pay","identity.verification_frame_title":"Identity Verification","instant_debits.dropped_session":"To continue paying with Instant Debits, please go back to dialog","instant_debits.unknown_error":"There was an error in the Instant Debits flow","konbini.voucher_frame_title":"Konbini payment instructions","lcpm.dropped_session":"To continue paying with Instant Debits, please go back to dialog","lcpm.unknown_error":"There was an error in the Instant Debits flow","lightbox.close":"Close","link.authentication_element.placeholder":"Email address","link.autofill.generic_error_enter_email":"Something went wrong. Please enter an email.","link.autofill.multipe_saved_addresses":"{num} saved addresses","link.autofill.one_saved_address":"1 saved address","link.autofill.select_an_option":"Select an option","link.autofill.use_other_email":"Use another email","link.autofill.use_saved_info":"Use your saved information","link.autofill_prompt.generic_error_body":"Please wait a few minutes and try logging in again or continue with your purchase by filling in your details below.","link.autofill_prompt.generic_error_header":"Something went wrong","link.autofill_prompt.rate_limit_error_header":"Too many log in attempts for this Link account","link.autofill_with_link":"Autofill with Link","link.backup_payment_method.add":"Add backup payment method","link.backup_payment_method.brandAndLast4":"{cardBrand} •••• {cardLast4}","link.purchase_protection_saved_debit_card_detail":"May include {link}","link.purchase_protection_saved_debit_card_detail.v2":"May include <link>price drop protection</link>","link.purchase_protection.add_debit_message":"Add debit","link.purchase_protection.select_debit_message":"Select debit to get {link}","link.purchase_protection.select_debit_message.v2":"Select debit to get <link>price drop protection</link>","link.purchase_protection.select_debit_card_message":"Select •••• {cardLast4}","link.purchase_protection.payment_picker_message":"<link>Free purchase protections</link>","link.purchase_protection.brief_description":"Get price matching, no-fee returns, accident coverage, <link>and more</link>.","link.purchase_protection.payment_picker_message.shopping":"Free purchase protections","link.purchase_protection.brief_description.shopping":"Includes price protection, no-fee returns, damage coverage, and more. <link>Terms apply</link>","link.purchase_protection.payment_picker_message.price":"Free price protection","link.purchase_protection.brief_description.price":"Get money back if you find a better price within 90 days. <link>Terms apply</link>","link.purchase_protection.payment_picker_message.return":"No-fee returns","link.purchase_protection.brief_description.return":"Includes no-fee returns, price protection, damage coverage, and more. <link>Terms apply</link>","link.purchase_protection.payment_picker_message.product":"Free damage protection","link.purchase_protection.brief_description.product":"Includes damage coverage, no-fee returns, price protection, and more. <link>Terms apply</link>","link.purchase_protection.add_payment_method_message.shopping":"<link>Free purchase protections</link>","link.purchase_protection.add_payment_method_message.price":"Free <link>price protection</link>","link.purchase_protection.add_payment_method_message.return":"<link>No-fee returns and more</link>","link.purchase_protection.add_payment_method_message.product":"<link>Free damage protection and more</link>","link.backup_payment_method.info.description":"If your original payment fails for any reason, we’ll retry using another saved card. This can be especially useful for ongoing subscriptions to help avoid delays on your purchases or services.","link.backup_payment_method.info.do_not_use":"Don’t use a backup","link.backup_payment_method.info.title":"Avoid interruptions with backup payments","link.backup_payment_method.info.use":"Use backup {cardBrand} •••• {cardLast4}","link.backup_payment_method.remove":"Don\'t use backup","link.backup_payment_method.use":"If declined, use {backupInfo}","link.checkout_faster":"Check out faster using Link","link.dataSecurityMessage":"Link stores contact information, shipping address, and payment information in accordance with PCI data security standards.","link.default":"Default","link.errors.payment_failed":"Your selected payment method failed. Please try another payment method.","link.errors.payment_failed_for_saved_card":"Charge failed on last attempt. Update or try again.","link.errors.unavailable_for_purchase":"Unavailable for this purchase","link.errors.update_payment_details_failed":"Unable to update payment details. Please try another payment method.","link.faq":"FAQ","link.info.cash_back":"Get {amount} cash back","link.info.cash_back.description":"Save your info with Link and you’ll get {amount} cash back sent to your payment account within 2 days.","link.info.close":"Close","link.info.cookies":"Cookie Policy","link.info.cookies.v2":"cookies","link.info.cookies_and_privacy_link":"Learn more about the Link {privacy_link} and {cookies_link}","link.info.cookies_and_privacy_link.v2":"Learn more about {privacy_link} and {cookies_link}.","link.info.data_encryption":"Data encryption","link.info.data_encryption.description":"Your card information stays secure with data encryption on servers that meet the highest PCI standards available in the payment industry.","link.info.headline":"{businessName} uses Link to securely save your payment information.","link.info.byline":"Link saves your contact information, payment details, and shipping addresses to autofill for future purchases on Link-supported sites.","link.info.byline.v2":"Link saves your contact information, payment details, and shipping addresses so you can pay faster next time.","link.info.mobile_verification":"Mobile verification","link.info.mobile_verification.description":"You’re protected with mobile authentication designed to ensure that you’re the only person who can access your information.","link.info.notice":"You can review every order before you pay.","link.info.privacy":"Privacy Policy","link.info.privacy.v2":"privacy","link.info.privacy_link":"Learn more about privacy","link.instant_debits.financial_incentive.explain_incentive":"Get {financialIncentive} back when you pay with your bank.","link.instant_debits.financial_incentive.explain_incentive_setup_intents":"Get {financialIncentive} when you pay for the first time with your bank.","link.instant_debits.financial_incentive.see_terms":"See terms","link.labels.email":"Email","link.labels.logout":"Log out of Link","link.labels.recollection_flow.cvc":"Confirm CVC","link.labels.recollection_flow.expiry":"Confirm expiration","link.labels.recollection_flow.multiple_fields":"Confirm card details","link.labels.recollection_flow.postal_code.eircode":"Confirm Eircode","link.labels.recollection_flow.postal_code.pin":"Confirm PIN","link.labels.recollection_flow.postal_code.postal":"Confirm postal code","link.labels.recollection_flow.postal_code.zip":"Confirm ZIP","link.labels.recollection_flow.full_name":"Confirm name","link.learn_more":"Learn more","link.learn_more_modal.header":"Pay quickly, shop confidently","link.learn_more_modal.fast_and_simple.header":"Fast and simple","link.learn_more_modal.fast_and_simple.description":"Autofill your payment, contact, and shipping details at checkout.","link.learn_more_modal.mulitple_ways_to_pay.header":"Multiple ways to pay","link.learn_more_modal.mulitple_ways_to_pay.description":"Choose from your favorite cards or bank account.","link.learn_more_modal.protects_your_data.header":"Protects your data","link.learn_more_modal.protects_your_data.description":"Shop safely knowing your information is encrypted.","link.learn_more_modal.purchase_protections.header":"Purchase protections","link.learn_more_modal.purchase_protections.description":"Get price protection, no-fee returns, <link>and more</link>.","link.learn_more_modal.legal_text":"Link autofills your contact information, card details, and shipping addresses for future purchases on Link-supported sites.","link.learn_more_modal.privacy":"<PrivacyLink>Privacy</PrivacyLink>","link.learn_more_modal.cookies":"<CookiePolicyLink>Cookies</CookiePolicyLink>","link.login":"Log in","link.login.email.suggest_correction":"Did you mean {emailDomain}?","link.login_title":"Use Link to check out","link.logout.description":"By logging out, your information saved with Link will no longer be available for use during this checkout session.","link.logout.title":"Log out of your Link account?","link.manage_account":"Manage account","link.mandate.control_terms":"By selecting to save your info, you agree to create an account subject to {linkTerms} and {linkPrivacy}.","link.mandate.control_terms_phone_email":"By providing phone number and email, you agree to create an account subject to {linkTerms} and {linkPrivacy}.","link.mandate.control_terms_email":"By providing your email, you agree to create an account subject to {linkTerms} and {linkPrivacy}.","link.mandate.control_terms_phone":"By providing your phone number, you agree to create an account subject to {linkTerms} and {linkPrivacy}.","link.mandate.control_terms_consolidated":"By selecting to save your info, you agree to create an account subject to Link\'s {linkTerms} and {linkPrivacy}. {learnMore}","link.mandate.control_terms_consolidated.no_learn_more":"By selecting to save your info, you agree to create an account subject to Link’s {linkTerms} and {linkPrivacy}.","link.mandate.terms.default_opt_in":"By providing your info, you agree to create an account subject to Link\'s {linkTerms} and {linkPrivacy}. {learnMore}","link.mandate.terms.default_opt_in.no_learn_more":"By providing your info, you agree to create an account subject to Link’s {linkTerms} and {linkPrivacy}.","link.mandate.optional_phone_collection":"By providing my phone number, I agree to create a Link account and save my payment info to Link, according to the {linkTerms} and {linkPrivacy}. {learnMore}","link.mandate.optional_phone_collection.no_learn_more":"By providing my phone number, I agree to create a Link account and save my payment info to Link, according to the {linkTerms} and {linkPrivacy}.","link.mandate.purchase_protection_terms":"By checking this box, you agree to create an account subject to Link\'s {linkTerms} and {linkPrivacy}. {learnMore}","link.mandate.default_integration":"By creating a Link Account, I agree to the {linkTerms} and {linkPrivacy}.","link.mandate.default_opt_in_terms":"By selecting to save your info, you agree to the {linkTerms} and {linkPrivacy}.","link.mandate.financial_terms":"By selecting to save your info, you agree to create an account subject to {linkTerms}, {promotionTerms}, and {linkPrivacy}.","link.mandate.part1_default_integration":"By creating a Link Account, I agree to the","link.mandate.part2":"and","link.mandate.part3_default_integration":"Your Link account will be created after payment is completed.","link.merchantAccessMessage":"Merchant cannot access payment or order history outside of orders placed on this website.","link.modal.header.close.aria_label":"close","link.opt_in.financial_incentive.amount":"Get {financialIncentive}","link.opt_in.financial_incentive.label":"Save your info for secure 1-click checkout, get cash back","link.opt_in.financial_incentive.subtext":"Pay faster at {businessName} and thousands of businesses and get {financialIncentive} cash back on this purchase.","link.opt_in.financial_incentive.subtext_mentioning_link":"Pay faster at {businessName} and everywhere Link is accepted and get {financialIncentive} cash back on this purchase.","link.opt_in.subtext":"Save your checkout info and get 1-click checkout here and across thousands of sites.","link.opt_in.subtext_mentioning_link":"Save your checkout info and get 1-click checkout here and everywhere Link is accepted.","link.pay_another_way":"Pay another way","link.powered_by_link":"Powered by Link","link.privacy":"Privacy Policy","link.support_site":"support site","link.payment_type.card":"Card","link.payment_type.credit":"Credit","link.payment_type.debit":"Debit","link.payment_type.prepaid":"Prepaid","link.payment_type.card_with_brand":"{brand} Card","link.payment_type.credit_with_brand":"{brand} Credit","link.payment_type.debit_with_brand":"{brand} Debit","link.payment_type.prepaid_with_brand":"{brand} Prepaid","link.purchase_protection.badge.text":"Covered","link.purchase_protection.learn_more.button":"Learn more","link.purchase_protection.serviced_by.text":"Serviced by {partner}","link.purchase_protection.pay_by_bank.button":"Pay by bank","link.purchase_protection.pay_by_bank.description":"Get {title} on this purchase.","link.purchase_protection.pay_by_bank.price.type":"free price protection","link.purchase_protection.pay_by_bank.product.type":"free accident coverage","link.purchase_protection.pay_by_bank.return.type":"no-fee returns","link.purchase_protection.pay_by_bank.shopping.type":"free shopping protections","link.purchase_protection.modal.all.description":"Your items may be eligible for protection when you pay with Link.","link.purchase_protection.modal.debit.description":"Your items may be eligible for protection when you pay with debit.","link.purchase_protection.modal.price.title":"Price drop protection","link.purchase_protection.modal.price.question":"What\'s price drop protection?","link.purchase_protection.modal.price.answer":"Get up to $200 cash back if your item\'s price drops within 30 days.","link.purchase_protection.modal.claim.question":"How do I file a claim?","link.purchase_protection.modal.claim.answer":"After you check out, you\'ll receive an email from Link with next steps.","link.purchase_protection.modal.eligibility.question":"What items aren\'t eligible?","link.purchase_protection.modal.eligibility.answer":"Food, cars, medication, animals, plants, air tickets, and event tickets.","link.purchase_protection.modal.link.subtext":"Link saves your contact details, payment method, and shipping address so you can pay faster next time.","link.purchase_protection.modal.mulberry.subtext":"Provided in partnership with {partner}","link.purchase_protection.modal.mulberry.title":"How we work with {partner}","link.purchase_protection.modal.mulberry.question":"What is {partner}?","link.purchase_protection.modal.mulberry.answer":"{partner} is a purchase protections provider that has partnered with Link to offer you free protections and a hassle-free claims process.","link.purchase_protection.modal.mulberry.answer.v2":"{partner} is a purchase protections provider partnering with Link to offer you free coverage.","link.purchase_protection.modal.mulberry_data.question":"What data is shared?","link.purchase_protection.modal.mulberry_data.answer":"{partner} may use your email address and certain information about your purchase to provide protection in the event of a claim.","link.purchase_protection.modal.mulberry_data.answer.v2":"Your email address and purchase information may be used in the event of a claim.","link.purchase_protection.modal.mulberry.eligibility.question":"What items aren’t eligible?","link.purchase_protection.modal.mulberry.eligibility.answer":"Food, cars, medication, animals, plants, air tickets, event tickets, and used items.","link.purchase_protection.modal.shopping.title":"Free purchase protections","link.purchase_protection.modal.shopping.description":"Your items may be eligible for protections.","link.purchase_protection.modal.shopping.price.question":"Price drop refunds","link.purchase_protection.modal.shopping.price.answer":"Get money back if the price drops within {days} days.","link.purchase_protection.modal.shopping.product.question":"Accident coverage","link.purchase_protection.modal.shopping.product.answer":"Get coverage for accidental damage or manufacturer defects.","link.purchase_protection.modal.shopping.return.question":"No-fee returns","link.purchase_protection.modal.shopping.return.answer":"Get reimbursed for shipping and restocking fees.","link.purchase_protection.modal.shopping.title.v2":"Purchase protections","link.purchase_protection.modal.shopping.description.v2":"Included on eligible items","link.purchase_protection.modal.shopping.price.question.v2":"Price matching","link.purchase_protection.modal.shopping.price.question.v3":"Price drop protection","link.purchase_protection.modal.shopping.price.question.v4":"Price protection","link.purchase_protection.modal.shopping.price.answer.v2":"Get money back if you find a better price within {days} days.","link.purchase_protection.modal.shopping.product.question.v2":"Damage, theft, or loss","link.purchase_protection.modal.shopping.product.answer.v2":"Get coverage if something goes wrong in the first 120 days.","link.purchase_protection.modal.shopping.product.answer.v3":"Get coverage if something goes wrong in the first {days} days.","link.purchase_protection.modal.shopping.return.question.v2":"No-fee returns","link.purchase_protection.modal.shopping.return.answer.v2":"Get reimbursed for return shipping and restocking fees.","link.purchase_protection.modal.product.title.v2":"Purchase protections","link.purchase_protection.modal.price.title.v2":"Price protection","link.purchase_protection.modal.return.title.v2":"No-fee returns","link.purchase_protection.modal.price.content.v2":"Your item(s) may be eligible for up to ${amount} in reimbursement if you find a better price within {days} days.","link.purchase_protection.modal.return.content.v2":"Your item(s) may be eligible for up to ${amount} in reimbursement on return shipping and restocking fees.","link.purchase_protection.modal.view_terms":"<link>View terms</link>","link.purchase_protection.modal.view_full_terms":"<link>View full terms</link>","link.purchase_protection.modal.provided_by":"Protections provided by","link.purchase_protection.modal.powered_by":"Protections powered by","link.purchase_protection.modal.administered_via":"Protections administered via","link.purchase_protection.returning_user_message":"Free <link>purchase protections</link> on eligible items","link.row_actions.remove":"Remove","link.row_actions.update":"Update","link.save_info_otp":"It looks like you\'ve saved information to Link before. Enter the code sent to your phone {redactedPhoneNumber} to use your saved information.","link.select_payment_method_to_pay_with":"Select a payment method to pay with","link.signed_in_as":"You\'re signed in as {email}","link.terms":"Link Terms","link.terms.financial_incentive":"Offer Terms","link.terms_short":"Terms","link.update.read_only_card_number.title":"Can’t update card number. Add new card instead.","link.use_redacted_card_with_logo":"Use {logo} •••• {last4}","link.verification.email_otp_sent":"Code sent, please check your email","link.verification.enter_code":"Enter the code sent to {recipientContactInfo}","link.verification.testmode_enter_code":"The current session is in testmode and will not send a code. Enter {testmodeOtpCode} to continue.","link.verification.error_unexpected":"Something went wrong","link.verification.login_with_passkey":"Log in with passkey","link.verification.phone_verification.back":"Back","link.verification.phone_verification.error":"That phone number is not associated with this account. Double check it and try again.","link.verification.phone_verification.header":"Enter your phone number","link.verification.phone_verification.subtext":"Before we can send a code to your email, we need to verify your phone number {redactedPhoneNumber}","link.verification.resend_code":"Resend code","link.verification.send_code_to_email":"Send code to email instead","link.verification.use_saved_info":"Use your saved information","link.payment.unavailable":"Paying with Link is currently unavailable. Try a different way to pay. If you have any questions, please visit our {supportSite}.","link.with_stripe":"Link","link.add_payment.consent":"By continuing, you agree to save your payment method with Link.","link_autofill.link_autofill_modal.address":"Ship to","link_autofill.link_autofill_modal.autofill_checkout":"Autofill checkout","link_autofill.link_autofill_modal.back_to_checkout":"Back to checkout","link_autofill.link_autofill_modal.billing_same_as_shipping":"Billing is the same as shipping","link_autofill.link_autofill_modal.code_instruction":"Enter the code sent to","link_autofill.link_autofill_modal.email":"Email","link_autofill.link_autofill_modal.explanation":"It looks like you have saved info to Link before.","link_autofill.link_autofill_modal.loading":"Loading","link_autofill.link_autofill_modal.no_address_option":"Use another address","link_autofill.link_autofill_modal.no_payment_option":"Use another payment","link_autofill.link_autofill_modal.payment":"Pay with","link_autofill.link_autofill_modal.select_address":"Select a shipping address","link_autofill.link_autofill_modal.select_payment":"Select a payment","link_autofill.link_autofill_modal.title":"Check out faster with Link","link_popup.add_and_use_card":"Add and use card","link_popup.add_card":"Add a card","link_popup.add_payment":"Add a payment method","link_popup.add_payment_method":"Add payment method","link_popup.add_shipping":"Add a shipping address","link_popup.add_shipping_address":"Add shipping address","link_popup.address":"Address","link_popup.address_autocomplete_results.enter_manually":"Enter address manually","link_popup.address_autocomplete_results.no_results":"No results found","link_popup.address_autocomplete_results.suggestions_powered_by":"Suggestions powered by","link_popup.amount_pending":"Amount Pending","link_popup.back":"Back","link_popup.back_to_merchant":"Back to {merchant_name}","link_popup.bank":"Bank","link_popup.button.continue":"Continue","link_popup.cancel":"Cancel","link_popup.change":"Change","link_popup.choose_how_to_pay":"Choose how to pay {merchant}.","link_popup.close":"Close","link_popup.close_login_form":"Close login form","link_popup.confirmation.card_saved_with_link":"Card saved with Link","link_popup.confirmation.description.enter_verification_code":"Enter the code sent to {redactedPhoneNumber} to finish saving.","link_popup.confirmation.header.welcome_back":"Welcome back","link_popup.confirmation.header.welcome_back_with_name":"Welcome back, {customer_name}","link_popup.confirmation.welcome_back_to_link":"Welcome back to Link","link_popup.confirmation.welcome_to_link":"Welcome to Link","link_popup.contact_support":"Contact support","link_popup.continue.to_checkout":"Continue to checkout","link_popup.continue.to_payment":"Continue to payment","link_popup.continue.to_shipping":"Continue to shipping","link_popup.default":"Default","link_popup.delivery.title.collapsed":"Delivery","link_popup.delivery.title.expanded":"Delivery options","link_popup.delivery_options_picker":"Delivery options picker","link_popup.edit":"Edit","link_popup.edit_payment":"Edit payment method","link_popup.email":"Email","link_popup.error":"Error","link_popup.error.bank.unavailable":"Your saved bank account is unavailable for this purchase.","link_popup.error.billing.recollection":"{merchant_name} requires your billing address.","link_popup.error.billing_address.invalid":"Your billing address is invalid.","link_popup.error.card.enter_valid_cvc":"Enter a valid CVC","link_popup.error.card.enter_valid_expiry":"Enter a valid expiration date","link_popup.error.card.enter_valid_number":"Enter a valid card number","link_popup.error.card.expiration_in_past":"Your card’s expiration is in the past.","link_popup.error.card.expiration_incomplete":"Your card’s expiration is incomplete.","link_popup.error.card.expired":"This card has expired. Please update this card or use a different card.","link_popup.error.card.expiry_invalid":"Your card’s expiration date is invalid.","link_popup.error.card.generic_error":"There was an error with the card you entered","link_popup.error.card.incomplete_number":"Your card number is incomplete.","link_popup.error.card.incorrect":"Your card number is invalid","link_popup.error.cvc.incomplete":"Your card’s security code is incomplete.","link_popup.error.cvc.incorrect":"Your card’s security code is incorrect.","link_popup.error.cvc.recollection":"For security, please re-enter your card’s security code.","link_popup.error.expired":"Expired","link_popup.error.generic_decline":"Payment failed. Please verify your information and try again.","link_popup.error.one_time_passcode_send":"We had trouble logging you in. Please try again.","link_popup.error.payment.unavailable_payment":"Unavailable for this purchase","link_popup.error.phone_number.invalid":"Your phone number is invalid.","link_popup.error.postal_code.recollection":"{merchant_name} requires your postal code.","link_popup.error.rate_limited":"There’s an unusual amount of traffic from your network. Please wait a few minutes and try again.","link_popup.error.shipping.unavailable":"Your saved address is unavailable for this purchase.","link_popup.error.shipping_address.invalid":"Your shipping address is invalid.","link_popup.error.shipping_new.unavailable":"Your shipping address is unavailable for this purchase.","link_popup.error.unexpected":"Something went wrong","link_popup.error.unexpected.subtitle":"Close the window and try again.","link_popup.expired":"Expired","link_popup.footer.cookie_settings":"Cookie settings","link_popup.footer.privacy":"Privacy","link_popup.footer.terms":"Terms","link_popup.free":"Free","link_popup.header.learn_more":"Learn more","link_popup.header.subtitle":"Save your payment information with Link, and securely check out in 1-click on Link-supported sites.","link_popup.header.subtitle.v2":"Save your payment details to check out safely at thousands of online retailers.","link_popup.header.subtitle.v3":"Save and autofill your payment details everywhere Link is accepted online.","link_popup.header.subtitle.v4":"Autofill your card details everywhere Link is accepted online.","link_popup.header.title":"Fast, secure, 1-click checkout","link_popup.header.title.save":"Save your card for next time","link_popup.header.title.v2":"Pay faster with Link","link_popup.header.title.v3":"Autofill your card","link_popup.incomplete":"Incomplete","link_popup.international_address_input.error.incomplete_address":"This field is incomplete.","link_popup.international_address_input.error.incomplete_full_name":"Please provide your full name.","link_popup.international_address_input.error.invalid_postal_code":"Your postal code is invalid.","link_popup.international_address_input.error.invalid_zip":"Your ZIP is invalid.","link_popup.international_address_input.error.po_box_prohibited":"Address must not contain a P.O. Box.","link_popup.labels.address":"Address","link_popup.labels.address.administrative_area.area":"Area","link_popup.labels.address.administrative_area.county":"County","link_popup.labels.address.administrative_area.department":"Department","link_popup.labels.address.administrative_area.district":"District","link_popup.labels.address.administrative_area.do_si":"Do Si","link_popup.labels.address.administrative_area.emirate":"Emirate","link_popup.labels.address.administrative_area.island":"Island","link_popup.labels.address.administrative_area.oblast":"Oblast","link_popup.labels.address.administrative_area.parish":"Parish","link_popup.labels.address.administrative_area.prefecture":"Prefecture","link_popup.labels.address.administrative_area.province":"Province","link_popup.labels.address.administrative_area.state":"State","link_popup.labels.address.country":"Country or region","link_popup.labels.address.full_name":"Full name","link_popup.labels.address.line1":"Address line 1","link_popup.labels.address.line2":"Address line 2","link_popup.labels.address.locality.city":"City","link_popup.labels.address.locality.district":"District","link_popup.labels.address.locality.post_town":"Town or city","link_popup.labels.address.locality.suburb":"Suburb","link_popup.labels.address.locality.suburb_or_city":"Suburb or city","link_popup.labels.address.postal_code.eircode":"Eircode","link_popup.labels.address.postal_code.pin":"PIN","link_popup.labels.address.postal_code.postal":"Postal code","link_popup.labels.address.postal_code.zip":"ZIP","link_popup.labels.address.sorting_code.cedex":"CEDEX","link_popup.labels.address.sublocality.district":"District","link_popup.labels.address.sublocality.neighborhood":"Neighborhood","link_popup.labels.address.sublocality.suburb":"Suburb","link_popup.labels.address.sublocality.townland":"Townland","link_popup.labels.address.sublocality.village_township":"Village or township","link_popup.labels.payment.billing_same_as":"Billing is the same as shipping","link_popup.labels.payment.card_number":"Card number","link_popup.labels.payment.cvc":"CVC","link_popup.labels.payment.expiry":"Expiration","link_popup.legal.log_in_footer":"By continuing, you agree to join {link_link} and its {terms_link} and {privacy_link}.","link_popup.legal.pay_footer":"By paying, you agree to join {link_link} and its {terms_link} and {privacy_link}.","link_popup.legal.pay_footer_share_phone":"By paying, you agree to join {link_link} and its {terms_link} and {privacy_link}. {merchant} requires your phone number to be shared with them to complete the transaction.","link_popup.legal.privacy_policy_link":"Privacy Policy","link_popup.legal.select_footer":"By continuing with Link, you agree to the {terms_link} and {privacy_link}.","link_popup.legal.terms_link":"Terms","link_popup.loading":"Loading","link_popup.log_out":"Log out","link_popup.login.description.enter_email_verification_code":"Enter the code sent to {emailAddress}.","link_popup.login.description.enter_email_verification_code_empty_email":"Enter the code sent to your email.","link_popup.login.description.enter_phone_number_for_verification":"To send a code to your email, please verify your phone number ending in {redactedPhoneNumberLastTwoDigits}.","link_popup.login.description.enter_verification_code":"Enter the code sent to {redactedPhoneNumber} to use your saved information.","link_popup.login.email.suggest_correction":"Did you mean @{emailDomain}?","link_popup.login.email.suggestion":"Did you mean {email}?","link_popup.login.error.invalid_phone_number":"The phone number you entered was invalid.","link_popup.login.header.already_have_link_account":"It looks like you already have a Link account","link_popup.login.header.enter_email_verification_code":"We sent you an email","link_popup.login.header.enter_phone_number_for_verification":"Verify your phone number","link_popup.login.header.enter_verification_code":"Enter your verification code","link_popup.login.resend_code_to_email_otp":"Resend","link_popup.login.resend_code_to_email_otp_sending":"Sending","link_popup.login.resend_code_to_email_otp_sent":"Sent","link_popup.login.save_and_join_link":"Save and join Link","link_popup.login.save_to_your_account":"Save to your account","link_popup.login.send_code_to_email_otp":"Send code to email instead","link_popup.login.terms_and_privacy_policy":"By continuing, you agree to the {termsLink} and {privacyPolicyLink}.","link_popup.login.verification.error.incorrect":"Hmm, that code didn’t work. Double check it and try again.","link_popup.login.verification.error.max_attempts":"It looks like the verification code you provided is not valid anymore. We sent you a new one.","link_popup.management_menu":"Management menu","link_popup.mandates.bank":"By submitting your order to {businessName} you agree to authorize payments pursuant to <linkTerms>these terms</linkTerms>.","link_popup.mandates.bank.setup_future_usage":"By saving your bank account for {businessName} you agree to authorize payments pursuant to <linkTerms>these terms</linkTerms>.","link_popup.mandates.card":"By providing your card information, you allow {businessName} to charge your card for future payments in accordance with their terms.","link_popup.merchant.phone_number.description":"{merchant} requires this phone number to be shared with them to complete the transaction.","link_popup.merchant.phone_number_recollection.description":"{merchant} uses this number for your order.","link_popup.modal.learn_more.built_by_stripe":"Link is built by Stripe","link_popup.modal.learn_more.built_by_stripe_description":"Millions of companies use Stripe to process payments and manage their businesses. Stripe created Link to provide a fast and secure way to pay in one click.","link_popup.modal.learn_more.data_encryption":"Data encryption","link_popup.modal.learn_more.data_encryption_description":"Your card information stays secure with data encryption on servers that meet the highest PCI standards available in the payment industry.","link_popup.modal.learn_more.mobile_verification":"Mobile verification","link_popup.modal.learn_more.mobile_verification_description":"You’re protected with mobile authentication designed to verify that you’re the only person who can access your information.","link_popup.modal.learn_more.privacy":"Learn more about privacy","link_popup.modal.learn_more.privacy_and_cookies":"Learn more about <PrivacyLink>privacy</PrivacyLink> and <CookiePolicyLink>cookies</CookiePolicyLink>.","link_popup.modal.learn_more.review_order":"You can review every order before you pay.","link_popup.modal.learn_more.title":"Link securely saves your contact information, card details, and shipping addresses so you can pay faster next time.","link_popup.modal.log_out.description":"This will remove your Link payment credentials from this device. You can always log back in using the same email.","link_popup.modal.log_out.title":"Are you sure you want to log out?","link_popup.order_details":"Order details","link_popup.pay.amount":"Pay {amount}","link_popup.pay.merchant":"Pay {merchant_name}","link_popup.pay.processing":"Processing…","link_popup.payment.section.billing.title":"Billing address","link_popup.payment.title.collapsed":"Payment","link_popup.payment.title.expanded":"Payment method","link_popup.payment_method_picker":"Payment method picker","link_popup.payment_methods":"Payment methods","link_popup.phone_number":"Mobile phone number","link_popup.phone_number.full_title":"Phone number","link_popup.phone_number.title":"Phone","link_popup.phone_number_mismatch":"That phone number is not associated with this account. Double check it and try again.","link_popup.remove":"Remove","link_popup.remove_address":"Remove address","link_popup.remove_address.confirmation.subtitle":"This shipping address will be removed from Link and will no longer be available on other websites that use Link.","link_popup.remove_address.confirmation.title":"Remove {addressLine1}?","link_popup.remove_bank.confirmation.title":"Remove {bank_name} {redacted_bank_number}?","link_popup.remove_card":"Remove card","link_popup.remove_card.confirmation.subtitle":"This payment method will be removed from Link and will no longer be available on other websites that use Link.","link_popup.remove_card.confirmation.title":"Remove {card_brand} {redacted_card_number}?","link_popup.remove_payment_method.confirmation.subtitle":"This payment method will be removed from Link and will no longer be available on other websites that use Link.","link_popup.save_with_link":"Save with Link","link_popup.save_your_card":"Save your card for secure, fast checkout","link_popup.save_your_card_with_link":"Save your card with Link for secure, fast checkout","link_popup.screen_overlay.deactivated.subtitle":"After review, we have deactivated your account. You will no longer be able to use your Link account. If you have any questions, please visit our <a>support site</a>.","link_popup.screen_overlay.deactivated.title":"Your account has been deactivated","link_popup.screen_overlay.in_review.subtitle":"Thanks for providing additional information about your account. We’ll send you an email once you’re all set. If you have any questions, please visit our <a>support site</a>.","link_popup.screen_overlay.in_review.title":"We’re reviewing your account","link_popup.screen_overlay.in_review_needs_info.subtitle":"Thanks for signing up for a Link account. You’re almost ready to get started—we just need a little more information. We’ve sent you an email with further instructions. If you have any questions, please visit our <a>support site</a>.","link_popup.screen_overlay.logged_out.text":"All logged out","link_popup.screen_overlay.payment_complete":"Payment complete","link_popup.secure_1_click_checkout":"Fast, secure, 1-click checkout","link_popup.select_card":"Select a card","link_popup.select_payment_method":"Select payment method","link_popup.shipping.title.collapsed":"Shipping","link_popup.shipping.title.expanded":"Shipping address","link_popup.shipping_address_picker":"Shipping address picker","link_popup.shipping_addresses":"Shipping addresses","link_popup.sign_up":"Sign up","link_popup.sign_up.disclaimer":"By joining {link_link}, you agree to the {terms_link} and {privacy_link}.","link_popup.sign_up.privacy_policy_link":"Privacy Policy","link_popup.sign_up.save_and_join_link":"Save and join Link","link_popup.sign_up.terms_link":"Terms","link_popup.sign_up_or_log_in":"Sign up or log in","link_popup.something_went_wrong":"Something went wrong. Please try reloading this page.","link_popup.submit_phone_number_for_verification":"Confirm phone number","link_popup.total":"Total","link_popup.update":"Update","link_popup.update_address":"Update address","link_popup.update_card":"Update card","link_popup.update_payment":"Update payment method","link_popup.update_to_use_this_card":"Update your card to pay {merchant}.","link_popup.update_your_card":"Update your card","link_popup.use_redacted_card":"Use •••• {last4}","link_popup.use_this_card":"Use this card to pay {merchant}.","link_popup.validation.invalid":"This field is invalid","link_popup.validation.required":"This field is required","linkedAccounts.accountLoadError.accountTypes.link":"US checking","linkedAccounts.accountLoadError.accountTypes.usBankAccount":"checking or savings","linkedAccounts.accountLoadError.description.noShowManualEntryWithRetry":"Please select another bank.","linkedAccounts.accountLoadError.description.noShowManualEntryWithoutRetry":"Please select another bank or try again.","linkedAccounts.accountLoadError.description.showManualEntry":"Please enter your bank details manually or select another bank.","linkedAccounts.accountLoadError.heading":"No {supportedAccountTypes} account available","linkedAccounts.accountLoadError.linkAnotherAccount":"Link another account","linkedAccounts.accountLoadError.manualEntry.description":"Please enter your bank details manually or try selecting another bank account.","linkedAccounts.accountLoadError.manualEntry.skipAccountSelection.description":"Please enter your bank details manually or try selecting another bank.","linkedAccounts.accountLoadError.manualEntryCta":"Enter bank details manually","linkedAccounts.accountLoadError.merchantName.description":"We found {numIneligibleAccounts} {institutionName} {numIneligibleAccounts, plural, one {account} other {accounts}} but you can only link {supportedAccountTypes} to {merchantName}.","linkedAccounts.accountLoadError.noMerchantName.description":"We found {numIneligibleAccounts} {institutionName} {numIneligibleAccounts, plural, one {account} other {accounts}} but you can only link {supportedAccountTypes}.","linkedAccounts.accountLoadError.selectAnotherBank":"Select another bank","linkedAccounts.accountLoadError.tryAgain":"Try again","linkedAccounts.accountLoadError.tryAgain.description":"Please try selecting another bank account.","linkedAccounts.accountLoadError.tryAgain.skipAccountSelection.description":"Please try selecting another bank.","linkedAccounts.accountNumberRetrievalFailure.description.allowManualEntry":"Please enter your bank details manually or select another bank.","linkedAccounts.accountNumberRetrievalFailure.description.noManualEntry":"Please select another bank.","linkedAccounts.accountNumberRetrievalFailure.heading":"Your account number couldn\'t be accessed at this time","linkedAccounts.accountNumberRetrievalFailure.manualEntryCta":"Enter bank details manually","linkedAccounts.accountNumberRetrievalFailure.selectAnotherBank":"Select another bank","linkedAccounts.accountPicker.accountDisabled.previouslyLinked":"Already linked","linkedAccounts.accountPicker.accountTypes.link":"US checking","linkedAccounts.accountPicker.accountTypes.usBankAccount":"checking or savings","linkedAccounts.accountPicker.allAccounts":"All accounts","linkedAccounts.accountPicker.balanceUnavailable":"Balance unavailable","linkedAccounts.accountPicker.cta":"Link {count, plural, one {account} other {accounts}}","linkedAccounts.accountPicker.heading":"Select {count, plural, one {an account} other {accounts}}","linkedAccounts.accountPicker.learnMoreLink":"Learn more","linkedAccounts.accountPicker.linkWithStripeCta":"Connect {count, plural, one {account} other {accounts}}","linkedAccounts.accountPicker.linkedBadge":"Linked","linkedAccounts.accountPicker.loading.description":"Please wait while we retrieve your accounts.","linkedAccounts.accountPicker.loading.title":"Retrieving accounts","linkedAccounts.accountPicker.singleAccount.description":"{businessName} only needs one account at this time.","linkedAccounts.accountPicker.singleAccount.description.noBusinessName":"This merchant only needs one account at this time.","linkedAccounts.accountPicker.singleAccount.description.withStripe":"Stripe only needs one account at this time.","linkedAccounts.accountPicker.singleAccount.select.placeholder":"Choose one","linkedAccounts.accountPicker.submitting.description.hasBusinessName":"Please wait while your {count, plural, one {account is} other {accounts are}} linked to {businessName} through Stripe.","linkedAccounts.accountPicker.submitting.description.noBusinessName":"Please wait while your {count, plural, one {account is} other {accounts are}} linked to Stripe.","linkedAccounts.accountPicker.submitting.descriptionLinkWithStripe.hasBusinessName":"Please wait while your {count, plural, one {account is} other {accounts are}} connected to {businessName} through Link.","linkedAccounts.accountPicker.submitting.descriptionLinkWithStripe.noBusinessName":"Please wait while your {count, plural, one {account is} other {accounts are}} connected to Link.","linkedAccounts.accountPicker.submitting.title":"Linking {count, plural, one {account} other {accounts}}","linkedAccounts.accountPicker.type.accountDetails":"account details","linkedAccounts.accountPicker.type.balances":"balances","linkedAccounts.accountPicker.type.ownership":"account ownership details","linkedAccounts.accountPicker.type.transactions":"transactions","linkedAccounts.authOptions.desktopAuth":"Log in with their website","linkedAccounts.authOptions.desktopAuthCaption":"Continue on their website in a new window","linkedAccounts.authOptions.manualEntryLink":"Enter bank details manually instead","linkedAccounts.authOptions.mobileAuth":"Log in with their mobile app","linkedAccounts.authOptions.mobileAuthCaption":"Scan a QR code to launch their app","linkedAccounts.authOptions.paneTitle":"Log in to link your accounts","linkedAccounts.closeConfimation.back":"Back","linkedAccounts.closeConfirmation.close":"Yes, cancel","linkedAccounts.closeConfirmation.description.hasBusinessName":"You haven\'t finished linking your bank account to Stripe and {businessName}.","linkedAccounts.closeConfirmation.description.noBusinessName":"You haven\'t finished linking your bank account to Stripe {businessName}.","linkedAccounts.closeConfirmation.heading":"Are you sure you want to cancel?","linkedAccounts.closeConfirmation.networkingDescription":"If you cancel now, your account will be linked to {businessName} but it will not be saved to Link.","linkedAccounts.consent.accessControl.content":"You can {disconnectLink} your accounts at any time.","linkedAccounts.consent.accessControl.heading":"You\'re in control","linkedAccounts.consent.cta.button":"Agree","linkedAccounts.consent.cta.genericTosDisclaimer":"Stripe\'s {linkedAccountsTermsLink} and {stripePrivacyPolicyLink}","linkedAccounts.consent.cta.learnMore":"Learn more","linkedAccounts.consent.cta.linkBankConnectionDisclaimer":"You agree to Link\'s {linkTosLink} and {linkPrivacyPolicyLink}","linkedAccounts.consent.cta.linkSignUpDisclaimer":"Link\'s {linkedAccountsTermsLink} and {stripePrivacyPolicyLink}","linkedAccounts.consent.cta.manualEntry":"Enter account details manually instead","linkedAccounts.consent.cta.manualVerification":"{manualVerificationLink} (takes 1-2 business days)","linkedAccounts.consent.cta.manualVerificationLink":"Manually verify instead","linkedAccounts.consent.cta.stripePrivacyPolicyLink":"Privacy Policy","linkedAccounts.consent.cta.stripeTosLink":"Terms","linkedAccounts.consent.dataAccess.content":"Stripe will allow {businessName} to access only the {dataAccessLink}. We never share your login details with them.","linkedAccounts.consent.dataAccess.contentWithConnectedAccount":"{connectedAccountName} partners with {businessName}. Stripe will allow them to access only the {dataAccessLink}.","linkedAccounts.consent.dataAccess.heading":"Limited access","linkedAccounts.consent.dataAccess.link":"data requested","linkedAccounts.consent.dataAccessNotice.accountDetails.content":"Account number, routing number, account type, account nickname","linkedAccounts.consent.dataAccessNotice.closeCta":"OK","linkedAccounts.consent.dataAccessNotice.connectedAccountNotice":"{connectedAccountName} will only have access to the account details.","linkedAccounts.consent.dataAccessNotice.heading":"Data requested by {businessName} for the accounts you link:","linkedAccounts.consent.dataAccessNotice.headingNoBusinessName":"Data requested by this business for the accounts you link:","linkedAccounts.consent.dataAccessNotice.type.accountDetails.title":"Account details","linkedAccounts.consent.dataAccessNotice.type.balances.content":"Current and pending balances when requested","linkedAccounts.consent.dataAccessNotice.type.balances.title":"Balances","linkedAccounts.consent.dataAccessNotice.type.ownership.content":"Account owner name and mailing address associated with your account","linkedAccounts.consent.dataAccessNotice.type.ownership.title":"Account owner information","linkedAccounts.consent.dataAccessNotice.type.transactions.content":"Current and pending transactions when requested","linkedAccounts.consent.dataAccessNotice.type.transactions.title":"Transactions","linkedAccounts.consent.dataSharing.content":"We don\'t share your financial data or login details with {businessName}.","linkedAccounts.consent.dataSharing.content.noMerchantName":"We don\'t share your financial data or login details with the merchant.","linkedAccounts.consent.dataUse.content":"Your data is encrypted for your protection.","linkedAccounts.consent.dataUse.contentWithConnectedAccount":"Your data is encrypted for your protection. Stripe never shares your login details with {connectedAccountName} or {businessName}.","linkedAccounts.consent.dataUse.heading":"Security","linkedAccounts.consent.heading":"{businessName} works with {stripeName} to link your accounts","linkedAccounts.consent.heading.stripe":"Stripe","linkedAccounts.consent.headingLinkWithStripe.hasInstitutionName":"Link your {institutionName} account with {stripeName}.","linkedAccounts.consent.headingLinkWithStripe.noInstitutionName":"Link your financial account with {stripeName}.","linkedAccounts.consent.headingNoBusinessName":"This business works with {stripeName} to link your accounts","linkedAccounts.consent.headingWithConnectedAccount":"{connectedAccountName} and {businessName} work with {stripeName} to link your accounts","linkedAccounts.cta.manualEntry":"Enter account details manually instead","linkedAccounts.cta.manualVerification":"{manualVerificationLink} (takes 1-2 business days)","linkedAccounts.cta.manualVerificationLink":"Manually verify instead","linkedAccounts.dataAccessText.content.direct":"{list}.","linkedAccounts.dataAccessText.content.notDirect":"{list} through Stripe.","linkedAccounts.dataAccessText.heading.hasBusinessName":"Data accessible to {businessName}:","linkedAccounts.dataAccessText.heading.noBusinessName":"Data accessible to this business:","linkedAccounts.dataAccessText.heading.stripe":"Data accessible to Stripe:","linkedAccounts.dataAccessText.linkWithStripe.hasBusinessName":"We don\'t share your financial data or login details with {businessName}.","linkedAccounts.dataAccessText.linkWithStripe.noBusinessName":"We don\'t share your financial data or login details with this business.","linkedAccounts.dataAccessText.networkingContent":"{list} through Link.","linkedAccounts.emailSuggestion.didYouMean":"Did you mean {suggestion}?","linkedAccounts.hostedMobileHandoff.errorDescription":"Your account can\'t be linked at this time. Please try again later.","linkedAccounts.hostedMobileHandoff.errorTitle":"Something went wrong","linkedAccounts.hostedMobileHandoff.qrError.description":"Please return to the original screen and start again.","linkedAccounts.hostedMobileHandoff.qrError.title":"Invalid QR code","linkedAccounts.hostedMobileHandoff.successDescription":"Now, complete the process in the original window.","linkedAccounts.hostedMobileHandoff.successTitle":"Return to the Stripe website","linkedAccounts.hostedPage.errorMessage":"This link is expired or invalid.","linkedAccounts.hostedPage.errorTitle":"Error loading page","linkedAccounts.instantDebitsOnly.errorMessage":"This link is expired or invalid.","linkedAccounts.instantDebitsOnly.errorTitle":"Error loading page","linkedAccounts.institutionLoadError.cta":"Select another bank","linkedAccounts.institutionLoadError.description.allowManualEntry":"Please enter your bank details manually or select another bank.","linkedAccounts.institutionLoadError.description.noManualEntry":"Please select another bank or try again later.","linkedAccounts.institutionLoadError.heading":"{institutionName} is currently unavailable","linkedAccounts.institutionLoadError.manualEntryCta":"Enter bank details manually","linkedAccounts.institutionScheduledDowntimeFailure.cta":"Select another bank","linkedAccounts.institutionScheduledDowntimeFailure.description.allowManualEntry":"Please enter your bank details manually or select another bank.","linkedAccounts.institutionScheduledDowntimeFailure.description.noManualEntry":"Please select another bank or try again later.","linkedAccounts.institutionScheduledDowntimeFailure.endTime.differentDay":"Maintenance is scheduled to end on {expectedEndDate} at {expectedEndTime}.","linkedAccounts.institutionScheduledDowntimeFailure.endTime.sameDay":"Maintenance is scheduled to end at {expectedEndTime}.","linkedAccounts.institutionScheduledDowntimeFailure.heading":"{institutionName} is undergoing maintenance","linkedAccounts.institutionScheduledDowntimeFailure.manualEntryCta":"Enter bank details manually","linkedAccounts.institutionSearch.heading":"Select your bank","linkedAccounts.institutionSearch.inputLabel":"Search for your bank by name","linkedAccounts.institutionSearch.inputPlaceholder":"Search for your bank","linkedAccounts.institutionSearch.manualEntry.description":"Enter your account and routing numbers","linkedAccounts.institutionSearch.manualEntry.title":"Don’t see your bank?","linkedAccounts.institutionSearch.noResults.description":"Double check your spelling and search terms","linkedAccounts.institutionSearch.noResults.title":"No results","linkedAccounts.institutionSearch.searchDisabled":"You can currently pay with the following banks:","linkedAccounts.institutionSearch.searchResults.empty.heading":"No results for “{searchTerm}”.","linkedAccounts.institutionSearch.searchResults.error.description.allowManualEntry":"Please try again later or {manualEntryLink}.","linkedAccounts.institutionSearch.searchResults.error.description.noManualEntry":"Please try again later.","linkedAccounts.institutionSearch.searchResults.error.heading":"Search is currently unavailable","linkedAccounts.institutionSearch.searchResults.error.manualEntryLink":"enter your bank details manually","linkedAccounts.institutionSearch.searchResults.help.emailSupport.heading":"Questions? Contact support","linkedAccounts.institutionSearch.searchResults.help.heading":"Can\'t find your bank?","linkedAccounts.institutionSearch.searchResults.help.manualEntry.heading":"Manually add your account","linkedAccounts.institutionSearch.searchResults.help.missingBank.heading":"Double check your spelling and search terms","linkedAccounts.institutionSearch.testmodeSelector":"Choose account linking scenario you want to simulate:","linkedAccounts.link.purchaseProtection.claim.lineItem.description":"Once your purchase is complete, you’ll get an email from Link with easy-to-follow instructions.","linkedAccounts.link.purchaseProtection.claim.lineItem.title":"How do I file a claim?","linkedAccounts.link.purchaseProtection.eligibility.cta":"{learn_more_link} about eligible items.","linkedAccounts.link.purchaseProtection.eligibility.cta.text":"Learn more","linkedAccounts.link.purchaseProtection.eligibility.description":"We offer protections for appliances, furniture, electronics, bikes, jewelry, watches, fitness equipment, and more. Note that at this time, we’re unable to cover used or refurbished items.","linkedAccounts.link.purchaseProtection.eligibility.title":"What types of items are eligible?","linkedAccounts.link.purchaseProtection.eligible.lineItem.description":"Item eligibility is determined after checkout. Non-eligible items include food, cars, medication, animals, plants, air tickets, and event tickets.","linkedAccounts.link.purchaseProtection.eligible.lineItem.title":"What items are eligible?","linkedAccounts.link.purchaseProtection.loggedIn.bankSelected.cta.text":"OK","linkedAccounts.link.purchaseProtection.loggedIn.cardSelected.cta.text":"Select {bankNumber}","linkedAccounts.link.purchaseProtection.loggedOut.cta.text":"Select bank","linkedAccounts.link.purchaseProtection.partnership.mulberry.cta":"Provided in partnership with {mulberryLink}.","linkedAccounts.link.purchaseProtection.partnership.mulberry.cta.text":"OK","linkedAccounts.link.purchaseProtection.partnership.mulberry.lineItem.one.description":"{mulberryName} is an extended warranty provider that has partnered with Link to offer you free protections and a hassle-free claims process.","linkedAccounts.link.purchaseProtection.partnership.mulberry.lineItem.one.title":"What is {mulberryName}?","linkedAccounts.link.purchaseProtection.partnership.mulberry.lineItem.two.description":"Yes, eligible items are covered for free. No surprise subscriptions or hidden charges.","linkedAccounts.link.purchaseProtection.partnership.mulberry.lineItem.two.title":"Is coverage really free?","linkedAccounts.link.purchaseProtection.partnership.mulberry.policy.cta.text":"View full policy terms","linkedAccounts.link.purchaseProtection.partnership.mulberry.title":"Introducing {mulberryName}","linkedAccounts.link.purchaseProtection.payByBank.cta.text":"Pay by bank","linkedAccounts.link.purchaseProtection.price.lineItem.description":"Get up to 10% cash back if the price drops within 3 months of your eligible purchase date.","linkedAccounts.link.purchaseProtection.price.lineItem.title":"What’s price protection?","linkedAccounts.link.purchaseProtection.price.title":"free price protection","linkedAccounts.link.purchaseProtection.product.eligible.lineItem.cta.text":"more","linkedAccounts.link.purchaseProtection.product.eligible.lineItem.description":"Appliances, furniture, electronics, bikes, jewelry, watches, fitness equipment, and {eligibility_link}. Used or refurbished items are not eligible.","linkedAccounts.link.purchaseProtection.product.eligible.lineItem.title":"What items are eligible?","linkedAccounts.link.purchaseProtection.product.lineItem.description":"Get 1 year of coverage on defects and accidental damage, such as drops, spills, cracks, and tears.","linkedAccounts.link.purchaseProtection.product.lineItem.title":"What’s accident coverage?","linkedAccounts.link.purchaseProtection.product.title":"free accident coverage","linkedAccounts.link.purchaseProtection.return.lineItem.description":"Get reimbursed for hidden return fees on eligible items, including shipping and restocking costs.","linkedAccounts.link.purchaseProtection.return.lineItem.title":"What’s a no-fee return guarantee?","linkedAccounts.link.purchaseProtection.return.title":"no-fee returns","linkedAccounts.link.purchaseProtection.shopping.price.lineItem.description":"Get money back if the price drops within 90 days.","linkedAccounts.link.purchaseProtection.shopping.price.lineItem.title":"Price drop protection","linkedAccounts.link.purchaseProtection.shopping.product.lineItem.description":"Get coverage for accidental damage or defects.","linkedAccounts.link.purchaseProtection.shopping.product.lineItem.title":"Accident and defect coverage","linkedAccounts.link.purchaseProtection.shopping.product.title":"free protections","linkedAccounts.link.purchaseProtection.shopping.return.lineItem.description":"Get reimbursed for shipping and restocking fees.","linkedAccounts.link.purchaseProtection.shopping.return.lineItem.title":"No-fee returns","linkedAccounts.link.purchaseProtection.title":"Pay with your bank","linkedAccounts.link.purchaseProtection.title.description":"Your items may be eligible for {coverageTitle} when you pay by bank.","linkedAccounts.linkAccountPicker.addNewAccount":"New bank account","linkedAccounts.linkAccountPicker.connectAccountCta":"Connect account","linkedAccounts.linkAccountPicker.heading":"Select an account to connect to {businessName}","linkedAccounts.linkAccountPicker.headingNoBusinessName":"Select an account to connect with this business","linkedAccounts.linkAccountPicker.repairAndConnectAccountCta":"Repair and connect account","linkedAccounts.linkAccountPicker.selectToRepairAccount":"Select to repair and connect","linkedAccounts.linkConsent.accessControl.content":"You can {disconnectLink} your accounts at any time.","linkedAccounts.linkConsent.accessControl.disconnectLink":"disconnect","linkedAccounts.linkConsent.cta.button":"Continue with Link","linkedAccounts.linkConsent.dataEncryption.content":"Your data is encrypted for your protection.","linkedAccounts.linkConsent.dataUse.content":"We don\'t share your financial data or login details with {businessName}.","linkedAccounts.linkConsent.dataUse.contentNoBusinessName":"We don\'t share your financial data or login details with this business.","linkedAccounts.linkConsent.heading":"{businessName} uses {linkWithStripeName} to connect your financial accounts","linkedAccounts.linkConsent.headingLinkWithStripe":"Connect your financial account with {linkWithStripeName}","linkedAccounts.linkConsent.linkWithStripe":"Link","linkedAccounts.linkLogin.description":"Securely save your information for faster checkout at thousands of merchants with Link.","linkedAccounts.linkLogin.emailLabel":"Email address","linkedAccounts.linkLogin.errorMessages.emptyPhoneNumber":"Please provide a mobile phone number.","linkedAccounts.linkLogin.errorMessages.incompleteEmail":"Your email address is incomplete.","linkedAccounts.linkLogin.errorMessages.incompletePhoneNumber":"Your mobile phone number is incomplete.","linkedAccounts.linkLogin.errorMessages.invalidEmail":"Your email address is invalid.","linkedAccounts.linkLogin.errorMessages.invalidPhoneNumber":"Your mobile phone number is invalid.","linkedAccounts.linkLogin.errorMessages.invalidPhoneNumberPrefix":"Please enter a valid country code starting with a \'+\'.","linkedAccounts.linkLogin.errorMessages.tooLongEmail":"Your email address is too long.","linkedAccounts.linkLogin.heading":"Safe, fast checkout with Link","linkedAccounts.linkLogin.joinLink":"Join Link","linkedAccounts.linkLogin.networkingDescription":"Link encrypts your data and never shares your login details.","linkedAccounts.linkLogin.networkingDescriptionMentioningLink":"Connect your account faster everywhere Link is accepted.","linkedAccounts.linkLogin.networkingHeading":"Save your account to Link","linkedAccounts.linkLogin.networkingMerchantDescription":"Connect your account faster on {businessName} and thousands of sites.","linkedAccounts.linkLogin.networkingMerchantDescriptionMentioningLink":"Connect your account faster on {businessName} and everywhere Link is accepted.","linkedAccounts.linkLogin.networkingNotNow":"Not now","linkedAccounts.linkLogin.networkingSaveToLink":"Save to Link","linkedAccounts.linkLogin.phoneNumberLabel":"Mobile number","linkedAccounts.linkStepUpVerification.description":"Enter the code sent to your email {emailAddress}.","linkedAccounts.linkStepUpVerification.heading":"Enter your verification code","linkedAccounts.linkVerification.codeExpired":"The previous code has expired. Please enter the new code sent to your phone.","linkedAccounts.linkVerification.codeInvalid":"Invalid code.","linkedAccounts.linkVerification.description":"Enter the code sent to your phone {redactedPhoneNumber}.","linkedAccounts.linkVerification.heading":"Enter your verification code","linkedAccounts.linkVerification.maxAttemptsExceeded":"Too many attempts. Please try again in a few minutes.","linkedAccounts.linkVerification.networkingDescription":"Enter the code sent to {redactedPhoneNumber}.","linkedAccounts.linkVerification.networkingHeading":"Sign in to Link","linkedAccounts.linkVerification.networkingLinkEmail":"{userEmail}","linkedAccounts.linkVerification.networkingNotNow":"Not now","linkedAccounts.linkVerification.networkingNotYou":"Not you?","linkedAccounts.linkVerification.networkingSigninInAs":"Signing in as {userEmail}.","linkedAccounts.linkVerification.resendEmailCode":"Resend code","linkedAccounts.manualEntry.accountNumber.description":"Your account can be checking or savings.","linkedAccounts.manualEntry.accountNumber.label":"Account number","linkedAccounts.manualEntry.confirmAccountNumber.label":"Confirm account number","linkedAccounts.manualEntry.cta":"Continue","linkedAccounts.manualEntry.description":"Your bank information will be verified with micro-deposits to your account.","linkedAccounts.manualEntry.heading":"Enter bank account details","linkedAccounts.manualEntry.routingNumber.label":"Routing number","linkedAccounts.manualEntry.validation.accountNumberLength":"Invalid bank account number: must be at most 17 digits long.","linkedAccounts.manualEntry.validation.confirmMismatch":"Your account numbers don\'t match.","linkedAccounts.manualEntry.validation.required":"{fieldLabel} is required.","linkedAccounts.manualEntry.validation.requiredConfirmation":"Confirm the account number.","linkedAccounts.manualEntry.validation.routingNumberInvalid":"Invalid routing number.","linkedAccounts.manualEntry.validation.routingNumberLength":"Please enter 9 digits for your routing number.","linkedAccounts.manualEntrySuccess.cta":"Done","linkedAccounts.manualEntrySuccess.description.hasLast4":"Expect two small deposits to the account ending in ••••{last4} in 1-2 business days and an email with additional instructions to verify your bank account.","linkedAccounts.manualEntrySuccess.description.noLast4":"Expect two small deposits to your account in 1-2 business days and an email with additional instructions to verify your bank account.","linkedAccounts.manualEntrySuccess.descriptorCode.description.hasLast4":"Expect a $0.01 deposit to the account ending in ••••{last4}in 1-2 business days and an email with additional instructions to verify your bank account.","linkedAccounts.manualEntrySuccess.descriptorCode.description.noLast4":"Expect a $0.01 deposit to your account in 1-2 business days and an email with additional instructions to verify your bank account.","linkedAccounts.manualEntrySuccess.heading":"Micro-deposits initiated","linkedAccounts.manualEntrySuccess.illustration.heading.hasLast4":"••••{last4} bank statement","linkedAccounts.manualEntrySuccess.illustration.heading.noLast4":"My bank statement","linkedAccounts.manualQrCta.cta.buttonLink":"Open app","linkedAccounts.manualQrCta.cta.title":"Title of post qr scan page cta","linkedAccounts.networkingLinkLoginWarmup.continueAs":"Continue as","linkedAccounts.networkingLinkLoginWarmup.description":"It looks like you have a Link account. Signing in will let you quickly access your saved bank accounts.","linkedAccounts.networkingLinkLoginWarmup.diffSignIn":"Not you? <DifferentLinkAccountButton>Sign in or join Link</DifferentLinkAccountButton>","linkedAccounts.networkingLinkLoginWarmup.heading":"Sign in to Link","linkedAccounts.networkingLinkLoginWarmup.skipSignIn":"Not you? <SkipSignInButton>Continue without signing in</SkipSignInButton>","linkedAccounts.partnerAuth.dataAccess.link":"requested data","linkedAccounts.partnerAuth.iframe.title":"Link with {institution}","linkedAccounts.partnerAuth.oauth.cta":"Link with {institution}","linkedAccounts.partnerAuth.oauth.description":"We will only share the {requestedData} with {merchant}, even if your bank grants access to more.","linkedAccounts.partnerAuth.oauth.descriptionNoBusinessName":"We will only share the {requestedData} with this business, even if your bank grants access to more.","linkedAccounts.partnerAuth.oauth.launchDescription.isSingleAccount":"A new window will open for you to log in and select the {institution} account you want to link.","linkedAccounts.partnerAuth.oauth.launchDescription.notSingleAccount":"A new window will open for you to log in and select the {institution} accounts you want to link.","linkedAccounts.partnerAuth.oauth.redirectDescription":"You\'ll return here once you\'re done.","linkedAccounts.partnerAuth.oauth.redirectLaunchDescription.isSingleAccount":"You will be taken to {institution} where you can log in and select the account you want to link.","linkedAccounts.partnerAuth.oauth.redirectLaunchDescription.notSingleAccount":"You will be taken to {institution} where you can log in and select the accounts you want to link.","linkedAccounts.partnerAuth.oauth.webviewLaunchDescription.isSingleAccount":"You will be redirected to log in and select the {institution} account you want to link.","linkedAccounts.partnerAuth.oauth.webviewLaunchDescription.notSingleAccount":"You will be redirected to log in and select the {institution} accounts you want to link.","linkedAccounts.partnerAuth.partnerDisclosure.disclaimer":"Stripe works with partners like {partnerName} to reliably offer access to thousands of financial institutions.","linkedAccounts.partnerAuth.partnerDisclosure.learnMoreLink":"Learn more","linkedAccounts.partnerAuth.trustedPartnerOverlay.finicityDescription":"Sign in via Stripe and its trusted partners","linkedAccounts.partnerAuth.trustedPartnerOverlay.iconLinkDescription":"What is the relationship between Stripe and Stripe\'s service providers?","linkedAccounts.partnerAuth.trustedPartnerOverlay.mxDescription":"via Stripe and its trusted partners","linkedAccounts.partnerAuth.trustedPartnerOverlay.mxTitle":"Sign in","linkedAccounts.partnerAuthLoading.description":"Please wait while a connection is established.","linkedAccounts.partnerAuthLoading.heading":"Establishing connection","linkedAccounts.partnerauth.oauth.cta.button":"Agree","linkedAccounts.shared.heading":"{businessName} works with {stripeName} to link your accounts","linkedAccounts.shared.heading.stripe":"Stripe","linkedAccounts.shared.headingLinkWithStripe.hasInstitutionName":"Link your {institutionName} account with {stripeName}.","linkedAccounts.shared.headingLinkWithStripe.noInstitutionName":"Link your financial account with {stripeName}.","linkedAccounts.shared.headingNoBusinessName":"This business works with {stripeName} to link your accounts","linkedAccounts.shared.headingWithConnectedAccount":"{connectedAccountName} and {businessName} work with {stripeName} to link your accounts","linkedAccounts.success.accounts":"accounts","linkedAccounts.success.cta":"Done","linkedAccounts.success.ctaContinue":"Continue with {businessName}","linkedAccounts.success.description.hasBusinessName":"Your {count, plural, one {account was} other {accounts were}} successfully linked to {businessName} through Stripe.","linkedAccounts.success.description.noBusinessName":"Your {count, plural, one {account was} other {accounts were}} successfully linked to Stripe.","linkedAccounts.success.descriptionLinkWithStripe.hasBusinessName":"Your {count, plural, one {account was} other {accounts were}} successfully connected to {businessName} through Link.","linkedAccounts.success.descriptionLinkWithStripe.noBusinessName":"Your {count, plural, one {account was} other {accounts were}} successfully connected to Link.","linkedAccounts.success.descriptionNetworkingSavedToLinkWithStripe.hasBusinessName":"Your {count, plural, one {account was} other {accounts were}} successfully connected to {businessName} and saved to Link.","linkedAccounts.success.descriptionNetworkingSavedToLinkWithStripe.noBusinessName":"Your {count, plural, one {account was} other {accounts were}} successfully connected and saved to Link.","linkedAccounts.success.disconnect.link":"disconnect your {count, plural, one {account} other {accounts}}","linkedAccounts.success.disconnect.message":"You can {disconnectLink} at any time.","linkedAccounts.success.heading":"Account connected","linkedAccounts.success.heading.link":"Success","linkedAccounts.success.linkAnotherAccount":"Link another account","linkedAccounts.success.networkingSaveToLinkFailed":"Your account was connected to {businessName} but could not be saved to Link at this time.","linkedAccounts.success.networkingSaveToLinkFailedNoBusiness":"Your account was connected to this business but could not be saved to Link at this time.","linkedAccounts.success.selectSingleAccountDescription":"{businessName} only needs one account at this time. Please select the account you\'d like to use.","linkedAccounts.success.singleAccountSelectLabel":"Select account...","linkedAccounts.truelayerMobileHandoff.loginHelp":"Scan the QR code with your mobile phone to log in to {institutionName}","linkedAccounts.truelayerMobileHandoff.loginTitle":"Log in with their app","linkedAccounts.truelayerMobileHandoff.qrScanned":"Complete the login process on your phone...","linkedAccounts.unclassifiedError.cta":"Close","linkedAccounts.unclassifiedError.description":"Your account can\'t be linked at this time. Please{allowManualEntry, select, true { enter your bank details manually or} false {}} try again later.","linkedAccounts.unclassifiedError.heading":"Something went wrong","linkedAccounts.unclassifiedError.manualEntryCta":"Enter bank details manually","linkedAccounts.v3.accountPicker.cta":"Connect {count, plural, one {account} other {accounts}}","linkedAccounts.v3.accountPicker.heading":"Select {isSingleAccount, select, true {account} other {accounts}}","linkedAccounts.v3.accountPicker.loadingHeading":"Retrieving accounts...","linkedAccounts.v3.dataAccessText.learnMoreLink":"Learn more","linkedAccounts.v3.dataAccessText.linkWithStripe.hasBusinessName":"Your login and financial details are never shared with {businessName}. {learnMore}","linkedAccounts.v3.dataAccessText.linkWithStripe.noBusinessName":"Your login and financial details are never shared with this business. {learnMore}","linkedAccounts.v3.dataAccessText.text.hasBusinessName":"{businessName} can access {list}. {learnMore}","linkedAccounts.v3.dataAccessText.text.noBusinessName":"This business can access {list}. {learnMore}","linkedAccounts.v3.dataAccessText.text.stripe":"Stripe can access {list}. {learnMore}","linkedAccounts.v3.dataAccessText.type.accountDetails":"account details","linkedAccounts.v3.dataAccessText.type.balances":"balances","linkedAccounts.v3.dataAccessText.type.ownership":"ownership details","linkedAccounts.v3.dataAccessText.type.transactions":"transactions","linkedAccounts.v3.failure.accountLoadError.heading":"There was a problem accessing your {institutionName} account","linkedAccounts.v3.failure.accountLoadError.isAccountPollingRetry.heading":"We still can’t access your {institutionName} account","linkedAccounts.v3.failure.accountNoneEligibleForInstantDebits.description":"We found {numIneligibleAccounts} {institutionName} {numIneligibleAccounts, plural, one {account} other {accounts}} but {numIneligibleAccounts, plural, one {it} other {they}} can\'t be used at this time.","linkedAccounts.v3.failure.accountNoneEligibleForInstantDebits.heading":"The {numIneligibleAccounts, plural, one {account} other {accounts}} you selected can\'t be used","linkedAccounts.v3.failure.accountNoneEligible.description.withMerchant":"We found {numIneligibleAccounts} {institutionName} {numIneligibleAccounts, plural, one {account} other {accounts}} but you can only link {supportedAccountTypes} accounts to {merchantName}.","linkedAccounts.v3.failure.accountNoneEligible.description.withoutMerchant":"We found {numIneligibleAccounts} {institutionName} {numIneligibleAccounts, plural, one {account} other {accounts}} but you can only link {supportedAccountTypes} accounts.","linkedAccounts.v3.failure.accountNoneEligible.heading":"No checking or savings account available","linkedAccounts.v3.failure.accountNoneEligible.userSelected.heading":"The {numIneligibleAccounts, plural, one {account} other {accounts}} you selected {numIneligibleAccounts, plural, one {isn\'t} other {aren\'t}} available for payments","linkedAccounts.v3.failure.accountNumberRetrievalError.heading":"Your account number couldn’t be accessed at this time","linkedAccounts.v3.failure.accountTypes.link":"US checking","linkedAccounts.v3.failure.accountTypes.accountSubcategories":"{accountSubcategories}","linkedAccounts.v3.failure.accountTypes.usBankAccount":"checking or savings","linkedAccounts.v3.failure.cta.close":"Close","linkedAccounts.v3.failure.cta.connectAnotherAccount":"Connect another account","linkedAccounts.v3.failure.cta.manualEntry":"Enter bank details manually","linkedAccounts.v3.failure.cta.selectAnotherBank":"Select another bank","linkedAccounts.v3.failure.cta.tryAgain":"Try again","linkedAccounts.v3.failure.cta.continue":"Continue","linkedAccounts.v3.failure.cta.selectAnotherAccount":"Select another account","linkedAccounts.v3.failure.description.connectAccount":"Please connect another account.","linkedAccounts.v3.failure.description.manualEntryOrConnectAccount":"Please enter your bank details manually or connect another account.","linkedAccounts.v3.failure.description.manualEntryOrSelectBank":"Please enter your bank details manually or select another bank.","linkedAccounts.v3.failure.description.selectBank":"Please select another bank.","linkedAccounts.v3.failure.description.selectBankOrTryAgain":"Please select another bank or try again later.","linkedAccounts.v3.failure.plannedDowntimeError.endTimeDescription.differentDay":"Maintenance is scheduled to end on {expectedEndDate} at {expectedEndTime}.","linkedAccounts.v3.failure.plannedDowntimeError.endTimeDescription.sameDay":"Maintenance is scheduled to end at {expectedEndTime}.","linkedAccounts.v3.failure.plannedDowntimeError.heading":"{institutionName} is undergoing maintenance","linkedAccounts.v3.failure.unclassifiedError.allowManualEntry.description":"Your account can’t be connected at this time. Please enter your bank details manually or try again later.","linkedAccounts.v3.failure.unclassifiedError.description":"Your account can’t be connected at this time. Please try again later.","linkedAccounts.v3.failure.unclassifiedError.selectAnotherBank.description":"Your account can’t be connected at this time. Please select another bank or try again later.","linkedAccounts.v3.failure.unclassifiedError.allowManualEntry.selectAnotherBank.description":"Your account can’t be connected at this time. Please enter your bank details manually or select another bank.","linkedAccounts.v3.failure.unclassifiedError.heading":"Something went wrong","linkedAccounts.v3.failure.unplannedDowntimeError.heading":"{institutionName} is currently unavailable","linkedAccounts.v3.failure.networkingSaveToLink.description":"Your account could not be saved to Link at this time.","linkedAccounts.v3.failure.networkingShareAccount.descriptionWithManualEntry":"You cannot use the selected account at this time. Try adding your bank details manually or selecting another account.","linkedAccounts.v3.failure.networkingShareAccount.description":"You cannot use the selected account at this time. Try selecting or adding another account.","linkedAccounts.v3.manualEntry.accountNumber.label":"Account number","linkedAccounts.v3.manualEntry.confirmAccountNumber.label":"Confirm account number","linkedAccounts.v3.manualEntry.cta":"Submit","linkedAccounts.v3.manualEntry.description.checkingOnly":"Only checking accounts are supported.","linkedAccounts.v3.manualEntry.description.checkingOrSavings":"Checking and savings accounts are supported.","linkedAccounts.v3.manualEntry.description.incentiveIneligible":"Not eligible for {text} back","linkedAccounts.v3.manualEntry.description.withVerification.checkingOnly":"Your bank information will be verified via micro-deposits to your account, typically within 1-2 business days. Only checking accounts are supported.","linkedAccounts.v3.manualEntry.description.withVerification.checkingOrSavings":"Your bank information will be verified with micro-deposits to your account. This typically takes 1-2 business days.","linkedAccounts.v3.manualEntry.heading":"Enter bank details","linkedAccounts.v3.manualEntry.microdepositsSuccessHeading":"Almost there","linkedAccounts.v3.manualEntry.microdepositsSucccessMessage":"Next, submit your payment details {merchantName, select, false {} other {with {merchantName}}} to initiate micro-deposits. You can expect an email with instructions within 1-2 business days.","linkedAccounts.v3.manualEntry.routingNumber.label":"Routing number","linkedAccounts.v3.manualEntry.validation.accountNumberLength":"Invalid bank account number: must be at most 17 digits long, containing only numbers.","linkedAccounts.v3.manualEntry.validation.confirmMismatch":"Your account numbers don’t match.","linkedAccounts.v3.manualEntry.validation.required":"{fieldLabel} is required.","linkedAccounts.v3.manualEntry.validation.requiredConfirmation":"Confirm the account number.","linkedAccounts.v3.manualEntry.validation.routingNumberInvalid":"Invalid routing number.","linkedAccounts.v3.manualEntry.validation.routingNumberLength":"Please enter 9 digits for your routing number.","linkedAccounts.v3.manualEntry.testmodeFill.button":"Use test account","linkedAccounts.v3.manualEntry.testmodeFill.description":"You\'re in test mode.","linkedAccounts.v3.manualEntry.errors.account_number_invalid":"Invalid account number.","linkedAccounts.v3.manualEntry.errors.routing_number_invalid":"Invalid routing number.","linkedAccounts.v3.success.cta":"{backToName, select, false {Done} other {Back to {backToName}}}","linkedAccounts.v3.success.description":"Your {count, plural, one {account was} other {accounts were}} connected.","linkedAccounts.v3.success.saveToLinkError":"Your {count, plural, one {account was} other {accounts were}} connected, but couldn\'t be saved with Link.","linkedAccounts.v3.success.heading":"Success","links.terms":"Link\'s Terms","linkOptIn.optional":"Optional","luxe.in_context.frame_title":"In-context payment completion page","luxe.naver_pay.selector.label.funding":"Select how you want to pay:","luxe.naver_pay.selector.funding.item.card":"Naver Pay Card","luxe.naver_pay.selector.funding.item.point":"Naver Pay Point","multibanco.voucher_frame_title":"Multibanco Voucher","oxxo.voucher_frame_title":"OXXO Voucher","payment.backToLink":"Back to Link wallet","payment.blik.bank_app_authorization_prompt":"After submitting your order, please authorize the payment in your mobile banking application","payment.blik.check_app_heading":"Approve Payment","payment.blik.check_app_message":"Open your bank\'s app to approve your payment","payment.card_installments.fixed_count.month":"{count} monthly payments of","payment.card_installments.fixed_count.month.mxn":"{count} payments of","payment.card_installments.pay_in_installments.label":"Pay in installments","payment.card_installments.pay_in_installments.label.mxn":"Pay in installments (meses sin intereses)","payment.card_installments.plan_total":"Total","payment.card_installments.selector.label":"Installment plans","payment.lpm_promotion.badge":"Save {financialIncentive}","payment.lpm_promotion.generic_badge":"Promo","payment.lpm_promotion.terms":"Terms and conditions apply","payment.lpm_promotion.cashapp.message":"Receive {promotion_descriptor} off (up to $20) when you pay with Cash App Pay. Limited to one discount per customer per merchant, while supplies last. {terms_link}.","payment.lpm_promotion.revolut_pay.message":"New accounts get up to {promotion_descriptor}. Join Revolut for 1-click secure checkout. {terms_link}","payment.lpm_promotion.revolut_pay.generic_message":"New Revolut users can get up to £20 after their first transaction as an accountholder. {terms_link}","payment.moreMenu":"More actions","payment.mb_way.app_authorization_prompt":"After submitting your order, please authorize the payment in your MB WAY app.","payment.paynow.button.saveQR":"Save QR Code","payment.paynow.instructions.step1":"Save this QR code to your photos or take a screenshot","payment.paynow.instructions.step2":"Open your bank app or payment app","payment.paynow.instructions.step3":"Select the option to scan a QR code","payment.paynow.instructions.step4":"Upload the QR code you saved earlier","payment.paynow.instructions.step5":"Complete the transaction","payment.paynow.label.bank":"Payments collected via Stripe. Payee name may appear as \\"Stripe Payments Singapore Pte. Ltd.\\". PayNow is supported by bank and payment apps such as","payment.paynow.label.instructions":"Scan and pay with PayNow","payment.paynow.label.instructions_v2":"Scan with your bank app or payment app","payment.paynow.product_name":"PayNow","payment.payto.bank_app_authorization_prompt":"After submitting your order, please authorize the PayTo agreement in your mobile banking app or via online banking.","payment.payto.terms":"Your PayTo transaction may be subject to the terms and conditions of your financial service provider and/or {businessName}.","payment.pix.button.copy_code":"Copy","payment.pix.label.copied_to_clipboard":"Copied","payment.pix.label.qr_code_instructions":"Scan to pay with your bank app","payment.pix.label.string_code_instructions":"Or copy the code to pay","payment.pix.text.instructions":"Scan the QR code or copy the Pix key after submitting your order to complete your purchase details.","payment.promptpay.button.saveQR":"Save QR Code","payment.promptpay.instructions.step1":"Save this QR code to your photos or take a screenshot","payment.promptpay.instructions.step2":"Open your bank app or payment app","payment.promptpay.instructions.step3":"Select the option to scan a QR code","payment.promptpay.instructions.step4":"Upload the QR code you saved earlier","payment.promptpay.instructions.step5":"Complete the transaction","payment.promptpay.label.bank":"Payments collected via Stripe. Payee name may appear as \\"STRIPE PAYMENTS (THAILAND) LTD\\". PromptPay is supported by bank and payment apps such as","payment.promptpay.label.instructions":"Scan and pay with PromptPay","payment.promptpay.label.instructions_v2":"Scan with your bank app or payment app","payment.promptpay.product_name":"PromptPay","payment.qr_code.displaying":"Scan me with your phone","payment.qr_code.placeholder":"QR Code","payment.removeSaved.customerFromSession.description":"This payment method will be removed from {merchantName}.","payment.removeSaved.description":"This payment method will be removed from Link and will no longer be available on other websites that use Link.","payment.removeSaved.description_v2":"This payment method will be removed from Link and will no longer be available on other websites that use Link.","payment.removeSaved.error":"Could not remove this payment method from your account. Please try again later.","payment.removeSaved.sepaDebit":"Remove SEPA Debit •••• {redactedAccountNumber}?","payment.removeSaved.title":"Remove •••• {redactedAccountNumber}?","payment.removeSaved.titleWithName":"Remove {accountName} •••• {redactedAccountNumber}?","payment.us_bank_account.instructions":"Bank account selected for check out.","payment.useSaved":"Use a saved payment method","payment.wechat_pay.label.instructions":"Scan and pay with WeChat","payment.wechat_pay.product_name":"WeChat Pay","pix.instructions_frame_title":"Pix Instructions","placeholders.auBankAccountNumber":"Account number","placeholders.cardNumber":"Card number","placeholders.cardNumberShort":"Number","placeholders.cvc":"CVC","placeholders.expiry":"MM / YY","placeholders.postal_code":"Postal code","placeholders.postcode":"Postcode","placeholders.securityCode":"Security Code","placeholders.selectBank":"Select bank","placeholders.accountHolderType":"Account holder type","placeholders.individual":"Personal","placeholders.company":"Business","placeholders.zip":"ZIP","pmme.initial_messaging.default.first_view":"Buy now pay later","pmme.initial_messaging.default.first_view_klarna":"Pay with Klarna","pmme.initial_messaging.learn_more":"Learn more","pmme.initial_messaging.list_view.pay_later.financing":"{installmentCount} monthly payments of {prettyPaymentAmount}, {prettyInterestRate} APR","pmme.initial_messaging.pay_later.financing":"As low as {roundedPrettyPaymentAmount} / month","pmme.initial_messaging.pay_later.interest_free.1_payment.30_days":"Pay in 30 days","pmme.initial_messaging.pay_later.interest_free.1_payment.60_days":"Pay in 60 days","pmme.initial_messaging.pay_later.interest_free.split_payment":"{installmentCount} interest-free payments of {prettyPaymentAmount}","pmme.initial_messaging.pay_later.interest_free.split_payment.3_or_4_payments":"3 or 4 interest-free payments.","pmme.initial_messaging.payment_plan.financing.1_partner":"As low as {roundedPrettyPaymentAmount} / month","pmme.initial_messaging.payment_plan.financing_and_pay_later_interest_free.1_partner":"As low as {roundedPrettyPaymentAmount} / month or interest-free with","pmme.initial_messaging.payment_plan.financing_and_pay_later_interest_free.multiple_partner":"As low as {roundedPrettyPaymentAmount} / month or interest-free","pmme.initial_messaging.payment_plan.financing_and_pay_later.1_partner":"As low as {roundedPrettyPaymentAmount} / month with","pmme.initial_messaging.payment_plan.financing_and_pay_later.multiple_partner":"As low as {roundedPrettyPaymentAmount} / month","pmme.initial_messaging.payment_plan.pay_now":"Pay now","pmme.initial_messaging.payment_plan.pay_later.1_partner":"{installmentCount} interest-free payments of {prettyPaymentAmount} with","pmme.initial_messaging.payment_plan.single_line.financing":"As low as {roundedPrettyPaymentAmount} / month with","pmme.initial_messaging.payment_plan.single_line.financing.1_partner":"As low as {roundedPrettyPaymentAmount} / month with","pmme.initial_messaging.payment_plan.single_line.financing_and_pay_later_interest_free.1_partner":"As low as {roundedPrettyPaymentAmount} / month or interest-free with","pmme.initial_messaging.payment_plan.single_line.financing_and_pay_later.1_partner":"As low as {roundedPrettyPaymentAmount} / month with","pmme.initial_messaging.payment_plan.single_line.interest_free.1_payment.30_days":"Pay in 30 days with","pmme.initial_messaging.payment_plan.single_line.interest_free.1_payment.60_days":"Pay in 60 days with","pmme.initial_messaging.payment_plan.single_line.interest_free.split_payment":"{installmentCount} interest-free payments of {prettyPaymentAmount} with","pmme.initial_messaging.payment_plan.single_line.interest_free.split_payment.3_or_4_payments":"3 or 4 interest-free payments with","pmme.initial_messaging.payment_plan.single_line.pay_later.1_partner":"{installmentCount} interest-free payments of {prettyPaymentAmount} with","pmme.initial_messaging.title.list_view":"Available offers from","pmme.initial_messaging.disclosure.klarna_gb":"18+, T&C apply, Credit subject to status.","pmme.modal.description.1_partner":"Select {partner1} as your payment method at checkout to pay in installments.","pmme.modal.description.2_partners":"Select {partner1} or {partner2} as your payment method at checkout to pay in installments.","pmme.modal.description.3_partners":"Select {partner1}, {partner2}, or {partner3} as your payment method at checkout to pay in installments.","pmme.modal.description.4_partners":"Select {partner1}, {partner2}, {partner3}, or {partner4} as your payment method at checkout to pay in installments.","pmme.modal.header.subtitle":"How it works:","pmme.modal.header.title":"Buy Now. Pay Later.","pmme.modal.header.total_purchase_price":"Purchase price: {prettyAmount}","pmme.modal.legal_disclaimer.affirm.country.ca.financing.v0":"Payment options through Affirm Canada Holdings Ltd. (“Affirm”). Your rate will be up to 0-32% APR (where available and subject to provincial regulatory limitations). APR offered is based on creditworthiness and subject to an eligibility check. Not all customers will be eligible for 0% APR. Payment options depend on your purchase amount, may vary by merchant, and may not be available in all provinces/territories. Actual payment option terms will be shown at checkout. A down payment (or a payment due today) may be required. Affirm accepts debit cards and PAD as forms of repayment on payment options. Select payment options may be eligible for repayment in the form of credit cards. Please review the terms and conditions of your credit card when using it as a form of repayment. Sample payment options may be: a $800 purchase could be split into 12 monthly payments of $72.21 at 15% APR, or 4 interest-free payments of $200 every 2 weeks. Financing offers may vary from time to time and may be amended or cancelled at any time. See https://helpcenter.affirm.ca for more information.","pmme.modal.legal_disclaimer.affirm.country.us.financing.v0":"Rates from 0-36% APR. Payment options may be subject to an eligibility check and may not be available in all states. While Affirm doesn\'t charge late fees, other payment methods may do so. Options depend on your purchase amount, and a down payment may be required. Estimated payment amounts exclude taxes and shipping charges, which are added at checkout. Loans to California residents made or arranged pursuant to a California Finance Lenders Law license. Financing options through Affirm are provided by these lending partners: affirm.com/lenders. CA residents: Loans by Affirm Loan Services, LLC are made or arranged pursuant to a California Finance Lender license. For licenses and disclosures, see affirm.com/licenses.","pmme.modal.legal_disclaimer.afterpay.country.au.pay_later.v0":"Late fees and additional eligibility criteria apply. The first payment may be due at the time of purchase. For complete terms visit {firstDisclosureLink}.","pmme.modal.legal_disclaimer.afterpay.country.ca.pay_later.v0":"You must be of the age of majority in your province or territory, a resident of Canada, and meet additional eligibility criteria to qualify. Estimated payment amounts shown on product pages exclude taxes and shipping charges, which are added at checkout. Click {firstDisclosureLink} for complete terms.","pmme.modal.legal_disclaimer.afterpay.country.es.pay_later.v0":"All you need to apply is to have a debit or credit card, to be over 18 years of age, and to be a resident of Spain. Late fees and additional eligibility criteria apply. The first payment may be due at the time of purchase. For complete terms visit {firstDisclosureLink}.","pmme.modal.legal_disclaimer.afterpay.country.fr.pay_later.v0":"Available for anyone aged 18 and older, residing in France and owning a credit card issued in France. Late fees and additional eligibility criteria can apply. The first payment is due at the time of the purchase. For complete terms visit {firstDisclosureLink}.","pmme.modal.legal_disclaimer.afterpay.country.gb.pay_later.v0":"Clearpay lends you a fixed amount of credit to allow you to pay for your purchase over 4 installments, due every 2 weeks. To be eligible for credit from Clearpay, you must be over 18 years of age and a permanent UK resident (excluding Channel Islands). Make sure you can make your repayments on time by each due date to avoid late fees. Additional eligibility criteria apply. The first payment is due at the time of purchase. For complete terms visit {firstDisclosureLink}. Clearpay Finance Limited. We encourage you to use Clearpay responsibly.","pmme.modal.legal_disclaimer.afterpay.country.gb.pay_later.v1":"Clearpay lends you a fixed amount of credit so you can pay for your purchase over 4 installments, due every 2 weeks. Ensure you can make repayments on time. You must be 18+ and a permanent UK resident (excl Channel Islands). Clearpay charges a £6 late fee for each late installment and a further £6 if it\'s still unpaid 7 days later. Late fees are capped at £6 for orders under £24 and the lower of £24 or 25% of the order value for orders over £24. Missed payments may affect your ability to use Clearpay in the future and your details may be passed onto a debt collection agency working on Clearpay\'s behalf. Clearpay is credit that is not regulated by the Financial Conduct Authority. T&Cs and other eligibility criteria apply {firstDisclosureLink}.","pmme.modal.legal_disclaimer.afterpay.country.nz.pay_later.v0":"All you need to apply is to have a debit or credit card, to be over 18 years of age, and to be a resident of New Zealand. Late fees and additional eligibility criteria apply. The first payment may be due at the time of purchase. For complete terms visit {firstDisclosureLink}.","pmme.modal.legal_disclaimer.afterpay.country.us.financing.v0":"For Afterpay Pay Monthly users, you must be 18 or older, a resident of the U.S. and meet additional eligibility criteria to qualify. Loans through the Afterpay Pay Monthly program are underwritten and issued by First Electronic Bank, Member FDIC. A down payment may be required. APRs range from 0% to 35.99%, depending on eligibility. As an example, a 12 month $1,000 loan with 21% APR would have 11 monthly payments of $93.11 and 1 payment of $93.19 for a total payment of $1,117.40. Loans are subject to credit check and approval and are not available to residents of Hawaii, New Mexico, West Virginia and Nevada. Valid debit card, accessible credit report and acceptance of final terms required to apply. Estimated payment amounts shown on product pages exclude taxes and shipping charges, which are added at checkout. Click {firstDisclosureLink} for complete terms.","pmme.modal.legal_disclaimer.afterpay.country.us.pay_later.v0":"You must be over 18, a resident of the U.S. and meet additional eligibility criteria to qualify. Late fees may apply. Estimated payment amounts shown on product pages exclude taxes and shipping charges, which are added at checkout. Click {firstDisclosureLink} for complete terms.","pmme.modal.legal_disclaimer.afterpay.country.us.pay_later.v1":"Late fees may apply. Eligibility criteria apply. Loans to California residents made or arranged pursuant to a California Finance Lenders Law license. Click {firstDisclosureLink} for complete terms.","pmme.modal.legal_disclaimer.afterpay.country.us.pay_later.v2":"For Afterpay Pay in 4 users, you must be over 18, a resident of the U.S. and meet additional eligibility criteria to qualify. Late fees may apply. Estimated payment amounts shown on product pages exclude taxes and shipping charges, which are added at checkout. Click {firstDisclosureLink} for complete terms. Loans to California residents made or arranged pursuant to a California Finance Lenders Law license.","pmme.modal.legal_disclaimer.country.au":"Late fees and additional eligibility criteria apply. The first payment (possibly higher, for some purchases) may be due at the time of purchase.","pmme.modal.legal_disclaimer.country.ca":"Payment options through Affirm Canada Holdings Ltd. (\'Affirm\'). Your rate will be up to 0–32% APR (where available and subject to provincial regulatory limitations). APR offered is based on creditworthiness and subject to an eligibility check. Not all customers will be eligible for 0% APR. Payment options depend on your purchase amount, may vary by merchant, and may not be available in all provinces/territories. Actual payment option terms will be shown at checkout. A down payment (or a payment due today) may be required. Affirm accepts debit cards and PAD as forms of repayment on payment options. Select payment options may be eligible for repayment in the form of credit cards. Please review the terms and conditions of your credit card when using it as a form of repayment. Sample payment options may be: a $800 purchase could be split into 12 monthly payments of $72.21 at 15% APR, or 4 interest-free payments of $200 every 2 weeks. Financing offers may vary from time to time and may be amended or cancelled at any time. See https://helpcenter.affirm.ca for more information. You must be of the age of majority in your province or territory, a resident of Canada, and meet additional eligibility criteria to qualify. A higher initial payment may be required for some consumers. Estimated payment amounts shown on product pages exclude tax and shipping charges, which are added at checkout.","pmme.modal.legal_disclaimer.country.es":"You must be over 18, a resident of Spain, and meet additional eligibility criteria to qualify. Late fees may apply. A first payment (possibly higher, for some purchases) may be due at the time of purchase.","pmme.modal.legal_disclaimer.country.fr":"You must be over 18, a resident of France, own a credit card issued in France, and meet additional eligibility criteria to qualify. Late fees may apply. A first payment (possibly higher, for some purchases) may be due at the time of purchase.","pmme.modal.legal_disclaimer.country.gb":"You must be over 18, a permanent resident of the UK (may exclude Channel Islands) and meet additional eligibility criteria to qualify. The payment methods may use soft searches with credit reference agencies. These do not affect your credit rating. Use of these payment methods and any missed payments can affect your ability to obtain credit in the future. Make sure you can make your repayments on time to avoid any late fees. For pay-in-3 / pay-in-4 offerings, the first payment is due at the time of purchase.","pmme.modal.legal_disclaimer.country.ie":"You must be over 18 to use this credit offer. The payment methods may use soft searches with credit reference agencies. These do not affect your credit rating. Missed payments can affect your ability to use the payment methods in the future.","pmme.modal.legal_disclaimer.country.it":"A higher initial payment may be required for some consumers.","pmme.modal.legal_disclaimer.country.nz":"You must be over 18, a resident of New Zealand and meet additional eligibility criteria to qualify. Late fees and additional eligibility criteria apply. A first payment (possibly higher, for some purchases) may be due at the time of purchase.","pmme.modal.legal_disclaimer.country.us":"Rates from 0-36% APR. Payment options may be subject to an eligibility check and may not be available in all states. While Affirm doesn\'t charge late fees, other payment methods may do so. Options depend on your purchase amount, and a down payment may be required. Estimated payment amounts exclude taxes and shipping charges, which are added at checkout. Loans to California residents made or arranged pursuant to a California Finance Lenders Law license. Financing options through Affirm are provided by these lending partners: affirm.com/lenders. CA residents: Loans by Affirm Loan Services, LLC are made or arranged pursuant to a California Finance Lender license. For licenses and disclosures, see affirm.com/licenses. Financing options through Klarna are issued by WebBank, member FDIC","pmme.modal.legal_disclaimer.example_agreement":"Example Agreement","pmme.modal.legal_disclaimer.here":"here","pmme.modal.legal_disclaimer.klarna":"Financing options through Klarna are provided by: Klarna Bank AB (publ), Sveavägen 46, 111 34 Stockholm, Sweden","pmme.modal.legal_disclaimer.klarna.country.at.financing.v1":"Credit issuer: Klarna Bank AB (publ), Sveavägen 46, 111 34 Stockholm, {firstDisclosureLink}","pmme.modal.legal_disclaimer.klarna.country.at.pay_in_30.v0":"{firstDisclosureLink}","pmme.modal.legal_disclaimer.klarna.country.au.pay_in_4.v1":"Pay in 4 is offered by Klarna Australia Pty Ltd. Please note that a higher initial payment may be required for some consumers. Missed payments may be subject to late fees. Read Klarna\'s Pay later in 4 installments {firstDisclosureLink} for more information.","pmme.modal.legal_disclaimer.klarna.country.au.pay_later.v0":"Please note that a higher initial payment may be required for some purchases. More information in the Pay later over 4 installments complete {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.ca.pay_in_4.v1":"Pay in 4 is offered by Klarna CA Ltd. It\'s available to eligible Canadian residents. Initial payments may be higher. Review the Pay in 4 {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.de.financing.v1":"The interest rate is fixed. Interest rate is 9,99%. Read the {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.de.pay_in_3.v1":"Pay in 3 is offered by Klarna Bank AB. It\'s available to eligible residents in Germany who are 18 years or older. Missed payments are subject to late fees and can affect your ability to obtain credit in the future. Review Klarna\'s Pay in 3 {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.es.pay_in_3.v1":"Pay over 3 interest-free installments is offered by Klarna Bank AB. Please note that a higher initial payment may be required for some purchases. Representative example for a purchase of 120€: acquisition price and total price in installments: €120. 3 payments of 40€, APR 0%, TIN 0%. Subject to Klarna\'s approval. Minimum and maximum purchase amount varies depending on the merchant. Read the pre-contractual and contractual Klarna {firstDisclosureLink} here.","pmme.modal.legal_disclaimer.klarna.country.es.pay_later.v0":"Please note that a higher initial payment may be required for some purchases. More information in the Pay later over 3 installments complete {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.fi.financing.v1":"Pay over time {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.fr.pay_in_3.v1":"Pay in 3 is offered by Klarna Bank AB French Branch. Please note that a higher initial payment may be required for some purchases. Klarna Pay later in 3 installments complete {firstDisclosureLink} apply.","pmme.modal.legal_disclaimer.klarna.country.fr.pay_later.v0":"Pay later in 3 installments complete {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.gb.financing.v2":"A deposit might be required. Klarna performs hard credit searches using credit reference agencies, which may affect your credit rating. Late fees may apply. Learn more in the Pre-contract explanation. Representative example: Representative APR (variable) with an assumed credit limit of £1,200 and a purchase rate of 21.90% p.a. {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.gb.pay_in_3.v1":"Pay in 3 is offered by Klarna Financial Services UK Limited and is an unregulated credit agreement. It is available to eligible UK residents who are 18 years or older. Borrowing more than you can afford or paying late may negatively impact your financial status and ability to obtain credit. Subject to status. Late fees and Klarna\'s Pay in 3 {firstDisclosureLink} apply.","pmme.modal.legal_disclaimer.klarna.country.gb.pay_in_30.v0":"Klarna\'s Pay in 30 days is an unregulated credit agreement. Borrowing more than you can afford or paying late may negatively impact your financial status and ability to obtain credit. 18+, UK residents only. Subject to status. {firstDisclosureLink} and late fees apply.","pmme.modal.legal_disclaimer.klarna.country.gb.pay_in_30_days.v1":"Klarna\'s Pay in 30 days is an unregulated credit agreement. Borrowing more than you can afford or paying late may negatively impact your financial status and ability to obtain credit. 18+, UK residents only. Subject to status. {firstDisclosureLink} and late fees apply.","pmme.modal.legal_disclaimer.klarna.country.gb.pay_later.v0":"Klarna\'s Pay in 3 is an unregulated credit agreement. Borrowing more than you can afford or paying late may negatively impact your financial status and ability to obtain credit. 18+, UK residents only. Subject to status. {firstDisclosureLink} and late fees apply.","pmme.modal.legal_disclaimer.klarna.country.ie.pay_in_3.v1":"Pay in 3 is offered by Klarna Bank AB. Please note that a higher initial payment may be required for some purchases. You must be 18+ to use this credit offer. Klarna uses soft searches with credit reference agencies. These do not affect your credit rating. Missed payments can affect your ability to use Klarna. Klarna Pay in 3 installments complete {firstDisclosureLink} apply.","pmme.modal.legal_disclaimer.klarna.country.ie.pay_later.v0":"You must be 18+ to use this credit offer. Klarna uses soft searches with credit reference agencies. These do not affect your credit rating. Missed payments can affect your ability to use Klarna. Pay in 3 installments complete {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.it.pay_later.v0":"Please note that a higher initial payment may be required for some purchases. More information in the Pay later over 3 installments complete {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.nl.pay_in_3.v1":"Pay in 3 is offered by Klarna Bank AB and is an unregulated credit agreement. It is available to eligible Dutch residents who are aged 18 years or older. Late fees and Klarna\'s Pay in 3 {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.no.financing.v1":"Pay monthly financing available through Klarna Bank AB. Klarna Bank AB {firstDisclosureLink} apply.","pmme.modal.legal_disclaimer.klarna.country.nz.pay_in_4.v1":"Pay in 4 is offered by Klarna New Zealand Limited. Please note that a higher initial payment may be required for some consumers.  Fees may apply. Read Klarna\'s Pay later in 4 installments {firstDisclosureLink} for more information.","pmme.modal.legal_disclaimer.klarna.country.nz.pay_later.v0":"Please note that a higher initial payment may be required for some purchases. For more information see payment {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.se.financing.v1":"Pay monthly financing available through Klarna Bank AB. Klarna Bank AB Terms and Conditions apply. Pay monthly financing available through Klarna Bank AB. Klarna Bank AB {firstDisclosureLink} apply.","pmme.modal.legal_disclaimer.klarna.country.us.financing.v1":"Pay monthly financing available through Klarna, Inc. is issued by WebBank, member FDIC. It\'s available to eligible US residents in most states. Rates (0-29.99% APR) are based on your credit. Missed payments are subject to late fees.","pmme.modal.legal_disclaimer.klarna.country.us.pay_in_4.v1":"Pay in 4 is offered by Klarna, Inc. It\'s available to eligible US residents in most states. Initial payments may be higher. Missed payments are subject to late fees. For CA residents, loans made or arranged by Klarna, Inc. pursuant to a California Financing Law license. Review the Pay in 4 {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.country.us.pay_later.v0":"See payment {firstDisclosureLink}. A higher initial payment may be required for some consumers. CA residents: Loans made or arranged pursuant to a California Financing Law license.","pmme.modal.legal_disclaimer.klarna.eu.generic.pay_in_3.v1":"Pay over 3 installments is offered by Klarna Bank AB. Please note that a higher initial payment may be required for some purchases. More information in the Pay later over 3 installments complete Klarna {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.eu.generic.pay_in_30_days.v1":"Pay in 30 days {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.eu.generic.pay_in_60_days.v1":"Pay in 60 days {firstDisclosureLink}.","pmme.modal.legal_disclaimer.klarna.terms.hyperlink":"{firstDisclosureLink}","pmme.modal.legal_disclaimer.terms":"terms","pmme.modal.legal_disclaimer.ts_and_cs":"Ts&Cs","pmme.modal.legal_disclaimer.terms_and_conditions":"Terms and conditions","pmme.modal.payment_plan.installments_primary_text":"{installmentCount} payments of {prettyPaymentAmount}","pmme.modal.payment_plan.interest_bearing.cadence.monthly":"monthly, {prettyInterestRate} APR","pmme.modal.payment_plan.interest_free":"interest-free","pmme.modal.payment_plan.interest_free.1_payment.30_days":"{prettyPaymentAmount} in 30 days","pmme.modal.payment_plan.interest_free.1_payment.60_days":"{prettyPaymentAmount} in 60 days","pmme.modal.payment_plan.interest_free.cadence.biweekly":"every 2 weeks, interest-free","pmme.modal.payment_plan.interest_free.cadence.monthly":"monthly, interest-free","pmme.modal.payment_plan.interest_free.pay_now":"Pay now","pmme.modal.payment_plan.interest_free.split_payment":"{installmentCount} payments of {prettyPaymentAmount}","pmme.modal.payment_plan.in_full":"in full","pmme.modal.payment_plan.legal_terms.1_partner":"See terms","pmme.modal.payment_plan.legal_terms.prefix":"See terms:","pmme.modal.payment_plan.total_cost":"Total: {estimatedTotalCost}","pmme.modal.timeline.step_1":"Add items to your cart","pmme.modal.timeline.step_2.1_partner":"Select {partner1} at checkout","pmme.modal.timeline.step_2.2_partners":"Select {partner1} or {partner2} at checkout","pmme.modal.timeline.step_2.3_or_more_partners":"Select payment method at checkout","pmme.modal.timeline.step_3":"Receive an approval decision","pmme.modal.timeline.step_4":"If approved, pay in installments","qty":"Qty","remove_promo_code":"Remove promo code","shippingAddress.disallowedAddress":"Unable to use this address","shippingAddress.removeSaved.description":"This shipping address will be removed from Link and will no longer be available on other websites that use Link.","shippingAddress.removeSaved.description_v2":"This shipping address will be removed from Link and will no longer be available on other websites that use Link.","shippingAddress.removeSaved.error":"Could not remove this shipping address from your account. Please try again later.","shippingAddress.removeSaved.title":"Remove {addressLine1}?","shippingAddress.useNew":"Add a new address","shippingAddress.useSaved":"Use a saved address","subtotal":"Subtotal","select_card_brand":"Select card brand (optional)","title.achBankSearchResults":"Bank search results","title.address":"Secure address input frame","title.afterpayClearpayMessage":"Afterpay consumer messaging","title.afterpayClearpayMessageModal":"Afterpay Purchase Terms dialogue","title.auBankAccount":"Secure BECS Direct Debit payment input frame","title.auBankAccountNumber":"Secure BECS Direct Debit account number input frame","title.auBsb":"Secure BECS Direct Debit BSB input frame","title.authentication":"Secure email input frame","title.authenticationPopover":"Secure one-time passcode input frame","title.autocompleteSuggestions":"Google autocomplete suggestions dropdown list","title.card":"Secure card payment input frame","title.cardCvc":"Secure CVC input frame","title.cardExpiry":"Secure expiration date input frame","title.cardNumber":"Secure card number input frame","title.currencySelector":"Secure currency selector","title.epsBank":"Secure EPS bank selection dropdown button","title.epsBankSecondary":"Secure EPS bank selection dropdown list","title.expressCheckout":"Secure express checkout frame","title.fpxBank":"Secure FPX bank selection dropdown button","title.fpxBankSecondary":"Secure FPX bank selection dropdown list","title.iban":"Secure IBAN input frame","title.idealBank":"Secure iDEAL bank selection dropdown button","title.idealBankSecondary":"Secure iDEAL bank selection dropdown list","title.linkInfoModal":"Link learn more info dialogue","title.p24Bank":"Secure P24 bank selection dropdown button","title.p24BankSecondary":"Secure P24 bank selection dropdown list","title.payButton":"Secure pay buttons frame","title.payment":"Secure payment input frame","title.paymentMethodMessaging":"Payment method messaging","title.paymentRequestButton":"Secure payment button frame","title.postalCode":"Secure postal code input frame","title.shippingAddress":"Shipping address input frame","ume.initial_messaging.fallback":"Pay over time.","ume.initial_messaging.klarna_financing":"{count} payments of {amount}/month.","ume.initial_messaging.pay_in_30":"Pay in 30 days.","ume.initial_messaging.split_in_3_or_4":"3 or 4 interest-free payments.","ume.initial_messaging.split_payments":"{count} interest-free payments of {amount}.","ume.learn_more_modal.disclaimer_link_to_sweden_general_terms":"Sweden General Terms of Business (AGB)","ume.learn_more_modal.payment_plan.klarna_financing":"{count} monthly payments of {amount} plus interest ({percentage} APR)","upe.hosted_instructions_text.customer_balance":"After submitting, you will be redirected to a bank transfer details page with instructions to securely complete your payment.","upe.hosted_instructions_text.id_bank_transfer":"After submitting your order, you will be redirected to a bank transfer details page with instructions to securely complete your purchase.","update_quantity":"Update quantity","upe.affirm.text":"Pay over time with Affirm","upe.alipay.text":"Alipay selected for check out.","upe.alipay.text_v2":"Alipay selected.","upe.alma.text_v2":"Alma selected.","upe.alma.redirect_text":"Choose Alma to pay in 2, 3 or 4. Once your purchase is verified, you will be redirected to a page where you\'ll be able to securely finalize the payment in installments.","upe.amazon_pay.text_v2":"Amazon Pay selected.","upe.sunbit.text_v2":"Sunbit selected.","upe.billie.text_v2":"Billie selected.","upe.satispay.text_v2":"Satispay selected.","upe.apple_pay.text":"Apple Pay selected for check out.","upe.apple_pay.text_v2":"Apple Pay selected.","upe.kriya.text_v2":"Kriya selected.","upe.bacs_debit.prompt.confirm":"Confirm your Direct Debit details","upe.bacs_debit.rules.confirmation_email":"An email will be sent to {customerEmail} within three business days to confirm the setup of this debit instruction.","upe.bacs_debit.rules.guarantee":"Your payments are protected by the {direct_debit_guarantee_link}.","upe.bacs_debit.rules.notice_of_debit":"Additionally, you will receive two days advance notice via email of any amount to be debited under this instruction. Payments will show as \'\'{sudn}\'\' on your bank statement.","upe.bankTransferRedirectMessage":"After submitting your order, you will be redirected to a bank transfer details page with instructions to securely complete your purchase.","upe.card_brand.accessibility.current_card":"Current card brand is {brand}.","upe.card_brand.accessibility.supported_cards":"Supported cards include {formattedAndLocalizedListOfCardBrands}.","upe.card_brand.amex":"American Express","upe.card_brand.diners":"Diners Club","upe.card_brand.discover":"Discover","upe.card_brand.elo":"Elo","upe.card_brand.jcb":"JCB","upe.card_brand.mastercard":"Mastercard","upe.card_brand.unionpay":"UnionPay","upe.card_brand.visa":"Visa","upe.card_brand.cartes_bancaires":"Cartes Bancaires","upe.card_brand.eftpos_au":"eftpos Australia","upe.card_brand.unknown":"Unknown","upe.cashapp.text":"Cash App Pay selected for check out.","upe.cashapp.text_v2":"Cash App Pay selected.","upe.capchase_pay.text_v2":"Capchase Pay selected.","upe.mondu.text_v2":"Mondu selected.","upe.crypto.redirect_message":"You\'ll be redirected to crypto.link.com to complete your purchase.","upe.crypto.text":"Connect your crypto wallet to Link for check out.","upe.crypto.text_v2":"Connect your crypto wallet to Link.","upe.crypto.pay_with_usdc":"Pay with USDC","upe.customer_balance.text":"Bank transfer selected for check out.","upe.customer_balance.text_v2":"Bank transfer selected.","upe.data.text":"{paymentMethod} selected for check out.","upe.data.text_v2":"{paymentMethod} selected.","upe.demo_pay.text_v2":"Demo Pay selected.","upe.eps.text_v2":"EPS selected","upe.external_payment_method.redirect_message":"After submission, you will be redirected to {externalPaymentMethod} to complete next steps.","upe.giropay.text":"giropay selected for check out.","upe.giropay.text_v2":"giropay selected.","upe.google_pay.text":"Google Pay selected for check out.","upe.google_pay.text_v2":"Google Pay selected.","upe.grabpay.text":"GrabPay selected for check out.","upe.grabpay.text_v2":"GrabPay selected.","upe.sequra.text_v2":"Sequra selected.","upe.id_bank_transfer.bank_delay_and_fees_notice.bca":"BCA transfers are free and instant except when using a Teller, where cost may vary and can take up to 1 business day. Non BCA bank transfers will be rejected.","upe.id_bank_transfer.bank_delay_and_fees_notice.bni":"BNI transfers are free and instant.","upe.id_bank_transfer.bank_delay_and_fees_notice.mandiri":"Mandiri transfers are free and instant.","upe.id_bank_transfer.bank_delay_and_fees_notice.other":"Transfer cost may vary and can take up to 1 business day.","upe.id_bank_transfer.bank_select.bca":"Bank Central Asia (BCA)","upe.id_bank_transfer.bank_select.bni":"Bank Negara Indonesia (BNI)","upe.id_bank_transfer.bank_select.mandiri":"Mandiri","upe.id_bank_transfer.bank_select.other":"Other banks","upe.ideal.text_v2":"iDEAL selected.","upe.kr_card.text_v2":"Local Card selected.","upe.naver_pay.text_v2":"Naver Pay selected.","upe.kakao_pay.text_v2":"Kakao Pay selected.","upe.payco.text_v2":"PAYCO selected.","upe.samsung_pay.text_v2":"Samsung Pay selected.","upe.klarna.text":"Pay with Klarna","upe.labels.ach.changeAccount":"Change account","upe.labels.ach.remove":"Remove","upe.labels.additionalPaymentMethods":"Additional Payment Methods","upe.labels.address":"Address","upe.labels.address.administrative_area.area":"Area","upe.labels.address.administrative_area.county":"County","upe.labels.address.administrative_area.department":"Department","upe.labels.address.administrative_area.district":"District","upe.labels.address.administrative_area.do_si":"Do Si","upe.labels.address.administrative_area.emirate":"Emirate","upe.labels.address.administrative_area.island":"Island","upe.labels.address.administrative_area.oblast":"Oblast","upe.labels.address.administrative_area.parish":"Parish","upe.labels.address.administrative_area.prefecture":"Prefecture","upe.labels.address.administrative_area.province":"Province","upe.labels.address.administrative_area.state":"State","upe.labels.address.country":"Country or region","upe.labels.address.line1":"Address line 1","upe.labels.address.line2":"Address line 2","upe.labels.address.locality.city":"City","upe.labels.address.locality.district":"District","upe.labels.address.locality.post_town":"Town or city","upe.labels.address.locality.suburb":"Suburb","upe.labels.address.locality.suburb_or_city":"Suburb or city","upe.labels.address.postal_code.eircode":"Eircode","upe.labels.address.postal_code.pin":"PIN","upe.labels.address.postal_code.postal":"Postal code","upe.labels.address.postal_code.zip":"ZIP","upe.labels.address.postal_code.zip.v2":"Zip code","upe.labels.address.sorting_code.cedex":"CEDEX","upe.labels.address.sublocality.district":"District","upe.labels.address.sublocality.neighborhood":"Neighborhood","upe.labels.address.sublocality.suburb":"Suburb","upe.labels.address.sublocality.townland":"Townland","upe.labels.address.sublocality.village_township":"Village or township","upe.labels.au_becs_debit.accountNumber":"Account number","upe.labels.au_becs_debit.bsb":"BSB","upe.labels.bacs_debit.account_number":"Account number","upe.labels.bacs_debit.confirm_details":"Confirm","upe.labels.bacs_debit.modify_details":"Modify Details","upe.labels.bacs_debit.name_on_account":"Name on account","upe.labels.bacs_debit.sort_code":"Sort code","upe.labels.bankAccount":"Bank account","upe.labels.billing_country":"Billing country","upe.labels.blik.code":"BLIK code","upe.labels.boleto.taxId":"CPF/CNPJ","upe.labels.cvc":"CVC","upe.labels.cvc.v2":"Security code","upe.labels.cardNetwork":"Card network","upe.labels.country":"Country","upe.labels.defaultSavedPayment":"Set as default payment method","upe.labels.email":"Email","upe.labels.expiration":"Expiration","upe.labels.expiration.v2":"Expiration date","upe.labels.expiration.v3":"Expiration date (MM/YY)","upe.labels.expiry":"Expiry","upe.labels.fullName":"Full name","upe.labels.fullName.optional":"Full name (optional)","upe.labels.id_bank_transfer.bank_select":"Choose your bank","upe.labels.konbini.phone":"Phone number (optional)","upe.labels.linkAutofillPromptDescription":"Securely pay with your saved info, or create a Link account for faster checkout next time.","upe.labels.linkAutofillPromptDescription.v1":"Securely pay with your saved info, or create an account for faster checkout next time.","upe.labels.linkAutofillPromptDescription.v2":"Log in to autofill your payment details.","upe.labels.linkAutofillPromptDescription.v3":"Sign up or log in to use your saved payment information.","upe.labels.linkAutofillPromptHeader.v1":"Secure, 1-click checkout","upe.labels.linkAutofillPromptHeader.v2":"Use your saved information","upe.labels.linkAutofillPromptHeader.v3":"Autofill your card details","upe.labels.purchase_protection.treatment_1.linkAutofillPromptDescription":"Sign up or log in to get {link} on eligible items.","upe.labels.purchase_protection.treatment_2.linkAutofillPromptDescription":"Sign up and pay with debit to get {link} on eligible items.","upe.labels.purchase_protection.treatment_1.linkAutofillPromptDescription.v2":"Sign up or log in to get <link>price drop protection</link> on eligible items.","upe.labels.purchase_protection.treatment_2.linkAutofillPromptDescription.v2":"Sign up and pay with debit to get <link>price drop protection</link> on eligible items.","upe.labels.purchase_protection.linkAutofillPromptDescription":"Pay faster and get <link>free purchase protections</link> everywhere Link is accepted.","upe.labels.purchase_protection.linkAutofillPromptDescription.shopping":"Pay faster and get <link>free purchase protections</link> everywhere Link is accepted.","upe.labels.purchase_protection.linkAutofillPromptDescription.price":"Pay faster and get <link>free price protection</link> everywhere Link is accepted.","upe.labels.purchase_protection.linkAutofillPromptDescription.return":"Pay faster and get <link>no-fee returns</link> everywhere Link is accepted.","upe.labels.purchase_protection.linkAutofillPromptDescription.product":"Pay faster and get <link>free damage protection</link> everywhere Link is accepted.","upe.labels.purchase_protection.linkAutofillPromptDescription.v2.shopping":"Pay faster and get free <link>purchase protections</link> on eligible items.","upe.labels.purchase_protection.linkAutofillPromptDescription.v2.price":"Pay faster and get free <link>price protection</link> on eligible items.","upe.labels.purchase_protection.linkAutofillPromptDescription.v2.return":"Pay faster and get <link>no-fee returns</link> on eligible items.","upe.labels.purchase_protection.linkAutofillPromptDescription.v2.product":"Pay faster and get <link>free damage protection</link> on eligible items.","upe.labels.linkAutofillPromptMessage":"Autofill your card with Link","upe.labels.linkAutofillPromptMessage.exp_1":"Secure, 1-click checkout with Link","upe.labels.linkAutofillPromptMessage.with_logo.v1":"Secure, 1-click checkout with {linkLogo}","upe.labels.linkAutofillPromptMessage.with_logo.v2":"Use your saved information with {linkLogo}","upe.labels.linkAutofillPromptMessage.with_logo.v3":"Autofill your card details with {linkLogo}","upe.labels.linkAutofillPromptMessageSaved":"Use saved payment","upe.labels.purchase_protection.linkOptInBanner":"Protect your purchase","upe.labels.purchase_protection.linkOptInBanner.protected":"Your items are now eligible for protection","upe.labels.purchase_protection.linkOptInMessage":"Get price drop protection from Link","upe.labels.purchase_protection.treatment_1.linkOptInMessage.v2":"Get free price drop protection from Link","upe.labels.purchase_protection.linkOptInDescription":"Your items may be eligible for {link} when you save your info with Link.","upe.labels.purchase_protection.linkOptInDescription.v2":"Pay faster and get <link>free purchase protections</link> everywhere Link is accepted.","upe.labels.purchase_protection.linkOptInDescription.shopping":"Pay faster and get <link>free purchase protections</link> everywhere Link is accepted.","upe.labels.purchase_protection.linkOptInDescription.price":"Pay faster and get <link>free price protections</link> everywhere Link is accepted.","upe.labels.purchase_protection.linkOptInDescription.return":"Pay faster and get <link>no-fee returns</link> everywhere Link is accepted.","upe.labels.purchase_protection.linkOptInDescription.product":"Pay faster and get <link>damage or defect protection</link> everywhere Link is accepted.","upe.labels.purchase_protection.linkOptInDescription.v2.shopping":"Pay faster and get free <link>purchase protections</link> on eligible items.","upe.labels.purchase_protection.linkOptInDescription.v2.price":"Pay faster and get free <link>price protection</link> on eligible items.","upe.labels.purchase_protection.linkOptInDescription.v2.return":"Pay faster and get <link>no-fee returns</link> on eligible items.","upe.labels.purchase_protection.linkOptInDescription.v2.product":"Pay faster and get <link>free damage protection</link> on eligible items.","upe.labels.purchase_protection.price.modal.cta":"price drop protection","upe.labels.purchase_protection.price.linkAutofillPromptPurchaseProtectionMessage":"Use debit to get price drop protection","upe.labels.purchase_protection.price.linkAutofillPromptPurchaseProtectionMessage.v2":"Use debit to get <b>price drop protection</b>","upe.labels.purchase_protection.treatment_1.price.linkAutofillPromptMessageSaved":"Get price drop protection from Link","upe.labels.purchase_protection.treatment_1.price.linkAutofillPromptMessageSaved.v2":"Get free price drop protection from Link","upe.labels.purchase_protection.treatment_2.price.linkAutofillPromptMessageSaved":"Use debit to get price drop protection","upe.labels.linkOptIn":"Save your info for secure 1-click checkout","upe.labels.linkOptInSubText":"Pay faster at {businessName} and thousands of businesses.","upe.labels.linkOptInSubTextMentioningLink":"Pay faster at {businessName} and everywhere Link is accepted.","upe.labels.linkOptInWithBrand":"Save your info for secure 1-click checkout with Link","upe.labels.mb_way.phone":"Phone number","upe.labels.mobilePhoneNumber":"Mobile number","upe.labels.mobilePhoneNumber.optional":"Mobile number (optional)","upe.labels.more":"More","upe.labels.name":"Name","upe.labels.nameOnCard":"Name on card","upe.labels.nz_bank_account.account_holder_name":"Name on your bank account","upe.labels.nz_bank_account.account_number":"Account number","upe.labels.nz_bank_account.bank_code":"Bank","upe.labels.nz_bank_account.bank_name":"Name of your bank","upe.labels.nz_bank_account.branch_code":"Branch","upe.labels.nz_bank_account.mandate":"Mandate","upe.labels.nz_bank_account.name":"Account signatory name","upe.labels.nz_bank_account.suffix":"Suffix","upe.labels.paymentMethods":"Payment Methods","upe.labels.rechnung.birthdate":"Birthdate","upe.labels.rechnung.phone":"Phone number (optional)","upe.labels.savePayment":"Save payment details for future purchases","upe.labels.savePaymentTo":"Save payment details to {businessName} for future purchases","upe.labels.sepa_debit.iban":"IBAN","upe.labels.setAsDefaultSavedPayment":"Set as default payment method","upe.labels.shippingAsBilling":"Billing is same as shipping information","upe.labels.billingAsShipping":"Shipping is same as billing information","upe.labels.upi.vpa":"VPA (Virtual payment address)","upe.labels.payto.accountNumber":"Account number","upe.labels.payto.bsbNumber":"BSB","upe.labels.payto.payId":"PayID","upe.labels.payto.switchToPayId":"Use PayID instead","upe.labels.payto.switchToBankAccount":"Use BSB and account number instead","upe.labels.pix.taxId":"CPF/CNPJ","upe.labels.progressiveCursor.screenReaderDescription":"While entering card information, you\'ll be automatically advanced to the next form field when the current field is complete.","upe.labels.us_bank_account.account_holder_type":"Account holder type","upe.labels.us_bank_account.account_holder_type.business":"Business","upe.labels.us_bank_account.account_holder_type.personal":"Personal","upe.labels.us_bank_account.account_number":"Account number","upe.labels.us_bank_account.account_type":"Account type","upe.labels.us_bank_account.account_type.business":"Business","upe.labels.us_bank_account.account_type.checking":"Checking","upe.labels.us_bank_account.account_type.savings":"Savings","upe.labels.us_bank_account.account_type.personal":"Personal","upe.labels.us_bank_account.confirm_account_number":"Confirm account number","upe.labels.us_bank_account.routing_number":"Routing number","upe.mandates.amazon_pay":"By confirming your payment with AmazonPay, you allow {businessName} to charge your AmazonPay account for future payments in accordance with their terms.","upe.mandates.apple_pay":"By continuing, you allow {businessName} to charge your Apple Pay for this payment and future payments in accordance with their terms.","upe.mandates.au_becs_debit.anchor":"Direct Debit Request service agreement","upe.mandates.au_becs_debit.part1":"By providing your bank account details and confirming this payment, you agree to this Direct Debit Request and the","upe.mandates.au_becs_debit.part2":"and authorise Stripe Payments Australia Pty Ltd ACN 160 180 343 Direct Debit User ID number 507156 (“Stripe”) to debit your account through the Bulk Electronic Clearing System (BECS) on behalf of {businessName} (the \\"Merchant\\") for any amounts separately communicated to you by the Merchant. You certify that you are either an account holder or an authorised signatory on the account listed above.","upe.mandates.bacs_debit.merchant_sun":"I understand that {sudn} has partnered with Stripe to collect Direct Debits on behalf of {sudn}. I confirm that I am the account holder and only person required to authorise debits from this account.","upe.mandates.bacs_debit.stripe_sun":"I understand that Stripe will be collecting Direct Debits on behalf of {businessName} and confirm that I am the account holder and the only person required to authorise debits from this account.","upe.mandates.card":"By providing your card information, you allow {businessName} to charge your card for future payments in accordance with their terms.","upe.mandates.cardNoBusinessName":"By providing your card information, you allow this merchant to charge your card for future payments in accordance with their terms.","upe.mandates.cashapp":"By continuing, you authorize {businessName} to debit your Cash App account for this payment and future payments in accordance with {businessName}\'s terms, until this authorization is revoked. You can change this anytime in your Cash App Settings.","upe.mandates.demo_pay":"By confirming your payment with DemoPay, you allow {businessName} to charge your DemoPay account for future payments in accordance with their terms.","upe.mandates.google_pay":"By continuing, you allow {businessName} to charge your Google Pay for this payment and future payments in accordance with their terms.","upe.mandates.klarna":"By continuing to Klarna, you allow {businessName} to charge your Klarna account for future payments in accordance with their terms and Klarna\'s terms. You can change this at any time in your Klarna app or by reaching out to {businessName}.","upe.mandates.linkBank":"By confirming this payment, you authorize {businessName} to debit the bank account specified for any amount owed for charges arising from your use of {businessName} services and/or purchase of products from {businessName}, pursuant to {businessName}\'s website and terms, until this authorization is revoked. You may amend or cancel this authorization at any time by providing notice to the merchant with 30 (thirty) days notice.","upe.mandates.linkBankSetupFutureUsage":"By confirming this payment, you authorize {businessName} to debit the bank account specified for any amount owed for charges arising from your use of {businessName} services and/or purchase of products from {businessName}, pursuant to {businessName}\'s website and terms, until this authorization is revoked. If you use {businessName}\'s services or purchase more than one of {businessName}\'s products periodically pursuant to {businessName}\'s terms, you authorize {businessName} to debit your bank account periodically. Payments that fall outside of the periodic debits authorized above will only be debited after your authorization is obtained. You may amend or cancel this authorization at any time by providing notice to the merchant with 30 (thirty) days notice.","upe.mandates.linkBankSetupFutureUsage_v2":"By saving your bank account for {businessName} you agree to authorize payments pursuant to","upe.mandates.linkBankSetupFutureUsage_v2_combined":"By saving your bank account for {businessName} you agree to authorize payments pursuant to {linkTerms}.","upe.mandates.linkBank_terms":"these terms","upe.mandates.linkBank_v2":"By submitting your order to {businessName} you agree to authorize payments pursuant to","upe.mandates.linkBank_v2_combined":"By submitting your order to {businessName} you agree to authorize payments pursuant to {linkTerms}.","upe.mandates.kr_card":"By confirming your payment with NICEPAY, you allow {businessName} to charge this payment method for future payments in accordance with their terms.","upe.mandates.kakao_pay":"By confirming your payment with NICEPAY, you allow {businessName} to charge this payment method for future payments in accordance with their terms.","upe.mandates.naver_pay":"By confirming your payment with NICEPAY, you allow {businessName} to charge this payment method for future payments in accordance with their terms.","upe.mandates.kr_market":"By confirming your payment with NICEPAY, you allow {businessName} to charge this payment method for future payments in accordance with their terms.","upe.mandates.ng_card":"By confirming your payment with Global Stack Services Limited, you allow {businessName} to charge this payment method for future payments in accordance with their terms.","upe.mandates.ng_market":"By confirming your payment with Global Stack Services Limited, you allow {businessName} to charge this payment method for future payments in accordance with their terms.","upe.mandates.nz_bank_account.anchor":"Direct Debit Terms & Conditions","upe.mandates.nz_bank_account.bullet1":"Your bank\'s terms and conditions that relate to your account","upe.mandates.nz_bank_account.bullet2":"The","upe.mandates.nz_bank_account.bullet2Anchor":"Direct Debit Service Terms & Conditions","upe.mandates.nz_bank_account.part1":"By providing your bank account details and confirming this payment, you authorise {businessName} (”Merchant”), DDA authorisation code {directDebitAuthorityNumber}, to debit your account with the amounts of direct debits from Merchant in accordance with this authority.","upe.mandates.nz_bank_account.part2":"You agree that this authority is subject to:","upe.mandates.nz_bank_account.part3":"You certify that you are either the sole account holder on the bank account listed above or that you are an authorised signatory on, and have authority to operate, this bank account severally. We will send you an email confirmation of this Direct Debit Request.","upe.mandates.nz_bank_account.part4":"We will send you an email confirmation no later than 5 business days after your confirmation of this Direct Debit Authority.","upe.mandates.paypal":"By confirming your payment with PayPal, you allow {businessName} to charge your PayPal account for future payments in accordance with their terms.","upe.mandates.revolut_pay":"By confirming your payment with RevolutPay, you allow {businessName} to charge your RevolutPay account for future payments in accordance with their terms.","upe.mandates.sepa":"By providing your payment information and confirming this payment, you authorise (A) {businessName} and Stripe, our payment service provider and/or PPRO, its local service provider, to send instructions to your bank to debit your account and (B) your bank to debit your account in accordance with those instructions. As part of your rights, you are entitled to a refund from your bank under the terms and conditions of your agreement with your bank. A refund must be claimed within 8 weeks starting from the date on which your account was debited. Your rights are explained in a statement that you can obtain from your bank. You agree to receive notifications for future debits up to 2 days before they occur.","upe.mandates.sepa.citi":"By providing your payment information and confirming this payment, you authorise (A) {businessName} and Stripe, our payment service provider, to send instructions to your bank to debit your account and (B) your bank to debit your account in accordance with those instructions. As part of your rights, you are entitled to a refund from your bank under the terms and conditions of your agreement with your bank. A refund must be claimed within 8 weeks starting from the date on which your account was debited. Your rights are explained in a statement that you can obtain from your bank. You agree to receive notifications for future debits up to 2 days before they occur.","upe.mandates.us_bank_account":"By clicking Pay, you authorize {businessName} to debit the bank account specified above for any amount owed for charges arising from your use of {businessName}\'s services and/or purchase of products from {businessName}, pursuant to {businessName}’s website and terms, until this authorization is revoked.","upe.mandates.us_bank_account.mandate_terms_link":"these terms","upe.mandates.us_bank_account.microdeposits":"You will see a $0.01 deposit in your account in 1-2 business days. Then you\'ll get an email with instructions to complete payment to {businessName}.","upe.mandates.us_bank_account.setupFutureUsage":"If you use {businessName}\'s services or purchase more than one of {businessName}\'s products periodically pursuant to {businessName}\'s terms, you authorize {businessName} to debit your bank account periodically. Payments that fall outside of the periodic debits authorized above will only be debited after your authorization is obtained. You may amend or cancel this authorization at any time by providing notice to the merchant with 30 (thirty) days notice.","upe.mandates.us_bank_account.setupFutureUsageV2":"By saving your bank account for {businessName} you agree to authorize payments pursuant to","upe.mandates.us_bank_account.setupFutureUsageV2_combined":"By saving your bank account for {businessName} you agree to authorize payments pursuant to {terms}.","upe.mandates.us_bank_accountV2":"By submitting your order to {businessName} you agree to authorize payments pursuant to","upe.mandates.us_bank_accountV2_combined":"By submitting your order to {businessName} you agree to authorize payments pursuant to {terms}.","upe.mandates.swish":"Stripe Technology Europe Limited (“Stripe”) has acquired the claim for payment. Therefore your payment will be made to Stripe.","upe.methods.acss_debit":"Pre-authorized Debit","upe.methods.affirm":"Affirm","upe.methods.afterpay":"Afterpay","upe.methods.alipay":"Alipay","upe.methods.alma":"Alma","upe.methods.amazon_pay":"Amazon Pay","upe.methods.sunbit":"Sunbit","upe.methods.billie":"Billie","upe.methods.satispay":"Satispay","upe.methods.apple_pay":"Apple Pay","upe.methods.au_becs_debit":"AU Direct Debit","upe.methods.bacs_debit":"Bacs Direct Debit","upe.methods.bancontact":"Bancontact","upe.methods.blik":"BLIK","upe.methods.boleto":"Boleto","upe.methods.card":"Card","upe.methods.cashapp":"Cash App Pay","upe.methods.capchase_pay":"Capchase Pay","upe.methods.clearpay":"Clearpay","upe.methods.crypto":"Crypto","upe.methods.qris":"QRIS","upe.methods.gopay":"GoPay","upe.methods.shopeepay":"ShopeePay","upe.methods.customer_balance":"Bank transfer","upe.methods.demo_pay":"Demo Pay","upe.methods.eps":"EPS","upe.methods.external_amazon_pay":"Amazon Pay","upe.methods.external_aplazame":"Aplazame","upe.methods.external_aplazo":"Aplazo","upe.methods.external_atome":"Atome","upe.methods.external_atone":"Atone","upe.methods.external_au_easy_payment":"au Easy Payment","upe.methods.external_au_pay":"au PAY","upe.methods.external_azupay":"Azupay","upe.methods.external_bank_pay":"Bank Pay","upe.methods.external_benefit":"Benefit","upe.methods.external_bitcash":"BitCash","upe.methods.external_bizum":"Bizum","upe.methods.external_bluecode":"Bluecode","upe.methods.external_catch":"Catch","upe.methods.external_coinbase_pay":"Coinbase Pay","upe.methods.external_dapp":"Dapp","upe.methods.external_dbarai":"D-Barai","upe.methods.external_divido":"Divido","upe.methods.external_famipay":"FamiPay","upe.methods.external_fawry":"Fawry","upe.methods.external_fonix":"Fonix","upe.methods.external_gcash":"GCash","upe.methods.external_gopay":"GoPay","upe.methods.external_grabpay_later":"Grab PayLater","upe.methods.external_hands_in":"Hands In","upe.methods.external_hip_ach_credit_transfer":"Bank Transfer","upe.methods.external_hip_paper_check":"Paper Check","upe.methods.external_hip_sepa_credit_transfer":"Bank Transfer","upe.methods.external_interac":"Interac","upe.methods.external_iwocapay":"iwocaPay","upe.methods.external_kbc":"KBC","upe.methods.external_knet":"KNET","upe.methods.external_laybuy":"Laybuy","upe.methods.external_line_pay":"LINE Pay","upe.methods.external_mercado_pago":"Mercado Pago","upe.methods.external_merpay":"Merpay","upe.methods.external_momo":"MoMo","upe.methods.external_mybank":"MyBank","upe.methods.external_net_cash":"NET CASH","upe.methods.external_nexi_pay":"Nexi","upe.methods.external_octopus":"Octopus","upe.methods.external_oney":"Oney","upe.methods.external_paidy":"Paidy","upe.methods.external_pay_easy":"Pay-easy","upe.methods.external_paybright":"PayBright","upe.methods.external_payconiq":"Payconiq","upe.methods.external_paydirekt":"Paydirekt","upe.methods.external_payit":"PayIt","upe.methods.external_paypal":"PayPal","upe.methods.external_paypay":"PayPay","upe.methods.external_paypo":"PayPo","upe.methods.external_payrexx":"Payrexx","upe.methods.external_paysafecard":"PaySafeCard","upe.methods.external_paytm":"Paytm","upe.methods.external_payu":"PayU","upe.methods.external_picpay":"PicPay","upe.methods.external_planpay":"PlanPay","upe.methods.external_poli":"POLi","upe.methods.external_postepay":"PostePay","upe.methods.external_postfinance":"PostFinance","upe.methods.external_rabbit_line_pay":"Rabbit LINE Pay","upe.methods.external_rakuten_pay":"Rakuten Pay","upe.methods.external_samsung_pay":"Samsung Pay","upe.methods.external_scalapay":"Scalapay","upe.methods.external_sezzle":"Sezzle","upe.methods.external_shopback_pay":"ShopBack Pay","upe.methods.external_skrill":"Skrill","upe.methods.external_sofinco":"Sofinco","upe.methods.external_softbank_carrier_payment":"SoftBank Carrier Payments","upe.methods.external_swish":"Swish","upe.methods.external_tabby":"Tabby","upe.methods.external_tng":"Touch \'n Go","upe.methods.external_tng_ewallet":"Touch \'n Go","upe.methods.external_toss_pay":"Toss Pay","upe.methods.external_truelayer":"Truelayer","upe.methods.external_trustly":"Trustly","upe.methods.external_twint":"TWINT","upe.methods.external_venmo":"Venmo","upe.methods.external_vipps":"Vipps","upe.methods.external_walley":"Walley","upe.methods.external_webmoney":"WebMoney","upe.methods.external_younited_pay":"Younited Pay","upe.methods.fpx":"FPX","upe.methods.giropay":"giropay","upe.methods.google_pay":"Google Pay","upe.methods.grabpay":"GrabPay","upe.methods.id_bank_transfer":"Bank transfer","upe.methods.ideal":"iDEAL","upe.methods.klarna":"Klarna","upe.methods.kriya":"Kriya","upe.methods.konbini":"Konbini","upe.methods.link":"Bank","upe.methods.mb_way":"MB WAY","upe.methods.mobilepay":"MobilePay","upe.methods.mondu":"Mondu","upe.methods.multibanco":"Multibanco","upe.methods.ng_bank":"Naira wallet","upe.methods.ng_bank_transfer":"Naira bank transfer","upe.methods.ng_card":"Naira card","upe.methods.ng_market":"Nigerian payment methods","upe.methods.ng_ussd":"Naira USSD","upe.methods.nz_bank_account":"NZ Direct Debit","upe.methods.oxxo":"OXXO","upe.methods.p24":"Przelewy24","upe.methods.pay_by_bank":"Pay By Bank","upe.methods.paynow":"PayNow","upe.methods.paypal":"PayPal","upe.methods.payto":"PayTo","upe.methods.pix":"Pix","upe.methods.promptpay":"PromptPay","upe.methods.rechnung":"Invoice","upe.methods.revolut_pay":"Revolut Pay","upe.methods.samsung_pay":"Samsung Pay","upe.methods.saved":"Saved","upe.methods.sepa":"SEPA Debit","upe.methods.sequra":"Sequra","upe.methods.sofort":"Sofort","upe.methods.south_korea_market":"Korean payment methods","upe.methods.naver_pay":"Naver Pay","upe.methods.kakao_pay":"Kakao Pay","upe.methods.payco":"PAYCO","upe.methods.kr_card":"Local card","upe.methods.kr_market":"Korean payment methods","upe.methods.swish":"Swish","upe.methods.twint":"TWINT","upe.methods.upi":"UPI","upe.methods.us_bank_account":"Bank","upe.methods.us_bank_account_v2":"US bank account","upe.methods.wechat_pay":"WeChat Pay","upe.methods.zip":"Zip","upe.mobilepay.text_v2":"MobilePay selected.","upe.modalRedirectMessage":"Another step will appear after submitting your order to complete your purchase details.","upe.modalRedirectMessage_v2":"Another step will appear to securely submit your payment information.","upe.multibanco.text":"Multibanco selected for check out.","upe.multibanco.text_v2":"Multibanco selected.","upe.ng_bank.text_v2":"Complete checkout to pay with Naira wallet.","upe.ng_bank_transfer.text_v2":"Complete checkout to pay with Naira bank transfer.","upe.ng_card.text_v2":"Complete checkout to pay with Naira card.","upe.ng_market.text_v2":"Complete checkout to pay with local Nigerian cards, bank transfers, or mobile money.","upe.ng_ussd.text_v2":"Complete checkout to pay with Naira USSD.","upe.oxxo.text":"OXXO selected for check out.","upe.oxxo.text_v2":"OXXO selected.","upe.p24.text_v2":"Przelewy24 selected.","upe.pay_by_bank.text":"Pay By Bank selected for check out.","upe.pay_by_bank.text_v2":"Pay By Bank selected.","upe.paynow.text":"PayNow selected for check out.","upe.paynow.text_v2":"PayNow selected.","upe.paypal.text":"PayPal selected for check out.","upe.paypal.text_v2":"PayPal selected.","upe.placeholders.address.line1":"Street address","upe.placeholders.address.line2":"Apt., suite, unit number, etc. (optional)","upe.placeholders.au_becs_debit.accountNumber":"Account number","upe.placeholders.au_becs_debit.bsb":"BSB","upe.placeholders.au_becs_debit.email":"john.smith@example.com","upe.placeholders.au_becs_debit.name":"John Smith","upe.placeholders.bacs_debit.account_number":"00012345","upe.placeholders.bacs_debit.sort_code":"10-88-00","upe.placeholders.cardNumber":"1234 1234 1234 1234","upe.placeholders.email":"Email","upe.placeholders.email.v2":"you@example.com","upe.placeholders.example_email":"john.smith@example.com","upe.placeholders.example_name":"John Smith","upe.placeholders.fullName":"First and last name","upe.placeholders.mb_way.phone":"+351 201 555 012","upe.placeholders.nz_bank_account.account_holder_name":"Your name or company name","upe.placeholders.nz_bank_account.account_number":"11-2222-3333333-444","upe.placeholders.nz_bank_account.bank_code":"00","upe.placeholders.nz_bank_account.bank_name":"Your bank","upe.placeholders.nz_bank_account.branch_code":"0000","upe.placeholders.nz_bank_account.email":"you@example.com","upe.placeholders.nz_bank_account.name":"Your name","upe.placeholders.nz_bank_account.suffix":"000","upe.placeholders.payment_detail_nickname":"Nickname (optional)","upe.placeholders.rechnung.birthdate":"dd / mm / yyyy","upe.placeholders.rechnung.phone":"+49123456789","upe.placeholders.searchBank":"Search for your bank","upe.placeholders.select":"Select","upe.placeholders.sepa_debit.iban":"DE00 0000 0000 0000 0000 00","upe.placeholders.upi.vpa":"username@okicici","upe.placeholders.payto.name":"John Smith","upe.placeholders.payto.email":"john.smith@example.com","upe.placeholders.payto.payId":"+61 2 1234 5678","upe.placeholders.payto.accountNumber":"000123456","upe.placeholders.payto.bsbNumber":"000-000","upe.placeholders.us_bank_account.account_number":"000123456789","upe.placeholders.us_bank_account.routing_number":"123456789","upe.promptpay.text":"PromptPay is supported by bank apps and payment apps such as KBank, SCB, Bangkok Bank, Krunthai Bank and Krungsri.","upe.qr_code_scan_text.cashapp":"After submitting your order, scan the QR code using Cash App.","upe.qr_code_scan_text.paynow":"After submitting your order, scan the QR code using your preferred banking or payment app.","upe.qr_code_scan_text.promptpay":"After submitting your order, scan the QR code using your mobile banking app.","upe.qr_code_scan_text.swish":"You\'ll be asked to scan a QR code with your Swish app and verify your identity with BankID.","upe.qr_code_scan_text.wechat_pay":"After submitting your order, scan the QR code using WeChat Pay.","upe.rechnung.instructions":"The invoice amount is due 14 days after the shipping confirmation email is sent.","upe.rechnung.legal_text":"By choosing to pay on invoice, you agree to the <paymentTermsLink>supplementary terms of payment</paymentTermsLink> and the undertaking of risk assessment. You also agree that your information (such as address, name and date of birth) will be shared in accordance with the <dataProtectionLink>supplementary data protection information</dataProtectionLink>.","upe.redirectMessage":"After submitting your order, you will be redirected to securely complete your purchase.","upe.redirectMessage_v2":"After submission, you will be redirected to securely complete next steps.","upe.redirectMessage.kr_card":"After submission, you will be redirected to NICEPAY to select your card issuer and securely complete next steps. NICEPAY will process this transaction in accordance with NICEPAY\'s {terms_link}.","upe.redirectMessage.kr_card.link_text":"terms of use","upe.redirectMessage.kakao_pay":"After submission, you will be redirected to Kakao Pay to securely complete next steps. This transaction will be processed via NICEPAY in accordance with NICEPAY’s {terms_link}.","upe.redirectMessage.kakao_pay.link_text":"terms of use","upe.redirectMessage.naver_pay":"After submission, you will be redirected to Naver Pay to securely complete next steps. This transaction will be processed via NICEPAY in accordance with NICEPAY’s {terms_link}.","upe.redirectMessage.naver_pay.link_text":"terms of use","upe.redirectMessage.nigeria_paystack":"By confirming your payment, you agree that your transaction will be handled by Global Stack Services Limited as merchant of record and in accordance with their {terms_link}.","upe.redirectMessage.nigeria_paystack.link_text":"terms of use","upe.redirectMessage.payco":"After submission, you will be redirected to PAYCO to securely complete next steps. This transaction will be processed via NICEPAY in accordance with NICEPAY’s {terms_link}.","upe.redirectMessage.payco.link_text":"terms of use","upe.redirectMessage.samsung_pay":"After submission, you will be redirected to Samsung Pay to securely complete next steps. This transaction will be processed via NICEPAY in accordance with NICEPAY’s {terms_link}.","upe.redirectMessage.samsung_pay.link_text":"terms of use","upe.revolut_pay.text":"Revolut Pay selected for check out.","upe.revolut_pay.text_v2":"Revolut Pay selected.","upe.qris.text_v2":"Complete checkout to pay with QRIS.","upe.shopeepay.text_v2":"Complete checkout to pay with ShopeePay.","upe.gopay.text_v2":"Complete checkout to pay with GoPay.","upe.saveInformation":"Save information to pay faster next time.","upe.saved.cvc_recollect":"For security, please re-enter your card’s security code.","upe.saved.errors.confirm":"Your card has been declined. Please update this card or use a different card.","upe.saved.errors.update_payment_details_failed":"Unable to update payment details. Please try another payment method.","upe.saved.expired":"Expired","upe.saved.information_needed":"Information needed","upe.saved.or":"Or","upe.sepa_debit.microdeposits.bank_table.header":"••••{last4} Bank statement","upe.sepa_debit.microdeposits.bank_table.transaction":"Transaction","upe.sepa_debit.microdeposits.bank_table.amount":"Amount","upe.sepa_debit.microdeposits.bank_table.type":"Type","upe.sepa_debit.microdeposits.bank_table.date":"Date","upe.sepa_debit.microdeposits.bank_table.descriptor.groceries":"Groceries","upe.sepa_debit.microdeposits.body":"Your bank account {last4} receives a €0.01 transfer within 1-2 business days of the request. You then receive an email with instructions to verify that you have access to this bank account. Your payment processes after you confirm this step.","upe.sepa_debit.microdeposits.button.confirm":"Confirm","upe.sepa_debit.microdeposits.header":"Microdeposits Bank Account Verification","upe.south_korea_market.selector_label":"Korean cards, wallets and banks","upe.south_korea_market.terms.link_text":"NICEPAY\'s Terms & Conditions","upe.south_korea_market.terms.text":"By confirming your payment with a selected payment method, the payment will be processed via NICEPAY in accordance with {terms_link}.","upe.south_korea_market.text_v2":"Complete checkout with NICEPAY to pay with popular wallets and local cards such as Naver Pay, Kakao Pay, Samsung Pay, Shinhan Card, Samsung Card, Hyundai Card, Kookmin Card, Lotte Card, Woori Card, Hana Card and many more.","upe.swish.text_v2":"Make payments using Swish and BankID.","upe.kr_market.selector_label":"Korean cards, wallets and banks","upe.kr_market.terms.link_text":"NICEPAY\'s Terms & Conditions","upe.kr_market.terms.text":"By confirming your payment with a selected payment method, the payment will be processed via NICEPAY in accordance with {terms_link}.","upe.kr_market.text_v2":"Complete checkout with NICEPAY to pay with local cards such as Shinhan Card, Samsung Card, Hyundai Card, Kookmin Card, Lotte Card, Woori Card, Hana Card and many more.","upe.tagline.affirm":"Buy now pay later","upe.tagline.afterpay":"Buy now pay later","upe.tagline.clearpay":"Buy now pay later","upe.tagline.klarna":"Pay with Klarna","upe.tagline.zip":"Buy now pay later","upe.us_bank_account.cant_find_your_bank":"Can\'t find your bank? Check your spelling and try again, or ","upe.us_bank_account.cant_find_your_bank_no_microdeposits":"Can\'t find your bank? Check your spelling and try again.","upe.us_bank_account.enter_bank_manual":"Enter bank details manually instead","upe.us_bank_account.enter_account_number_manually":"Enter your account number manually","upe.us_bank_account.enter_bank_manual_lowercase":"enter bank details manually instead.","upe.us_bank_account.issue_try_again":"There was an issue. Please try again.","upe.us_bank_account.manual_business_days":" (takes 1-2 business days)","upe.us_bank_account.manually_verify":"manually verify your bank account.","upe.us_bank_account.no_banks_found":"No banks found. Check your spelling and try again, or ","upe.us_bank_account.manually_verify_subtitle_link":"manually enter details","upe.us_bank_account.no_banks_found_subtitle":"Try searching another bank or {textWithLink}.","upe.us_bank_account.no_banks_found_no_microdeposits":"No banks found. Check your spelling and try again.","upe.us_bank_account.no_banks_found_no_microdeposits_subtitle":"Try searching another bank","upe.us_bank_account.no_banks_found_heading":"No results","upe.us_bank_account.search_failed.heading":"Search is currently unavailable","upe.us_bank_account.search_failed.subtitle":"Please try again later","upe.us_bank_account.search_failed.subtitle_with_manual_entry":"Please try again later or {textWithLink}","upe.us_bank_account.searching_banks":"Searching banks","upe.useNew":"New payment method","upe.wechat_pay.text":"WeChat Pay selected for check out.","upe.zip.text":"Zip selected for check out.","upe.zip.text_v2":"Zip selected.","upe.twint.text":"TWINT selected.","upe.twint.text_v2":"TWINT selected."}')
        },
        83666: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"إغلاق مربع الحوار","button.apple_pay.add_money":"إضافة نقود باستخدام Apple Pay","button.apple_pay.book":"احجز باستخدام Apple Pay","button.apple_pay.buy":"الشراء باستخدام Apple Pay","button.apple_pay.check_out":"تسديد الحساب باستخدام Apple Pay","button.apple_pay.contribute":"تقديم المساهمات باستخدام Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"التبرع باستخدام Apple Pay","button.apple_pay.order":"الطلب باستخدام Apple Pay","button.apple_pay.reload":"إعادة الشحن باستخدام Apple Pay","button.apple_pay.rent":"الاستئجار باستخدام Apple Pay","button.apple_pay.subscribe":"الاشتراك باستخدام Apple Pay","button.apple_pay.support":"تقديم المساعدة باستخدام Apple Pay","button.apple_pay.tip":"دفع إكرامية باستخدام Apple Pay","button.apple_pay.top_up":"إضافة مبلغ باستخدام Apple Pay","button.cancel":"إلغاء","button.change":"تغيير","button.google_pay.buy":"الشراء باستخدام Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"التبرع باستخدام Google Pay","button.link.autofill":"Autofill","button.link.autofill_alt":"استخدم","button.link.autofill_aria_label":"أدخل البيانات تلقائيًا باستخدام Link","button.link.card_clear":"توقف عن استخدام Link وأدخل تفاصيل البطاقة بنفسك.","button.link.express_pay":"دفع سريع","button.link.manage":"يتم الدفع حاليًا عبر Link باستخدام البطاقة المنتهية بالأرقام {last4}. اختر وسيلة دفع أخرى","button.link.manage.cardCvc":"يتم حاليًا استخدام حساب Link. قم بتحديث رمز CVC الخاص بالبطاقة.","button.link.manage.cardExpiry":"يتم حاليًا استخدام حساب Link بتاريخ انتهاء {expiry}. قم بتحديث تاريخ الانتهاء الخاص بالبطاقة.","button.link.manage.postalCode":"يتم حاليًا استخدام حساب Link بالرمز البريدي {postal}. قم بتحديث الرمز البريدي الخاص بالبطاقة.","button.link.pay_faster":"دفع بطريقة أسرع","button.link.pay_faster_with":"ادفع أسرع مع {linkLogo}","button.link.pay_faster_with_link":"ادفع بصورة أسرع باستخدام Link","button.link.pay_with":"ادفع باستخدام{linkLogo}","button.link.pay_with_last_4":"دفع بـ••{last4}","button.link.save_with":"الحفظ باستخدام {linkLogo}","button.link.save_with_aria_label":"الحفظ باستخدام Link","button.link.use_last_4_aria_label":"أدخل بيانات بطاقتك تلقائيًا مع Link عند استخدام البطاقة المنتهية بالأرقام {last4}","button.logout":"تسجيل الخروج","button.pay_with":"ادفع باستخدام","button.payment_request.book":"احجز الآن","button.payment_request.buy":"الشراء الآن","button.payment_request.default":"السداد الآن","button.payment_request.donate":"تبرع","button.remove":"إزالة","button.retry":"أعد المحاولة","button.save":"حفظ","button.save_with":"حفظ في","button.see_more":"تعرف على المزيد","button.update":"تحديث","placeholders.accountHolderType":"نوع صاحب الحساب","placeholders.auBankAccountNumber":"رقم الحساب","placeholders.cardNumber":"رقم البطاقة","placeholders.cardNumberShort":"الرقم","placeholders.company":"حساب تجاري","placeholders.cvc":"CVC","placeholders.expiry":"سنة / شهر","placeholders.individual":"حساب شخصي","placeholders.postal_code":"الرمز البريدي","placeholders.postcode":"الرمز البريدي","placeholders.securityCode":"رمز الأمان","placeholders.selectBank":"تحديد البنك","placeholders.zip":"رقم المنطقة البريدي","button.prb_warning.badge_label":"الترقية متوفرة","button.prb_warning.button_primary":"الترقية الآن","button.prb_warning.button_secondary":"تجاهل لمدة أسبوع","button.prb_warning.description":"لقد لاحظنا أنك تستخدم زر \\"طلب الدفع\\". قم بالترقية إلى {ece_link} للوصول إلى أحدث المزايا والتحسينات.","button.prb_warning.ece_link":"عنصر الدفع السريع","button.prb_warning.li1":"عرض طرق دفع متعددة في وقت واحد، بما في ذلك: Amazon Pay وLink وPayPal (في الاتحاد الأوروبي فقط).","button.prb_warning.li2":"الدعم عبر المتصفحات لكل من Google Pay وApple Pay على نظام (iOS 18+).","button.prb_warning.li3":"قم بفرز خيارات الدفع السريع الأكثر ملاءمة وعرضها بشكل ديناميكي لعملائك.","button.prb_warning.nav_header":"وضع الاختبار","button.prb_warning.title":"قم بترقية أزرار الدفع بنقرة واحدة القديمة"}')
        },
        9373: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Затваряне на диалогов прозорец","button.apple_pay.add_money":"Внесете пари с Apple Pay","button.apple_pay.book":"Резервирайте с Apple Pay","button.apple_pay.buy":"Купете с Apple Pay","button.apple_pay.check_out":"Финализирайте плащане с Apple Pay","button.apple_pay.contribute":"Дайте своя дял с Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Дарете с Apple Pay","button.apple_pay.order":"Поръчайте с Apple Pay","button.apple_pay.reload":"Презаредете с Apple Pay","button.apple_pay.rent":"Наемете с Apple Pay","button.apple_pay.subscribe":"Абонирайте се с Apple Pay","button.apple_pay.support":"Подкрепете с Apple Pay","button.apple_pay.tip":"Бакшиш с Apple Pay","button.apple_pay.top_up":"Захранване с Apple Pay","button.cancel":"Отмяна","button.change":"Промяна","button.google_pay.buy":"Купете с Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Дарете с Google Pay","button.link.autofill":"Използване","button.link.autofill_alt":"Използване","button.link.autofill_aria_label":"Автоматично попълване с Link","button.link.card_clear":"Спрете да използвате Link и въведете данните на картата ръчно.","button.link.express_pay":"Ескпрес плащане","button.link.manage":"В момента плащате с Link, като използвате картата, завършваща на {last4}. Изберете друг метод на плащане","button.link.manage.cardCvc":"В момента използвате Link. Актуализирайте CVC кода на картата.","button.link.manage.cardExpiry":"В момента използвате Link със срок на валидност до {expiry}. Актуализирайте срока на валидност на картата.","button.link.manage.postalCode":"В момента използвате Link с пощенски код {postal}. Актуализирайте пощенския код на картата.","button.link.pay_faster":"Плати по-бързо","button.link.pay_faster_with":"Плати по-бързо с {linkLogo}","button.link.pay_faster_with_link":"Плащайте по-бързо с Link","button.link.pay_with":"Плати с {linkLogo}","button.link.pay_with_last_4":"Плати с••{last4}","button.link.save_with":"Запазване с {linkLogo}","button.link.save_with_aria_label":"Запазване с Link","button.link.use_last_4_aria_label":"Автоматично попълване чрез Link с карта, завършваща на {last4}","button.logout":"Излизане","button.pay_with":"Плащане с/със","button.payment_request.book":"Резервирайте сега","button.payment_request.buy":"Купете сега","button.payment_request.default":"Платете сега","button.payment_request.donate":"Дарете","button.remove":"Премахване","button.retry":"Опитайте отново","button.save":"Запазване","button.save_with":"Запазване с","button.see_more":"Вижте повече","button.update":"Актуализиране","placeholders.accountHolderType":"Тип на титуляря на сметката","placeholders.auBankAccountNumber":"Номер на сметката","placeholders.cardNumber":"Номер на картата","placeholders.cardNumberShort":"Номер","placeholders.company":"Фирма","placeholders.cvc":"CVC код","placeholders.expiry":"ММ / ГГ","placeholders.individual":"Лична","placeholders.postal_code":"Пощенски код","placeholders.postcode":"Пощенски код","placeholders.securityCode":"Код за сигурност","placeholders.selectBank":"Изберете банка","placeholders.zip":"ZIP код","button.prb_warning.badge_label":"Налична надстройка","button.prb_warning.button_primary":"Надстройте сега","button.prb_warning.button_secondary":"Отхвърляне за една седмица","button.prb_warning.description":"Забелязахме, че използвате бутона за заявка за плащане. Надстройте до {ece_link} за достъп до най-новите функции и оптимизации.","button.prb_warning.ece_link":"Елемент за експресно финализиране на плащане","button.prb_warning.li1":"Показване на няколко начина на плащане едновременно, включително: Amazon Pay, Link и PayPal (само в ЕС).","button.prb_warning.li2":"Поддръжка на Google Pay и Apple Pay в различни браузъри (iOS 18+).","button.prb_warning.li3":"Сортирайте и показвайте динамично на клиентите си най-подходящите опции за експресно финализиране на плащане.","button.prb_warning.nav_header":"Тестов режим","button.prb_warning.title":"Актуализирайте вече остарелите си бутони за плащане с едно кликване"}')
        },
        90945: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Zavřít dialog","button.apple_pay.add_money":"Přidat peníze pomocí Apple Pay","button.apple_pay.book":"Rezervovat s Apple Pay","button.apple_pay.buy":"Koupit s Apple Pay","button.apple_pay.check_out":"Rezervovat pomocí Apple Pay","button.apple_pay.contribute":"Přispět pomocí Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Darovat s Apple Pay","button.apple_pay.order":"Objednat pomocí Apple Pay","button.apple_pay.reload":"Znovu načíst pomocí Apple Pay","button.apple_pay.rent":"Pronájem pomocí Apple Pay","button.apple_pay.subscribe":"Přispět pomocí Apple Pay","button.apple_pay.support":"Podpora pomocí Apple Pay","button.apple_pay.tip":"Spropitné pomocí Apple Pay","button.apple_pay.top_up":"Doplatit pomocí Apple Pay","button.cancel":"Zrušit","button.change":"Změnit","button.google_pay.buy":"Koupit s Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Darovat s Google Pay","button.link.autofill":"Použít","button.link.autofill_alt":"Použít","button.link.autofill_aria_label":"Automaticky vyplnit pomocí Link","button.link.card_clear":"Přestaňte používat Link a zadejte údaje o kartě ručně.","button.link.express_pay":"Expresní platba","button.link.manage":"V současné době platíte kartou s koncovkou {last4}. Zvolte jiný způsob platby","button.link.manage.cardCvc":"V současné době používáte Link. Aktualizujte kód CVC karty.","button.link.manage.cardExpiry":"V současné době používáte Link s datem vypršení platnosti {expiry}. Aktualizujte datum platnosti karty.","button.link.manage.postalCode":"V současné době používáte Link s poštovním směrovacím číslem {postal}. Aktualizujte poštovní směrovací číslo karty.","button.link.pay_faster":"Plaťte rychleji","button.link.pay_faster_with":"Plaťte rychle s {linkLogo}","button.link.pay_faster_with_link":"Plaťte rychleji se službou Link","button.link.pay_with":"Plaťte s {linkLogo}","button.link.pay_with_last_4":"Plaťte s ••{last4}","button.link.save_with":"Ušetřete s {linkLogo}","button.link.save_with_aria_label":"Uložit pomocí Link","button.link.use_last_4_aria_label":"Automatické vyplňování pomocí Link s kartou končící na {last4}","button.logout":"Odhlásit","button.pay_with":"Zaplatit pomocí","button.payment_request.book":"Rezervovat teď","button.payment_request.buy":"Koupit teď","button.payment_request.default":"Zaplatit teď","button.payment_request.donate":"Darovat","button.remove":"Odebrat","button.retry":"Zkusit znovu","button.save":"Uložit","button.save_with":"Ušetřete s","button.see_more":"Zobrazit více","button.update":"Aktualizovat","placeholders.accountHolderType":"Typ majitele účtu","placeholders.auBankAccountNumber":"Číslo účtu","placeholders.cardNumber":"Číslo karty","placeholders.cardNumberShort":"Číslo","placeholders.company":"Firemní","placeholders.cvc":"CVC","placeholders.expiry":"MM / RR","placeholders.individual":"Osobní","placeholders.postal_code":"Poštovní směrovací číslo","placeholders.postcode":"Poštovní směrovací číslo","placeholders.securityCode":"Bezpečnostní kód","placeholders.selectBank":"Vyberte banku","placeholders.zip":"PSČ","button.prb_warning.badge_label":"Možnost upgradu","button.prb_warning.button_primary":"Upgradujte nyní","button.prb_warning.button_secondary":"Propuštění na jeden týden","button.prb_warning.description":"Všimli jsme si, že používáte tlačítko žádosti o platbu. Upgradujte na {ece_link} pro přístup k nejnovějším funkcím a optimalizacím.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Zobrazení více platebních metod současně, včetně: Amazon Pay, Link a PayPal (pouze v EU).","button.prb_warning.li2":"Podpora Google Pay a Apple Pay napříč prohlížeči (iOS 18+).","button.prb_warning.li3":"Dynamické třídění a zobrazování nejrelevantnějších možností expresní objednávky zákazníkům.","button.prb_warning.nav_header":"Zkušební režim","button.prb_warning.title":"Upgrade starších platebních tlačítek jedním kliknutím"}')
        },
        82736: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Luk dialog","button.apple_pay.add_money":"Tilføj penge med Apple Pay","button.apple_pay.book":"Reservér med Apple Pay","button.apple_pay.buy":"Køb med Apple Pay","button.apple_pay.check_out":"Tjek ud med Apple Pay","button.apple_pay.contribute":"Bidrag med Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Donér med Apple Pay","button.apple_pay.order":"Bestil med Apple Pay","button.apple_pay.reload":"Genindlæs med Apple Pay","button.apple_pay.rent":"Lej med Apple Pay","button.apple_pay.subscribe":"Abonner med Apple Pay","button.apple_pay.support":"Støt med Apple Pay","button.apple_pay.tip":"Giv drikkepenge med Apple Pay","button.apple_pay.top_up":"Genopfyld med Apple Pay","button.cancel":"Annuller","button.change":"Skift","button.google_pay.buy":"Køb med Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Donér med Google Pay","button.link.autofill":"Autofyld","button.link.autofill_alt":"Brug","button.link.autofill_aria_label":"Udfyld automatisk med Link","button.link.card_clear":"Stop med at bruge Link, og indtast kortoplysninger manuelt.","button.link.express_pay":"Ekspresbetaling","button.link.manage":"Du bruger i øjeblikket Link med et kort, der slutter på {last4}. Vælg en anden betalingsmetode","button.link.manage.cardCvc":"Link bruges i øjeblikket. Opdater kortets CVC-kode.","button.link.manage.cardExpiry":"Link bruges i øjeblikket med udløbsdatoen {expiry}. Opdater kortets udløbsdato.","button.link.manage.postalCode":"Link bruges i øjeblikket med postnummeret {postal}. Opdater kortets postnummer.","button.link.pay_faster":"Betal hurtigere","button.link.pay_faster_with":"Betal let med {linkLogo}","button.link.pay_faster_with_link":"Betal hurtigere med Link","button.link.pay_with":"Betal med {linkLogo}","button.link.pay_with_last_4":"Betal med••{last4}","button.link.save_with":"Gem med {linkLogo}","button.link.save_with_aria_label":"Gem med Link","button.link.use_last_4_aria_label":"Udfyld automatisk med Link med et kort, der slutter på {last4}","button.logout":"Log ud","button.pay_with":"Betal med","button.payment_request.book":"Reservér nu","button.payment_request.buy":"Køb nu","button.payment_request.default":"Betal nu","button.payment_request.donate":"Donér","button.remove":"Fjern","button.retry":"Prøv igen","button.save":"Gem","button.save_with":"Gem med","button.see_more":"Se mere","button.update":"Opdater","placeholders.accountHolderType":"Kontoindehavertype","placeholders.auBankAccountNumber":"Kontonummer","placeholders.cardNumber":"Kortnummer","placeholders.cardNumberShort":"Kortnr.","placeholders.company":"Virksomhed","placeholders.cvc":"CVC","placeholders.expiry":"MM / ÅÅ","placeholders.individual":"Personlig","placeholders.postal_code":"Postnr.","placeholders.postcode":"Postnr.","placeholders.securityCode":"Sikkerhedskode","placeholders.selectBank":"Vælg bank","placeholders.zip":"Postnr.","button.prb_warning.badge_label":"Opgradering tilgængelig","button.prb_warning.button_primary":"Opgrader nu","button.prb_warning.button_secondary":"Afvis i en uge","button.prb_warning.description":"Vi har bemærket, at du bruger Payment Request-knappen. Opgrader til {ece_link} for at få adgang til de nyeste funktioner og optimeringer.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Vis flere betalingsmetoder samtidigt, herunder: Amazon Pay, Link og PayPal (kun i EU).","button.prb_warning.li2":"Understøttelse af Google Pay og Apple Pay på tværs af browsere (iOS 18+).","button.prb_warning.li3":"Sortér og vis de mest relevante ekspresbetalingsmuligheder dynamisk til dine kunder.","button.prb_warning.nav_header":"Testtilstand","button.prb_warning.title":"Opgrader dine gamle direkte betalingsknapper"}')
        },
        21969: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Dialogfeld schließen","button.apple_pay.add_money":"Mit Apple Pay Gelder aufstocken","button.apple_pay.book":"Mit Apple Pay buchen","button.apple_pay.buy":"Mit Apple Pay kaufen","button.apple_pay.check_out":"Mit Apple Pay auschecken","button.apple_pay.contribute":"Mit Apple Pay einen Beitrag leisten","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Mit Apple Pay spenden","button.apple_pay.order":"Mit Apple Pay bestellen","button.apple_pay.reload":"Mit Apple Pay wiederaufladen","button.apple_pay.rent":"Mit Apple Pay mieten","button.apple_pay.subscribe":"Mit Apple Pay abonnieren","button.apple_pay.support":"Mit Apple Pay unterstützen","button.apple_pay.tip":"Mit Apple Pay Trinkgeld geben","button.apple_pay.top_up":"Mit Apple Pay aufladen","button.cancel":"Abbrechen","button.change":"Ändern","button.google_pay.buy":"Mit Google Pay kaufen","button.google_pay.default":"Google Pay","button.google_pay.donate":"Mit Google Pay spenden","button.link.autofill":"Autofill","button.link.autofill_alt":"Verwenden","button.link.autofill_aria_label":"Automatisch mit Link ausfüllen","button.link.card_clear":"Verwendung von Link beenden und Kartendaten manuell eingeben.","button.link.express_pay":"Express-Zahlung","button.link.manage":"Sie zahlen derzeit mit Link unter Verwendung der Karte mit den Endziffern {last4}. Andere Zahlungsmethode auswählen","button.link.manage.cardCvc":"Sie verwenden derzeit Link. Aktualisieren Sie die Prüfziffer/CVC der Karte.","button.link.manage.cardExpiry":"Sie verwenden Link derzeit mit dem Ablaufdatum {expiry}. Aktualisieren Sie das Ablaufdatum der Karte.","button.link.manage.postalCode":"Sie verwenden Link derzeit mit der Postleitzahl {postal}. Aktualisieren Sie die Postleitzahl der Karte.","button.link.pay_faster":"Schneller zahlen","button.link.pay_faster_with":"Schneller zahlen mit {linkLogo}","button.link.pay_faster_with_link":"Schneller zahlen mit Link","button.link.pay_with":"Zahlen mit {linkLogo}","button.link.pay_with_last_4":"Zahlen mit ••{last4}","button.link.save_with":"Mit {linkLogo} speichern","button.link.save_with_aria_label":"Mit Link speichern","button.link.use_last_4_aria_label":"Automatisch mit Link ausfüllen mit einer Karte mit den Endziffern {last4}","button.logout":"Abmelden","button.pay_with":"Zahlen mit","button.payment_request.book":"Jetzt buchen","button.payment_request.buy":"Kaufen","button.payment_request.default":"Jetzt bezahlen","button.payment_request.donate":"Spenden","button.remove":"Entfernen","button.retry":"Erneut versuchen","button.save":"Speichern","button.save_with":"Speichern mit","button.see_more":"Weitere Infos","button.update":"Aktualisieren","placeholders.accountHolderType":"Art des Kontoinhaber/der Kontoinhaberin","placeholders.auBankAccountNumber":"Kontonummer","placeholders.cardNumber":"Kartennummer","placeholders.cardNumberShort":"Nummer","placeholders.company":"Geschäftlich","placeholders.cvc":"Prüfziffer","placeholders.expiry":"MM/JJ","placeholders.individual":"Privat","placeholders.postal_code":"PLZ","placeholders.postcode":"PLZ","placeholders.securityCode":"Sicherheitscode","placeholders.selectBank":"Bank auswählen","placeholders.zip":"PLZ","button.prb_warning.badge_label":"Upgrade verfügbar","button.prb_warning.button_primary":"Jetzt umsteigen","button.prb_warning.button_secondary":"In einer Woche erinnern","button.prb_warning.description":"Wir haben festgestellt, dass Sie die Schaltfläche für Zahlungsanfragen benutzen. Steigen Sie um auf das {ece_link}, um Zugang zu den neuesten Funktionen und Optimierungen zu erhalten.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Anzeige mehrerer Zahlungsmethoden gleichzeitig, darunter: Amazon Pay, Link und PayPal (nur EU).","button.prb_warning.li2":"Browserübergreifende Unterstützung für Google Pay und Apple Pay (iOS 18+).","button.prb_warning.li3":"Dynamisches Sortieren und Anzeigen der relevantesten Express-Zahlungsoptionen für Ihre Kundinnen und Kunden.","button.prb_warning.nav_header":"Test-Modus","button.prb_warning.title":"Führen Sie ein Upgrade der veralteten Schaltflächen für die Zahlung mit einem Klick durch"}')
        },
        82697: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Κλείσιμο παραθύρου διαλόγου","button.apple_pay.add_money":"Προσθήκη χρημάτων με Apple Pay","button.apple_pay.book":"Κράτηση με Apple Pay","button.apple_pay.buy":"Αγορά με Apple Pay","button.apple_pay.check_out":"Ολοκλήρωση αγοράς με Apple Pay","button.apple_pay.contribute":"Συνεισφορά με Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Δωρεά με Apple Pay","button.apple_pay.order":"Παραγγελία με Apple Pay","button.apple_pay.reload":"Επαναφόρτωση με Apple Pay","button.apple_pay.rent":"Ενοικίαση με Apple Pay","button.apple_pay.subscribe":"Συνδρομή με Apple Pay","button.apple_pay.support":"Υποστήριξη με Apple Pay","button.apple_pay.tip":"Φιλοδώρημα με Apple Pay","button.apple_pay.top_up":"Συμπληρωματική πληρωμή με Apple Pay","button.cancel":"Ακύρωση","button.change":"Αλλαγή","button.google_pay.buy":"Αγορά με Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Δωρεά με Google Pay","button.link.autofill":"Autofill","button.link.autofill_alt":"Χρήση","button.link.autofill_aria_label":"Αυτόματη συμπλήρωση με το Link","button.link.card_clear":"Σταματήστε να χρησιμοποιείτε το Link και εισαγάγετε τα στοιχεία κάρτας με μη αυτόματο τρόπο.","button.link.express_pay":"Άμεση πληρωμή","button.link.manage":"Επί του παρόντος, πληρώνετε με το Link χρησιμοποιώντας την κάρτα που λήγει σε {last4}. Επιλέξτε διαφορετική μέθοδο πληρωμής.","button.link.manage.cardCvc":"Επί του παρόντος χρησιμοποιείτε το Link. Ενημερώστε τον κωδικό CVC της κάρτας.","button.link.manage.cardExpiry":"Επί του παρόντος χρησιμοποιείτε το Link με την ημερομηνία λήξης {expiry}. Ενημερώστε την ημερομηνία λήξης της κάρτας.","button.link.manage.postalCode":"Επί του παρόντος χρησιμοποιείτε το Link με τον ταχυδρομικό κώδικα {postal}. Ενημερώστε τον ταχυδρομικό κώδικα της κάρτας.","button.link.pay_faster":"Ταχύτερη πληρωμή","button.link.pay_faster_with":"Ταχύτερες πλ. με {linkLogo}","button.link.pay_faster_with_link":"Ταχύτερες πληρωμές με το Link","button.link.pay_with":"Πληρωμή με {linkLogo}","button.link.pay_with_last_4":"Πλ. με ••{last4}","button.link.save_with":"Αποθήκευση με το {linkLogo}","button.link.save_with_aria_label":"Αποθήκευση με το Link","button.link.use_last_4_aria_label":"Αυτόματη συμπλήρωση χρησιμοποιώντας το Link με την κάρτα που λήγει σε {last4}","button.logout":"Αποσύνδεση","button.pay_with":"Πληρωμή με","button.payment_request.book":"Κράτηση τώρα","button.payment_request.buy":"Αγορά τώρα","button.payment_request.default":"Πληρωμή τώρα","button.payment_request.donate":"Πραγματοποιήστε δωρεά","button.remove":"Αφαίρεση","button.retry":"Δοκιμάστε ξανά","button.save":"Αποθήκευση","button.save_with":"Αποθήκευση με","button.see_more":"Εμφάνιση περισσότερων","button.update":"Ενημέρωση","placeholders.accountHolderType":"Τύπος δικαιούχου λογαριασμού","placeholders.auBankAccountNumber":"Αριθμός λογαριασμού","placeholders.cardNumber":"Αριθμός κάρτας","placeholders.cardNumberShort":"Αριθμός","placeholders.company":"Επιχείρηση","placeholders.cvc":"CVC","placeholders.expiry":"ΜΜ / ΕΕ","placeholders.individual":"Προσωπικός","placeholders.postal_code":"Ταχυδρομικός κώδικας","placeholders.postcode":"Ταχυδρομικός κώδικας","placeholders.securityCode":"Κωδικός ασφαλείας","placeholders.selectBank":"Επιλογή τράπεζας","placeholders.zip":"Τ.Κ.","button.prb_warning.badge_label":"Διαθέσιμη αναβάθμιση","button.prb_warning.button_primary":"Αναβάθμιση τώρα","button.prb_warning.button_secondary":"Αγνόηση για μία εβδομάδα","button.prb_warning.description":"Παρατηρήσαμε ότι χρησιμοποιείτε το Κουμπί αιτήματος πληρωμής. Αναβαθμίστε στο {ece_link} για πρόσβαση στα πιο πρόσφατα χαρακτηριστικά και βελτιστοποιήσεις.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Εμφανίστε πολλαπλές μεθόδους πληρωμής ταυτόχρονα, συμπεριλαμβανομένων των εξής: Amazon Pay, Link και PayPal (μόνο στην ΕΕ).","button.prb_warning.li2":"Υποστήριξη πολλαπλών προγραμμάτων περιήγησης για Google Pay και Apple Pay (iOS 18+).","button.prb_warning.li3":"Ταξινομήστε και εμφανίστε δυναμικά στους πελάτες σας τις πιο συναφείς επιλογές ταχείας ολοκλήρωσης αγοράς.","button.prb_warning.nav_header":"Δοκιμαστική λειτουργία","button.prb_warning.title":"Ενημερώστε τα παλαιού τύπου κουμπιά πληρωμής με ένα κλικ"}')
        },
        57410: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Close window","button.apple_pay.add_money":"Add Money with Apple Pay","button.apple_pay.book":"Book with Apple Pay","button.apple_pay.buy":"Buy with Apple Pay","button.apple_pay.check_out":"Check out with Apple Pay","button.apple_pay.contribute":"Contribute with Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Donate with Apple Pay","button.apple_pay.order":"Order with Apple Pay","button.apple_pay.reload":"Reload with Apple Pay","button.apple_pay.rent":"Rent with Apple Pay","button.apple_pay.subscribe":"Subscribe with Apple Pay","button.apple_pay.support":"Support with Apple Pay","button.apple_pay.tip":"Tip with Apple Pay","button.apple_pay.top_up":"Top Up with Apple Pay","button.cancel":"Cancel","button.change":"Change","button.google_pay.buy":"Buy with Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Donate with Google Pay","button.link.autofill":"Autofill","button.link.autofill_alt":"Use","button.link.autofill_aria_label":"Autofill with Link","button.link.card_clear":"Stop using Link and enter card details manually.","button.link.express_pay":"Express pay","button.link.manage":"Currently using Link with a card ending in {last4}. Choose a different payment method.","button.link.manage.cardCvc":"Currently using Link. Update the card\'s CVC code.","button.link.manage.cardExpiry":"Currently using Link with an expiry date of {expiry}. Update the card\'s expiry date.","button.link.manage.postalCode":"Currently using Link with a postal code of {postal}. Update the card\'s postal code.","button.link.pay_faster":"Pay faster","button.link.pay_faster_with":"Pay faster with {linkLogo}","button.link.pay_faster_with_link":"Pay faster with Link","button.link.pay_with":"Pay with {linkLogo}","button.link.pay_with_last_4":"Pay with ••{last4}","button.link.save_with":"Save with {linkLogo}","button.link.save_with_aria_label":"Save with Link","button.link.use_last_4_aria_label":"Autofill using Link with a card ending in {last4}","button.logout":"Log out","button.pay_with":"Pay with","button.payment_request.book":"Book now","button.payment_request.buy":"Buy now","button.payment_request.default":"Pay now","button.payment_request.donate":"Donate","button.remove":"Remove","button.retry":"Retry","button.save":"Save","button.save_with":"Save with","button.see_more":"See more","button.update":"Update","placeholders.accountHolderType":"Account holder type","placeholders.auBankAccountNumber":"Account number","placeholders.cardNumber":"Card number","placeholders.cardNumberShort":"Number","placeholders.company":"Business","placeholders.cvc":"CVC","placeholders.expiry":"MM / YY","placeholders.individual":"Personal","placeholders.postal_code":"Postal code","placeholders.postcode":"Postcode","placeholders.securityCode":"Security Code","placeholders.selectBank":"Select bank","placeholders.zip":"ZIP","button.prb_warning.badge_label":"Upgrade available","button.prb_warning.button_primary":"Upgrade now","button.prb_warning.button_secondary":"Dismiss for one week","button.prb_warning.description":"We noticed you\'re using the Payment Request Button. Upgrade to the {ece_link} for access to the latest features and optimisations.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Display multiple payment methods simultaneously, including Amazon Pay, Link and PayPal (in EU only).","button.prb_warning.li2":"Cross-browser support for Google Pay and Apple Pay (iOS 18+).","button.prb_warning.li3":"Sort and display the most relevant express checkout options dynamically to your customers.","button.prb_warning.nav_header":"Test mode","button.prb_warning.title":"Upgrade your legacy one-click payment buttons"}')
        },
        32126: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Cerrar el cuadro de diálogo","button.apple_pay.add_money":"Agregar dinero con Apple Pay","button.apple_pay.book":"Reservar con Apple Pay","button.apple_pay.buy":"Comprar con Apple Pay","button.apple_pay.check_out":"Comprar con Apple Pay","button.apple_pay.contribute":"Aportar con Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Donar con Apple Pay","button.apple_pay.order":"Hacer un pedido con Apple Pay","button.apple_pay.reload":"Recargar con Apple Pay","button.apple_pay.rent":"Alquilar con Apple Pay","button.apple_pay.subscribe":"Suscribirse con Apple Pay","button.apple_pay.support":"Dar apoyo con Apple Pay","button.apple_pay.tip":"Dar propina con Apple Pay","button.apple_pay.top_up":"Recargar con Apple Pay","button.cancel":"Cancelar","button.change":"Cambiar","button.google_pay.buy":"Comprar con Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Donar con Google Pay","button.link.autofill":"Usar","button.link.autofill_alt":"Utilizar","button.link.autofill_aria_label":"Autocompletar con Link","button.link.card_clear":"Dejar de usar Link e introducir manualmente los datos de la tarjeta.","button.link.express_pay":"Pago Express","button.link.manage":"Ahora mismo se paga con Link utilizando la tarjeta que termina en {last4}. Elige un método de pago distinto.","button.link.manage.cardCvc":"Actualmente se está utilizando Link. Actualiza el CVC de la tarjeta.","button.link.manage.cardExpiry":"Actualmente se está utilizando Link con una fecha de vencimiento de {expiry}. Actualiza la fecha de vencimiento de la tarjeta.","button.link.manage.postalCode":"Actualmente se está utilizando Link con un código postal de {postal}. Actualiza el código postal de la tarjeta.","button.link.pay_faster":"Pago rápido","button.link.pay_faster_with":"Pago rápido con {linkLogo}","button.link.pay_faster_with_link":"Paga más rápido con Link","button.link.pay_with":"Pagar con {linkLogo}","button.link.pay_with_last_4":"Pagar con ••{last4}","button.link.save_with":"Guardar con {linkLogo}","button.link.save_with_aria_label":"Guardar con Link","button.link.use_last_4_aria_label":"Autocompletar utilizando Link con una tarjeta que termine en {last4}","button.logout":"Cerrar sesión","button.pay_with":"Pagar con","button.payment_request.book":"Reservar ahora","button.payment_request.buy":"Comprar ahora","button.payment_request.default":"Pagar ahora","button.payment_request.donate":"Donar","button.remove":"Eliminar","button.retry":"Reintentar","button.save":"Guardar","button.save_with":"Guardar con","button.see_more":"Más información","button.update":"Actualizar","placeholders.accountHolderType":"Tipo de titular de la cuenta","placeholders.auBankAccountNumber":"Número de cuenta","placeholders.cardNumber":"Número de tarjeta","placeholders.cardNumberShort":"Número","placeholders.company":"Empresa","placeholders.cvc":"CVC","placeholders.expiry":"MM/AA","placeholders.individual":"Personal","placeholders.postal_code":"Código postal","placeholders.postcode":"Código postal","placeholders.securityCode":"Código de seguridad","placeholders.selectBank":"Seleccionar banco","placeholders.zip":"Código postal","button.prb_warning.badge_label":"Actualización disponible","button.prb_warning.button_primary":"Actualizar ahora","button.prb_warning.button_secondary":"Omitir durante una semana","button.prb_warning.description":"Nos dimos cuenta de que utilizas el Payment Request Button. Actualiza a {ece_link} para acceder a las últimas funcionalidades y optimizaciones.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Muestra varios métodos de pago a la vez, como Amazon Pay, Link y PayPal (solo en la UE).","button.prb_warning.li2":"Soporte transfronterizo para Google Pay y Apple Pay (iOS 18 o posterior)","button.prb_warning.li3":"Clasifica y muestra de forma dinámica a tus clientes las opciones más relevantes del proceso de compra exprés","button.prb_warning.nav_header":"Modo de prueba","button.prb_warning.title":"Actualiza tus botones de pago heredados en un clic"}')
        },
        21858: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Cerrar diálogo","button.apple_pay.add_money":"Añadir dinero con Apple Pay","button.apple_pay.book":"Reservar con Apple Pay","button.apple_pay.buy":"Comprar con Apple Pay","button.apple_pay.check_out":"Comprar con Apple Pay","button.apple_pay.contribute":"Contribuir con Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Donar con Apple Pay","button.apple_pay.order":"Hacer un pedido con Apple Pay","button.apple_pay.reload":"Recargar con Apple Pay","button.apple_pay.rent":"Alquilar con Apple Pay","button.apple_pay.subscribe":"Suscribirse con Apple Pay","button.apple_pay.support":"Apoyar con Apple Pay","button.apple_pay.tip":"Dar propina con Apple Pay","button.apple_pay.top_up":"Recargar con Apple Pay","button.cancel":"Cancelar","button.change":"Cambiar","button.google_pay.buy":"Comprar con Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Donar con Google Pay","button.link.autofill":"Utilizar","button.link.autofill_alt":"Utilizar","button.link.autofill_aria_label":"Autorrellenar con Link","button.link.card_clear":"Dejar de usar Link e introducir manualmente los datos de la tarjeta.","button.link.express_pay":"Pago Express","button.link.manage":"Ahora mismo se paga con Link utilizando la tarjeta que termina en {last4}. Elige un método de pago distinto.","button.link.manage.cardCvc":"Actualmente se está utilizando Link. Actualiza el CVC de la tarjeta.","button.link.manage.cardExpiry":"Actualmente se está utilizando Link con una fecha de caducidad de {expiry}. Actualiza la fecha de caducidad de la tarjeta.","button.link.manage.postalCode":"Actualmente se está utilizando Link con un código postal de {postal}. Actualiza el código postal de la tarjeta.","button.link.pay_faster":"Pago rápido","button.link.pay_faster_with":"Pago rápido con {linkLogo}","button.link.pay_faster_with_link":"Paga más rápido con Link","button.link.pay_with":"Pagar con {linkLogo}","button.link.pay_with_last_4":"Pagar con ••{last4}","button.link.save_with":"Guardar con {linkLogo}","button.link.save_with_aria_label":"Guardar con Link","button.link.use_last_4_aria_label":"Autorrellenar utilizando Link con una tarjeta que termine con {last4}","button.logout":"Cerrar sesión","button.pay_with":"Pagar con","button.payment_request.book":"Reservar ahora","button.payment_request.buy":"Comprar ahora","button.payment_request.default":"Pagar ahora","button.payment_request.donate":"Donar","button.remove":"Eliminar","button.retry":"Reintentar","button.save":"Guardar","button.save_with":"Guardar con","button.see_more":"Más información","button.update":"Actualizar","placeholders.accountHolderType":"Tipo de titular de la cuenta","placeholders.auBankAccountNumber":"Número de cuenta","placeholders.cardNumber":"Número de tarjeta","placeholders.cardNumberShort":"Número","placeholders.company":"Empresa","placeholders.cvc":"CVC","placeholders.expiry":"MM / AA","placeholders.individual":"Personal","placeholders.postal_code":"Código postal","placeholders.postcode":"Código postal","placeholders.securityCode":"Código de seguridad","placeholders.selectBank":"Seleccionar banco","placeholders.zip":"C. P.","button.prb_warning.badge_label":"Actualización disponible","button.prb_warning.button_primary":"Actualizar ahora","button.prb_warning.button_secondary":"Omitir durante una semana","button.prb_warning.description":"Nos hemos dado cuenta de que utilizas el botón de solicitud de pago. Actualiza a {ece_link} para acceder a las últimas funciones y optimizaciones.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Muestra varios métodos de pago a la vez, como Amazon Pay, Link y PayPal (solo en la UE).","button.prb_warning.li2":"Soporte transfronterizo para Google Pay y Apple Pay (iOS 18 o superior).","button.prb_warning.li3":"Ordena y muestra de forma dinámica a tus clientes las opciones más relevantes del proceso de compra exprés.","button.prb_warning.nav_header":"Modo de prueba","button.prb_warning.title":"Actualiza tus botones de pago antiguos en un clic"}')
        },
        9450: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Sulge dialoog","button.apple_pay.add_money":"Lisa raha Apple Pay\'ga","button.apple_pay.book":"Broneeri Apple Pay\'ga","button.apple_pay.buy":"Osta Apple Pay\'ga","button.apple_pay.check_out":"Maksa Apple Pay\'ga","button.apple_pay.contribute":"Panusta Apple Pay\'ga","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Anneta Apple Pay\'ga","button.apple_pay.order":"Telli Apple Pay\'ga","button.apple_pay.reload":"Laadi Apple Pay\'ga","button.apple_pay.rent":"Rendi Apple Pay\'ga","button.apple_pay.subscribe":"Telli Apple Pay\'ga","button.apple_pay.support":"Toeta Apple Pay\'ga","button.apple_pay.tip":"Maksa tippi Apple Pay\'ga","button.apple_pay.top_up":"Lisa raha Apple Pay\'ga","button.cancel":"Tühista","button.change":"Muuda","button.google_pay.buy":"Osta Google Pay\'ga","button.google_pay.default":"Google Pay","button.google_pay.donate":"Anneta Google Payga","button.link.autofill":"Autofill","button.link.autofill_alt":"Kasuta","button.link.autofill_aria_label":"Täida kaardiandmed Linkiga automaatelt","button.link.card_clear":"Lõpeta Linki kasutamine ja sisesta kaardi andmed käsitsi.","button.link.express_pay":"Ekspressmakse","button.link.manage":"Maksate praegu Linkiga, kasutades kaarti, mille numbri lõpus on {last4}. Vali mõni muu makseviis","button.link.manage.cardCvc":"Kasutate praegu Linki. Uuendage kaardi CVC-koodi.","button.link.manage.cardExpiry":"Kasutate praegu Linki aegumiskuupäevaga {expiry}. Uuendage kaardi aegumiskuupäeva.","button.link.manage.postalCode":"Kasutate praegu Linki postiindeksiga {postal}. Uuendage kaardi postiindeksit.","button.link.pay_faster":"Maksa kiiremini","button.link.pay_faster_with":"Kiirmakseviis {linkLogo}","button.link.pay_faster_with_link":"Maksa kiiremini Linkiga","button.link.pay_with":"Makseviis {linkLogo}","button.link.pay_with_last_4":"Makseviis ••{last4}","button.link.save_with":"Salvesta Linki {linkLogo}","button.link.save_with_aria_label":"Salvesta Linki","button.link.use_last_4_aria_label":"Täida kaardiandmed Linkiga automaatselt, kasutades kaarti, mis lõpeb numbritega {last4}","button.logout":"Logi välja","button.pay_with":"Makseviis","button.payment_request.book":"Broneeri kohe","button.payment_request.buy":"Osta kohe","button.payment_request.default":"Maksa kohe","button.payment_request.donate":"Anneta","button.remove":"Eemalda","button.retry":"Proovi uuesti","button.save":"Salvesta","button.save_with":"Salvesta","button.see_more":"Kuva rohkem","button.update":"Uuenda","placeholders.accountHolderType":"Kontoomaniku tüüp","placeholders.auBankAccountNumber":"Kontonumber","placeholders.cardNumber":"Kaardinumber","placeholders.cardNumberShort":"Number","placeholders.company":"Äriline","placeholders.cvc":"CVC","placeholders.expiry":"KK / AA","placeholders.individual":"Isiklik","placeholders.postal_code":"Sihtnumber","placeholders.postcode":"Sihtkood","placeholders.securityCode":"Turvakood","placeholders.selectBank":"Vali pank","placeholders.zip":"Sihtnumber","button.prb_warning.badge_label":"Versioonitäiendus on saadaval","button.prb_warning.button_primary":"Täienda versiooni kohe","button.prb_warning.button_secondary":"Lükka nädala võrra edasi","button.prb_warning.description":"Märkasime, et kasutate maksetaotluse nuppu. Uusimad funktsioonid ja optimeerimised on kättesaadavad versioonile {ece_link} täiendamisel.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Kuvage korraga mitut makseviisi, sealhulgas Amazon Pay, Link ja PayPal (ainult EL-is).","button.prb_warning.li2":"Google Pay ja Apple Pay brauseriülene tugi (iOS 18+).","button.prb_warning.li3":"Sortige ja kuvage dünaamiliselt oma klientidele kõige asjakohasemaid kiirkassavõimalusi.","button.prb_warning.nav_header":"Testrežiim","button.prb_warning.title":"Uuendage oma pärandversiooni ühe hiireklõpsuga maksmise nuppe"}')
        },
        17705: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Sulje valintaikkuna","button.apple_pay.add_money":"Lisää rahaa Apple Paylla","button.apple_pay.book":"Varaa Apple Paylla","button.apple_pay.buy":"Osta Apple Payn kautta","button.apple_pay.check_out":"Siirry kassalle Apple Paylla","button.apple_pay.contribute":"Osallistu Apple Paylla","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Lahjoita Apple Payn kautta","button.apple_pay.order":"Tilaa Apple Paylla","button.apple_pay.reload":"Lataa uudelleen Apple Paylla","button.apple_pay.rent":"Vuokraa Apple Paylla","button.apple_pay.subscribe":"Tee tilaus Apple Paylla","button.apple_pay.support":"Tue Apple Paylla","button.apple_pay.tip":"Anna tippi Apple Paylla","button.apple_pay.top_up":"Täydennä Apple Paylla","button.cancel":"Peruuta","button.change":"Muuta","button.google_pay.buy":"Osta Google Paylla","button.google_pay.default":"Google Pay","button.google_pay.donate":"Lahjoita Google Payn kautta","button.link.autofill":"Käytä","button.link.autofill_alt":"Käytä","button.link.autofill_aria_label":"Täytä automaattisesti Link-palvelulla","button.link.card_clear":"Lopeta Link-palvelun käyttö ja anna kortin tiedot manuaalisesti.","button.link.express_pay":"Pikamaksu","button.link.manage":"Maksu tällä hetkellä Link-palvelulla käyttäen korttia, joka päättyy numeroihin {last4}. Valitse toinen maksutapa","button.link.manage.cardCvc":"Nyt käytössä Link. Päivitä kortin CVC-numero.","button.link.manage.cardExpiry":"Nyt käytössä Link eräpäivällä {expiry}. Päivitä kortin eräpäivä.","button.link.manage.postalCode":"Nyt käytössä Link postinumerolla {postal}. Päivitä kortin postinumero.","button.link.pay_faster":"Maksa nopeammin","button.link.pay_faster_with":"Maksa nopeammin {linkLogo}","button.link.pay_faster_with_link":"Maksa Linkillä","button.link.pay_with":"Maksa palvelulla {linkLogo}","button.link.pay_with_last_4":"Maksutapa ••{last4}","button.link.save_with":"Tallenna kohteella {linkLogo}","button.link.save_with_aria_label":"Tallenna Link-palvelulla","button.link.use_last_4_aria_label":"Täytä automaattisesti Link-palvelulla ja kortilla, joka päättyy numeroihin {last4}","button.logout":"Kirjaudu ulos","button.pay_with":"Maksa kohteella","button.payment_request.book":"Varaa nyt","button.payment_request.buy":"Osta nyt","button.payment_request.default":"Maksa nyt","button.payment_request.donate":"Lahjoita","button.remove":"Poista","button.retry":"Yritä uudelleen","button.save":"Tallenna","button.save_with":"Tallenna kohteella","button.see_more":"Näytä lisää","button.update":"Päivitä","placeholders.accountHolderType":"Tilinhaltijan tyyppi","placeholders.auBankAccountNumber":"Tilinumero","placeholders.cardNumber":"Kortin numero","placeholders.cardNumberShort":"Numero","placeholders.company":"Yritys","placeholders.cvc":"CVC","placeholders.expiry":"KK/VV","placeholders.individual":"Henkilökohtainen","placeholders.postal_code":"Postinumero","placeholders.postcode":"Postinumero","placeholders.securityCode":"Turvallisuuskoodi","placeholders.selectBank":"Valitse pankki","placeholders.zip":"Postinumero","button.prb_warning.badge_label":"Päivitys saatavilla","button.prb_warning.button_primary":"Päivitä nyt","button.prb_warning.button_secondary":"Ohita yhden viikon ajan","button.prb_warning.description":"Huomasimme, että käytät Maksupyyntö-painiketta. Päivitä kohteeseen {ece_link} käyttääksesi uusimpia ominaisuuksia ja optimointeja.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Näytä useita maksutapoja samanaikaisesti, mukaan lukien: Amazon Pay, Link ja PayPal (vain EU).","button.prb_warning.li2":"Selainten välinen tuki Google Paylle ja Apple Paylle (iOS 18+).","button.prb_warning.li3":"Lajittele ja näytä olennaisimmat Express-maksuvaihtoehdot dynaamisesti asiakkaillesi.","button.prb_warning.nav_header":"Testitila","button.prb_warning.title":"Päivitä vanhat kerran napsautettavat maksupainikkeet"}')
        },
        70395: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Isara ang Dialog","button.apple_pay.add_money":"Magdagdag ng Pera gamit ang Apple Pay","button.apple_pay.book":"Mag-book gamit ang Apple Pay","button.apple_pay.buy":"Bumili gamit ang Apple Pay","button.apple_pay.check_out":"Mag-check out gamit ang Apple Pay","button.apple_pay.contribute":"Mag-ambag gamit ang Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Mag-donate gamit ang Apple Pay","button.apple_pay.order":"Umorder gamit ang Apple Pay","button.apple_pay.reload":"Mag-reload gamit ang Apple Pay","button.apple_pay.rent":"Umupa gamit ang Apple Pay","button.apple_pay.subscribe":"Mag-subscribe gamit ang Apple Pay","button.apple_pay.support":"Suporta gamit ang Apple Pay","button.apple_pay.tip":"Mag-tip gamit ang Apple Pay","button.apple_pay.top_up":"Mag-top Up gamit ang Apple Pay","button.cancel":"Kanselahin","button.change":"Palitan","button.google_pay.buy":"Bumili gamit ang Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Magbigay ng donasyon gamit ang Google Pay","button.link.autofill":"Autofill","button.link.autofill_alt":"Gamitin","button.link.autofill_aria_label":"I-autofill gamit ang Link","button.link.card_clear":"Humintong gamitin ang Link at ilagay nang manu-mano ang mga detalye ng kard.","button.link.express_pay":"Express bayad","button.link.manage":"Kasalukuyang nagbabayad gamit ang Link sa card na nagtatapos sa {last4}. Pumili ng ibang paraan ng pagbabayad","button.link.manage.cardCvc":"Kasalukuyang ginagamit ang Link. I-update ang CVC code ng kard.","button.link.manage.cardExpiry":"Kasalukuyang ginagamit ang Link na may expiry date na {expiry}. I-update ang petsa ng expiry ng kard.","button.link.manage.postalCode":"Kasalukuyang ginagamit ang Link na may postal code na {postal}. I-update ang postal code ng card.","button.link.pay_faster":"Bilis bayad","button.link.pay_faster_with":"Magbayad sa {linkLogo}","button.link.pay_faster_with_link":"Magbayad nang mas mabilis gamit ang Link","button.link.pay_with":"Bilis bayad sa {linkLogo}","button.link.pay_with_last_4":"Magbayad sa ••{last4}","button.link.save_with":"I-save gamit ang {linkLogo}","button.link.save_with_aria_label":"I-save gamit ang Link","button.link.use_last_4_aria_label":"I-autofill gamit ang Link gamit ang kard na nagtatapos sa {last4}","button.logout":"Mag-log out","button.pay_with":"Magbayad gamit ang","button.payment_request.book":"Mag-book ngayon","button.payment_request.buy":"Bumili ngayon","button.payment_request.default":"Magbayad ngayon","button.payment_request.donate":"Mag-donasyon","button.remove":"Alisin","button.retry":"Subukan muli","button.save":"I-save","button.save_with":"I-save gamit ang","button.see_more":"Tingnan ang higit pa","button.update":"I-update","placeholders.accountHolderType":"Uri ng may-hawak ng account","placeholders.auBankAccountNumber":"Numero ng account","placeholders.cardNumber":"Numero ng kard","placeholders.cardNumberShort":"Numero","placeholders.company":"Negosyo","placeholders.cvc":"CVC","placeholders.expiry":"BB / TT","placeholders.individual":"Personal","placeholders.postal_code":"Postal code","placeholders.postcode":"Postcode","placeholders.securityCode":"Security Code","placeholders.selectBank":"Piliin ang bangko","placeholders.zip":"ZIP","button.prb_warning.badge_label":"May available na upgrade","button.prb_warning.button_primary":"Mag-upgrade na ngayon","button.prb_warning.button_secondary":"I-dismiss nang isang linggo","button.prb_warning.description":"Napansin namin na ginagamit mo ang Payment Request Button. Mag-upgrade sa {ece_link} para sa access sa mga pinakabagong feature at optimization.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Sabay-sabay na ipakita ang maraming paraan ng pagbabayad, kabilang ang: Amazon Pay, Link at PayPal (sa EU lamang).","button.prb_warning.li2":"Cross-browser na suporta para sa Google Pay at Apple Pay (iOS 18+).","button.prb_warning.li3":"Ayusin at ipakita sa iyong mga kostumer ang karamihan ng mga naaangkop na opsyon sa express checkout sa dinamikong paraan","button.prb_warning.nav_header":"Test mode","button.prb_warning.title":"I-upgrade ang iyong mga legacy one-click payment button"}')
        },
        12693: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Fermer la boîte de dialogue","button.apple_pay.add_money":"Ajouter de l\'argent avec Apple Pay","button.apple_pay.book":"Réserver avec Apple Pay","button.apple_pay.buy":"Acheter avec Apple Pay","button.apple_pay.check_out":"Payer avec Apple Pay","button.apple_pay.contribute":"Contribuer avec Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Faire un don avec Apple Pay","button.apple_pay.order":"Commander avec Apple Pay","button.apple_pay.reload":"Recharger avec Apple Pay","button.apple_pay.rent":"Louer avec Apple Pay","button.apple_pay.subscribe":"S\'abonner avec Apple Pay","button.apple_pay.support":"Soutenir avec Apple Pay","button.apple_pay.tip":"Donner un pourboire avec Apple Pay","button.apple_pay.top_up":"Recharger avec Apple Pay","button.cancel":"Annuler","button.change":"Modifier","button.google_pay.buy":"Acheter avec Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Faire un don avec Google Pay","button.link.autofill":"Utiliser","button.link.autofill_alt":"Utiliser","button.link.autofill_aria_label":"Remplir automatiquement avec Link","button.link.card_clear":"Ne plus utiliser Link et saisir les informations de carte manuellement.","button.link.express_pay":"Payer rapidement","button.link.manage":"Vous payez actuellement avec Link à l\'aide de la carte se terminant par {last4}. Choisissez un autre moyen de paiement.","button.link.manage.cardCvc":"Vous utilisez actuellement Link. Actualisez le code CVC de la carte.","button.link.manage.cardExpiry":"Vous utilisez actuellement Link avec la date d\'expiration {expiry}. Actualisez la date d\'expiration de la carte.","button.link.manage.postalCode":"Vous utilisez actuellement Link avec le code postal {postal}. Actualisez le code postal de la carte.","button.link.pay_faster":"Paiement rapide","button.link.pay_faster_with":"Payer vite avec {linkLogo}","button.link.pay_faster_with_link":"Payer plus rapidement avec Link","button.link.pay_with":"Payer avec {linkLogo}","button.link.pay_with_last_4":"Payer avec ••{last4}","button.link.save_with":"Enregistrer avec {linkLogo}","button.link.save_with_aria_label":"Enregistrer sur Link","button.link.use_last_4_aria_label":"Remplir automatiquement avec Link les informations de votre carte se terminant par {last4}","button.logout":"Déconnexion","button.pay_with":"Payer par","button.payment_request.book":"Réserver","button.payment_request.buy":"Acheter","button.payment_request.default":"Payer","button.payment_request.donate":"Faire un don","button.remove":"Supprimer","button.retry":"Réessayer","button.save":"Enregistrer","button.save_with":"Enregistrer avec","button.see_more":"Voir plus","button.update":"Modifier","placeholders.accountHolderType":"Type de titulaire du compte","placeholders.auBankAccountNumber":"Numéro de compte","placeholders.cardNumber":"Numéro de carte","placeholders.cardNumberShort":"Numéro","placeholders.company":"Professionnel","placeholders.cvc":"CVC","placeholders.expiry":"MM/AA","placeholders.individual":"Personnel","placeholders.postal_code":"Code postal","placeholders.postcode":"Code postal","placeholders.securityCode":"Code de sécurité","placeholders.selectBank":"Sélectionner l\'institution financière","placeholders.zip":"Code postal","button.prb_warning.badge_label":"Mise à niveau disponible","button.prb_warning.button_primary":"Mettre à niveau","button.prb_warning.button_secondary":"Ignorer pendant une semaine","button.prb_warning.description":"Nous avons remarqué que vous utilisez le bouton de demande de paiement. Effectuez une mise à niveau vers {ece_link} afin d\'accéder aux fonctionnalités et optimisations les plus récentes.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Affichez simultanément plusieurs moyens de paiement, comme : Amazon Pay, Link et PayPal (uniquement dans l\'UE).","button.prb_warning.li2":"Prise en charge de Google Pay et Apple Pay (iOS 18+) sur de nombreux navigateurs.","button.prb_warning.li3":"Triez et affichez dynamiquement les options de paiement express les plus adaptées à votre clientèle.","button.prb_warning.nav_header":"Mode test","button.prb_warning.title":"Mettez à niveau vos anciens boutons de paiement en un clic"}')
        },
        81546: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Fermer la boîte de dialogue","button.apple_pay.add_money":"Ajouter de l\'argent avec Apple Pay","button.apple_pay.book":"Réserver avec Apple Pay","button.apple_pay.buy":"Acheter avec Apple Pay","button.apple_pay.check_out":"Payer avec Apple Pay","button.apple_pay.contribute":"Contribuer avec Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Faire un don avec Apple Pay","button.apple_pay.order":"Commander avec Apple Pay","button.apple_pay.reload":"Recharger avec Apple Pay","button.apple_pay.rent":"Louer avec Apple Pay","button.apple_pay.subscribe":"S\'abonner avec Apple Pay","button.apple_pay.support":"Soutenir avec Apple Pay","button.apple_pay.tip":"Donner un pourboire avec Apple Pay","button.apple_pay.top_up":"Recharger avec Apple Pay","button.cancel":"Annuler","button.change":"Modifier","button.google_pay.buy":"Acheter avec Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Faire un don avec Google Pay","button.link.autofill":"Préremplir","button.link.autofill_alt":"Utiliser","button.link.autofill_aria_label":"Remplir automatiquement avec Link","button.link.card_clear":"Ne plus utiliser Link et saisir les informations de carte manuellement.","button.link.express_pay":"Payer rapidement","button.link.manage":"Vous payez actuellement avec Link à l\'aide de la carte se terminant par {last4}. Choisissez un autre moyen de paiement.","button.link.manage.cardCvc":"Vous utilisez actuellement Link. Modifiez le code CVC de la carte bancaire.","button.link.manage.cardExpiry":"Vous utilisez actuellement Link avec la date d\'expiration {expiry}. Modifiez la date d\'expiration de la carte bancaire.","button.link.manage.postalCode":"Vous utilisez actuellement Link avec le code postal {postal}. Modifiez le code postal de la carte bancaire.","button.link.pay_faster":"Paiement rapide","button.link.pay_faster_with":"Payer vite avec {linkLogo}","button.link.pay_faster_with_link":"Payer plus rapidement avec Link","button.link.pay_with":"Payer avec {linkLogo}","button.link.pay_with_last_4":"Payer avec ••{last4}","button.link.save_with":"Enregistrer avec {linkLogo}","button.link.save_with_aria_label":"Enregistrer sur Link","button.link.use_last_4_aria_label":"Remplir automatiquement avec Link les informations de votre carte se terminant par {last4}","button.logout":"Se déconnecter","button.pay_with":"Payer par","button.payment_request.book":"Réserver maintenant","button.payment_request.buy":"Acheter maintenant","button.payment_request.default":"Payer maintenant","button.payment_request.donate":"Faire un don","button.remove":"Supprimer","button.retry":"Réessayer","button.save":"Enregistrer","button.save_with":"Enregistrer avec","button.see_more":"Afficher plus","button.update":"Modifier","placeholders.accountHolderType":"Type de titulaire du compte","placeholders.auBankAccountNumber":"Numéro de compte","placeholders.cardNumber":"Numéro de carte","placeholders.cardNumberShort":"Numéro","placeholders.company":"Professionnel","placeholders.cvc":"CVC","placeholders.expiry":"MM / AA","placeholders.individual":"Personnel","placeholders.postal_code":"Code postal","placeholders.postcode":"Code postal","placeholders.securityCode":"Code de sécurité","placeholders.selectBank":"Sélectionner la banque","placeholders.zip":"Code postal","button.prb_warning.badge_label":"Mise à niveau disponible","button.prb_warning.button_primary":"Mettre à niveau","button.prb_warning.button_secondary":"Ignorer pendant une semaine","button.prb_warning.description":"Nous avons remarqué que vous utilisez le bouton de demande de paiement. Effectuez une mise à niveau vers {ece_link} afin d\'accéder aux fonctionnalités et optimisations les plus récentes.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Affichez simultanément plusieurs moyens de paiement, comme : Amazon Pay, Link et PayPal (uniquement dans l\'UE).","button.prb_warning.li2":"Prise en charge de Google Pay et Apple Pay (iOS 18+) sur de nombreux navigateurs.","button.prb_warning.li3":"Triez et affichez dynamiquement les options de paiement express les plus adaptées à votre clientèle.","button.prb_warning.nav_header":"Mode test","button.prb_warning.title":"Mettez à niveau vos anciens boutons de paiement en un clic"}')
        },
        33946: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"סגירת דו-שיח","button.apple_pay.add_money":"הוספת כסף באמצעות Apple Pay","button.apple_pay.book":"הזמנה עם Apple Pay","button.apple_pay.buy":"קנה באמצעות Apple Pay","button.apple_pay.check_out":"התנתקות באמצעות Apple Pay","button.apple_pay.contribute":"תרומה באמצעות Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"תרומה באמצעות Apple Pay","button.apple_pay.order":"הזמנה באמצעות Apple Pay","button.apple_pay.reload":"טעינה מחדש באמצעות Apple Pay","button.apple_pay.rent":"השכרה באמצעות Apple Pay","button.apple_pay.subscribe":"הרשמה כמנוי באמצעות Apple Pay","button.apple_pay.support":"תמיכה באמצעות Apple Pay","button.apple_pay.tip":"טיפ באמצעות Apple Pay","button.apple_pay.top_up":"מילוי באמצעות Apple Pay","button.cancel":"בטל","button.change":"שינוי","button.google_pay.buy":"קנייה עם Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"תרומה באמצעות Google Pay","button.link.autofill":"השתמש","button.link.autofill_alt":"השתמש","button.link.autofill_aria_label":"מילוי אוטומטי עם Link","button.link.card_clear":"הפסק להשתמש ב-Link והזן את פרטי הכרטיס באופן ידני.","button.link.express_pay":"תשלום מהיר","button.link.manage":"הנך משלם כעת באמצעות Link בכרטיס המסתיים ב-{last4}. בחר אמצעי תשלום אחר","button.link.manage.cardCvc":"נכון לעכשיו משתמש ב-Link. עדכן את קוד ה-CVC של הכרטיס.","button.link.manage.cardExpiry":"נכון לעכשיו משתמש ב-Link עם תאריך תפוגה של {expiry}. עדכן את תאריך התפוגה של הכרטיס.","button.link.manage.postalCode":"נכון לעכשיו משתמש ב-Link עם מיקוד של {postal}. עדכן את מיקוד הכרטיס.","button.link.pay_faster":"שלם מהר יותר","button.link.pay_faster_with":"שלם מהר יותר עם{linkLogo}","button.link.pay_faster_with_link":"שלם מהר יותר עם Link","button.link.pay_with":"שלם באמצעות{linkLogo}","button.link.pay_with_last_4":"שלם באמצעות ••{last4}","button.link.save_with":"שמור ב- {linkLogo}","button.link.save_with_aria_label":"שמור עם Link","button.link.use_last_4_aria_label":"מילוי אוטומטי באמצעות Link עם כרטיס המסתיים ב-{last4}","button.logout":"התנתקות","button.pay_with":"שלם עם","button.payment_request.book":"להזמנה","button.payment_request.buy":"קנה עכשיו","button.payment_request.default":"שלם עכשיו","button.payment_request.donate":"תרומה","button.remove":"הסר","button.retry":"נסה שוב","button.save":"שמור","button.save_with":"שמור ב-","button.see_more":"ראה עוד","button.update":"עדכן","placeholders.accountHolderType":"סוג בעל חשבון","placeholders.auBankAccountNumber":"מספר חשבון","placeholders.cardNumber":"מספר כרטיס","placeholders.cardNumberShort":"מספר","placeholders.company":"עסקי","placeholders.cvc":"CVC","placeholders.expiry":"MM / YY","placeholders.individual":"אישי","placeholders.postal_code":"מיקוד","placeholders.postcode":"מיקוד","placeholders.securityCode":"קוד ביטחון","placeholders.selectBank":"בחר בנק","placeholders.zip":"מיקוד","button.prb_warning.badge_label":"שדרוג זמין","button.prb_warning.button_primary":"שדרג כעת","button.prb_warning.button_secondary":"דחה בשבוע","button.prb_warning.description":"שמנו לב שאתה משתמש בלחצן בקשת תשלום. שדרג ל-{ece_link} לקבלת גישה לתכונות העדכניות והמיטביות ביותר.","button.prb_warning.ece_link":"רכיב תשלום מהיר","button.prb_warning.li1":"הצג מספר שיטות תשלום בו-זמנית, כולל: Amazon Pay, Link ו-PayPal (באיחוד האירופי בלבד).","button.prb_warning.li2":"תמיכה חוצת דפדפנים עבור Google Pay ו-Apple Pay (iOS 18+).","button.prb_warning.li3":"מיין והצג את אפשרויות התשלום המהיר הרלוונטיות ביותר באופן דינמי ללקוחות שלך.","button.prb_warning.nav_header":"מצב בדיקה","button.prb_warning.title":"שדרג את לחצני התשלום הישנים שלך בלחיצה אחת"}')
        },
        20129: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Zatvori dijalog","button.apple_pay.add_money":"Dodajte novac koristeći Apple Pay","button.apple_pay.book":"Rezerviraj koristeći Apple Pay","button.apple_pay.buy":"Kupi koristeći Apple Pay","button.apple_pay.check_out":"Odjavite se koristeći Apple Pay","button.apple_pay.contribute":"Doprinesite korirsteći Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Doniraj koristeći Apple Pay","button.apple_pay.order":"Naručite koristeći Apple Pay","button.apple_pay.reload":"Ponovno učitajte koristeći Apple Pay","button.apple_pay.rent":"Unajmite koristeći Apple Pay","button.apple_pay.subscribe":"Pretplatite se koristeći Apple Pay","button.apple_pay.support":"Podržite koristeći Apple Pay","button.apple_pay.tip":"Ostavite napojnicu koristeći Apple Pay","button.apple_pay.top_up":"Nadopunite koristeći Apple Pay","button.cancel":"Otkaži","button.change":"Izmijeni","button.google_pay.buy":"Kupi koristeći Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Donirajte koristeći Google Pay","button.link.autofill":"Samoispuna","button.link.autofill_alt":"Upotrijebi","button.link.autofill_aria_label":"Automatski ispunite podatke uz Link","button.link.card_clear":"Prestani koristiti Link i ručno unesi podatke o kartici.","button.link.express_pay":"Plati s Express","button.link.manage":"Trenutačno plaćate uz Link karticom koja završava s {last4}. Odaberite drugi način plaćanja","button.link.manage.cardCvc":"Trenutno koristite Link. Ažurirajte CVC kod kartice.","button.link.manage.cardExpiry":"Trenutačno koristite Link s datumom isteka {expiry}. Ažurirajte datum isteka kartice.","button.link.manage.postalCode":"Trenutačno koristite Link s poštanskim brojem {postal}. Ažurirajte poštanski broj kartice.","button.link.pay_faster":"Plati brže","button.link.pay_faster_with":"Plati brže s {linkLogo}","button.link.pay_faster_with_link":"Platite brže uz Link","button.link.pay_with":"Plati koristeći {linkLogo}","button.link.pay_with_last_4":"Plati s ••{last4}","button.link.save_with":"Spremi s {linkLogo}","button.link.save_with_aria_label":"Spremi s Linkom","button.link.use_last_4_aria_label":"Automatski ispunite podatke uz Link s karticom koja završava na {last4}","button.logout":"Odjava","button.pay_with":"Platite koristeći","button.payment_request.book":"Rezerviraj odmah","button.payment_request.buy":"Kupi odmah","button.payment_request.default":"Plati odmah","button.payment_request.donate":"Doniraj","button.remove":"Ukloni","button.retry":"Pokušaj ponovo","button.save":"Spremi","button.save_with":"Spremite koristeći","button.see_more":"Pogledajte više","button.update":"Ažuriraj","placeholders.accountHolderType":"Tip vlasnika računa","placeholders.auBankAccountNumber":"Broj računa","placeholders.cardNumber":"Broj kartice","placeholders.cardNumberShort":"Broj","placeholders.company":"Poslovni","placeholders.cvc":"CVC","placeholders.expiry":"MM / GG","placeholders.individual":"Osobni","placeholders.postal_code":"Poštanski broj","placeholders.postcode":"Poštanski broj","placeholders.securityCode":"Sigurnosni kod","placeholders.selectBank":"Odaberite banku","placeholders.zip":"ZIP","button.prb_warning.badge_label":"Ažuriranje je dostupno","button.prb_warning.button_primary":"Ažuriraj odmah","button.prb_warning.button_secondary":"Zatvori obavijest i ne prikazuj je na jedan tjedan","button.prb_warning.description":"Primijetili smo da koristite gumb Zahtjev za plaćanje. Nadogradite na {ece_link} za pristup najnovijim značajkama i optimizacijama.","button.prb_warning.ece_link":"Element ekspresnog plaćanja","button.prb_warning.li1":"Prikaži više načina plaćanja istovremeno, uključujući: Amazon Pay, Link i PayPal (samo u EU).","button.prb_warning.li2":"Podrška na svim preglednicima za Google Pay i Apple Pay (iOS 18+).","button.prb_warning.li3":"Sortirajte i dinamički prikažite svojim kupcima najrelevantnije opcije ekspresne naplate.","button.prb_warning.nav_header":"Testni režim rada","button.prb_warning.title":"Jednim klikom ažurirajte svoje starije gumbe"}')
        },
        24407: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Párbeszédablak bezárása","button.apple_pay.add_money":"Pénz hozzáadása az Apple Payjel","button.apple_pay.book":"Előjegyzés az Apple Payjel","button.apple_pay.buy":"Vásárlás az Apple Payjel","button.apple_pay.check_out":"Fizetés az Apple Payjel","button.apple_pay.contribute":"Hozzájárulás az Apple Payjel","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Adományozás az Apple Payjel","button.apple_pay.order":"Rendelés az Apple Payjel","button.apple_pay.reload":"Visszatöltés az Apple Payjel","button.apple_pay.rent":"Bérlés az Apple Payjel","button.apple_pay.subscribe":"Előfizetés az Apple Payjel","button.apple_pay.support":"Támogatás az Apple Payjel","button.apple_pay.tip":"Borravaló az Apple Payjel","button.apple_pay.top_up":"Feltöltés az Apple Payjel","button.cancel":"Mégse","button.change":"Módosítás","button.google_pay.buy":"Vásárlás a Google Payjel","button.google_pay.default":"Google Pay","button.google_pay.donate":"Adományozás a Google Payjel","button.link.autofill":"Autofill","button.link.autofill_alt":"Használat","button.link.autofill_aria_label":"Automatikus kitöltés Linkkel","button.link.card_clear":"Link használatának befejezése és a kártyaadatok megadása kézzel","button.link.express_pay":"Express fizetés","button.link.manage":"Jelenleg a(z) {last4} végződésű bankkártyával fizet a Linkkel. Válasszon egy másik fizetési módot.","button.link.manage.cardCvc":"Jelenleg a Linket használja. Frissítse a bankkártyájának CVC kódját.","button.link.manage.cardExpiry":"Jelenleg a Linket használja, a lejárat dátuma: {expiry}. Frissítse a bankkártyájának lejárati dátumát.","button.link.manage.postalCode":"Jelenleg a Linket használja, az irányítószám: {postal}. Frissítse a bankkártyájának irányítószámát.","button.link.pay_faster":"Gyorsfizetés","button.link.pay_faster_with":"Gyorsfizetés: {linkLogo}","button.link.pay_faster_with_link":"Gyorsabb fizetés a Linkkel","button.link.pay_with":"Fizetés: {linkLogo}","button.link.pay_with_last_4":"Fizetés: ••{last4}","button.link.save_with":"Mentés ezzel: {linkLogo}","button.link.save_with_aria_label":"Mentés Linkkel","button.link.use_last_4_aria_label":"Autokitöltés Linkkel és a következő végződésű kártyával: {last4}","button.logout":"Kijelentkezés","button.pay_with":"Fizetés a következővel:","button.payment_request.book":"Előjegyzés","button.payment_request.buy":"Vásárlás","button.payment_request.default":"Fizetés","button.payment_request.donate":"Adományozás","button.remove":"Eltávolítás","button.retry":"Újra","button.save":"Mentés","button.save_with":"Mentés ezzel:","button.see_more":"Továbbiak megjelenítése","button.update":"Frissítés","placeholders.accountHolderType":"A számlatulajdonos jellege","placeholders.auBankAccountNumber":"Számlaszám","placeholders.cardNumber":"Kártyaszám","placeholders.cardNumberShort":"Szám","placeholders.company":"Vállalkozás","placeholders.cvc":"CVC","placeholders.expiry":"HH/ÉÉ","placeholders.individual":"Magánszemély","placeholders.postal_code":"Postai irányítószám","placeholders.postcode":"Irányítószám","placeholders.securityCode":"Biztonsági kód","placeholders.selectBank":"Bankválasztás","placeholders.zip":"Irányítószám","button.prb_warning.badge_label":"Frissítés elérhető","button.prb_warning.button_primary":"Frissítés most","button.prb_warning.button_secondary":"Elvetés egy hétre","button.prb_warning.description":"Észrevettük, hogy használja a Payment Request Button elemet. A(z) {ece_link} szolgáltatásra való bővítéssel hozzáférést kaphat a legújabb funkciókhoz és optimizálásokhoz.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Megjeleníthet egyszerre több fizetési módot, például Amazon Pay, Link és PayPal (csak az EU-ban).","button.prb_warning.li2":"Több böngésző támogatása a Google Pay és az Apple Pay (iOS 18 és újabb) használatához.","button.prb_warning.li3":"Lehetőség van a legfontosabb egykattintásos fizetési módok dinamikus sorbarendezésére és ügyfeleknek való megjelenítésére.","button.prb_warning.nav_header":"Teszt mód","button.prb_warning.title":"Korszerűsítse a régi egykattintásos fizetési gombjait"}')
        },
        36549: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Tutup Dialog","button.apple_pay.add_money":"Tambah Uang dengan Apple Pay","button.apple_pay.book":"Pesan dengan Apple Pay","button.apple_pay.buy":"Beli dengan Apple Pay","button.apple_pay.check_out":"Bayar dengan Apple Pay","button.apple_pay.contribute":"Berkontribusi dengan Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Donasi dengan Apple Pay","button.apple_pay.order":"Pesan dengan Apple Pay","button.apple_pay.reload":"Muat Ulang dengan Apple Pay","button.apple_pay.rent":"Sewa dengan Apple Pay","button.apple_pay.subscribe":"Berlangganan dengan Apple Pay","button.apple_pay.support":"Dukung dengan Apple Pay","button.apple_pay.tip":"Tip dengan Apple Pay","button.apple_pay.top_up":"Tambah Saldo dengan Apple Pay","button.cancel":"Batalkan","button.change":"Ubah","button.google_pay.buy":"Beli dengan Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Donasikan dengan Google Pay","button.link.autofill":"Isi","button.link.autofill_alt":"Penggunaan","button.link.autofill_aria_label":"Isi otomatis dengan Link","button.link.card_clear":"Hentikan penggunaan Link dan masukkan detail kartu secara manual.","button.link.express_pay":"Pembayaran cepat","button.link.manage":"Saat ini membayar dengan Link menggunakan kartu yang berakhiran dengan {last4}. Pilih metode pembayaran yang berbeda","button.link.manage.cardCvc":"Saat ini menggunakan Link. Perbarui kode CVC kartu.","button.link.manage.cardExpiry":"Saat ini menggunakan Link dengan tanggal kedaluwarsa {expiry}. Perbarui tanggal kedaluwarsa kartu.","button.link.manage.postalCode":"Saat ini menggunakan Link dengan kode pos {postal}. Perbarui kode pos kartu.","button.link.pay_faster":"Bayar cepat","button.link.pay_faster_with":"Bayar cepat dgn {linkLogo}","button.link.pay_faster_with_link":"Bayar dengan cepat dengan Link","button.link.pay_with":"Bayar dengan {linkLogo}","button.link.pay_with_last_4":"Bayar dengan ••{last4}","button.link.save_with":"Simpan dengan {linkLogo}","button.link.save_with_aria_label":"Simpan dengan Link","button.link.use_last_4_aria_label":"Isi otomatis menggunakan Link dengan kartu yang berakhiran {last4}","button.logout":"Keluar","button.pay_with":"Bayar dengan","button.payment_request.book":"Pesan sekarang","button.payment_request.buy":"Beli sekarang","button.payment_request.default":"Bayar sekarang","button.payment_request.donate":"Donasikan","button.remove":"Hapus","button.retry":"Coba ulang","button.save":"Simpan","button.save_with":"Simpan dengan","button.see_more":"Lihat selengkapnya","button.update":"Perbarui","placeholders.accountHolderType":"Tipe pemilik rekening","placeholders.auBankAccountNumber":"Nomor rekening","placeholders.cardNumber":"Nomor kartu","placeholders.cardNumberShort":"Nomor","placeholders.company":"Bisnis","placeholders.cvc":"CVC","placeholders.expiry":"BB / TT","placeholders.individual":"Pribadi","placeholders.postal_code":"Kode pos","placeholders.postcode":"Kode pos","placeholders.securityCode":"Kode Keamanan","placeholders.selectBank":"Pilih bank","placeholders.zip":"Kode Pos","button.prb_warning.badge_label":"Upgrade tersedia","button.prb_warning.button_primary":"Upgrade sekarang","button.prb_warning.button_secondary":"Tutup selama seminggu","button.prb_warning.description":"Kami perhatikan Anda menggunakan Tombol Permintaan Pembayaran. Upgrade ke {ece_link} untuk mengakses fitur dan optimisasi terbaru.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Tampilkan beberapa metode pembayaran secara bersamaan, termasuk: Amazon Pay, Link, dan PayPal (hanya di UE).","button.prb_warning.li2":"Dukungan lintas browser untuk Google Pay dan Apple Pay (iOS 18+).","button.prb_warning.li3":"Urutkan dan tampilkan opsi checkout Express yang paling relevan secara dinamis kepada pelanggan Anda.","button.prb_warning.nav_header":"Mode percobaan","button.prb_warning.title":"Upgrade tombol pembayaran sekali klik Anda terdahulu"}')
        },
        90404: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Chiudi finestra di dialogo","button.apple_pay.add_money":"Aggiungi denaro con Apple Pay","button.apple_pay.book":"Prenota con Apple Pay","button.apple_pay.buy":"Acquista con Apple Pay","button.apple_pay.check_out":"Paga con Apple Pay","button.apple_pay.contribute":"Contribuisci con Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Dona con Apple Pay","button.apple_pay.order":"Ordina con Apple Pay","button.apple_pay.reload":"Ricarica con Apple Pay","button.apple_pay.rent":"Noleggia con Apple Pay","button.apple_pay.subscribe":"Abbonati con Apple Pay","button.apple_pay.support":"Supporta con Apple Pay","button.apple_pay.tip":"Dai la mancia con Apple Pay","button.apple_pay.top_up":"Ricarica con Apple Pay","button.cancel":"Annulla","button.change":"Cambia","button.google_pay.buy":"Acquista con Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Dona con Google Pay","button.link.autofill":"Usa dati","button.link.autofill_alt":"Usa","button.link.autofill_aria_label":"Compila automaticamente con Link","button.link.card_clear":"Non utilizzare più Link e inserisci i dati della carta manualmente.","button.link.express_pay":"Pagamento rapido","button.link.manage":"Attualmente paghi con Link utilizzando la carta che termina con {last4}. Scegli una modalità di pagamento diversa.","button.link.manage.cardCvc":"Link in uso. Aggiorna il codice CVC della carta.","button.link.manage.cardExpiry":"Link in uso con una data di scadenza ({expiry}). Aggiorna la data di scadenza della carta.","button.link.manage.postalCode":"Link in uso con un codice postale ({postal}). Aggiorna il codice postale della carta.","button.link.pay_faster":"Paga più veloce","button.link.pay_faster_with":"Paga più veloce con {linkLogo}","button.link.pay_faster_with_link":"Paga più veloce con Link","button.link.pay_with":"Paga con {linkLogo}","button.link.pay_with_last_4":"Paga con ••{last4}","button.link.save_with":"Salva con {linkLogo}","button.link.save_with_aria_label":"Salva con Link","button.link.use_last_4_aria_label":"Compila automaticamente con Link utilizzando una carta che termina con {last4}","button.logout":"Esci","button.pay_with":"Paga con","button.payment_request.book":"Prenota ora","button.payment_request.buy":"Acquista ora","button.payment_request.default":"Paga ora","button.payment_request.donate":"Dona","button.remove":"Rimuovi","button.retry":"Riprova","button.save":"Salva","button.save_with":"Salva con","button.see_more":"Scopri di più","button.update":"Aggiorna","placeholders.accountHolderType":"Tipo di intestatario del conto","placeholders.auBankAccountNumber":"Numero di conto","placeholders.cardNumber":"Numero carta","placeholders.cardNumberShort":"Numero","placeholders.company":"Business","placeholders.cvc":"CVC","placeholders.expiry":"MM / AA","placeholders.individual":"Personale","placeholders.postal_code":"CAP","placeholders.postcode":"CAP","placeholders.securityCode":"Codice di sicurezza","placeholders.selectBank":"Seleziona la banca","placeholders.zip":"CAP","button.prb_warning.badge_label":"Aggiornamento disponibile","button.prb_warning.button_primary":"Esegui l\'aggiornamento ora","button.prb_warning.button_secondary":"Ignora per una settimana","button.prb_warning.description":"Abbiamo notato che stai utilizzando Payment Request Button. Effettua l\'aggiornamento a {ece_link} per accedere alle ultime funzionalità e ottimizzazioni.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Visualizza contemporaneamente più metodi di pagamento, tra cui: Amazon Pay, Link e PayPal (solo nell\'UE).","button.prb_warning.li2":"Supporto su più browser per Google Pay e Apple Pay (iOS 18 e versioni successive).","button.prb_warning.li3":"Ordina e mostra ai clienti in modo dinamico le opzioni di pagamento veloce più pertinenti.","button.prb_warning.nav_header":"Modalità di test","button.prb_warning.title":"Esegui l\'aggiornamento dei pulsanti di pagamento con un clic precedenti"}')
        },
        23344: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"ダイアログを閉じる","button.apple_pay.add_money":"Apple Pay で資金を追加","button.apple_pay.book":"Apple Pay で予約","button.apple_pay.buy":"Apple Pay で購入","button.apple_pay.check_out":"Apple Pay でチェックアウト","button.apple_pay.contribute":"Apple Pay で寄付","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Apple Pay で寄付","button.apple_pay.order":"Apple Pay で注文","button.apple_pay.reload":"Apple Pay で再度読み込む","button.apple_pay.rent":"Apple Pay で借りる","button.apple_pay.subscribe":"ApplePay で登録","button.apple_pay.support":"ApplePay でサポート","button.apple_pay.tip":"Apple Pay でチップを支払う","button.apple_pay.top_up":"Apple Pay でトップアップ","button.cancel":"キャンセル","button.change":"変更","button.google_pay.buy":"Google Pay で購入","button.google_pay.default":"Google Pay","button.google_pay.donate":"Google Pay で寄付","button.link.autofill":"自動入力","button.link.autofill_alt":"使用","button.link.autofill_aria_label":"Link を使用して自動入力する","button.link.card_clear":"Link の使用を停止してカード詳細を手動で入力。","button.link.express_pay":"スピーディーに支払う","button.link.manage":"現在、末尾 4 桁が {last4} のクレジットカードを使用して Link で支払い中です。別の決済手段を選択してください","button.link.manage.cardCvc":"現在、Link を使用しています。カードのセキュリティコードを更新してください。","button.link.manage.cardExpiry":"現在、有効期限が {expiry} に設定された Link を使用しています。カードの有効期限を更新してください。","button.link.manage.postalCode":"現在、郵便番号が {postal} に設定された Link を使用しています。カードの郵便番号を更新してください。","button.link.pay_faster":"スピーディーに支払う","button.link.pay_faster_with":"{linkLogo} を使用してスピーディーに支払う","button.link.pay_faster_with_link":"Link を使用してスピーディーに支払う","button.link.pay_with":"{linkLogo} で支払う","button.link.pay_with_last_4":"••{last4} で支払う","button.link.save_with":"{linkLogo} で保存する","button.link.save_with_aria_label":"Link で保存する","button.link.use_last_4_aria_label":"Link を使用して末尾が {last4} のカードを自動入力する","button.logout":"ログアウト","button.pay_with":"決済手段","button.payment_request.book":"今すぐ予約","button.payment_request.buy":"今すぐ購入","button.payment_request.default":"今すぐ支払う","button.payment_request.donate":"寄付","button.remove":"削除する","button.retry":"再試行","button.save":"保存","button.save_with":"保存方法","button.see_more":"もっと見る","button.update":"更新","placeholders.accountHolderType":"口座名義人の種別","placeholders.auBankAccountNumber":"口座番号","placeholders.cardNumber":"カード番号","placeholders.cardNumberShort":"番号","placeholders.company":"ビジネス","placeholders.cvc":"セキュリティコード","placeholders.expiry":"月 / 年","placeholders.individual":"個人","placeholders.postal_code":"郵便番号","placeholders.postcode":"郵便番号","placeholders.securityCode":"セキュリティコード","placeholders.selectBank":"銀行を選択","placeholders.zip":"郵便番号","button.prb_warning.badge_label":"アップグレードが可能","button.prb_warning.button_primary":"今すぐアップグレードする","button.prb_warning.button_secondary":"1 週間先送りする","button.prb_warning.description":"お客様が支払いリクエストボタンを使用していることがわかりました。最新の機能と最適化にアクセスするには、{ece_link} にアップグレードしてください。","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Amazon Pay、Link、PayPal (EU のみ) をはじめとする複数の決済手段を同時に表示します。","button.prb_warning.li2":"Google Pay および Apple Pay (iOS 18 以上) に対するブラウザーを越えたサポート。","button.prb_warning.li3":"スピーディーな決済オプションを、最も関連度が高い順に動的に並べ替えて顧客に表示します。","button.prb_warning.nav_header":"テスト環境","button.prb_warning.title":"レガシーのワンクリックの支払いボタンをアップグレードしてください"}')
        },
        32557: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"대화 상자 닫기","button.apple_pay.add_money":"Apple Pay로 자금 추가","button.apple_pay.book":"Apple Pay로 예약","button.apple_pay.buy":"Apple Pay로 구매","button.apple_pay.check_out":"Apple Pay로 체크아웃","button.apple_pay.contribute":"Apple Pay로 기부","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Apple Pay로 기부","button.apple_pay.order":"Apple Pay로 주문","button.apple_pay.reload":"Apple Pay로 다시 로드","button.apple_pay.rent":"Apple Pay로 임대료 결제","button.apple_pay.subscribe":"Apple Pay로 구독","button.apple_pay.support":"Apple Pay 지원","button.apple_pay.tip":"Apple Pay로 팁 결제","button.apple_pay.top_up":"Apple Pay로 추가 결제","button.cancel":"취소","button.change":"변경","button.google_pay.buy":"Google Pay로 구매","button.google_pay.default":"Google Pay","button.google_pay.donate":"Google Pay로 기부","button.link.autofill":"자동 입력","button.link.autofill_alt":"사용","button.link.autofill_aria_label":"Link로 자동 채우기","button.link.card_clear":"Link 사용을 중지하고 카드 세부사항을 수동으로 입력하십시오.","button.link.express_pay":"빠른 결제","button.link.manage":"현재 {last4}(으)로 끝나는 카드를 사용하여 Link에 결제 중입니다. 다른 결제 방식을 선택하십시오.","button.link.manage.cardCvc":"현재 Link를 사용하고 있습니다. 카드의 보안 코드(CVC)를 업데이트하십시오.","button.link.manage.cardExpiry":"현재 만료 날짜가 {expiry}인 Link를 사용하고 있습니다. 카드 만료 날짜를 업데이트하십시오.","button.link.manage.postalCode":"현재 우편번호가 {postal}인 Link를 사용하고 있습니다. 카드의 우편번호를 업데이트하십시오.","button.link.pay_faster":"빠른 결제","button.link.pay_faster_with":"{linkLogo}로 빠르게 결제","button.link.pay_faster_with_link":"Link로 더 빠르게 결제하기","button.link.pay_with":"{linkLogo}로 결제","button.link.pay_with_last_4":"••{last4}(으)로 결제","button.link.save_with":"{linkLogo}로 저장","button.link.save_with_aria_label":"Link로 저장","button.link.use_last_4_aria_label":"{last4}(으)로 끝나는 카드로 Link를 사용하여 자동 채우기","button.logout":"로그아웃","button.pay_with":"결제 방식","button.payment_request.book":"지금 예약","button.payment_request.buy":"지금 구매","button.payment_request.default":"지금 결제","button.payment_request.donate":"기부","button.remove":"제거","button.retry":"다시 시도","button.save":"저장","button.save_with":"다음으로 저장","button.see_more":"더 보기","button.update":"업데이트","placeholders.accountHolderType":"계정 소유자 유형","placeholders.auBankAccountNumber":"계좌 번호","placeholders.cardNumber":"카드 번호","placeholders.cardNumberShort":"번호","placeholders.company":"비즈니스","placeholders.cvc":"CVC","placeholders.expiry":"MM / YY","placeholders.individual":"개인","placeholders.postal_code":"우편번호","placeholders.postcode":"우편번호","placeholders.securityCode":"보안 코드","placeholders.selectBank":"은행 선택","placeholders.zip":"우편번호","button.prb_warning.badge_label":"업그레이드 가능","button.prb_warning.button_primary":"지금 바로 업그레이드","button.prb_warning.button_secondary":"1주일 동안 해제","button.prb_warning.description":"결제 요청 버튼을 사용 중인 것으로 보입니다. 최신 기능과 최적화에 액세스하려면 {ece_link}(으)로 업그레이드하십시오.","button.prb_warning.ece_link":"빠른 결제 요소","button.prb_warning.li1":"Amazon Pay, Link, PayPal(EU만 해당)을 포함하여 여러 결제 방식을 동시에 표시합니다.","button.prb_warning.li2":"Google Pay와 Apple Pay에 대해 크로스 브라우저 지원(iOS 18 이상).","button.prb_warning.li3":"고객에게 가장 관련성 있는 빠른 결제 옵션을 동적으로 정렬하여 표시합니다.","button.prb_warning.nav_header":"테스트 모드","button.prb_warning.title":"기존 원클릭 결제 버튼 업그레이드"}')
        },
        21377: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Uždaryti dialogo langą","button.apple_pay.add_money":"Pridėti pinigų naudojant „Apple Pay“","button.apple_pay.book":"Užsisakyti naudojant „Apple Pay“","button.apple_pay.buy":"Pirkti naudojant „Apple Pay“","button.apple_pay.check_out":"Atsiskaityti naudojant „Apple Pay“","button.apple_pay.contribute":"Prisidėti naudojant „Apple Pay“","button.apple_pay.default":"„Apple Pay“","button.apple_pay.donate":"Aukoti naudojant „Apple Pay“","button.apple_pay.order":"Užsakyti naudojant „Apple Pay“","button.apple_pay.reload":"Įkelti iš naujo naudojant „Apple Pay“","button.apple_pay.rent":"Nuomoti naudojant „Apple Pay“","button.apple_pay.subscribe":"Užsiprenumeruoti naudojant „Apple Pay“","button.apple_pay.support":"Pagalba naudojant „Apple Pay“","button.apple_pay.tip":"Palikti arbatpinigių naudojant „Apple Pay“","button.apple_pay.top_up":"Papildyti naudojant „Apple Pay“","button.cancel":"Atšaukti","button.change":"Keisti","button.google_pay.buy":"Pirkti naudojant „Google Pay“","button.google_pay.default":"„Google Pay“","button.google_pay.donate":"Aukoti naudojant „Google Pay“","button.link.autofill":"Naudoti","button.link.autofill_alt":"Naudoti","button.link.autofill_aria_label":"Automatiškai užpildyti naudojant „Link“","button.link.card_clear":"Nebenaudokite „Link“ ir įveskite kortelės duomenis rankiniu būdu.","button.link.express_pay":"Greitas mokėjimas","button.link.manage":"Šiuo metu mokate per „Link“ naudodami kortelę, kuri baigiasi {last4}. Pasirinkite kitą mokėjimo būdą","button.link.manage.cardCvc":"Šiuo metu naudojate „Link“. Atnaujinkite kortelės CVC kodą.","button.link.manage.cardExpiry":"Šiuo metu jūsų „Link“ galiojimo data yra {expiry}. Atnaujinkite kortelės galiojimo datą.","button.link.manage.postalCode":"Šiuo metu „Link“ naudojate su {postal} pašto kodu. Atnaujinkite kortelės pašto kodą.","button.link.pay_faster":"Mokėk greičiau","button.link.pay_faster_with":"Mokėk greičiau {linkLogo}","button.link.pay_faster_with_link":"Mokėti greičiau naudojant „Link“","button.link.pay_with":"Mokėk {linkLogo}","button.link.pay_with_last_4":"Mokėk ••{last4}","button.link.save_with":"Išsaugoti naudojant {linkLogo}","button.link.save_with_aria_label":"Išsaugoti naudojant „Link“","button.link.use_last_4_aria_label":"Automatiškai užpildyti naudojant „Link“ su kortele, kurios numerio paskutiniai skaičiai yra {last4}","button.logout":"Atsijungti","button.pay_with":"Mokėti naudojant","button.payment_request.book":"Užsisakyti dabar","button.payment_request.buy":"Pirkti dabar","button.payment_request.default":"Mokėti dabar","button.payment_request.donate":"Aukoti","button.remove":"Pašalinti","button.retry":"Bandyti dar kartą","button.save":"Išsaugoti","button.save_with":"Išsaugoti naudojant","button.see_more":"Žr. daugiau","button.update":"Atnaujinti","placeholders.accountHolderType":"Paskyros turėtojo tipas","placeholders.auBankAccountNumber":"Sąskaitos numeris","placeholders.cardNumber":"Kortelės numeris","placeholders.cardNumberShort":"Numeris","placeholders.company":"Įmonė","placeholders.cvc":"CVC","placeholders.expiry":"mm / MM","placeholders.individual":"Asmeninė","placeholders.postal_code":"Pašto kodas","placeholders.postcode":"Pašto kodas","placeholders.securityCode":"Saugos kodas","placeholders.selectBank":"Pasirinkti banką","placeholders.zip":"Pašto kodas","button.prb_warning.badge_label":"Galimas atnaujinimas","button.prb_warning.button_primary":"Atnaujinti dabar","button.prb_warning.button_secondary":"Nepaisyti vieną savaitę","button.prb_warning.description":"Pastebėjome, kad naudojate mokėjimo užklausos mygtuką. Atnaujinkite į {ece_link}, kad galėtumėte pasiekti naujausias funkcijas ir optimizacijas.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Vienu metu rodyti kelis mokėjimo būdus, įskaitant: \\"Amazon Pay\\", \\"Link\\" ir \\"PayPal\\" (tik ES).","button.prb_warning.li2":"Kelių naršyklių palaikymas, skirtas \\"Google Pay\\" ir \\"Apple Pay\\" (\\"iOS 18\\" ir naujesnėms versijoms).","button.prb_warning.li3":"Dinamiškai rūšiuokite ir rodykite klientams aktualiausias skubaus pirkimo užbaigimo parinktis.","button.prb_warning.nav_header":"Bandomasis režimas","button.prb_warning.title":"Atnaujinkite senstelėjusius mokėjimo vienu spustelėjimu mygtukus"}')
        },
        22435: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Aizvērt dialoglodziņu","button.apple_pay.add_money":"Papildināt naudu ar Apple Pay","button.apple_pay.book":"Rezervēt ar Apple Pay","button.apple_pay.buy":"Iegādāties ar Apple Pay","button.apple_pay.check_out":"Nopirkt ar Apple Pay","button.apple_pay.contribute":"Iemaksāt ar Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Ziedot ar Apple Pay","button.apple_pay.order":"Pasūtīt ar Apple Pay","button.apple_pay.reload":"Atkārtoti ielādēt ar Apple Pay","button.apple_pay.rent":"Maksāt par īri ar Apple Pay","button.apple_pay.subscribe":"Abonēt ar Apple Pay","button.apple_pay.support":"Atbalstīt ar Apple Pay","button.apple_pay.tip":"Dot dzeramnaudu ar Apple Pay","button.apple_pay.top_up":"Papildināt ar Apple Pay","button.cancel":"Atcelt","button.change":"Mainīt","button.google_pay.buy":"Iegādāties ar Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Ziedot ar Google Pay","button.link.autofill":"Izmantot","button.link.autofill_alt":"Izmantot","button.link.autofill_aria_label":"Automātiski aizpildīt ar Link","button.link.card_clear":"Pārtrauciet izmantot Link un ievadiet kartes informāciju manuāli.","button.link.express_pay":"Ekspress Samaksa","button.link.manage":"Šobrīd maksāšana tiek veikta, izmantojot karti, kas beidzas ar {last4}. Izmantojiet citu maksājuma veidu","button.link.manage.cardCvc":"Šobrīd tiek izmantots Link. Atjauniniet kartes CVC kodu.","button.link.manage.cardExpiry":"Šobrīd tiek izmantots Link ar derīguma termiņu {expiry}. Atjauniniet kartes derīguma termiņu.","button.link.manage.postalCode":"Šobrīd tiek izmantots Link ar pasta indeksu {postal}. Atjauniniet kartes pasta indeksu.","button.link.pay_faster":"Maksāt ātrāk","button.link.pay_faster_with":"Maksāt ātrāk ar {linkLogo}","button.link.pay_faster_with_link":"Maksājiet ātrāk ar Link","button.link.pay_with":"Maksāt ar {linkLogo}","button.link.pay_with_last_4":"Maksāt ••{last4}","button.link.save_with":"Saglabāt ar {linkLogo}","button.link.save_with_aria_label":"Saglabāt ar Link","button.link.use_last_4_aria_label":"Automātiski aizpildīt Link ar karti, kas beidzas ar {last4}","button.logout":"Izrakstīties","button.pay_with":"Maksāt ar","button.payment_request.book":"Rezervēt tagad","button.payment_request.buy":"Iegādāties tūlīt","button.payment_request.default":"Maksāt tūlīt","button.payment_request.donate":"Ziedot","button.remove":"Noņemt","button.retry":"Mēģināt vēlreiz","button.save":"Saglabāt","button.save_with":"Saglabāt ar","button.see_more":"Skatīt vairāk","button.update":"Atjaunināt","placeholders.accountHolderType":"Konta turētāja veids","placeholders.auBankAccountNumber":"Konta numurs","placeholders.cardNumber":"Kartes numurs","placeholders.cardNumberShort":"Numurs","placeholders.company":"Uzņēmums","placeholders.cvc":"CVC","placeholders.expiry":"MM/GG","placeholders.individual":"Personīgais konts","placeholders.postal_code":"Pasta indekss","placeholders.postcode":"Pasta indekss","placeholders.securityCode":"Drošības kods","placeholders.selectBank":"Atlasīt banku","placeholders.zip":"Pasta indekss","button.prb_warning.badge_label":"Pieejams atjauninājums","button.prb_warning.button_primary":"Atjaunināt tagad","button.prb_warning.button_secondary":"Noraidīt uz vienu nedēļu","button.prb_warning.description":"Mēs pamanījām, ka izmantojat maksājuma pieprasījuma pogu. Atjauniniet uz {ece_link}, lai piekļūtu jaunākajām funkcijām un optimizācijām.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Parādīt vairākus maksājumu veidus vienlaicīgi, tostarp: Amazon Pay, Link un PayPal (tikai ES).","button.prb_warning.li2":"Vairāku pārlūku atbalsts lietotnēm Google Pay un Apple Pay (iOS 18+).","button.prb_warning.li3":"Kārtojiet un dinamiski parādiet saviem klientiem visatbilstošākās ātrās norēķināšanās iespējas.","button.prb_warning.nav_header":"Testa režīms","button.prb_warning.title":"Atjauniniet savas mantotā viena klikšķa maksājuma pogas"}')
        },
        95139: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Tutup Dialog","button.apple_pay.add_money":"Tambah Wang dengan Apple Pay","button.apple_pay.book":"Tempah dengan Apple Pay","button.apple_pay.buy":"Beli dengan Apple Pay","button.apple_pay.check_out":"Bayar dan keluar dengan Apple Pay","button.apple_pay.contribute":"Sumbang dengan Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Derma dengan Apple Pay","button.apple_pay.order":"Pesan dengan Apple Pay","button.apple_pay.reload":"Muatkan semula dengan Apple Pay","button.apple_pay.rent":"Sewa dengan Apple Pay","button.apple_pay.subscribe":"Langgan dengan Apple Pay","button.apple_pay.support":"Sokong dengan Apple Pay","button.apple_pay.tip":"Berikan tip dengan Apple Pay","button.apple_pay.top_up":"Tambah Nilai dengan Apple Pay","button.cancel":"Batalkan","button.change":"Ubah","button.google_pay.buy":"Beli dengan Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Derma dengan Google Pay","button.link.autofill":"Autoisi","button.link.autofill_alt":"Gunakan","button.link.autofill_aria_label":"Isi secara automatik dengan Link","button.link.card_clear":"Berhenti menggunakan Link dan masukkan butiran kad secara manual.","button.link.express_pay":"Bayar ekspres","button.link.manage":"Pembayaran dibuat pada masa ini dengan Link menggunakan kad yang berakhir dengan {last4}. Pilih kaedah pembayaran yang berbeza.","button.link.manage.cardCvc":"Pada masa ini anda menggunakan Link. Kemas kinikan kod CVC kad tersebut.","button.link.manage.cardExpiry":"Pada masa ini anda menggunakan Link dengan tarikh tamat tempoh {expiry}. Kemas kinikan tarikh tamat tempoh kad tersebut.","button.link.manage.postalCode":"Pada masa ini anda menggunakan Link dengan poskod {postal}. Kemas kinikan poskod kad tersebut.","button.link.pay_faster":"Bayar cepat","button.link.pay_faster_with":"Bayar cepat guna {linkLogo}","button.link.pay_faster_with_link":"Bayar dengan lebih cepat menggunakan Link","button.link.pay_with":"Bayar guna {linkLogo}","button.link.pay_with_last_4":"Bayar guna ••{last4}","button.link.save_with":"Simpan dengan {linkLogo}","button.link.save_with_aria_label":"Simpan dengan Link","button.link.use_last_4_aria_label":"Isi secara automatik menggunakan Link dengan kad yang berakhir dengan {last4}","button.logout":"Log keluar","button.pay_with":"Bayar dengan","button.payment_request.book":"Tempah sekarang","button.payment_request.buy":"Beli sekarang","button.payment_request.default":"Bayar sekarang","button.payment_request.donate":"Derma","button.remove":"Alih Keluar","button.retry":"Cuba semula","button.save":"Simpan","button.save_with":"Simpan dengan","button.see_more":"Lihat selanjutnya","button.update":"Kemas Kinikan","placeholders.accountHolderType":"Jenis pemegang akaun","placeholders.auBankAccountNumber":"Nombor akaun","placeholders.cardNumber":"Nombor kad","placeholders.cardNumberShort":"Nombor","placeholders.company":"Perniagaan","placeholders.cvc":"CVC","placeholders.expiry":"BB/TT","placeholders.individual":"Persendirian","placeholders.postal_code":"Poskod","placeholders.postcode":"Poskod","placeholders.securityCode":"Kod Keselamatan","placeholders.selectBank":"Pilih bank","placeholders.zip":"ZIP","button.prb_warning.badge_label":"Penaiktarafan tersedia","button.prb_warning.button_primary":"Naik taraf sekarang","button.prb_warning.button_secondary":"Ketepikan untuk satu minggu","button.prb_warning.description":"Kami mendapati anda menggunakan Butang Permintaan Pembayaran. Naik taraf kepada {ece_link} untuk mendapatkan akses kepada ciri dan pengoptimuman terkini.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Paparkan berbilang kaedah pembayaran serentak, termasuk: Amazon Pay, Link dan PayPal (di EU sahaja).","button.prb_warning.li2":"Sokongan rentas pelayar untuk Google Pay dan Apple Pay (iOS 18+).","button.prb_warning.li3":"Isih dan paparkan pilihan bayar dan keluar ekspres yang paling berkaitan kepada pelanggan anda secara dinamik.","button.prb_warning.nav_header":"Mod ujian","button.prb_warning.title":"Naik taraf butang legasi anda bagi pembayaran satu klik"}')
        },
        379: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Agħlaq it-Tieqa","button.apple_pay.add_money":"Żid il-Flus permezz ta\' Apple Pay","button.apple_pay.book":"Ibbukkja b\'Apple Pay","button.apple_pay.buy":"Ixtri b\'Apple Pay","button.apple_pay.check_out":"Agħmel checkout permezz ta\' Apple Pay","button.apple_pay.contribute":"Ikkontribwixxi permezz ta\' Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Agħti donazzjoni b\'Apple Pay","button.apple_pay.order":"Ordna permezz ta\' Apple Pay","button.apple_pay.reload":"Irrilowdja permezz ta\' Apple Pay","button.apple_pay.rent":"Ikri permezz ta\' Apple Pay","button.apple_pay.subscribe":"Abbona permezz ta\' Apple Pay","button.apple_pay.support":"Appoġġja permezz ta\' Apple Pay","button.apple_pay.tip":"Agħti tipp permezz ta\' Apple Pay","button.apple_pay.top_up":"Ittoppja permezz ta\' Apple Pay","button.cancel":"Ikkanċella","button.change":"Ibdel","button.google_pay.buy":"Ixtri b\'Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Agħmel donazzjoni bil-Google Pay","button.link.autofill":"Uża","button.link.autofill_alt":"Uża","button.link.autofill_aria_label":"Imla awtomatikament grazzi għal Link","button.link.card_clear":"Tkomplix tuża Link u daħħal id-dettalji tal-karta int stess.","button.link.express_pay":"Ħallas malajr","button.link.manage":"Bħalissa qed tħallas b\'Link minn karta b\'numru li jintemm b\'\'{last4}. Agħżel metodu tal-pagament ieħor","button.link.manage.cardCvc":"Bħalissa qed tuża Link. Ibdel il-kodiċi CVC tal-karta.","button.link.manage.cardExpiry":"Bħalissa qed tuża Link b\'din id-data tal-iskadenza: {expiry}. Ibdel id-data tal-iskadenza tal-karta.","button.link.manage.postalCode":"Bħalissa qed tuża Link b\'kodiċi postali ta\' {postal}. Aġġorna l-kodiċi postali tal-karta.","button.link.pay_faster":"Ħallas malajr","button.link.pay_faster_with":"Ħallas malajr b\' {linkLogo}","button.link.pay_faster_with_link":"Ħallas iktar malajr grazzi għal Link","button.link.pay_with":"Ħallas b\' {linkLogo}","button.link.pay_with_last_4":"Ħallas b\'••{last4}","button.link.save_with":"Erfa\' ma\' {linkLogo}","button.link.save_with_aria_label":"Erfa\' ma\' Link","button.link.use_last_4_aria_label":"Imla d-dettalji awtomatikament billi tuża Link b\'karta li tispiċċa {last4}","button.logout":"Oħroġ","button.pay_with":"Ħallas billi tuża","button.payment_request.book":"Ibbukkja issa","button.payment_request.buy":"Ixtri issa","button.payment_request.default":"Ħallas issa","button.payment_request.donate":"Agħti donazzjoni","button.remove":"Neħħi","button.retry":"Erġa\' pprova","button.save":"Issejvja","button.save_with":"Erfa\' ma\'","button.see_more":"Ara iktar","button.update":"Aġġorna","placeholders.accountHolderType":"Ix-xorta tad-detentur tal-kont","placeholders.auBankAccountNumber":"In-numru tal-kont","placeholders.cardNumber":"In-numru tal-karta","placeholders.cardNumberShort":"Numru","placeholders.company":"Negozju","placeholders.cvc":"CVC","placeholders.expiry":"XX / SS","placeholders.individual":"Personali","placeholders.postal_code":"Kodiċi postali","placeholders.postcode":"Kodiċi postali","placeholders.securityCode":"Kodiċi tas-Sigurtà","placeholders.selectBank":"Agħżel bank","placeholders.zip":"Kodiċi Postali","button.prb_warning.badge_label":"Aġġornament disponibbli","button.prb_warning.button_primary":"Ibdel issa","button.prb_warning.button_secondary":"Tagħtix kas għal ġimgħa","button.prb_warning.description":"Innutajna li qed tuża l-Buttuna Itlob Pagament. Ibdilha għal {ece_link} biex tikseb aċċess għall-aħħar faċilitajiet u titjibiet.","button.prb_warning.ece_link":"Element ta\' Express Checkout","button.prb_warning.li1":"Uri ħafna metodi tal-pagament fl-istess ħin fosthom Amazon Pay, Link u PayPal (fl-UE biss).","button.prb_warning.li2":"Google Pay u Apple Pay (iOS 18+) kompatibbli ma\' għadd ta\' brawżers.","button.prb_warning.li3":"Sarbat u, skont il-każ, uri l-għażliet tal-ħlas ta\' malajr li l-iktar jgħoddu għall-klijenti tiegħek.","button.prb_warning.nav_header":"Modalità ta\' prova","button.prb_warning.title":"Ibdel il-buttuni tal-pagamenti b\'mossa waħda l-qodma tiegħek"}')
        },
        30228: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Lukk dialog","button.apple_pay.add_money":"Legg til penger med Apple Pay","button.apple_pay.book":"Bestill med Apple Pay","button.apple_pay.buy":"Kjøp med Apple Pay","button.apple_pay.check_out":"Betal med Apple Pay","button.apple_pay.contribute":"Bidra med Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Doner med Apple Pay","button.apple_pay.order":"Bestill med Apple Pay","button.apple_pay.reload":"Last på nytt med Apple Pay","button.apple_pay.rent":"Lei med Apple Pay","button.apple_pay.subscribe":"Abonner med Apple Pay","button.apple_pay.support":"Støtt med Apple Pay","button.apple_pay.tip":"Gi tips med Apple Pay","button.apple_pay.top_up":"Fyll opp med Apple Pay","button.cancel":"Avbryt","button.change":"Endre","button.google_pay.buy":"Kjøp med Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Doner med Google Pay","button.link.autofill":"Autofyll","button.link.autofill_alt":"Bruk","button.link.autofill_aria_label":"Fyll inn automatisk med LInk","button.link.card_clear":"Slutt å bruke Link og skriv inn kortopplysninger manuelt.","button.link.express_pay":"Ekspressbetaling","button.link.manage":"Du betaler for øyeblikket med Link med kortet som slutter på {last4}. Velg en annen betalingsmetode","button.link.manage.cardCvc":"Bruker for øyeblikket Link. Oppdater kortets CVC-kode.","button.link.manage.cardExpiry":"Bruker for øyeblikket Link med utløpsdatoen {expiry}. Oppdater kortets utløpsdato.","button.link.manage.postalCode":"Bruker for øyeblikket Link med postnummeret {postal}. Oppdater kortets postnummer.","button.link.pay_faster":"Betal raskere","button.link.pay_faster_with":"Betal raskt med {linkLogo}","button.link.pay_faster_with_link":"Betal raskere med Link","button.link.pay_with":"Betal med {linkLogo}","button.link.pay_with_last_4":"Betal med ••{last4}","button.link.save_with":"Lagre med {linkLogo}","button.link.save_with_aria_label":"Lagre med Link","button.link.use_last_4_aria_label":"Fyll inn automatisk ved hjelp av Link med et kort som slutter på {last4}","button.logout":"Logg ut","button.pay_with":"Betal med","button.payment_request.book":"Bestill nå","button.payment_request.buy":"Kjøp nå","button.payment_request.default":"Betal","button.payment_request.donate":"Doner","button.remove":"Fjern","button.retry":"Prøv på nytt","button.save":"Lagre","button.save_with":"Lagre med","button.see_more":"Se mer","button.update":"Oppdater","placeholders.accountHolderType":"Type kontoinnehaver","placeholders.auBankAccountNumber":"Kontonummer","placeholders.cardNumber":"Kortnummer","placeholders.cardNumberShort":"Nummer","placeholders.company":"Bedrift","placeholders.cvc":"CVC","placeholders.expiry":"MM / ÅÅ","placeholders.individual":"Personlig","placeholders.postal_code":"Postnr","placeholders.postcode":"Postnr","placeholders.securityCode":"Sikkerhetskode","placeholders.selectBank":"Velg bank","placeholders.zip":"ZIP","button.prb_warning.badge_label":"Oppgradering er tilgjengelig","button.prb_warning.button_primary":"Oppgrader nå","button.prb_warning.button_secondary":"Avvis i én uke","button.prb_warning.description":"Vi la merke til at du bruker knappen for betalingsforespørsel. Oppgrader til {ece_link} for å få tilgang til de nyeste funksjonene og optimaliseringene.","button.prb_warning.ece_link":"Express Checkout-element","button.prb_warning.li1":"Vis flere betalingsmåter samtidig, inkludert: Amazon Pay, Link og PayPal (kun i EU).","button.prb_warning.li2":"Støtte for flere nettlesere for Google Pay og Apple Pay (iOS 18+).","button.prb_warning.li3":"Sorter og vis de mest relevante hurtigkassealternativene dynamisk til kundene dine.","button.prb_warning.nav_header":"Testmodus","button.prb_warning.title":"Oppgrader de gamle betalingsknappene med ett klikk"}')
        },
        80385: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Dialoogvenster sluiten","button.apple_pay.add_money":"Geld toevoegen met Apple Pay","button.apple_pay.book":"Boeken met Apple Pay","button.apple_pay.buy":"Kopen met Apple Pay","button.apple_pay.check_out":"Betalen met Apple Pay","button.apple_pay.contribute":"Bijdragen met Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Doneren met Apple Pay","button.apple_pay.order":"Bestellen met Apple Pay","button.apple_pay.reload":"Laden met Apple Pay","button.apple_pay.rent":"Huren met Apple Pay","button.apple_pay.subscribe":"Abonneren met Apple Pay","button.apple_pay.support":"Ondersteunen met Apple Pay","button.apple_pay.tip":"Fooi geven met Apple Pay","button.apple_pay.top_up":"Opwaarderen met Apple Pay","button.cancel":"Annuleren","button.change":"Wijzigen","button.google_pay.buy":"Kopen met Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Doneren met Google Pay","button.link.autofill":"AutoVullen","button.link.autofill_alt":"Gebruiken","button.link.autofill_aria_label":"Automatisch invullen met Link","button.link.card_clear":"Link niet meer gebruiken en kaartgegevens handmatig invoeren.","button.link.express_pay":"Sneller betalen","button.link.manage":"Je betaalt nu via Link met de betaalkaart die eindigt op {last4}. Kies een andere betaalmethode","button.link.manage.cardCvc":"Link wordt momenteel gebruikt. Werk de CVC-code van de betaalkaart bij.","button.link.manage.cardExpiry":"Link wordt momenteel gebruikt met vervaldatum {expiry}. Werk de vervaldatum van de kaart bij.","button.link.manage.postalCode":"Link wordt momenteel gebruikt met postcode {postal}. Werk de postcode van de kaart bij.","button.link.pay_faster":"Sneller betalen","button.link.pay_faster_with":"Betaal snel met {linkLogo}","button.link.pay_faster_with_link":"Sneller betalen met Link","button.link.pay_with":"Betalen met {linkLogo}","button.link.pay_with_last_4":"Betalen met ••{last4}","button.link.save_with":"Opslaan met {linkLogo}","button.link.save_with_aria_label":"Opslaan met Link","button.link.use_last_4_aria_label":"Automatisch invullen met Link bij een betaalkaart die eindigt op {last4}","button.logout":"Afmelden","button.pay_with":"Betalen met","button.payment_request.book":"Nu boeken","button.payment_request.buy":"Nu kopen","button.payment_request.default":"Betalen","button.payment_request.donate":"Doneren","button.remove":"Verwijderen","button.retry":"Opnieuw","button.save":"Opslaan","button.save_with":"Opslaan met","button.see_more":"Meer bekijken","button.update":"Bijwerken","placeholders.accountHolderType":"Type rekeninghouder","placeholders.auBankAccountNumber":"Rekeningnummer","placeholders.cardNumber":"Kaartnummer","placeholders.cardNumberShort":"Nummer","placeholders.company":"Zakelijk","placeholders.cvc":"CVC","placeholders.expiry":"MM / JJ","placeholders.individual":"Privé","placeholders.postal_code":"Postcode","placeholders.postcode":"Postcode","placeholders.securityCode":"Beveiligingscode","placeholders.selectBank":"Bank selecteren","placeholders.zip":"Postcode","button.prb_warning.badge_label":"Upgrade beschikbaar","button.prb_warning.button_primary":"Nu upgraden","button.prb_warning.button_secondary":"Eén week uitstellen","button.prb_warning.description":"We hebben gemerkt dat je de knop Betaalverzoek gebruikt. Voer een upgrade uit naar {ece_link} voor toegang tot de nieuwste functies en optimalisaties.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Meerdere betaalmethoden tegelijkertijd weergeven, inclusief Amazon Pay, Link en PayPal (alleen in de EU).","button.prb_warning.li2":"Ondersteuning voor meerdere browsers voor Google Pay en Apple Pay (iOS 18+).","button.prb_warning.li3":"Sorteer en geef de meest relevante Express Checkout-opties dynamisch weer aan je klanten.","button.prb_warning.nav_header":"Testmodus","button.prb_warning.title":"Verouderde knoppen voor betalen met één klik bijwerken"}')
        },
        42619: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Dialoogvenster sluiten","button.apple_pay.add_money":"Geld toevoegen met Apple Pay","button.apple_pay.book":"Boeken met Apple Pay","button.apple_pay.buy":"Kopen met Apple Pay","button.apple_pay.check_out":"Betalen met Apple Pay","button.apple_pay.contribute":"Bijdragen met Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Doneren met Apple Pay","button.apple_pay.order":"Bestellen met Apple Pay","button.apple_pay.reload":"Laden met Apple Pay","button.apple_pay.rent":"Huren met Apple Pay","button.apple_pay.subscribe":"Abonneren met Apple Pay","button.apple_pay.support":"Ondersteunen met Apple Pay","button.apple_pay.tip":"Fooi geven met Apple Pay","button.apple_pay.top_up":"Opwaarderen met Apple Pay","button.cancel":"Annuleren","button.change":"Wijzigen","button.google_pay.buy":"Kopen met Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Doneren met Google Pay","button.link.autofill":"AutoVullen","button.link.autofill_alt":"Gebruiken","button.link.autofill_aria_label":"Automatisch invullen met Link","button.link.card_clear":"Link niet meer gebruiken en kaartgegevens handmatig invoeren.","button.link.express_pay":"Sneller betalen","button.link.manage":"Je betaalt nu via Link met de betaalkaart die eindigt op {last4}. Kies een andere betaalmethode","button.link.manage.cardCvc":"Link wordt momenteel gebruikt. Werk de CVC-code van de betaalkaart bij.","button.link.manage.cardExpiry":"Link wordt momenteel gebruikt met vervaldatum {expiry}. Werk de vervaldatum van de kaart bij.","button.link.manage.postalCode":"Link wordt momenteel gebruikt met postcode {postal}. Werk de postcode van de kaart bij.","button.link.pay_faster":"Sneller betalen","button.link.pay_faster_with":"Betaal snel met {linkLogo}","button.link.pay_faster_with_link":"Sneller betalen met Link","button.link.pay_with":"Betalen met {linkLogo}","button.link.pay_with_last_4":"Betalen met ••{last4}","button.link.save_with":"Opslaan met {linkLogo}","button.link.save_with_aria_label":"Opslaan met Link","button.link.use_last_4_aria_label":"Automatisch invullen met Link bij een betaalkaart die eindigt op {last4}","button.logout":"Afmelden","button.pay_with":"Betalen met","button.payment_request.book":"Nu boeken","button.payment_request.buy":"Nu kopen","button.payment_request.default":"Betalen","button.payment_request.donate":"Doneren","button.remove":"Verwijderen","button.retry":"Opnieuw","button.save":"Opslaan","button.save_with":"Opslaan met","button.see_more":"Meer bekijken","button.update":"Bijwerken","placeholders.accountHolderType":"Type rekeninghouder","placeholders.auBankAccountNumber":"Rekeningnummer","placeholders.cardNumber":"Kaartnummer","placeholders.cardNumberShort":"Nummer","placeholders.company":"Zakelijk","placeholders.cvc":"CVC","placeholders.expiry":"MM / JJ","placeholders.individual":"Privé","placeholders.postal_code":"Postcode","placeholders.postcode":"Postcode","placeholders.securityCode":"Beveiligingscode","placeholders.selectBank":"Bank selecteren","placeholders.zip":"Postcode","button.prb_warning.badge_label":"Upgrade beschikbaar","button.prb_warning.button_primary":"Nu upgraden","button.prb_warning.button_secondary":"Eén week uitstellen","button.prb_warning.description":"We hebben gemerkt dat je de knop Betaalverzoek gebruikt. Voer een upgrade uit naar {ece_link} voor toegang tot de nieuwste functies en optimalisaties.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Meerdere betaalmethoden tegelijkertijd weergeven, inclusief Amazon Pay, Link en PayPal (alleen in de EU).","button.prb_warning.li2":"Ondersteuning voor meerdere browsers voor Google Pay en Apple Pay (iOS 18+).","button.prb_warning.li3":"Sorteer en geef de meest relevante Express Checkout-opties dynamisch weer aan je klanten.","button.prb_warning.nav_header":"Testmodus","button.prb_warning.title":"Verouderde knoppen voor betalen met één klik bijwerken"}')
        },
        75764: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Zamknij okno dialogowe","button.apple_pay.add_money":"Dodaj pieniądze z Apple Pay","button.apple_pay.book":"Rezerwuj, używając Apple Pay","button.apple_pay.buy":"Kup przy użyciu Apple Pay","button.apple_pay.check_out":"Zapłać z Apple Pay","button.apple_pay.contribute":"Przekaż wkład z Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Przekaż darowiznę przy użyciu Apple Pay","button.apple_pay.order":"Zamów z Apple Pay","button.apple_pay.reload":"Wykonaj operację typu reload z Apple Pay","button.apple_pay.rent":"Wynajmij z Apple Pay","button.apple_pay.subscribe":"Zasubskrybuj z Apple Pay","button.apple_pay.support":"Wesprzyj z Apple Pay","button.apple_pay.tip":"Przekaż napiwek z Apple Pay","button.apple_pay.top_up":"Wyrównaj z Apple Pay","button.cancel":"Anuluj","button.change":"Zmień","button.google_pay.buy":"Kup przy użyciu Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Przekaż darowiznę przy użyciu Google Pay","button.link.autofill":"Uzupełnij","button.link.autofill_alt":"Użyj","button.link.autofill_aria_label":"Automatycznie uzupełnianie za pomocą Link","button.link.card_clear":"Przestań używać Link i wprowadzaj dane karty ręcznie.","button.link.express_pay":"Płać ekspresowo","button.link.manage":"Obecnie płacisz z Link, korzystając z karty o numerze kończącym się na {last4}. Wybierz inną metodę płatności","button.link.manage.cardCvc":"Obecnie używasz karty Link. Zaktualizuj kod CVC karty.","button.link.manage.cardExpiry":"Obecnie używasz karty Link z datą ważności {expiry}. Zaktualizuj datę ważności karty.","button.link.manage.postalCode":"Obecnie używasz karty Link z kodem pocztowym {postal}. Zaktualizuj kod pocztowy karty.","button.link.pay_faster":"Zapłać szybciej","button.link.pay_faster_with":"Zapłać szybciej z {linkLogo}","button.link.pay_faster_with_link":"Płać szybciej z Link","button.link.pay_with":"Zapłać z {linkLogo}","button.link.pay_with_last_4":"Zapłać z ••{last4}","button.link.save_with":"Zapisz za pomocą {linkLogo}","button.link.save_with_aria_label":"Zapisz z Link","button.link.use_last_4_aria_label":"Automatycznie uzupełniaj dane karty o numerze kończącym się cyframi {last4} za pomocą Link","button.logout":"Wyloguj się","button.pay_with":"Zapłać za pomocą","button.payment_request.book":"Rezerwuj teraz","button.payment_request.buy":"Kup teraz","button.payment_request.default":"Zapłać teraz","button.payment_request.donate":"Przekaż darowiznę","button.remove":"Usuń","button.retry":"Ponów próbę","button.save":"Zapisz","button.save_with":"Zapisz za pomocą","button.see_more":"Zobacz więcej","button.update":"Aktualizuj","placeholders.accountHolderType":"Typ własności rachunku","placeholders.auBankAccountNumber":"Numer konta","placeholders.cardNumber":"Numer karty","placeholders.cardNumberShort":"Numer","placeholders.company":"Firmowe","placeholders.cvc":"Kod CVC","placeholders.expiry":"MM / RR","placeholders.individual":"Osobiste","placeholders.postal_code":"Kod pocztowy","placeholders.postcode":"Kod pocztowy","placeholders.securityCode":"Kod bezpieczeństwa","placeholders.selectBank":"Wybierz bank","placeholders.zip":"Kod pocztowy","button.prb_warning.badge_label":"Uaktualnienie dostępne","button.prb_warning.button_primary":"Uaktualnij teraz","button.prb_warning.button_secondary":"Odrzucaj przez jeden tydzień","button.prb_warning.description":"Zauważyliśmy, że korzystasz z przycisku żądania płatności. Uaktualnij do wersji {ece_link}, aby uzyskać dostęp do najnowszych funkcji i optymalizacji.","button.prb_warning.ece_link":"Element szybkiej finalizacji","button.prb_warning.li1":"Wyświetlaj jednocześnie różne metody płatności, w tym: Amazon Pay, Link oraz PayPal (tylko w UE).","button.prb_warning.li2":"Obsługa krzyżowa przeglądarek dla Google Pay i Apple Pay (iOS 18+).","button.prb_warning.li3":"Dynamicznie sortuj i wyświetlaj najbardziej istotne opcje szybkiej finalizacji dla swoich klientów.","button.prb_warning.nav_header":"Tryb testowy","button.prb_warning.title":"Uaktualnij starsze przyciski płatności jednym kliknięciem"}')
        },
        41605: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Fechar caixa de diálogo","button.apple_pay.add_money":"Adicionar dinheiro com Apple Pay","button.apple_pay.book":"Reservar com Apple Pay","button.apple_pay.buy":"Comprar com Apple Pay","button.apple_pay.check_out":"Fazer check out com Apple Pay","button.apple_pay.contribute":"Contribuir com Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Faça uma doação com Apple Pay","button.apple_pay.order":"Fazer pedido com Apple Pay","button.apple_pay.reload":"Recarregar com Apple Pay","button.apple_pay.rent":"Alugar com Apple Pay","button.apple_pay.subscribe":"Assinar com Apple Pay","button.apple_pay.support":"Apoiar com Apple Pay","button.apple_pay.tip":"Dar gorjeta com Apple Pay","button.apple_pay.top_up":"Fazer recarga com Apple Pay","button.cancel":"Cancelar","button.change":"Alterar","button.google_pay.buy":"Comprar com Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Faça uma doação com Google Pay","button.link.autofill":"Usar","button.link.autofill_alt":"Usar","button.link.autofill_aria_label":"Preencher automaticamente com o Link","button.link.card_clear":"Pare de usar o Link e insira os dados do cartão manualmente.","button.link.express_pay":"Pague já","button.link.manage":"Pagando atualmente com o Link no cartão terminado em {last4}. Escolha uma forma de pagamento diferente","button.link.manage.cardCvc":"Atualmente usando o Link. Atualize o código CVC do cartão.","button.link.manage.cardExpiry":"Atualmente usando o Link com uma data de validade de {expiry}. Atualize a data de validade do cartão.","button.link.manage.postalCode":"Atualmente usando o Link com um código postal de {postal}. Atualize o código postal do cartão.","button.link.pay_faster":"Pague rápido","button.link.pay_faster_with":"Pague rápido com {linkLogo}","button.link.pay_faster_with_link":"Pague mais rápido com o Link","button.link.pay_with":"Pagar com {linkLogo}","button.link.pay_with_last_4":"Pagar com ••{last4}","button.link.save_with":"Salvar com {linkLogo}","button.link.save_with_aria_label":"Salvar com Link","button.link.use_last_4_aria_label":"Preencher automaticamente com um cartão terminado em {last4}","button.logout":"Fazer logout","button.pay_with":"Pagar com","button.payment_request.book":"Reservar agora","button.payment_request.buy":"Compre agora","button.payment_request.default":"Pague agora","button.payment_request.donate":"Faça uma doação","button.remove":"Remover","button.retry":"Tentar novamente","button.save":"Salvar","button.save_with":"Salvar com","button.see_more":"Ver mais","button.update":"Atualizar","placeholders.accountHolderType":"Tipo de titular da conta","placeholders.auBankAccountNumber":"Número da conta","placeholders.cardNumber":"Número do cartão","placeholders.cardNumberShort":"Número","placeholders.company":"Empresa","placeholders.cvc":"CVC","placeholders.expiry":"MM / AA","placeholders.individual":"Pessoal","placeholders.postal_code":"Código postal","placeholders.postcode":"Código postal","placeholders.securityCode":"Código de segurança","placeholders.selectBank":"Selecione o banco","placeholders.zip":"CEP","button.prb_warning.badge_label":"Atualização disponível","button.prb_warning.button_primary":"Fazer upgrade agora","button.prb_warning.button_secondary":"Descartar por uma semana","button.prb_warning.description":"Notamos que você está usando o botão Solicitar pagamento. Atualize para o {ece_link} para acessar os últimos recursos e otimizações.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Exiba várias formas de pagamento simultaneamente, incluindo: Amazon Pay, Link e PayPal (somente na UE).","button.prb_warning.li2":"Compatibilidade entre navegadores para Google Pay e Apple Pay (iOS 18+).","button.prb_warning.li3":"Ordene e exiba dinamicamente as opções de checkout expresso mais relevantes para os seus clientes.","button.prb_warning.nav_header":"Modo de teste","button.prb_warning.title":"Atualize seus botões de pagamento com um clique herdados"}')
        },
        29138: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Fechar caixa de diálogo","button.apple_pay.add_money":"Adicionar dinheiro com Apple Pay","button.apple_pay.book":"Reservar com Apple Pay","button.apple_pay.buy":"Comprar com Apple Pay","button.apple_pay.check_out":"Finalizar compra com Apple Pay","button.apple_pay.contribute":"Contribuir com Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Doar com Apple Pay","button.apple_pay.order":"Encomendar com Apple Pay","button.apple_pay.reload":"Recarregar com Apple Pay","button.apple_pay.rent":"Alugar com Apple Pay","button.apple_pay.subscribe":"Subscrever com Apple Pay","button.apple_pay.support":"Aceitar com Apple Pay","button.apple_pay.tip":"Deixar gorjeta com Apple Pay","button.apple_pay.top_up":"Carregar com Apple Pay","button.cancel":"Cancelar","button.change":"Alterar","button.google_pay.buy":"Comprar com Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Doar com Google Pay","button.link.autofill":"Utilizar","button.link.autofill_alt":"Utilizar","button.link.autofill_aria_label":"Preencher automaticamente com Link","button.link.card_clear":"Parar de utilizar o Link e introduzir detalhes do cartão manualmente.","button.link.express_pay":"Pague já","button.link.manage":"A pagar atualmente com Link utilizando o cartão que termina em {last4}. Escolha um método de pagamento diferente","button.link.manage.cardCvc":"Está atualmente a utilizar o Link. Atualize o código CVC do cartão.","button.link.manage.cardExpiry":"Está atualmente a utilizar o Link com uma data de validade de {expiry}. Atualize a data de validade do cartão.","button.link.manage.postalCode":"Está atualmente a utilizar o Link com o código postal {postal}. Atualize o código postal do cartão.","button.link.pay_faster":"Pagar rápido","button.link.pay_faster_with":"Pagar agora com {linkLogo}","button.link.pay_faster_with_link":"Pagar mais rapidamente com Link","button.link.pay_with":"Pagar com {linkLogo}","button.link.pay_with_last_4":"Pagar com ••{last4}","button.link.save_with":"Guardar com {linkLogo}","button.link.save_with_aria_label":"Guardar com Link","button.link.use_last_4_aria_label":"Preencher automaticamente com o Link com o cartão terminado em {last4}","button.logout":"Terminar sessão","button.pay_with":"Pagar com","button.payment_request.book":"Reservar agora","button.payment_request.buy":"Comprar agora","button.payment_request.default":"Pagar agora","button.payment_request.donate":"Doar","button.remove":"Remover","button.retry":"Tentar novamente","button.save":"Guardar","button.save_with":"Guardar com","button.see_more":"Ver mais","button.update":"Atualizar","placeholders.accountHolderType":"Tipo de titular da conta","placeholders.auBankAccountNumber":"Número da conta","placeholders.cardNumber":"Número do cartão","placeholders.cardNumberShort":"Número","placeholders.company":"Negócio","placeholders.cvc":"CVC","placeholders.expiry":"MM/AA","placeholders.individual":"Pessoal","placeholders.postal_code":"Código postal","placeholders.postcode":"Código postal","placeholders.securityCode":"Código de segurança","placeholders.selectBank":"Selecionar banco","placeholders.zip":"CP","button.prb_warning.badge_label":"Atualização disponível","button.prb_warning.button_primary":"Atualizar agora","button.prb_warning.button_secondary":"Ignorar por uma semana","button.prb_warning.description":"Reparámos que está a utilizar o botão de pedido de pagamento. Atualize para o {ece_link} para aceder às mais recentes características e otimizações.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Apresente vários métodos de pagamento em simultâneo, incluindo: Amazon Pay, Link e PayPal (apenas na UE).","button.prb_warning.li2":"Compatibilidade entre navegadores para Google Pay e Apple Pay (iOS 18+).","button.prb_warning.li3":"Ordene e apresente dinamicamente aos seus clientes as opções de finalização de compra rápida mais relevantes.","button.prb_warning.nav_header":"Modo de teste","button.prb_warning.title":"Atualize os seus antigos botões de pagamento com um clique"}')
        },
        51001: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Închidere casetă de dialog","button.apple_pay.add_money":"Adăugați bani prin intermediul Apple Pay","button.apple_pay.book":"Rezervați prin intermediul Apple Pay","button.apple_pay.buy":"Cumpărați prin intermediul Apple Pay","button.apple_pay.check_out":"Finalizați comanda prin intermediul Apple Pay","button.apple_pay.contribute":"Contribuiți prin intermediul Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Donați prin intermediul Apple Pay","button.apple_pay.order":"Comandați prin intermediul Apple Pay","button.apple_pay.reload":"Reîncărcați prin intermediul Apple Pay","button.apple_pay.rent":"Închiriați prin intermediul Apple Pay","button.apple_pay.subscribe":"Abonați-vă prin intermediul Apple Pay","button.apple_pay.support":"Susțineți prin intermediul Apple Pay","button.apple_pay.tip":"Lăsați bacșiș prin intermediul Apple Pay","button.apple_pay.top_up":"Suplimentați prin intermediul Apple Pay","button.cancel":"Anulare","button.change":"Modificare","button.google_pay.buy":"Cumpărați prin intermediul Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Donați prin intermediul Google Pay","button.link.autofill":"Utilizați","button.link.autofill_alt":"Utilizați","button.link.autofill_aria_label":"Completați automat cu Link","button.link.card_clear":"Nu mai utilizați Link și introduceți manual informațiile cardului.","button.link.express_pay":"Plată Express","button.link.manage":"În acest moment plătiți cu Link folosind cardul care se termină în {last4}. Alegeți o altă metodă de plată","button.link.manage.cardCvc":"În prezent, folosiți Link. Actualizați codul CVC al cardului.","button.link.manage.cardExpiry":"În prezent, folosiți Link cu o dată de expirare de {expiry}. Actualizați data de expirare a cardului.","button.link.manage.postalCode":"În prezent, folosiți Link cu un cod poștal de {postal}. Actualizați codul poștal al cardului.","button.link.pay_faster":"Plată rapidă","button.link.pay_faster_with":"Plată rapidă cu {linkLogo}","button.link.pay_faster_with_link":"Plătiți mai rapid cu Link","button.link.pay_with":"Plătiți cu {linkLogo}","button.link.pay_with_last_4":"Plată cu ••{last4}","button.link.save_with":"Salvare cu {linkLogo}","button.link.save_with_aria_label":"Salvare cu Link","button.link.use_last_4_aria_label":"Completați automat utilizând Link cu un card care se termină în {last4}","button.logout":"Deconectare","button.pay_with":"Folosiți ca metodă de plată","button.payment_request.book":"Rezervați acum","button.payment_request.buy":"Cumpărați acum","button.payment_request.default":"Plătiți acum","button.payment_request.donate":"Donați","button.remove":"Eliminare","button.retry":"Încercați din nou","button.save":"Salvare","button.save_with":"Salvare cu","button.see_more":"Afișați mai multe","button.update":"Actualizare","placeholders.accountHolderType":"Tip titular cont","placeholders.auBankAccountNumber":"Număr cont","placeholders.cardNumber":"Număr card","placeholders.cardNumberShort":"Număr","placeholders.company":"Întreprindere","placeholders.cvc":"CVC","placeholders.expiry":"LL/AA","placeholders.individual":"Personal","placeholders.postal_code":"Cod poștal","placeholders.postcode":"Cod poștal","placeholders.securityCode":"Cod de securitate","placeholders.selectBank":"Selectare bancă","placeholders.zip":"Cod poștal","button.prb_warning.badge_label":"Upgrade disponibil","button.prb_warning.button_primary":"Faceți upgrade acum","button.prb_warning.button_secondary":"Suspendați pentru o săptămână","button.prb_warning.description":"Am observat că utilizați butonul Solicitare plată. Faceți upgrade la {ece_link} pentru a avea acces la cele mai recente caracteristici și optimizări.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Afișați simultan mai multe metode de plată, inclusiv: Amazon Pay, Link și PayPal (numai în UE).","button.prb_warning.li2":"Asistență pentru toate browserele pentru Google Pay și Apple Pay (iOS 18+).","button.prb_warning.li3":"Sortați și afișați în mod dinamic clienților dvs. cele mai relevante opțiuni de finalizare rapidă a comenzii.","button.prb_warning.nav_header":"Mod de testare","button.prb_warning.title":"Faceți upgrade la butoanele vechi pentru plata cu un singur clic"}')
        },
        69114: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Закрыть диалоговое окно","button.apple_pay.add_money":"Пополнить сумму с помощью Apple Pay","button.apple_pay.book":"Зарезервировать с помощью Apple Pay","button.apple_pay.buy":"Купить с помощью Apple Pay","button.apple_pay.check_out":"Закончить оформление покупки с помощью Apple Pay","button.apple_pay.contribute":"Пожертвовать с помощью Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Пожертвовать при помощи Apple Pay","button.apple_pay.order":"Заказать с помощью Apple Pay","button.apple_pay.reload":"Перезарядить с помощью Apple Pay","button.apple_pay.rent":"Арендовать с помощью Apple Pay","button.apple_pay.subscribe":"Подписаться с помощью Apple Pay","button.apple_pay.support":"Поддержать с помощью Apple Pay","button.apple_pay.tip":"Отправить чаевые с помощью Apple Pay","button.apple_pay.top_up":"Пополнить с помощью Apple Pay","button.cancel":"Отмена","button.change":"Изменить","button.google_pay.buy":"Купить с помощью Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Пожертвовать при помощи Google Pay","button.link.autofill":"Автозаполнение","button.link.autofill_alt":"Использовать","button.link.autofill_aria_label":"Автозаполнение через Link","button.link.card_clear":"Прекратить использование Link и ввести реквизиты карты вручную.","button.link.express_pay":"Экспресс-оплата","button.link.manage":"Сейчас выполняется оплата через Link с использованием карты, номер которой оканчивается на {last4}. Выберите другой способ оплаты","button.link.manage.cardCvc":"Сейчас используется Link. Обновите CVC-код карты.","button.link.manage.cardExpiry":"Сейчас используется Link с датой истечения срока действия {expiry}. Обновите срок действия карты.","button.link.manage.postalCode":"Сейчас используется Link с почтовым индексом {postal}. Измените почтовый индекс, связанный с картой.","button.link.pay_faster":"Платите быстрее","button.link.pay_faster_with":"Быстрая оплата с помощью {linkLogo}","button.link.pay_faster_with_link":"Платите быстрее с Link","button.link.pay_with":"Оплата с {linkLogo}","button.link.pay_with_last_4":"Оплатить через ••{last4}","button.link.save_with":"Сэкономить с помощью {linkLogo}","button.link.save_with_aria_label":"Сохранить в Link","button.link.use_last_4_aria_label":"Автоматически заполнять с помощью Link реквизитами карты с номером, оканчивающимся на {last4}","button.logout":"Выйти","button.pay_with":"Оплатить через","button.payment_request.book":"Зарезервировать сейчас","button.payment_request.buy":"Купить сейчас","button.payment_request.default":"Оплатить сейчас","button.payment_request.donate":"Пожертвовать","button.remove":"Удалить","button.retry":"Повторить","button.save":"Сохранить","button.save_with":"Сохранить с помощью","button.see_more":"Показать больше","button.update":"Обновить","placeholders.accountHolderType":"Тип владельца счета","placeholders.auBankAccountNumber":"Номер счета","placeholders.cardNumber":"Номер карты","placeholders.cardNumberShort":"Номер","placeholders.company":"Компания","placeholders.cvc":"CVC","placeholders.expiry":"ММ / ГГ","placeholders.individual":"Частное лицо","placeholders.postal_code":"Индекс","placeholders.postcode":"Индекс","placeholders.securityCode":"Код безопасности","placeholders.selectBank":"Выбрать банк","placeholders.zip":"Индекс","button.prb_warning.badge_label":"Доступно обновление","button.prb_warning.button_primary":"Обновить сейчас","button.prb_warning.button_secondary":"Закрыть уведомление и не показывать его неделю","button.prb_warning.description":"Мы заметили, что вы используете кнопку \\"Запросить платеж\\". Перейдите на более новую версию, {ece_link}, чтобы получить доступ к новейшим функциям и оптимизированным возможностям.","button.prb_warning.ece_link":"Элемент экспресс-оформления покупки","button.prb_warning.li1":"Показывайте различные способы оплаты одновременно, в том числе: Amazon Pay, Link и PayPal (только в ЕС).","button.prb_warning.li2":"Поддержка различных браузеров для Google Pay and Apple Pay (iOS 18+).","button.prb_warning.li3":"Сортируйте и показывайте покупателям динамически самые актуальные возможности экспресс-оформления покупок.","button.prb_warning.nav_header":"Тестовый режим","button.prb_warning.title":"Обновите устаревшие кнопки для оплаты одним щелчком"}')
        },
        1256: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Zatvoriť dialógové okno","button.apple_pay.add_money":"Pridať peniaze pomocou Apple Pay","button.apple_pay.book":"Zarezervovať pomocou Apple Pay","button.apple_pay.buy":"Kúpiť pomocou Apple Pay","button.apple_pay.check_out":"Vyskúšať pomocou Apple Pay","button.apple_pay.contribute":"Prispieť pomocou Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Darovať pomocou Apple Pay","button.apple_pay.order":"Objednať pomocou Apple Pay","button.apple_pay.reload":"Znova načítať pomocou Apple Pay","button.apple_pay.rent":"Prenajať pomocou Apple Pay","button.apple_pay.subscribe":"Prihlásiť sa na odber pomocou Apple Pay","button.apple_pay.support":"Podporiť pomocou Apple Pay","button.apple_pay.tip":"Tipovať pomocou Apple Pay","button.apple_pay.top_up":"Topovať pomocou Apple Pay","button.cancel":"Zrušiť","button.change":"Zmeniť","button.google_pay.buy":"Kúpiť pomocou Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Darovať pomocou Google Pay","button.link.autofill":"Použiť","button.link.autofill_alt":"Použiť","button.link.autofill_aria_label":"Automatické vyplnenie pomocou služby Link","button.link.card_clear":"Prestaňte používať službu Link a zadajte údaje o karte manuálne.","button.link.express_pay":"Platba Express","button.link.manage":"Aktuálne platíte pomocou služby Link kartou s koncovkou {last4}. Vyberte si iný spôsob platby","button.link.manage.cardCvc":"Aktuálne používate službu Link. Aktualizujte CVC kód karty.","button.link.manage.cardExpiry":"Aktuálne používate službu Link s dátumom platnosti {expiry}. Aktualizujte dátum platnosti karty.","button.link.manage.postalCode":"Aktuálne používate službu Link s poštovým smerovacím číslom {postal}. Aktualizujte poštové smerovacie číslo karty.","button.link.pay_faster":"Plaťte rýchlo","button.link.pay_faster_with":"Plaťte rýchlo so službou {linkLogo}","button.link.pay_faster_with_link":"Plaťte rýchlejšie pomocou služby Link","button.link.pay_with":"Platiť so službou {linkLogo}","button.link.pay_with_last_4":"Platiť s ••{last4}","button.link.save_with":"Uložiť pomocou {linkLogo}","button.link.save_with_aria_label":"Uložiť so službou Link","button.link.use_last_4_aria_label":"Automatické vyplnenie pomocou služby Link s kartou končiacou na {last4}","button.logout":"Odhlásiť sa","button.pay_with":"Zaplatiť kartou","button.payment_request.book":"Rezervovať hneď","button.payment_request.buy":"Kúpiť hneď","button.payment_request.default":"Zaplatiť hneď","button.payment_request.donate":"Darovať","button.remove":"Odstrániť","button.retry":"Skúsiť znova","button.save":"Uložiť","button.save_with":"Uložiť pomocou","button.see_more":"Ďalšie informácie","button.update":"Aktualizovať","placeholders.accountHolderType":"Typ vlastníka účtu","placeholders.auBankAccountNumber":"Číslo účtu","placeholders.cardNumber":"Číslo karty","placeholders.cardNumberShort":"Číslo","placeholders.company":"Spoločnosť","placeholders.cvc":"CVC","placeholders.expiry":"MM/RR","placeholders.individual":"Jednotlivec","placeholders.postal_code":"PSČ","placeholders.postcode":"PSČ","placeholders.securityCode":"Bezpečnostný kód","placeholders.selectBank":"Zvoľte banku","placeholders.zip":"PSČ","button.prb_warning.badge_label":"Inovácia je k dispozícii","button.prb_warning.button_primary":"Inovujte teraz","button.prb_warning.button_secondary":"Zrušiť na jeden týždeň","button.prb_warning.description":"Všimli sme si, že používate tlačidlo Žiadosť o platbu. Inovujte na úroveň {ece_link} pre prístup k najnovším funkciám a optimalizáciám.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Zobrazte viaceré spôsoby platby súčasne vrátane: Amazon Pay, Link a PayPal (len v EÚ).","button.prb_warning.li2":"Podpora služieb Google Pay a Apple Pay v rôznych prehliadačoch (iOS 18+).","button.prb_warning.li3":"Dynamicky vytrieďte a zobrazte zákazníkom najrelevantnejšie možnosti expresných platieb.","button.prb_warning.nav_header":"Testovací režim","button.prb_warning.title":"Aktualizujte si staršie tlačidlá platby na jedným kliknutím"}')
        },
        70424: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Zapri pogovorno okno","button.apple_pay.add_money":"Dodaj denar z Apple Pay","button.apple_pay.book":"Rezerviraj z Apple Pay","button.apple_pay.buy":"Kupi z Apple Pay","button.apple_pay.check_out":"Zaključi nakup z Apple Pay","button.apple_pay.contribute":"Prispevaj z Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Podari z Apple Pay","button.apple_pay.order":"Naroči z Apple Pay","button.apple_pay.reload":"Znova naloži z Apple Pay","button.apple_pay.rent":"Najemi z Apple Pay","button.apple_pay.subscribe":"Naroči se z Apple Pay","button.apple_pay.support":"Podpora za Apple Pay","button.apple_pay.tip":"Nasvet za Apple Pay","button.apple_pay.top_up":"Napolni z Apple Pay","button.cancel":"Prekliči","button.change":"Spremeni","button.google_pay.buy":"Kupi z Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Podari z Google Pay","button.link.autofill":"Uporabi","button.link.autofill_alt":"Uporabi","button.link.autofill_aria_label":"Samoizpolni s storitvijo Link","button.link.card_clear":"Prenehajte uporabljati Link in ročno vnesite podatke o kartici.","button.link.express_pay":"Plačilo Express","button.link.manage":"Za plačilo s storitvijo Link trenutno uporabljate kartico, ki se konča s števkami {last4}. Izberite drug način plačila.","button.link.manage.cardCvc":"Trenutno uporabljate Link. Posodobite kodo CVC kartice.","button.link.manage.cardExpiry":"Link trenutno uporabljate z datumom poteka {expiry}. Posodobite datum poteka kartice.","button.link.manage.postalCode":"Link trenutno uporabljate s poštno številko {postal}. Posodobite poštno številko kartice.","button.link.pay_faster":"Plačaj hitreje","button.link.pay_faster_with":"Plačaj hitro s storitvijo {linkLogo}","button.link.pay_faster_with_link":"Plačujte hitreje s storitvijo Link","button.link.pay_with":"Plačaj s storitvijo {linkLogo}","button.link.pay_with_last_4":"Plačaj z ••{last4}","button.link.save_with":"Za shranjevanje uporabi {linkLogo}","button.link.save_with_aria_label":"Shrani s storitvijo Link","button.link.use_last_4_aria_label":"Samoizpolni s storitvijo Link s podatki o kartici, ki se konča z {last4}","button.logout":"Odjava","button.pay_with":"Za plačilo uporabi","button.payment_request.book":"Rezerviraj zdaj","button.payment_request.buy":"Kupi zdaj","button.payment_request.default":"Plačaj zdaj","button.payment_request.donate":"Podari","button.remove":"Odstrani","button.retry":"Poskusi znova","button.save":"Shrani","button.save_with":"Za shranjevanje uporabi","button.see_more":"Prikaži več","button.update":"Posodobi","placeholders.accountHolderType":"Vrsta imetnika računa","placeholders.auBankAccountNumber":"Številka računa","placeholders.cardNumber":"Številka kartice","placeholders.cardNumberShort":"Številka","placeholders.company":"Podjetje","placeholders.cvc":"CVC","placeholders.expiry":"MM/LL","placeholders.individual":"Osebni","placeholders.postal_code":"Poštna številka","placeholders.postcode":"Poštna številka","placeholders.securityCode":"Varnostna koda","placeholders.selectBank":"Izberite banko","placeholders.zip":"Poštna številka","button.prb_warning.badge_label":"Na voljo je nadgradnja","button.prb_warning.button_primary":"Nadgradi zdaj","button.prb_warning.button_secondary":"Opusti za en teden","button.prb_warning.description":"Opazili smo, da uporabljate gumb zahteve za plačilo. Za dostop do najnovejših funkcij in optimizacij nadgradite na {ece_link}.","button.prb_warning.ece_link":"Element hitre izvedbe plačila","button.prb_warning.li1":"Hkrati prikažite več načinov plačila, vključno z naslednjimi: Amazon Pay, Link in PayPal (na voljo samo v EU).","button.prb_warning.li2":"Podpora za Google Pay in Apple Pay (iOS 18 in novejše različice) v več brskalnikih.","button.prb_warning.li3":"Dinamično razvrstite in strankam prikažite najustreznejše možnosti hitre izvedbe plačila.","button.prb_warning.nav_header":"Način preskusne uporabe","button.prb_warning.title":"Nadgradite svoje starejše gumbe za plačilo z enim klikom"}')
        },
        59091: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Stäng Dialog","button.apple_pay.add_money":"Lägg till pengar med Apple Pay","button.apple_pay.book":"Boka med Apple Pay","button.apple_pay.buy":"Köp med Apple Pay","button.apple_pay.check_out":"Gå till kassan med Apple Pay","button.apple_pay.contribute":"Bidra med Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Donera med Apple Pay","button.apple_pay.order":"Beställ med Apple Pay","button.apple_pay.reload":"Ladda om med Apple Pay","button.apple_pay.rent":"Hyr med Apple Pay","button.apple_pay.subscribe":"Prenumerera med Apple Pay","button.apple_pay.support":"Stöd med Apple Pay","button.apple_pay.tip":"Ge dricks med Apple Pay","button.apple_pay.top_up":"Fyll på med Apple Pay","button.cancel":"Avbryt","button.change":"Ändra","button.google_pay.buy":"Köp med Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Donera med Google Pay","button.link.autofill":"Autofyll","button.link.autofill_alt":"Använd","button.link.autofill_aria_label":"Fyll i automatiskt med Link","button.link.card_clear":"Sluta använda Link och ange kortuppgifterna manuellt.","button.link.express_pay":"Expressbetalning","button.link.manage":"Betalar för närvarande med Link med hjälp av det kort som slutar med {last4}. Välj en annan betalningsmetod","button.link.manage.cardCvc":"Använder för närvarande Link. Uppdatera kortets CVC-kod.","button.link.manage.cardExpiry":"Använder för närvarande Link med utgångsdatumet {expiry}. Uppdatera kortets utgångsdatum.","button.link.manage.postalCode":"Använder för närvarande Link med postnumret {postal}. Uppdatera kortets postnummer.","button.link.pay_faster":"Betala snabbare","button.link.pay_faster_with":"Betala snabbt med {linkLogo}","button.link.pay_faster_with_link":"Betala snabbare med Link","button.link.pay_with":"Betala med {linkLogo}","button.link.pay_with_last_4":"Betala med ••{last4}","button.link.save_with":"Spara med {linkLogo}","button.link.save_with_aria_label":"Spara med Link","button.link.use_last_4_aria_label":"Fyll i automatiskt med Link med ett kort som slutar på {last4}","button.logout":"Logga ut","button.pay_with":"Betala med","button.payment_request.book":"Boka nu","button.payment_request.buy":"Köp","button.payment_request.default":"Betala nu","button.payment_request.donate":"Donera","button.remove":"Ta bort","button.retry":"Försök igen","button.save":"Spara","button.save_with":"Spara med","button.see_more":"Visa mer","button.update":"Uppdatera","placeholders.accountHolderType":"Typ av kontoinnehavare","placeholders.auBankAccountNumber":"Kontonummer","placeholders.cardNumber":"Kortnummer","placeholders.cardNumberShort":"Nummer","placeholders.company":"Företag","placeholders.cvc":"CVC-kod","placeholders.expiry":"MM/ÅÅ","placeholders.individual":"Privat","placeholders.postal_code":"Postnr","placeholders.postcode":"Postnr","placeholders.securityCode":"Säkerhetskod","placeholders.selectBank":"Välj bank","placeholders.zip":"Postnr","button.prb_warning.badge_label":"Uppgradering tillgänglig","button.prb_warning.button_primary":"Uppgradera nu","button.prb_warning.button_secondary":"Avvisa i en vecka","button.prb_warning.description":"Vi har lagt märke till att du använder Payment Request-knappen. Uppgradera till {ece_link} för att få tillgång till de senaste funktionerna och optimeringarna.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Visa flera betalningsmetoder samtidigt, bland annat: Amazon Pay, Link och PayPal (endast i EU).","button.prb_warning.li2":"Stöd för Google Pay och Apple Pay (iOS 18+) i olika webbläsare.","button.prb_warning.li3":"Sortera och visa dynamiskt de mest relevanta alternativen för expressbetalning för dina kunder.","button.prb_warning.nav_header":"Testläge","button.prb_warning.title":"Uppgradera dina förlegade knappar för betalning med ett enda klick"}')
        },
        79550: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"ปิดกล่องโต้ตอบ","button.apple_pay.add_money":"เติมเงินด้วย Apple Pay","button.apple_pay.book":"จองด้วย Apple Pay","button.apple_pay.buy":"ซื้อด้วย Apple Pay","button.apple_pay.check_out":"ชำระเงินด้วย Apple Pay","button.apple_pay.contribute":"บริจาคด้วย Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"บริจาคด้วย Apple Pay","button.apple_pay.order":"สั่งซื้อด้วย Apple Pay","button.apple_pay.reload":"เติมเงินด้วย Apple Pay","button.apple_pay.rent":"ชำระค่าเช่าด้วย Apple Pay","button.apple_pay.subscribe":"สมัครใช้บริการด้วย Apple Pay","button.apple_pay.support":"มอบเงินสนับสนุนด้วย Apple Pay","button.apple_pay.tip":"ให้ทิปด้วย Apple Pay","button.apple_pay.top_up":"เติมเงินด้วย Apple Pay","button.cancel":"ยกเลิก","button.change":"เปลี่ยน","button.google_pay.buy":"ซื้อด้วย Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"บริจาคด้วย Google Pay","button.link.autofill":"ใช้","button.link.autofill_alt":"ใช้","button.link.autofill_aria_label":"กรอกข้อมูลโดยอัตโนมัติด้วย Link","button.link.card_clear":"เลิกใช้ Link และป้อนรายละเอียดของบัตรด้วยตนเอง","button.link.express_pay":"ชำระอย่างรวดเร็ว","button.link.manage":"ขณะนี้การชำระเงินด้วย Link ใช้บัตรที่ลงท้ายด้วย {last4} โปรดเลือกวิธีการชำระเงินอื่น","button.link.manage.cardCvc":"กำลังใช้ Link อยู่ในขณะนี้ โปรดอัปเดตรหัส CVC ของบัตร","button.link.manage.cardExpiry":"กำลังใช้ Link โดยมีวันหมดอายุเป็น {expiry} โปรดอัปเดตวันหมดอายุของบัตร","button.link.manage.postalCode":"กำลังใช้ Link โดยมีรหัสไปรษณีย์เป็น {postal} โปรดอัปเดตรหัสไปรษณีย์ของบัตร","button.link.pay_faster":"จ่ายได้เร็วขึ้น","button.link.pay_faster_with":"จ่ายได้เร็วด้วย {linkLogo}","button.link.pay_faster_with_link":"จ่ายได้เร็วด้วย Link","button.link.pay_with":"จ่ายด้วย {linkLogo}","button.link.pay_with_last_4":"จ่ายด้วย ••{last4}","button.link.save_with":"บันทึกด้วย {linkLogo}","button.link.save_with_aria_label":"บันทึกด้วย Link","button.link.use_last_4_aria_label":"กรอกข้อมูลบัตรที่ลงท้ายด้วย {last4} โดยอัตโนมัติด้วย Link","button.logout":"ออกจากระบบ","button.pay_with":"ชำระด้วย","button.payment_request.book":"จองเลย","button.payment_request.buy":"ซื้อเลย","button.payment_request.default":"ชำระเงินเลย","button.payment_request.donate":"บริจาค","button.remove":"นำออก","button.retry":"ลองอีกครั้ง","button.save":"บันทึก","button.save_with":"บันทึกด้วย","button.see_more":"ดูเพิ่มเติม","button.update":"อัปเดต","placeholders.accountHolderType":"ประเภทเจ้าของบัญชี","placeholders.auBankAccountNumber":"หมายเลขบัญชี","placeholders.cardNumber":"หมายเลขบัตร","placeholders.cardNumberShort":"หมายเลข","placeholders.company":"ธุรกิจ","placeholders.cvc":"CVC","placeholders.expiry":"ดด / ปป","placeholders.individual":"ส่วนบุคคล","placeholders.postal_code":"รหัสไปรษณีย์","placeholders.postcode":"รหัสไปรษณีย์","placeholders.securityCode":"รหัสความปลอดภัย","placeholders.selectBank":"เลือกธนาคาร","placeholders.zip":"รหัสไปรษณีย์","button.prb_warning.badge_label":"พร้อมให้อัปเกรด","button.prb_warning.button_primary":"อัปเกรดเลย","button.prb_warning.button_secondary":"ปิดเป็นเวลา 1 สัปดาห์","button.prb_warning.description":"เราสังเกตว่าคุณกำลังใช้ปุ่มส่งคำขอให้ชำระเงิน โปรดอัปเกรดเป็น {ece_link} เพื่อเข้าถึงฟีเจอร์และการเพิ่มประสิทธิภาพล่าสุด","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"แสดงวิธีการชำระเงินหลายแบบพร้อมกัน รวมถึง Amazon Pay, Link และ PayPal (เฉพาะในสหภาพยุโรปเท่านั้น)","button.prb_warning.li2":"รองรับการใช้งานข้ามเบราว์เซอร์สำหรับ Google Pay และ Apple Pay (iOS 18+)","button.prb_warning.li3":"จัดเรียงและแสดงตัวเลือกการชำระเงินด่วนที่เกี่ยวข้องมากที่สุดต่อลูกค้าโดยอัตโนมัติ","button.prb_warning.nav_header":"โหมดทดสอบ","button.prb_warning.title":"อัปเกรดปุ่มการชำระเงินในคลิกเดียวแบบเก่า"}')
        },
        46089: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"İletişim kutusunu kapat","button.apple_pay.add_money":"Apple Pay ile para ekleyin","button.apple_pay.book":"Apple Pay ile rezervasyon yapın","button.apple_pay.buy":"Apple Pay ile satın alın","button.apple_pay.check_out":"Apple Pay ile ödeyin","button.apple_pay.contribute":"Apple Pay ile katkıda bulunun","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Apple Pay ile bağış yapın","button.apple_pay.order":"Apple Pay ile sipariş verin","button.apple_pay.reload":"Apple Pay ile yeniden yükleyin","button.apple_pay.rent":"Apple Pay ile kiralayın","button.apple_pay.subscribe":"Apple Pay ile abone olun","button.apple_pay.support":"Apple Pay ile destek olun","button.apple_pay.tip":"Apple Pay ile bahşiş verin","button.apple_pay.top_up":"Apple Pay ile tamamlayın","button.cancel":"İptal et","button.change":"Değiştir","button.google_pay.buy":"Google Pay ile satın alın","button.google_pay.default":"Google Pay","button.google_pay.donate":"Google Pay ile katkıda bulunun","button.link.autofill":"Kullan","button.link.autofill_alt":"Kullan","button.link.autofill_aria_label":"Link ile otomatik olarak doldurun","button.link.card_clear":"Link kullanmayı bırakıp kart bilgilerini manuel olarak girin.","button.link.express_pay":"Ekspres öde","button.link.manage":"Şu anda son 4 hanesi {last4} olan kart kullanılarak Link ile ödeme yapılıyor. Farklı bir ödeme yöntemi seçin","button.link.manage.cardCvc":"Şu anda Link kullanılıyor. Kartın CVC kodunu güncelleyin.","button.link.manage.cardExpiry":"Şu anda son kullanma tarihi {expiry} olan Link kullanılıyor. Kartın son kullanma tarihini güncelleyin.","button.link.manage.postalCode":"Şu anda {postal} posta koduyla Link kullanılıyor. Kartın posta kodunu güncelleyin.","button.link.pay_faster":"Hızlı öde","button.link.pay_faster_with":"{linkLogo} ile hızlı öde","button.link.pay_faster_with_link":"Link ile daha hızlı ödeme yapın","button.link.pay_with":"{linkLogo} ile öde","button.link.pay_with_last_4":"{last4} ile öde","button.link.save_with":"{linkLogo} ile kaydedin","button.link.save_with_aria_label":"Link ile kaydedin","button.link.use_last_4_aria_label":"{last4} ile biten bir kartta Link\'i kullanarak otomatik doldurma","button.logout":"Oturumu kapat","button.pay_with":"Şununla öde:","button.payment_request.book":"Şimdi rezervasyon yapın","button.payment_request.buy":"Şimdi satın alın","button.payment_request.default":"Şimdi ödeyin","button.payment_request.donate":"Bağış yapın","button.remove":"Kaldır","button.retry":"Tekrar deneyin","button.save":"Kaydet","button.save_with":"Şuna kaydet:","button.see_more":"Daha fazla göster","button.update":"Güncelle","placeholders.accountHolderType":"Hesap sahibinin türü","placeholders.auBankAccountNumber":"Hesap numarası","placeholders.cardNumber":"Kart numarası","placeholders.cardNumberShort":"Numara","placeholders.company":"İşletme","placeholders.cvc":"CVC","placeholders.expiry":"AA / YY","placeholders.individual":"Bireysel","placeholders.postal_code":"Posta kodu","placeholders.postcode":"Posta kodu","placeholders.securityCode":"Güvenlik Kodu","placeholders.selectBank":"Banka seçin","placeholders.zip":"ZIP kodu","button.prb_warning.badge_label":"Yükseltme mevcut","button.prb_warning.button_primary":"Şimdi yükselt","button.prb_warning.button_secondary":"Bir haftalığına kapat","button.prb_warning.description":"Ödeme Talebi Düğmesini kullandığınızı fark ettik. En yeni özelliklere ve optimizasyonlara erişim için {ece_link} sürümüne geçin.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Amazon Pay, Link ve PayPal (yalnızca AB\'de) dahil olmak üzere birden fazla ödeme yöntemini aynı anda görüntüleyin.","button.prb_warning.li2":"Google Pay ve Apple Pay (iOS 18+) için tarayıcılar arası destek.","button.prb_warning.li3":"Müşterilerinize en alakalı hızlı ödeme seçeneklerini dinamik olarak sıralayın ve görüntüleyin.","button.prb_warning.nav_header":"Test modu","button.prb_warning.title":"Eski tek tıklamayla ödeme düğmelerinizi yükseltin"}')
        },
        28609: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"Đóng hộp thoại","button.apple_pay.add_money":"Thêm Tiền thông qua Apple Pay","button.apple_pay.book":"Đặt chỗ thông qua Apple Pay","button.apple_pay.buy":"Mua thông qua Apple Pay","button.apple_pay.check_out":"Thanh toán thông qua Apple Pay","button.apple_pay.contribute":"Đóng góp thông qua Apple Pay","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"Quyên tặng thông qua Apple Pay","button.apple_pay.order":"Đặt hàng thông qua Apple Pay","button.apple_pay.reload":"Tải lại thông qua Apple Pay","button.apple_pay.rent":"Thuê thông qua Apple Pay","button.apple_pay.subscribe":"Đăng ký thông qua Apple Pay","button.apple_pay.support":"Hỗ trợ thông qua Apple Pay","button.apple_pay.tip":"Tiền boa thông qua Apple Pay","button.apple_pay.top_up":"Nạp tiền thông qua Apple Pay","button.cancel":"Hủy","button.change":"Thay đổi","button.google_pay.buy":"Mua thông qua Google Pay","button.google_pay.default":"Google Pay","button.google_pay.donate":"Quyên tặng thông qua Google Pay","button.link.autofill":"Dùng","button.link.autofill_alt":"Sử dụng","button.link.autofill_aria_label":"Tự động điền thông tin bằng Link","button.link.card_clear":"Ngưng sử dụng Link và nhập thông tin thẻ.","button.link.express_pay":"Trả nhanh","button.link.manage":"Bạn hiện đang dùng Link thanh toán bằng thẻ có số đuôi {last4}. Hãy chọn một phương thức thanh toán khác","button.link.manage.cardCvc":"Hiện đang sử dụng Link. Cập nhật mã CVC của thẻ.","button.link.manage.cardExpiry":"Hiện đang sử dụng Link có thời hạn sử dụng là {expiry}. Cập nhật ngày hết hạn của thẻ.","button.link.manage.postalCode":"Hiện đang sử dụng Link có mã bưu chính là {postal}. Cập nhật mã bưu chính của thẻ.","button.link.pay_faster":"Trả nhanh hơn","button.link.pay_faster_with":"Trả nhanh hơn với {linkLogo}","button.link.pay_faster_with_link":"Thanh toán nhanh hơn với Link","button.link.pay_with":"Trả với {linkLogo}","button.link.pay_with_last_4":"Trả với ••{last4}","button.link.save_with":"Lưu bằng {linkLogo}","button.link.save_with_aria_label":"Lưu bằng Link","button.link.use_last_4_aria_label":"Tự động điền bằng Link với thẻ có số đuôi là {last4}","button.logout":"Đăng xuất","button.pay_with":"Thanh toán bằng","button.payment_request.book":"Đặt chỗ ngay","button.payment_request.buy":"Mua ngay","button.payment_request.default":"Trả ngay","button.payment_request.donate":"Quyên tặng","button.remove":"Xóa","button.retry":"Thử lại","button.save":"Lưu","button.save_with":"Lưu với","button.see_more":"Xem thêm","button.update":"Cập nhật","placeholders.accountHolderType":"Loại chủ tài khoản","placeholders.auBankAccountNumber":"Số tài khoản","placeholders.cardNumber":"Số thẻ","placeholders.cardNumberShort":"Số","placeholders.company":"Doanh nghiệp","placeholders.cvc":"CVC","placeholders.expiry":"MM / YY","placeholders.individual":"Cá nhân","placeholders.postal_code":"Mã bưu chính","placeholders.postcode":"Mã bưu điện","placeholders.securityCode":"Mã bảo mật","placeholders.selectBank":"Chọn ngân hàng","placeholders.zip":"ZIP","button.prb_warning.badge_label":"Nâng cấp khả dụng","button.prb_warning.button_primary":"Nâng cấp ngay","button.prb_warning.button_secondary":"Nghỉ một tuần","button.prb_warning.description":"Chúng tôi nhận thấy bạn đang sử dụng Nút Yêu cầu Thanh toán. Hãy nâng cấp lên {ece_link} để truy cập nhiều tính năng và lựa chọn tối ưu hóa mới nhất.","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"Hiển thị nhiều phương thức thanh toán cùng lúc, bao gồm: Amazon Pay, Link và PayPal (chỉ EU).","button.prb_warning.li2":"Hỗ trợ Google Pay và Apple Pay trên nhiều trình duyệt (iOS 18+).","button.prb_warning.li3":"Sắp xếp và hiển thị các tùy chọn thanh toán nhanh một cách linh hoạt và phù hợp nhất cho khách hàng của bạn.","button.prb_warning.nav_header":"Chế độ thử nghiệm","button.prb_warning.title":"Nâng cấp nút thanh toán bằng một cú nhấp chuột của bạn"}')
        },
        88359: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"關閉對話框","button.apple_pay.add_money":"用 Apple Pay 充值","button.apple_pay.book":"用 Apple Pay 預定","button.apple_pay.buy":"用 Apple Pay 購買","button.apple_pay.check_out":"用 Apple Pay 結賬","button.apple_pay.contribute":"用 Apple Pay 捐款","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"用 Apple Pay 捐獻","button.apple_pay.order":"用 Apple Pay 下單","button.apple_pay.reload":"用 Apple Pay 重新載入","button.apple_pay.rent":"用 Apple Pay 租賃","button.apple_pay.subscribe":"用 Apple Pay 訂閱","button.apple_pay.support":"用 Apple Pay 支持","button.apple_pay.tip":"用 Apple Pay 支付小費","button.apple_pay.top_up":"用 Apple Pay 充值","button.cancel":"取消","button.change":"更改","button.google_pay.buy":"用 Google Pay 購買","button.google_pay.default":"Google Pay","button.google_pay.donate":"用 Google Pay 捐款","button.link.autofill":"自動填充","button.link.autofill_alt":"使用","button.link.autofill_aria_label":"用 Link 自動填充","button.link.card_clear":"停止使用 Link 並手動輸入銀行卡詳情。","button.link.express_pay":"快速支付","button.link.manage":"目前在 Link 上支付使用的是尾號為 {last4} 的銀行卡。選擇另一支付方式","button.link.manage.cardCvc":"當前使用 Link。請更新此卡的 CVC 安全碼。","button.link.manage.cardExpiry":"當前使用 Link，有效期為 {expiry}。請更新此卡的有效期。","button.link.manage.postalCode":"當前使用 Link，郵區編號為 {postal}。請更新此卡的郵區編號。","button.link.pay_faster":"更快支付","button.link.pay_faster_with":"用 {linkLogo} 更快支付","button.link.pay_faster_with_link":"用 Link 更快支付","button.link.pay_with":"用  {linkLogo} 支付","button.link.pay_with_last_4":"用 ••{last4} 支付","button.link.save_with":"用 {linkLogo} 保存","button.link.save_with_aria_label":"用 Link 保存","button.link.use_last_4_aria_label":"用 Link 自動填充尾號為 {last4} 的銀行卡","button.logout":"退出","button.pay_with":"支付方式","button.payment_request.book":"立即預定","button.payment_request.buy":"立即購買","button.payment_request.default":"立即支付","button.payment_request.donate":"捐款","button.remove":"移除","button.retry":"重試","button.save":"保存","button.save_with":"保存方式","button.see_more":"查看更多","button.update":"更新","placeholders.accountHolderType":"賬戶持有人類型","placeholders.auBankAccountNumber":"賬號","placeholders.cardNumber":"卡號","placeholders.cardNumberShort":"卡號","placeholders.company":"商家","placeholders.cvc":"CVC","placeholders.expiry":"月/年","placeholders.individual":"個人","placeholders.postal_code":"郵區編號","placeholders.postcode":"郵區編號","placeholders.securityCode":"安全碼","placeholders.selectBank":"選擇銀行","placeholders.zip":"郵區編號","button.prb_warning.badge_label":"有可用的升級","button.prb_warning.button_primary":"立即升級","button.prb_warning.button_secondary":"解散一週","button.prb_warning.description":"我們注意到您正在使用付款請求按鈕 (Payment Request Button)。升級到 {ece_link} 以獲得最新的功能和優化。","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"同時顯示多種支付方式，包括：Amazon Pay、Link 和 PayPal（僅限歐盟）。","button.prb_warning.li2":"跨瀏覽器支援 Google Pay 和 Apple Pay (iOS 18+)。","button.prb_warning.li3":"為您的客戶動態排序和顯示最相關的快速結賬選項。","button.prb_warning.nav_header":"測試模式","button.prb_warning.title":"升級您的傳統一鍵支付按鈕"}')
        },
        55504: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"關閉對話框","button.apple_pay.add_money":"用 Apple Pay 充值","button.apple_pay.book":"用 Apple Pay 預定","button.apple_pay.buy":"用 Apple Pay 購買","button.apple_pay.check_out":"用 Apple Pay 結帳","button.apple_pay.contribute":"用 Apple Pay 捐款","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"用 Apple Pay 捐獻","button.apple_pay.order":"用 Apple Pay 下單","button.apple_pay.reload":"用 Apple Pay 重新載入","button.apple_pay.rent":"用 Apple Pay 租賃","button.apple_pay.subscribe":"用 Apple Pay 訂閱","button.apple_pay.support":"用 Apple Pay 支持","button.apple_pay.tip":"用 Apple Pay 支付小費","button.apple_pay.top_up":"用 Apple Pay 充值","button.cancel":"取消","button.change":"更改","button.google_pay.buy":"用 Google Pay 購買","button.google_pay.default":"Google Pay","button.google_pay.donate":"用 Google Pay 捐款","button.link.autofill":"自動填充","button.link.autofill_alt":"使用","button.link.autofill_aria_label":"用 Link 自動填充","button.link.card_clear":"停止使用 Link 並手動輸入金融卡詳情。","button.link.express_pay":"快速支付","button.link.manage":"目前在 Link 上支付使用的是尾號為 {last4} 的金融卡。選擇另一支付方式","button.link.manage.cardCvc":"當前使用 Link。請更新此卡的 CVC 安全碼。","button.link.manage.cardExpiry":"當前使用 Link，有效期為 {expiry}。請更新此卡的有效期。","button.link.manage.postalCode":"當前使用 Link，郵遞區號為 {postal}。請更新此卡的郵遞區號。","button.link.pay_faster":"更快支付","button.link.pay_faster_with":"用 {linkLogo} 更快支付","button.link.pay_faster_with_link":"用 Link 更快支付","button.link.pay_with":"用  {linkLogo} 支付","button.link.pay_with_last_4":"用 ••{last4} 支付","button.link.save_with":"用 {linkLogo} 保存","button.link.save_with_aria_label":"用 Link 保存","button.link.use_last_4_aria_label":"用 Link 自動填充尾號為 {last4} 的金融卡","button.logout":"退出","button.pay_with":"支付方式","button.payment_request.book":"立即預定","button.payment_request.buy":"立即購買","button.payment_request.default":"立即支付","button.payment_request.donate":"捐款","button.remove":"移除","button.retry":"重試","button.save":"保存","button.save_with":"保存方式","button.see_more":"查看更多","button.update":"更新","placeholders.accountHolderType":"開戶人類型","placeholders.auBankAccountNumber":"帳號","placeholders.cardNumber":"卡號","placeholders.cardNumberShort":"卡號","placeholders.company":"商家","placeholders.cvc":"CVC","placeholders.expiry":"月/年","placeholders.individual":"個人","placeholders.postal_code":"郵遞區號","placeholders.postcode":"郵遞區號","placeholders.securityCode":"安全碼","placeholders.selectBank":"選擇銀行","placeholders.zip":"郵遞區號","button.prb_warning.badge_label":"有可用升級","button.prb_warning.button_primary":"立即升級","button.prb_warning.button_secondary":"解散一週","button.prb_warning.description":"我們注意到您正在使用付款請求按鈕 (Payment Request Button)。升級到 {ece_link} 以獲得最新的功能和優化。","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"同時顯示多種支付方式，包括：Amazon Pay、Link 和 PayPal（僅限歐盟）。","button.prb_warning.li2":"跨瀏覽器支援 Google Pay 和 Apple Pay (iOS 18+)。","button.prb_warning.li3":"為您的客戶動態排序和顯示最相關的快速結帳選項。","button.prb_warning.nav_header":"測試模式","button.prb_warning.title":"升級您的傳統一鍵支付按鈕"}')
        },
        70445: function(e) {
            "use strict";
            e.exports = JSON.parse('{"button.afterpay.close_dialog":"关闭对话框","button.apple_pay.add_money":"用 Apple Pay 充值","button.apple_pay.book":"用 Apple Pay 预订","button.apple_pay.buy":"用 Apple Pay 购买","button.apple_pay.check_out":"用 Apple Pay 结账","button.apple_pay.contribute":"用 Apple Pay 捐款","button.apple_pay.default":"Apple Pay","button.apple_pay.donate":"使用 Apple Pay 捐赠","button.apple_pay.order":"用 Apple Pay 下单","button.apple_pay.reload":"用 Apple Pay 重新加载","button.apple_pay.rent":"用 Apple Pay 租赁","button.apple_pay.subscribe":"用 Apple Pay 订阅","button.apple_pay.support":"用 Apple Pay 支持","button.apple_pay.tip":"用 Apple Pay 支付小费","button.apple_pay.top_up":"用 Apple Pay 充值","button.cancel":"取消","button.change":"更改","button.google_pay.buy":"用 Google Pay 购买","button.google_pay.default":"Google Pay","button.google_pay.donate":"用 Google Pay 捐款","button.link.autofill":"自动填充","button.link.autofill_alt":"使用","button.link.autofill_aria_label":"用 Link 自动填充","button.link.card_clear":"停止使用 Link 并手动输入银行卡详情。","button.link.express_pay":"快速支付","button.link.manage":"目前在 Link 上支付使用的是尾号为 {last4} 的银行卡。选择另一支付方式","button.link.manage.cardCvc":"当前使用的是 Link。请更新此卡的 CVC 安全码。","button.link.manage.cardExpiry":"当前使用 Link，有效期为 {expiry}。更新此卡的有效期。","button.link.manage.postalCode":"当前使用 Link，邮编为 {postal}。更新此卡的邮编。","button.link.pay_faster":"更快支付","button.link.pay_faster_with":"用 {linkLogo} 更快支付","button.link.pay_faster_with_link":"用 Link 更快支付","button.link.pay_with":"用  {linkLogo} 支付","button.link.pay_with_last_4":"用 ••{last4} 支付","button.link.save_with":"用 {linkLogo} 保存","button.link.save_with_aria_label":"用 Link 保存","button.link.use_last_4_aria_label":"用 Link 自动填充尾号为 {last4} 的银行卡","button.logout":"退出","button.pay_with":"支付方式","button.payment_request.book":"立即预订","button.payment_request.buy":"立即购买","button.payment_request.default":"立即支付","button.payment_request.donate":"捐款","button.remove":"移除","button.retry":"重试","button.save":"保存","button.save_with":"保存方式","button.see_more":"查看更多","button.update":"更新","placeholders.accountHolderType":"账户持有人类型","placeholders.auBankAccountNumber":"账号","placeholders.cardNumber":"卡号","placeholders.cardNumberShort":"卡号","placeholders.company":"商家","placeholders.cvc":"CVC","placeholders.expiry":"月/年","placeholders.individual":"个人","placeholders.postal_code":"邮编","placeholders.postcode":"邮编","placeholders.securityCode":"安全码","placeholders.selectBank":"选择银行","placeholders.zip":"邮编","button.prb_warning.badge_label":"有可用的升级","button.prb_warning.button_primary":"立即升级","button.prb_warning.button_secondary":"解散一周","button.prb_warning.description":"我们注意到您正在使用付款请求按钮 (Payment Request Button)。升级到 {ece_link} 以获得最新的功能和优化。","button.prb_warning.ece_link":"Express Checkout Element","button.prb_warning.li1":"同时显示多种支付方式，包括：Amazon Pay、Link 和 PayPal（仅限欧盟）。","button.prb_warning.li2":"跨浏览器支持 Google Pay 和 Apple Pay (iOS 18+)。","button.prb_warning.li3":"为您的客户动态排序和显示最相关的快速结账选项。","button.prb_warning.nav_header":"测试模式","button.prb_warning.title":"升级您的传统一键支付按钮"}')
        }
    }
]);