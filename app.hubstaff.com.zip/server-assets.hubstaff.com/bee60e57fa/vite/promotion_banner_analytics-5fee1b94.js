window.onPromotionBannerCtaClick = a => {
    a && a.addEventListener("click", () => {
        var o;
        (o = window.analytics) == null || o.track("Retention banner primary CTA", {
            feature: a.dataset.feature,
            product: a.dataset.product || null,
            promotion_type: a.dataset.promotionType,
            organization_id: parseInt(a.dataset.organizationId),
            user_role: a.dataset.userRole,
            organization_plan: a.dataset.organizationPlan,
            organization_plan_trial: a.dataset.organizationPlanTrial === "true"
        })
    })
};
onPromotionBannerCtaClick(document.querySelector("#primary-cta-promotion-banner"));