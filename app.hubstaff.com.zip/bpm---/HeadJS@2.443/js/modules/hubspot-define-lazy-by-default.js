// Change the default hubspot.define bahavior to be lazy by default
hubspot.define = hubspot.defineLazy;