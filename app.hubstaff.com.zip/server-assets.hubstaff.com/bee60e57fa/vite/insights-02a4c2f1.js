import "./init-ef420420.js";
import {
    B as e,
    V as i
} from "./vendor-f5db2be7.js";
import {
    c as r
} from "./base-543c3a70.js";
import {
    s as c,
    a as d,
    b as g,
    c as u
} from "./mutations-2c62a19a.js";
import {
    t as h,
    kB as l
} from "./shared-5f1b437f.js";
const a = "LOAD_STATE",
    p = {
        loadState({
            commit: t
        }, s) {
            t(a, s)
        }
    },
    m = {
        proficiencyRankingTop: t => e(t, "widgets.productivity_top", []),
        proficiencyRankingBottom: t => e(t, "widgets.productivity_bottom", []),
        insightsUrl: t => t.insights_url || "#"
    },
    S = {
        [a](t, s) {
            t.insights_url = s.insights_url, t.widgets = s.widgets
        }
    },
    b = {
        insights_url: null
    },
    f = { ...b,
        ...c
    },
    _ = { ...m,
        ...d
    },
    A = { ...p,
        ...g
    },
    w = { ...S,
        ...u
    };

function D(t = {}) {
    return r({
        state: { ...f,
            ...t.state
        },
        getters: _,
        mutations: w,
        actions: A
    })
}
const o = {
    install(t) {
        t.directive("tooltip", h)
    },
    createdHook(t) {
        return function() {
            this.$store.dispatch("loadState", t)
        }
    }
};

function I() {
    const t = document.querySelector("#insights-widget"),
        s = JSON.parse(t.dataset.initialState);
    i.use(o), new i({
        el: t,
        store: D(),
        name: "InsightsDashboardWidget",
        render: n => n(l),
        created: o.createdHook(s)
    })
}
export {
    I as i
};