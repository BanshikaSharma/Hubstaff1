import { FILES, QUICK_REPLIES, LOCATION, CONTACT } from '../../common-message-format/constants/attachmentTypes';
export const ACCEPTED_ATTACHMENT_TYPES = {
  [FILES]: true,
  [QUICK_REPLIES]: true,
  [LOCATION]: true,
  [CONTACT]: true
};