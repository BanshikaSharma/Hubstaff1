export const SEGMENT_API_HOST = 'api.segment.io/v1'
