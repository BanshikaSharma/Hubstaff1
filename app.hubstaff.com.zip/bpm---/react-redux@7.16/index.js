"use strict";
"use es6";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Provider = Provider;
exports.ReactReduxContext = void 0;
Object.defineProperty(exports, "batch", {
    enumerable: true,
    get: function() {
        return _reactDom.unstable_batchedUpdates;
    }
});
exports.connect = connect;
exports.createDispatchHook = createDispatchHook;
exports.createSelectorHook = createSelectorHook;
exports.createStoreHook = createStoreHook;
exports.shallowEqual = shallowEqual;
exports.useStore = exports.useSelector = exports.useDispatch = void 0;
var _react = _interopRequireWildcard(require("react"));
var _withSelector = require("use-sync-external-store/with-selector");
var _reactDom = require("react-dom");
var _hoistNonReactStatics = _interopRequireDefault(require("hoist-non-react-statics"));
var _reactIs = require("react-is");

function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}

function _interopRequireWildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {};
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var key in obj) {
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
// Default to a dummy "batch" implementation that just runs the callback
function defaultNoopBatch(callback) {
    callback();
}
let batch = defaultNoopBatch; // Allow injecting another batching function later

const setBatch = newBatch => batch = newBatch; // Supply a getter just to skip dealing with ESM bindings

const getBatch = () => batch;
const ReactReduxContext = exports.ReactReduxContext = /*#__PURE__*/ (0, _react.createContext)(null);
if (process.env.NODE_ENV !== 'production') {
    ReactReduxContext.displayName = 'ReactRedux';
}

/**
 * A hook to access the value of the `ReactReduxContext`. This is a low-level
 * hook that you should usually not need to call directly.
 *
 * @returns {any} the value of the `ReactReduxContext`
 *
 * @example
 *
 * import React from 'react'
 * import { useReduxContext } from 'react-redux'
 *
 * export const CounterComponent = () => {
 *   const { store } = useReduxContext()
 *   return <div>{store.getState()}</div>
 * }
 */
function useReduxContext() {
    const contextValue = (0, _react.useContext)(ReactReduxContext);
    if (process.env.NODE_ENV !== 'production' && !contextValue) {
        throw new Error('could not find react-redux context value; please ensure the component is wrapped in a <Provider>');
    }
    return contextValue;
}
const notInitialized = () => {
    throw new Error('uSES not initialized!');
};
let useSyncExternalStoreWithSelector = notInitialized;
const initializeUseSelector = fn => {
    useSyncExternalStoreWithSelector = fn;
};
const refEquality = (a, b) => a === b;
/**
 * Hook factory, which creates a `useSelector` hook bound to a given context.
 *
 * @param {React.Context} [context=ReactReduxContext] Context passed to your `<Provider>`.
 * @returns {Function} A `useSelector` hook bound to the specified context.
 */

function createSelectorHook(context = ReactReduxContext) {
    const useReduxContext$1 = context === ReactReduxContext ? useReduxContext : () => (0, _react.useContext)(context);
    return function useSelector(selector, equalityFn = refEquality) {
        if (process.env.NODE_ENV !== 'production') {
            if (!selector) {
                throw new Error(`You must pass a selector to useSelector`);
            }
            if (typeof selector !== 'function') {
                throw new Error(`You must pass a function as a selector to useSelector`);
            }
            if (typeof equalityFn !== 'function') {
                throw new Error(`You must pass a function as an equality function to useSelector`);
            }
        }
        const {
            store,
            subscription,
            getServerState
        } = useReduxContext$1();
        const selectedState = useSyncExternalStoreWithSelector(subscription.addNestedSub, store.getState, getServerState || store.getState, selector, equalityFn);
        (0, _react.useDebugValue)(selectedState);
        return selectedState;
    };
}
/**
 * A hook to access the redux store's state. This hook takes a selector function
 * as an argument. The selector is called with the store state.
 *
 * This hook takes an optional equality comparison function as the second parameter
 * that allows you to customize the way the selected state is compared to determine
 * whether the component needs to be re-rendered.
 *
 * @param {Function} selector the selector function
 * @param {Function=} equalityFn the function that will be used to determine equality
 *
 * @returns {any} the selected state
 *
 * @example
 *
 * import React from 'react'
 * import { useSelector } from 'react-redux'
 *
 * export const CounterComponent = () => {
 *   const counter = useSelector(state => state.counter)
 *   return <div>{counter}</div>
 * }
 */

const useSelector = exports.useSelector = /*#__PURE__*/ createSelectorHook();

function _extends() {
    _extends = Object.assign || function(target) {
        for (var i = 1; i < arguments.length; i++) {
            var source = arguments[i];
            for (var key in source) {
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key];
                }
            }
        }
        return target;
    };
    return _extends.apply(this, arguments);
}

function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}

/**
 * Prints a warning in the console if it exists.
 *
 * @param {String} message The warning message.
 * @returns {void}
 */
function warning(message) {
    /* eslint-disable no-console */
    if (typeof console !== 'undefined' && typeof console.error === 'function') {
        console.error(message);
    }
    /* eslint-enable no-console */

    try {
        // This error was thrown as a convenience so that if you enable
        // "break on all exceptions" in your console,
        // it would pause the execution at this line.
        throw new Error(message);
        /* eslint-disable no-empty */
    } catch (e) {}
    /* eslint-enable no-empty */
}

function verify(selector, methodName) {
    if (!selector) {
        throw new Error(`Unexpected value for ${methodName} in connect.`);
    } else if (methodName === 'mapStateToProps' || methodName === 'mapDispatchToProps') {
        if (!Object.prototype.hasOwnProperty.call(selector, 'dependsOnOwnProps')) {
            warning(`The selector for ${methodName} of connect did not specify a value for dependsOnOwnProps.`);
        }
    }
}

function verifySubselectors(mapStateToProps, mapDispatchToProps, mergeProps) {
    verify(mapStateToProps, 'mapStateToProps');
    verify(mapDispatchToProps, 'mapDispatchToProps');
    verify(mergeProps, 'mergeProps');
}
const _excluded$1 = ["initMapStateToProps", "initMapDispatchToProps", "initMergeProps"];

function pureFinalPropsSelectorFactory(mapStateToProps, mapDispatchToProps, mergeProps, dispatch, {
    areStatesEqual,
    areOwnPropsEqual,
    areStatePropsEqual
}) {
    let hasRunAtLeastOnce = false;
    let state;
    let ownProps;
    let stateProps;
    let dispatchProps;
    let mergedProps;

    function handleFirstCall(firstState, firstOwnProps) {
        state = firstState;
        ownProps = firstOwnProps;
        stateProps = mapStateToProps(state, ownProps);
        dispatchProps = mapDispatchToProps(dispatch, ownProps);
        mergedProps = mergeProps(stateProps, dispatchProps, ownProps);
        hasRunAtLeastOnce = true;
        return mergedProps;
    }

    function handleNewPropsAndNewState() {
        stateProps = mapStateToProps(state, ownProps);
        if (mapDispatchToProps.dependsOnOwnProps) dispatchProps = mapDispatchToProps(dispatch, ownProps);
        mergedProps = mergeProps(stateProps, dispatchProps, ownProps);
        return mergedProps;
    }

    function handleNewProps() {
        if (mapStateToProps.dependsOnOwnProps) stateProps = mapStateToProps(state, ownProps);
        if (mapDispatchToProps.dependsOnOwnProps) dispatchProps = mapDispatchToProps(dispatch, ownProps);
        mergedProps = mergeProps(stateProps, dispatchProps, ownProps);
        return mergedProps;
    }

    function handleNewState() {
        const nextStateProps = mapStateToProps(state, ownProps);
        const statePropsChanged = !areStatePropsEqual(nextStateProps, stateProps);
        stateProps = nextStateProps;
        if (statePropsChanged) mergedProps = mergeProps(stateProps, dispatchProps, ownProps);
        return mergedProps;
    }

    function handleSubsequentCalls(nextState, nextOwnProps) {
        const propsChanged = !areOwnPropsEqual(nextOwnProps, ownProps);
        const stateChanged = !areStatesEqual(nextState, state, nextOwnProps, ownProps);
        state = nextState;
        ownProps = nextOwnProps;
        if (propsChanged && stateChanged) return handleNewPropsAndNewState();
        if (propsChanged) return handleNewProps();
        if (stateChanged) return handleNewState();
        return mergedProps;
    }
    return function pureFinalPropsSelector(nextState, nextOwnProps) {
        return hasRunAtLeastOnce ? handleSubsequentCalls(nextState, nextOwnProps) : handleFirstCall(nextState, nextOwnProps);
    };
}
// TODO: Add more comments
// The selector returned by selectorFactory will memoize its results,
// allowing connect's shouldComponentUpdate to return false if final
// props have not changed.
function finalPropsSelectorFactory(dispatch, _ref) {
    let {
        initMapStateToProps,
        initMapDispatchToProps,
        initMergeProps
    } = _ref,
    options = _objectWithoutPropertiesLoose(_ref, _excluded$1);
    const mapStateToProps = initMapStateToProps(dispatch, options);
    const mapDispatchToProps = initMapDispatchToProps(dispatch, options);
    const mergeProps = initMergeProps(dispatch, options);
    if (process.env.NODE_ENV !== 'production') {
        verifySubselectors(mapStateToProps, mapDispatchToProps, mergeProps);
    }
    return pureFinalPropsSelectorFactory(mapStateToProps, mapDispatchToProps, mergeProps, dispatch, options);
}

function bindActionCreators(actionCreators, dispatch) {
    const boundActionCreators = {};
    for (const key in actionCreators) {
        const actionCreator = actionCreators[key];
        if (typeof actionCreator === 'function') {
            boundActionCreators[key] = (...args) => dispatch(actionCreator(...args));
        }
    }
    return boundActionCreators;
}

/**
 * @param {any} obj The object to inspect.
 * @returns {boolean} True if the argument appears to be a plain object.
 */
function isPlainObject(obj) {
    if (typeof obj !== 'object' || obj === null) return false;
    let proto = Object.getPrototypeOf(obj);
    if (proto === null) return true;
    let baseProto = proto;
    while (Object.getPrototypeOf(baseProto) !== null) {
        baseProto = Object.getPrototypeOf(baseProto);
    }
    return proto === baseProto;
}

function verifyPlainObject(value, displayName, methodName) {
    if (!isPlainObject(value)) {
        warning(`${methodName}() in ${displayName} must return a plain object. Instead received ${value}.`);
    }
}

function wrapMapToPropsConstant(
    // * Note:
    //  It seems that the dispatch argument
    //  could be a dispatch function in some cases (ex: whenMapDispatchToPropsIsMissing)
    //  and a state object in some others (ex: whenMapStateToPropsIsMissing)
    // eslint-disable-next-line no-unused-vars
    getConstant) {
    return function initConstantSelector(dispatch) {
        const constant = getConstant(dispatch);

        function constantSelector() {
            return constant;
        }
        constantSelector.dependsOnOwnProps = false;
        return constantSelector;
    };
} // dependsOnOwnProps is used by createMapToPropsProxy to determine whether to pass props as args
// to the mapToProps function being wrapped. It is also used by makePurePropsSelector to determine
// whether mapToProps needs to be invoked when props have changed.
//
// A length of one signals that mapToProps does not depend on props from the parent component.
// A length of zero is assumed to mean mapToProps is getting args via arguments or ...args and
// therefore not reporting its length accurately..
// TODO Can this get pulled out so that we can subscribe directly to the store if we don't need ownProps?

function getDependsOnOwnProps(mapToProps) {
    return mapToProps.dependsOnOwnProps ? Boolean(mapToProps.dependsOnOwnProps) : mapToProps.length !== 1;
} // Used by whenMapStateToPropsIsFunction and whenMapDispatchToPropsIsFunction,
// this function wraps mapToProps in a proxy function which does several things:
//
//  * Detects whether the mapToProps function being called depends on props, which
//    is used by selectorFactory to decide if it should reinvoke on props changes.
//
//  * On first call, handles mapToProps if returns another function, and treats that
//    new function as the true mapToProps for subsequent calls.
//
//  * On first call, verifies the first result is a plain object, in order to warn
//    the developer that their mapToProps function is not returning a valid result.
//

function wrapMapToPropsFunc(mapToProps, methodName) {
    return function initProxySelector(dispatch, {
        displayName
    }) {
        const proxy = function mapToPropsProxy(stateOrDispatch, ownProps) {
            return proxy.dependsOnOwnProps ? proxy.mapToProps(stateOrDispatch, ownProps) : proxy.mapToProps(stateOrDispatch, undefined);
        }; // allow detectFactoryAndVerify to get ownProps

        proxy.dependsOnOwnProps = true;
        proxy.mapToProps = function detectFactoryAndVerify(stateOrDispatch, ownProps) {
            proxy.mapToProps = mapToProps;
            proxy.dependsOnOwnProps = getDependsOnOwnProps(mapToProps);
            let props = proxy(stateOrDispatch, ownProps);
            if (typeof props === 'function') {
                proxy.mapToProps = props;
                proxy.dependsOnOwnProps = getDependsOnOwnProps(props);
                props = proxy(stateOrDispatch, ownProps);
            }
            if (process.env.NODE_ENV !== 'production') verifyPlainObject(props, displayName, methodName);
            return props;
        };
        return proxy;
    };
}

function createInvalidArgFactory(arg, name) {
    return (dispatch, options) => {
        throw new Error(`Invalid value of type ${typeof arg} for ${name} argument when connecting component ${options.wrappedComponentName}.`);
    };
}

function mapDispatchToPropsFactory(mapDispatchToProps) {
    return mapDispatchToProps && typeof mapDispatchToProps === 'object' ? wrapMapToPropsConstant(dispatch =>
            // @ts-ignore
            bindActionCreators(mapDispatchToProps, dispatch)) : !mapDispatchToProps ? wrapMapToPropsConstant(dispatch => ({
            dispatch
        })) : typeof mapDispatchToProps === 'function' ?
        // @ts-ignore
        wrapMapToPropsFunc(mapDispatchToProps, 'mapDispatchToProps') : createInvalidArgFactory(mapDispatchToProps, 'mapDispatchToProps');
}

function mapStateToPropsFactory(mapStateToProps) {
    return !mapStateToProps ? wrapMapToPropsConstant(() => ({})) : typeof mapStateToProps === 'function' ?
        // @ts-ignore
        wrapMapToPropsFunc(mapStateToProps, 'mapStateToProps') : createInvalidArgFactory(mapStateToProps, 'mapStateToProps');
}

function defaultMergeProps(stateProps, dispatchProps, ownProps) {
    // @ts-ignore
    return _extends({}, ownProps, stateProps, dispatchProps);
}

function wrapMergePropsFunc(mergeProps) {
    return function initMergePropsProxy(dispatch, {
        displayName,
        areMergedPropsEqual
    }) {
        let hasRunOnce = false;
        let mergedProps;
        return function mergePropsProxy(stateProps, dispatchProps, ownProps) {
            const nextMergedProps = mergeProps(stateProps, dispatchProps, ownProps);
            if (hasRunOnce) {
                if (!areMergedPropsEqual(nextMergedProps, mergedProps)) mergedProps = nextMergedProps;
            } else {
                hasRunOnce = true;
                mergedProps = nextMergedProps;
                if (process.env.NODE_ENV !== 'production') verifyPlainObject(mergedProps, displayName, 'mergeProps');
            }
            return mergedProps;
        };
    };
}

function mergePropsFactory(mergeProps) {
    return !mergeProps ? () => defaultMergeProps : typeof mergeProps === 'function' ? wrapMergePropsFunc(mergeProps) : createInvalidArgFactory(mergeProps, 'mergeProps');
}

// well as nesting subscriptions of descendant components, so that we can ensure the
// ancestor components re-render before descendants

function createListenerCollection() {
    const batch = getBatch();
    let first = null;
    let last = null;
    return {
        clear() {
            first = null;
            last = null;
        },
        notify() {
            batch(() => {
                let listener = first;
                while (listener) {
                    listener.callback();
                    listener = listener.next;
                }
            });
        },
        get() {
            let listeners = [];
            let listener = first;
            while (listener) {
                listeners.push(listener);
                listener = listener.next;
            }
            return listeners;
        },
        subscribe(callback) {
            let isSubscribed = true;
            let listener = last = {
                callback,
                next: null,
                prev: last
            };
            if (listener.prev) {
                listener.prev.next = listener;
            } else {
                first = listener;
            }
            return function unsubscribe() {
                if (!isSubscribed || first === null) return;
                isSubscribed = false;
                if (listener.next) {
                    listener.next.prev = listener.prev;
                } else {
                    last = listener.prev;
                }
                if (listener.prev) {
                    listener.prev.next = listener.next;
                } else {
                    first = listener.next;
                }
            };
        }
    };
}
const nullListeners = {
    notify() {},
    get: () => []
};

function createSubscription(store, parentSub) {
    let unsubscribe;
    let listeners = nullListeners;

    function addNestedSub(listener) {
        trySubscribe();
        return listeners.subscribe(listener);
    }

    function notifyNestedSubs() {
        listeners.notify();
    }

    function handleChangeWrapper() {
        if (subscription.onStateChange) {
            subscription.onStateChange();
        }
    }

    function isSubscribed() {
        return Boolean(unsubscribe);
    }

    function trySubscribe() {
        if (!unsubscribe) {
            unsubscribe = parentSub ? parentSub.addNestedSub(handleChangeWrapper) : store.subscribe(handleChangeWrapper);
            listeners = createListenerCollection();
        }
    }

    function tryUnsubscribe() {
        if (unsubscribe) {
            unsubscribe();
            unsubscribe = undefined;
            listeners.clear();
            listeners = nullListeners;
        }
    }
    const subscription = {
        addNestedSub,
        notifyNestedSubs,
        handleChangeWrapper,
        isSubscribed,
        trySubscribe,
        tryUnsubscribe,
        getListeners: () => listeners
    };
    return subscription;
}

// To get around it, we can conditionally useEffect on the server (no-op) and
// useLayoutEffect in the browser. We need useLayoutEffect to ensure the store
// subscription callback always has the selector from the latest render commit
// available, otherwise a store update may happen between render and the effect,
// which may cause missed updates; we also must ensure the store subscription
// is created synchronously, otherwise a store update may occur before the
// subscription is created and an inconsistent state may be observed
// Matches logic in React's `shared/ExecutionEnvironment` file

const canUseDOM = !!(typeof window !== 'undefined' && typeof window.document !== 'undefined' && typeof window.document.createElement !== 'undefined');
const useIsomorphicLayoutEffect = canUseDOM ? _react.useLayoutEffect : _react.useEffect;

function is(x, y) {
    if (x === y) {
        return x !== 0 || y !== 0 || 1 / x === 1 / y;
    } else {
        return x !== x && y !== y;
    }
}

function shallowEqual(objA, objB) {
    if (is(objA, objB)) return true;
    if (typeof objA !== 'object' || objA === null || typeof objB !== 'object' || objB === null) {
        return false;
    }
    const keysA = Object.keys(objA);
    const keysB = Object.keys(objB);
    if (keysA.length !== keysB.length) return false;
    for (let i = 0; i < keysA.length; i++) {
        if (!Object.prototype.hasOwnProperty.call(objB, keysA[i]) || !is(objA[keysA[i]], objB[keysA[i]])) {
            return false;
        }
    }
    return true;
}
const _excluded = ["reactReduxForwardedRef"];
let useSyncExternalStore = notInitialized;
const initializeConnect = fn => {
    useSyncExternalStore = fn;
}; // Define some constant arrays just to avoid re-creating these
const NO_SUBSCRIPTION_ARRAY = [null, null]; // Attempts to stringify whatever not-really-a-component value we were given
// for logging in an error message

const stringifyComponent = Comp => {
    try {
        return JSON.stringify(Comp);
    } catch (err) {
        return String(Comp);
    }
};

// This is "just" a `useLayoutEffect`, but with two modifications:
// - we need to fall back to `useEffect` in SSR to avoid annoying warnings
// - we extract this to a separate function to avoid closing over values
//   and causing memory leaks
function useIsomorphicLayoutEffectWithArgs(effectFunc, effectArgs, dependencies) {
    useIsomorphicLayoutEffect(() => effectFunc(...effectArgs), dependencies);
} // Effect callback, extracted: assign the latest props values to refs for later usage

function captureWrapperProps(lastWrapperProps, lastChildProps, renderIsScheduled, wrapperProps,
    // actualChildProps: unknown,
    childPropsFromStoreUpdate, notifyNestedSubs) {
    // We want to capture the wrapper props and child props we used for later comparisons
    lastWrapperProps.current = wrapperProps;
    renderIsScheduled.current = false; // If the render was from a store update, clear out that reference and cascade the subscriber update

    if (childPropsFromStoreUpdate.current) {
        childPropsFromStoreUpdate.current = null;
        notifyNestedSubs();
    }
} // Effect callback, extracted: subscribe to the Redux store or nearest connected ancestor,
// check for updates after dispatched actions, and trigger re-renders.

function subscribeUpdates(shouldHandleStateChanges, store, subscription, childPropsSelector, lastWrapperProps, lastChildProps, renderIsScheduled, isMounted, childPropsFromStoreUpdate, notifyNestedSubs,
    // forceComponentUpdateDispatch: React.Dispatch<any>,
    additionalSubscribeListener) {
    // If we're not subscribed to the store, nothing to do here
    if (!shouldHandleStateChanges) return () => {}; // Capture values for checking if and when this component unmounts

    let didUnsubscribe = false;
    let lastThrownError = null; // We'll run this callback every time a store subscription update propagates to this component

    const checkForUpdates = () => {
        if (didUnsubscribe || !isMounted.current) {
            // Don't run stale listeners.
            // Redux doesn't guarantee unsubscriptions happen until next dispatch.
            return;
        } // TODO We're currently calling getState ourselves here, rather than letting `uSES` do it

        const latestStoreState = store.getState();
        let newChildProps, error;
        try {
            // Actually run the selector with the most recent store state and wrapper props
            // to determine what the child props should be
            newChildProps = childPropsSelector(latestStoreState, lastWrapperProps.current);
        } catch (e) {
            error = e;
            lastThrownError = e;
        }
        if (!error) {
            lastThrownError = null;
        } // If the child props haven't changed, nothing to do here - cascade the subscription update

        if (newChildProps === lastChildProps.current) {
            if (!renderIsScheduled.current) {
                notifyNestedSubs();
            }
        } else {
            // Save references to the new child props.  Note that we track the "child props from store update"
            // as a ref instead of a useState/useReducer because we need a way to determine if that value has
            // been processed.  If this went into useState/useReducer, we couldn't clear out the value without
            // forcing another re-render, which we don't want.
            lastChildProps.current = newChildProps;
            childPropsFromStoreUpdate.current = newChildProps;
            renderIsScheduled.current = true; // TODO This is hacky and not how `uSES` is meant to be used
            // Trigger the React `useSyncExternalStore` subscriber

            additionalSubscribeListener();
        }
    }; // Actually subscribe to the nearest connected ancestor (or store)

    subscription.onStateChange = checkForUpdates;
    subscription.trySubscribe(); // Pull data from the store after first render in case the store has
    // changed since we began.

    checkForUpdates();
    const unsubscribeWrapper = () => {
        didUnsubscribe = true;
        subscription.tryUnsubscribe();
        subscription.onStateChange = null;
        if (lastThrownError) {
            // It's possible that we caught an error due to a bad mapState function, but the
            // parent re-rendered without this component and we're about to unmount.
            // This shouldn't happen as long as we do top-down subscriptions correctly, but
            // if we ever do those wrong, this throw will surface the error in our tests.
            // In that case, throw the error from here so it doesn't get lost.
            throw lastThrownError;
        }
    };
    return unsubscribeWrapper;
} // Reducer initial state creation for our update reducer

function strictEqual(a, b) {
    return a === b;
}
/**
 * Infers the type of props that a connector will inject into a component.
 */

let hasWarnedAboutDeprecatedPureOption = false;
/**
 * Connects a React component to a Redux store.
 *
 * - Without arguments, just wraps the component, without changing the behavior / props
 *
 * - If 2 params are passed (3rd param, mergeProps, is skipped), default behavior
 * is to override ownProps (as stated in the docs), so what remains is everything that's
 * not a state or dispatch prop
 *
 * - When 3rd param is passed, we don't know if ownProps propagate and whether they
 * should be valid component props, because it depends on mergeProps implementation.
 * As such, it is the user's responsibility to extend ownProps interface from state or
 * dispatch props or both when applicable
 *
 * @param mapStateToProps A function that extracts values from state
 * @param mapDispatchToProps Setup for dispatching actions
 * @param mergeProps Optional callback to merge state and dispatch props together
 * @param options Options for configuring the connection
 *
 */

function connect(mapStateToProps, mapDispatchToProps, mergeProps, {
    // The `pure` option has been removed, so TS doesn't like us destructuring this to check its existence.
    // @ts-ignore
    pure,
    areStatesEqual = strictEqual,
    areOwnPropsEqual = shallowEqual,
    areStatePropsEqual = shallowEqual,
    areMergedPropsEqual = shallowEqual,
    // use React's forwardRef to expose a ref of the wrapped component
    forwardRef = false,
    // the context consumer to use
    context = ReactReduxContext
} = {}) {
    if (process.env.NODE_ENV !== 'production') {
        if (pure !== undefined && !hasWarnedAboutDeprecatedPureOption) {
            hasWarnedAboutDeprecatedPureOption = true;
            warning('The `pure` option has been removed. `connect` is now always a "pure/memoized" component');
        }
    }
    const Context = context;
    const initMapStateToProps = mapStateToPropsFactory(mapStateToProps);
    const initMapDispatchToProps = mapDispatchToPropsFactory(mapDispatchToProps);
    const initMergeProps = mergePropsFactory(mergeProps);
    const shouldHandleStateChanges = Boolean(mapStateToProps);
    const wrapWithConnect = WrappedComponent => {
        if (process.env.NODE_ENV !== 'production' && !(0, _reactIs.isValidElementType)(WrappedComponent)) {
            throw new Error(`You must pass a component to the function returned by connect. Instead received ${stringifyComponent(WrappedComponent)}`);
        }
        const wrappedComponentName = WrappedComponent.displayName || WrappedComponent.name || 'Component';
        const displayName = `Connect(${wrappedComponentName})`;
        const selectorFactoryOptions = {
            shouldHandleStateChanges,
            displayName,
            wrappedComponentName,
            WrappedComponent,
            // @ts-ignore
            initMapStateToProps,
            // @ts-ignore
            initMapDispatchToProps,
            initMergeProps,
            areStatesEqual,
            areStatePropsEqual,
            areOwnPropsEqual,
            areMergedPropsEqual
        };

        function ConnectFunction(props) {
            const [propsContext, reactReduxForwardedRef, wrapperProps] = (0, _react.useMemo)(() => {
                // Distinguish between actual "data" props that were passed to the wrapper component,
                // and values needed to control behavior (forwarded refs, alternate context instances).
                // To maintain the wrapperProps object reference, memoize this destructuring.
                const {
                    reactReduxForwardedRef
                } = props,
                wrapperProps = _objectWithoutPropertiesLoose(props, _excluded);
                return [props.context, reactReduxForwardedRef, wrapperProps];
            }, [props]);
            const ContextToUse = (0, _react.useMemo)(() => {
                // Users may optionally pass in a custom context instance to use instead of our ReactReduxContext.
                // Memoize the check that determines which context instance we should use.
                return propsContext && propsContext.Consumer &&
                    // @ts-ignore
                    (0, _reactIs.isContextConsumer)( /*#__PURE__*/ _react.default.createElement(propsContext.Consumer, null)) ? propsContext : Context;
            }, [propsContext, Context]); // Retrieve the store and ancestor subscription via context, if available

            const contextValue = (0, _react.useContext)(ContextToUse); // The store _must_ exist as either a prop or in context.
            // We'll check to see if it _looks_ like a Redux store first.
            // This allows us to pass through a `store` prop that is just a plain value.

            const didStoreComeFromProps = Boolean(props.store) && Boolean(props.store.getState) && Boolean(props.store.dispatch);
            const didStoreComeFromContext = Boolean(contextValue) && Boolean(contextValue.store);
            if (process.env.NODE_ENV !== 'production' && !didStoreComeFromProps && !didStoreComeFromContext) {
                throw new Error(`Could not find "store" in the context of ` + `"${displayName}". Either wrap the root component in a <Provider>, ` + `or pass a custom React context provider to <Provider> and the corresponding ` + `React context consumer to ${displayName} in connect options.`);
            } // Based on the previous check, one of these must be true

            const store = didStoreComeFromProps ? props.store : contextValue.store;
            const getServerState = didStoreComeFromContext ? contextValue.getServerState : store.getState;
            const childPropsSelector = (0, _react.useMemo)(() => {
                // The child props selector needs the store reference as an input.
                // Re-create this selector whenever the store changes.
                return finalPropsSelectorFactory(store.dispatch, selectorFactoryOptions);
            }, [store]);
            const [subscription, notifyNestedSubs] = (0, _react.useMemo)(() => {
                if (!shouldHandleStateChanges) return NO_SUBSCRIPTION_ARRAY; // This Subscription's source should match where store came from: props vs. context. A component
                // connected to the store via props shouldn't use subscription from context, or vice versa.

                const subscription = createSubscription(store, didStoreComeFromProps ? undefined : contextValue.subscription); // `notifyNestedSubs` is duplicated to handle the case where the component is unmounted in
                // the middle of the notification loop, where `subscription` will then be null. This can
                // probably be avoided if Subscription's listeners logic is changed to not call listeners
                // that have been unsubscribed in the  middle of the notification loop.

                const notifyNestedSubs = subscription.notifyNestedSubs.bind(subscription);
                return [subscription, notifyNestedSubs];
            }, [store, didStoreComeFromProps, contextValue]); // Determine what {store, subscription} value should be put into nested context, if necessary,
            // and memoize that value to avoid unnecessary context updates.

            const overriddenContextValue = (0, _react.useMemo)(() => {
                if (didStoreComeFromProps) {
                    // This component is directly subscribed to a store from props.
                    // We don't want descendants reading from this store - pass down whatever
                    // the existing context value is from the nearest connected ancestor.
                    return contextValue;
                } // Otherwise, put this component's subscription instance into context, so that
                // connected descendants won't update until after this component is done

                return _extends({}, contextValue, {
                    subscription
                });
            }, [didStoreComeFromProps, contextValue, subscription]); // Set up refs to coordinate values between the subscription effect and the render logic

            const lastChildProps = (0, _react.useRef)();
            const lastWrapperProps = (0, _react.useRef)(wrapperProps);
            const childPropsFromStoreUpdate = (0, _react.useRef)();
            const renderIsScheduled = (0, _react.useRef)(false);
            (0, _react.useRef)(false);
            const isMounted = (0, _react.useRef)(false);
            const latestSubscriptionCallbackError = (0, _react.useRef)();
            useIsomorphicLayoutEffect(() => {
                isMounted.current = true;
                return () => {
                    isMounted.current = false;
                };
            }, []);
            const actualChildPropsSelector = (0, _react.useMemo)(() => {
                const selector = () => {
                    // Tricky logic here:
                    // - This render may have been triggered by a Redux store update that produced new child props
                    // - However, we may have gotten new wrapper props after that
                    // If we have new child props, and the same wrapper props, we know we should use the new child props as-is.
                    // But, if we have new wrapper props, those might change the child props, so we have to recalculate things.
                    // So, we'll use the child props from store update only if the wrapper props are the same as last time.
                    if (childPropsFromStoreUpdate.current && wrapperProps === lastWrapperProps.current) {
                        return childPropsFromStoreUpdate.current;
                    } // TODO We're reading the store directly in render() here. Bad idea?
                    // This will likely cause Bad Things (TM) to happen in Concurrent Mode.
                    // Note that we do this because on renders _not_ caused by store updates, we need the latest store state
                    // to determine what the child props should be.

                    return childPropsSelector(store.getState(), wrapperProps);
                };
                return selector;
            }, [store, wrapperProps]); // We need this to execute synchronously every time we re-render. However, React warns
            // about useLayoutEffect in SSR, so we try to detect environment and fall back to
            // just useEffect instead to avoid the warning, since neither will run anyway.

            const subscribeForReact = (0, _react.useMemo)(() => {
                const subscribe = reactListener => {
                    if (!subscription) {
                        return () => {};
                    }
                    return subscribeUpdates(shouldHandleStateChanges, store, subscription,
                        // @ts-ignore
                        childPropsSelector, lastWrapperProps, lastChildProps, renderIsScheduled, isMounted, childPropsFromStoreUpdate, notifyNestedSubs, reactListener);
                };
                return subscribe;
            }, [subscription]);
            useIsomorphicLayoutEffectWithArgs(captureWrapperProps, [lastWrapperProps, lastChildProps, renderIsScheduled, wrapperProps, childPropsFromStoreUpdate, notifyNestedSubs]);
            let actualChildProps;
            try {
                actualChildProps = useSyncExternalStore(
                    // TODO We're passing through a big wrapper that does a bunch of extra side effects besides subscribing
                    subscribeForReact,
                    // TODO This is incredibly hacky. We've already processed the store update and calculated new child props,
                    // TODO and we're just passing that through so it triggers a re-render for us rather than relying on `uSES`.
                    actualChildPropsSelector, getServerState ? () => childPropsSelector(getServerState(), wrapperProps) : actualChildPropsSelector);
            } catch (err) {
                if (latestSubscriptionCallbackError.current) {
                    err.message += `\nThe error may be correlated with this previous error:\n${latestSubscriptionCallbackError.current.stack}\n\n`;
                }
                throw err;
            }
            useIsomorphicLayoutEffect(() => {
                latestSubscriptionCallbackError.current = undefined;
                childPropsFromStoreUpdate.current = undefined;
                lastChildProps.current = actualChildProps;
            }); // Now that all that's done, we can finally try to actually render the child component.
            // We memoize the elements for the rendered child component as an optimization.

            const renderedWrappedComponent = (0, _react.useMemo)(() => {
                return /*#__PURE__*/ (
                    // @ts-ignore
                    _react.default.createElement(WrappedComponent, _extends({}, actualChildProps, {
                        ref: reactReduxForwardedRef
                    }))
                );
            }, [reactReduxForwardedRef, WrappedComponent, actualChildProps]); // If React sees the exact same element reference as last time, it bails out of re-rendering
            // that child, same as if it was wrapped in React.memo() or returned false from shouldComponentUpdate.

            const renderedChild = (0, _react.useMemo)(() => {
                if (shouldHandleStateChanges) {
                    // If this component is subscribed to store updates, we need to pass its own
                    // subscription instance down to our descendants. That means rendering the same
                    // Context instance, and putting a different value into the context.
                    return /*#__PURE__*/ _react.default.createElement(ContextToUse.Provider, {
                        value: overriddenContextValue
                    }, renderedWrappedComponent);
                }
                return renderedWrappedComponent;
            }, [ContextToUse, renderedWrappedComponent, overriddenContextValue]);
            return renderedChild;
        }
        const _Connect = /*#__PURE__*/ _react.default.memo(ConnectFunction);

        // Add a hacky cast to get the right output type
        const Connect = _Connect;
        Connect.WrappedComponent = WrappedComponent;
        Connect.displayName = ConnectFunction.displayName = displayName;
        if (forwardRef) {
            const _forwarded = /*#__PURE__*/ _react.default.forwardRef(function forwardConnectRef(props, ref) {
                // @ts-ignore
                return /*#__PURE__*/ _react.default.createElement(Connect, _extends({}, props, {
                    reactReduxForwardedRef: ref
                }));
            });
            const forwarded = _forwarded;
            forwarded.displayName = displayName;
            forwarded.WrappedComponent = WrappedComponent;
            return (0, _hoistNonReactStatics.default)(forwarded, WrappedComponent);
        }
        return (0, _hoistNonReactStatics.default)(Connect, WrappedComponent);
    };
    return wrapWithConnect;
}

function Provider({
    store,
    context,
    children,
    serverState
}) {
    const contextValue = (0, _react.useMemo)(() => {
        const subscription = createSubscription(store);
        return {
            store,
            subscription,
            getServerState: serverState ? () => serverState : undefined
        };
    }, [store, serverState]);
    const previousState = (0, _react.useMemo)(() => store.getState(), [store]);
    useIsomorphicLayoutEffect(() => {
        const {
            subscription
        } = contextValue;
        subscription.onStateChange = subscription.notifyNestedSubs;
        subscription.trySubscribe();
        if (previousState !== store.getState()) {
            subscription.notifyNestedSubs();
        }
        return () => {
            subscription.tryUnsubscribe();
            subscription.onStateChange = undefined;
        };
    }, [contextValue, previousState]);
    const Context = context || ReactReduxContext; // @ts-ignore 'AnyAction' is assignable to the constraint of type 'A', but 'A' could be instantiated with a different subtype

    return /*#__PURE__*/ _react.default.createElement(Context.Provider, {
        value: contextValue
    }, children);
}

/**
 * Hook factory, which creates a `useStore` hook bound to a given context.
 *
 * @param {React.Context} [context=ReactReduxContext] Context passed to your `<Provider>`.
 * @returns {Function} A `useStore` hook bound to the specified context.
 */

function createStoreHook(context = ReactReduxContext) {
    const useReduxContext$1 =
        // @ts-ignore
        context === ReactReduxContext ? useReduxContext : () => (0, _react.useContext)(context);
    return function useStore() {
        const {
            store
        } = useReduxContext$1(); // @ts-ignore

        return store;
    };
}
/**
 * A hook to access the redux store.
 *
 * @returns {any} the redux store
 *
 * @example
 *
 * import React from 'react'
 * import { useStore } from 'react-redux'
 *
 * export const ExampleComponent = () => {
 *   const store = useStore()
 *   return <div>{store.getState()}</div>
 * }
 */

const useStore = exports.useStore = /*#__PURE__*/ createStoreHook();

/**
 * Hook factory, which creates a `useDispatch` hook bound to a given context.
 *
 * @param {React.Context} [context=ReactReduxContext] Context passed to your `<Provider>`.
 * @returns {Function} A `useDispatch` hook bound to the specified context.
 */

function createDispatchHook(context = ReactReduxContext) {
    const useStore$1 =
        // @ts-ignore
        context === ReactReduxContext ? useStore : createStoreHook(context);
    return function useDispatch() {
        const store = useStore$1(); // @ts-ignore

        return store.dispatch;
    };
}
/**
 * A hook to access the redux `dispatch` function.
 *
 * @returns {any|function} redux store's `dispatch` function
 *
 * @example
 *
 * import React, { useCallback } from 'react'
 * import { useDispatch } from 'react-redux'
 *
 * export const CounterComponent = ({ value }) => {
 *   const dispatch = useDispatch()
 *   const increaseCounter = useCallback(() => dispatch({ type: 'increase-counter' }), [])
 *   return (
 *     <div>
 *       <span>{value}</span>
 *       <button onClick={increaseCounter}>Increase counter</button>
 *     </div>
 *   )
 * }
 */

const useDispatch = exports.useDispatch = /*#__PURE__*/ createDispatchHook();

// The secondary entry point assumes we are working with React 18, and thus have
initializeUseSelector(_withSelector.useSyncExternalStoreWithSelector);
initializeConnect(_react.useSyncExternalStore); // Enable batched updates in our subscriptions for use
// with standard React renderers (ReactDOM, React Native)

setBatch(_reactDom.unstable_batchedUpdates);