"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = _default;

function toVal(mix) {
    var k,
        y,
        str = '';
    if (mix) {
        if (typeof mix === 'object') {
            if (!!mix.push) {
                for (k = 0; k < mix.length; k++) {
                    if (mix[k] && (y = toVal(mix[k]))) {
                        str && (str += ' ');
                        str += y;
                    }
                }
            } else {
                for (k in mix) {
                    if (mix[k] && (y = toVal(k))) {
                        str && (str += ' ');
                        str += y;
                    }
                }
            }
        } else if (typeof mix !== 'boolean' && !mix.call) {
            str && (str += ' ');
            str += mix;
        }
    }
    return str;
}

function _default() {
    var i = 0,
        x,
        str = '';
    while (i < arguments.length) {
        if (x = toVal(arguments[i++])) {
            str && (str += ' ');
            str += x;
        }
    }
    return str;
}
module.exports = exports.default;