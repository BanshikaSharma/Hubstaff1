"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.setCustomAttribute = exports.MEASURE_USER_INFO_TIME = exports.MEASURE_API_VERIFY_TIME = exports.MARK_USER_INFO_SUCCESS = exports.MARK_USER_INFO_START = void 0;
const newRelicAvailabile = () => Boolean(window.newrelic);
const MARK_USER_INFO_START = exports.MARK_USER_INFO_START = 'mark_user_info_start';
const MARK_USER_INFO_SUCCESS = exports.MARK_USER_INFO_SUCCESS = 'mark_user_info_success';
const MEASURE_USER_INFO_TIME = exports.MEASURE_USER_INFO_TIME = 'measure_user_info_time';
const MEASURE_API_VERIFY_TIME = exports.MEASURE_API_VERIFY_TIME = 'measure_api_verify_time';
const setCustomAttribute = (name, value) => {
    if (newRelicAvailabile()) {
        window.newrelic.setCustomAttribute(name, value);
    }
};
exports.setCustomAttribute = setCustomAttribute;