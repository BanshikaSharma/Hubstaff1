import {
    e5 as t,
    e6 as e,
    e7 as n,
    e8 as p,
    e9 as m,
    ea as l,
    eb as s
} from "./shared-5f1b437f.js";
const i = {
    install(o, a) {
        if (!a) throw new Error("Google Maps key is required");
        t(o, {
            installComponents: !1,
            load: {
                libraries: "places",
                key: a
            }
        }), o.component("GmapMap", e), o.component("GmapMarker", n), o.component("GmapCircle", p), o.component("GmapPolyline", m), o.component("GmapInfoWindow", l), o.component("GmapAutocomplete", s)
    },
    Map: e,
    Marker: n,
    Circle: p,
    InfoWindow: l,
    Autocomplete: s
};
export {
    i as G
};