import "./init-ef420420.js";
import {
    at as y,
    V as l
} from "./vendor-f5db2be7.js";
import {
    br as b,
    bm as w,
    m as R,
    cd as k,
    x as A,
    d6 as S,
    t as D,
    ce as E,
    iS as i,
    iT as O,
    iU as s,
    iV as c,
    iW as I,
    iX as $
} from "./shared-5f1b437f.js";
import {
    c as T
} from "./base-543c3a70.js";
const C = {
    install(e) {
        e.component("AppDialog", b), e.component("AppButton", w), e.component("AppSelect", R), e.component("AppTooltipIcon", k), e.component("AppInfiniteScroll", A), e.component("AppCopyInputValue", S), e.directive("tooltip", D), e.directive("loading", E)
    }
};

function v(e) {
    let o = {
            note_class: e.status,
            note_tooltip: ""
        },
        n = e.converted_at || e.org_created_at || e.signup_at;
    switch (e.status) {
        case "delayed":
            if (o.note = "Delayed start", e.discount_payout.type === "percent") {
                let t = c(e.discount_payout) || "discount";
                o.note_tooltip = `You’re already at 100%! We’ll save this and start the ${t} when the next one ends.`
            } else {
                let t = s(e.discount_payout);
                o.note_tooltip = `Your discount of ${t} will be applied to your next invoice`
            }
            break;
        case "active":
            {
                let t = moment(e.discount_stops_at);o.note = `Expires ${i(t)}`
            }
            break;
        case "expired":
            {
                let t = moment(e.discount_stops_at);
                if (e.discount_payout.type === "percent") o.note = `Expired ${i(t)}`;
                else {
                    o.note = "Discount applied";
                    let a = s(e.discount_payout);
                    o.note_tooltip = `Your discount of ${a} was applied on ${i(t)}`
                }
            }
            break;
        case "timed_out":
            o.note = "Referral expired";
            break;
        case "pending":
            o.note = "Pending";
            break;
        case "trialing":
            if (e.my_referral) {
                let t = s(e.program_discount);
                switch (e.program_discount.type) {
                    case "percent":
                        let a = c(e.program_discount);
                        o.note = `${t} off`, a && (o.note += ` for ${a}`);
                        break;
                    case "fixed":
                        o.note = `${t} discount is waiting`;
                        break
                }
                o.note_tooltip = `Your ${t} discount is waiting! The discount will start when you subscribe to a paid plan.`
            } else o.note = "Pending";
            break;
        case "converted":
            o.note = "Pending";
            break;
        case "revoked":
            o.note = "Discount revoked";
            break;
        case "canceled":
            {
                let t = moment(e.discount_stops_at);o.note = `Canceled ${i(t)}`
            }
            break
    }
    if (e.my_referral) o.summary = "You were referred by another member";
    else {
        let t = e.org_created_at ? e.converted_at ? "subscribed" : "signed up for a trial" : "created an account";
        o.summary = `${e.user_email} ${t}`
    }
    return o.date = i(moment(n)), o
}
const x = {
        showDialogLoading: e => e.dialog_loading,
        showLoadingMore: e => e.loading_more,
        hasPaidPlan: e => e.has_paid_plan,
        hasReferrals: e => e.referrals.length > 0,
        hasMoreReferrals: e => e.has_more_referrals,
        hasManyOrganizations: e => e.organizations.length > 1,
        hasOneOrganization: e => e.organizations.length === 1,
        hasOrganizations: e => e.organizations.length > 0,
        myReferral: e => e.referrals.find(o => o.my_referral),
        isPending: e => e.program.status === "pending",
        isActive: e => e.program.status === "active",
        isBlocked: e => e.program.status === "blocked",
        hasChosenOrganization: e => e.organization_id !== "auto",
        organizationOptions(e) {
            return e.organizations.map(o => ({
                id: o.id,
                text: o.name
            })).sort((o, n) => o.text.localeCompare(n.text))
        },
        referralsWithInfo(e) {
            return e.referrals.map(o => {
                let n = y(o);
                return n.info = v(n), n
            })
        },
        referralSummary(e, o) {
            let n = "";
            if (e.program.effective_discount > 0) {
                if (n = `You currently have a ${e.program.effective_discount}% discount`, e.program.next_stop) {
                    let t = moment(e.program.next_stop);
                    n += ` until ${i(t)}`
                }
            } else o.myReferral && O.includes(o.myReferral.status) ? n = `Your ${s(o.myReferral.program_discount)} discount is waiting! The discount will start when you subscribe to a paid plan.` : e.program.status === "blocked" ? n = "Your referral program access has been blocked" : n = "Share your link then come back here and track your progress";
            return n
        },
        referralSummaryClass(e, o) {
            return o.isBlocked && e.program.effective_discount === 0 ? "bg-danger" : "bg-info"
        },
        oldestSignupTime(e) {
            return e.referrals.reduce((o, n) => o && o < n.signup_at ? o : n.signup_at, null)
        },
        showOrganizationDropdown: (e, o) => o.hasManyOrganizations,
        showCreateOrganization(e, o) {
            return !o.hasOrganizations && !o.showDialogLoading
        },
        showShareButtons(e, o) {
            return o.isActive && o.hasPaidPlan
        },
        showBlockedInfo: (e, o) => o.isBlocked,
        showReferralList(e, o) {
            return !o.isPending && o.hasPaidPlan
        },
        showReferralLink(e, o) {
            return o.hasOrganizations && !o.isBlocked && o.hasPaidPlan
        },
        showReferralSummary(e, o) {
            return o.isBlocked || o.hasReferrals
        },
        showShareYourLink(e, o) {
            return !o.showReferralSummary && o.showReferralLink && !o.isPending
        },
        showUpgradePlan(e, o) {
            return o.hasChosenOrganization && !o.hasPaidPlan && !o.showDialogLoading && !o.isBlocked
        },
        shareButtons(e) {
            let o = e.program.tracking_url,
                n = s(e.program.discount),
                t = c(e.program.discount);
            t ? t = ` for ${t}` : t = "";
            let a = `Try Hubstaff free then get ${n} off${t}!`,
                r = `I’ve been using Hubstaff’s all-in-one work time tracker and I thought it could help your business too.
Try it free for 14 days and if you decide to sign up, we’ll both get ${n} off${t}!

Don’t forget to use this link when you sign up: ${o}`;
            return [{
                type: "twitter",
                iconClasses: "hi hi-twitter",
                label: "Tweet",
                href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(a+" "+o)}`
            }, {
                type: "facebook",
                iconClasses: "fa fa-facebook-official",
                label: "Share",
                href: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(o)}`
            }, {
                type: "linkedin",
                iconClasses: "hi hi-linkedin",
                label: "Share",
                href: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(o)}`
            }, {
                type: "email",
                iconClasses: "hi hi-mail",
                label: "Email",
                href: `mailto:?subject=${encodeURIComponent(a)}&body=${encodeURIComponent(r)}`
            }]
        }
    },
    d = "REFERRAL_LOAD_STATE",
    u = "REFERRAL_SET_DIALOG_LOADING",
    p = "REFERRAL_SET_LOADING_MORE",
    g = "REFERRAL_SET_CURRENT_ORGANIZATION",
    f = () => ({
        dialog_loading: !1,
        loading_more: !1,
        organization_id: "auto",
        has_paid_plan: !1,
        program: {
            description: "",
            tracking_url: null,
            effective_discount: 0,
            next_stop: null,
            blocked_info: null,
            discount: {
                type: "none",
                amount: null,
                percent: null,
                duration: null
            },
            status: "pending"
        },
        organizations: [],
        referrals: [],
        has_more_referrals: !1
    }),
    z = {
        loadDialogData({
            commit: e,
            state: o
        }, {
            load: n = [],
            activate: t = !1,
            offset: a = null
        } = {}) {
            e(a ? p : u, !0);
            let r = {
                load: n
            };
            t && (r.activate = 1), a && (r.offset = a);
            const m = I.get({
                id: o.organization_id
            }, r);
            return m.then(_ => {
                e(d, _), e(a ? p : u, !1)
            }), m
        },
        setCurrentOrganization({
            commit: e,
            dispatch: o
        }, {
            organizationId: n,
            load: t = [],
            activate: a = !1
        }) {
            return e(g, n || "auto"), o("loadDialogData", {
                load: t,
                activate: a
            })
        },
        resetDialogState({
            commit: e
        }) {
            e(d, f())
        }
    },
    L = {
        [d](e, o) {
            if (o !== void 0)
                for (const n in o) n === "more_referrals" ? l.set(e, "referrals", e.referrals.concat(o[n])) : l.set(e, n, o[n])
        },
        [u](e, o) {
            e.dialog_loading = o
        },
        [p](e, o) {
            e.loading_more = o
        },
        [g](e, o) {
            e.organization_id = o
        }
    },
    P = f();

function N(e = {}) {
    return e = Object.assign({
        state: P,
        getters: x,
        mutations: L,
        actions: z
    }, e), T(e)
}
l.use(C);
const h = document.createElement("div");
document.body.appendChild(h);
window.ReferralDialog = new l({
    el: h,
    store: N,
    name: "ReferralDialog",
    render: e => e($),
    methods: {
        open(e = "auto") {
            this.$children[0].open(e)
        }
    }
});