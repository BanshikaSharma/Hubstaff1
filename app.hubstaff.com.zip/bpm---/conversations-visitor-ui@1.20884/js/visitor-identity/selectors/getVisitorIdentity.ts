import get from 'transmute/get';
export const getVisitorIdentity = state => get('visitorIdentity', state);