import {
    l as i
} from "./locations-7e06344f.js";
import {
    i as t
} from "./insights-02a4c2f1.js";
import "./init-ef420420.js";
import "./vendor-f5db2be7.js";
import "./shared-5f1b437f.js";
import "./index-b1c3925d.js";
import "./base-543c3a70.js";
import "./google_maps-3f82c093.js";
import "./mutations-2c62a19a.js";
window.widgetInitializers || (window.widgetInitializers = {
    locationsWidget: i,
    insightsWidget: t
});