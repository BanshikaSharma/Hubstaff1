const f = {
    install(s, l) {
        s.prototype.$appMessage = (a, e = {}) => {
            let t = HubstaffUtils.escapeHTML(a);
            e = Object.assign({
                life: 5e3,
                header: '<i class="fa fa-info-circle"></i> Notice'
            }, e), $.jGrowl(t, e)
        }
    }
};
export {
    f as A
};