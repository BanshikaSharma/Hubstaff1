import "./init-ef420420.js";
import {
    V as o,
    c as s
} from "./vendor-f5db2be7.js";
import {
    H as c
} from "./hub_app-778c98e3.js";
import {
    fF as d,
    iR as u
} from "./shared-5f1b437f.js";
import "./app_messages-e83d8e06.js";
const E = new o;
let a = 0;
const i = (n = []) => {
    n.forEach(e => {
        const m = document.createElement("div"),
            t = d(e),
            r = `AppBanner::${s(t.promotionType)}::${a}`;
        window.VueAppBanners[r] = new o({
            el: m,
            name: r,
            render: p => p(u, {
                props: t
            })
        }), a++
    })
};
o.use(c);
window.VueAppBanners = {};
window.BannersEventEmitter = E;
document.addEventListener("DOMContentLoaded", () => {
    const n = document.querySelector("div[data-app-promotion-banner]");
    if (!n) return;
    const e = JSON.parse(n.dataset.appPromotionBanner || "[]");
    i(e), setTimeout(() => n.remove())
});
window.BannersEventEmitter.$on("promotion-banners:init", (n = []) => {
    i(n)
});