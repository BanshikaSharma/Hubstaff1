import {
    br as o,
    bs as s,
    bt as a,
    V as t
} from "./vendor-f5db2be7.js";
import "./shared-5f1b437f.js";
o.drive = !1;
s.reload = function() {
    var e;
    (e = document.getElementById(this.getAttribute("target"))) == null || e.reload()
};
window.addEventListener("turbo:load", () => {
    document.addEventListener("turbo:before-stream-render", e => {
        if (e.target.action === "replace_state") {
            const r = e.target.attributes.url.value;
            history.replaceState(null, null, r), e.preventDefault()
        }
    })
});
window.ResizeObserver = window.ResizeObserver || a;
({}).VITE_PROFILE_VUE === "true" && (t.config.devtools = !0, t.config.performance = !0);