! function(e, t) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e || self).RipeSDK = t()
}(this, function() {
    var e = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
        t = function(t) {
            var n = {
                exports: {}
            };
            return function(t, n) {
                var s;
                s = () => {
                    var t, n = {},
                        s = {
                            exports: n
                        },
                        i = Object.defineProperty,
                        o = Object.defineProperties,
                        r = Object.getOwnPropertyDescriptor,
                        a = Object.getOwnPropertyDescriptors,
                        c = Object.getOwnPropertyNames,
                        l = Object.getOwnPropertySymbols,
                        h = Object.prototype.hasOwnProperty,
                        u = Object.prototype.propertyIsEnumerable,
                        d = (e, t, n) => t in e ? i(e, t, {
                            enumerable: !0,
                            configurable: !0,
                            writable: !0,
                            value: n
                        }) : e[t] = n,
                        g = (e, t) => {
                            for (var n in t || (t = {})) h.call(t, n) && d(e, n, t[n]);
                            if (l)
                                for (var n of l(t)) u.call(t, n) && d(e, n, t[n]);
                            return e
                        },
                        p = (e, t) => o(e, a(t)),
                        f = (e, t) => {
                            for (var n in t) i(e, n, {
                                get: t[n],
                                enumerable: !0
                            })
                        },
                        m = {};
                    f(m, {
                        ErrorInfo: () => k,
                        Realtime: () => Pn,
                        Rest: () => Lt,
                        default: () => ks,
                        msgpack: () => Os,
                        protocolMessageFromDeserialized: () => Ft
                    }), s.exports = (t = m, ((e, t, n, s) => {
                        if (t && "object" == typeof t || "function" == typeof t)
                            for (let n of c(t)) h.call(e, n) || void 0 === n || i(e, n, {
                                get: () => t[n],
                                enumerable: !(s = r(t, n)) || s.enumerable
                            });
                        return e
                    })(i({}, "__esModule", {
                        value: !0
                    }), t));
                    var y = class {},
                        v = void 0 !== e ? e : "undefined" != typeof window ? window : self;

                    function w(e, t) {
                        return `${e}`.padStart(t ? 3 : 2, "0")
                    }

                    function b(e) {
                        return y.Config.logTimestamps ? function(t) {
                            const n = /* @__PURE__ */ new Date;
                            e(w(n.getHours()) + ":" + w(n.getMinutes()) + ":" + w(n.getSeconds()) + "." + w(n.getMilliseconds(), 1) + " " + t)
                        } : function(t) {
                            e(t)
                        }
                    }
                    var C = class e {
                        constructor() {
                            this.deprecated = (e, t) => {
                                this.deprecationWarning(`${e} is deprecated and will be removed in a future version. ${t}`)
                            }, this.shouldLog = e => e <= this.logLevel, this.setLog = (e, t) => {
                                void 0 !== e && (this.logLevel = e), void 0 !== t && (this.logHandler = this.logErrorHandler = t)
                            }, this.logLevel = e.defaultLogLevel, this.logHandler = e.defaultLogHandler, this.logErrorHandler = e.defaultLogErrorHandler
                        }
                        static initLogHandlers() {
                            const [t, n] = (() => {
                                var e;
                                let t, n;
                                return "function" == typeof(null == (e = null == v ? void 0 : v.console) ? void 0 : e.log) ? (t = function(...e) {
                                    console.log.apply(console, e)
                                }, n = console.warn ? function(...e) {
                                    console.warn.apply(console, e)
                                } : t) : t = n = function() {}, [t, n].map(b)
                            })();
                            this.defaultLogHandler = t, this.defaultLogErrorHandler = n, this.defaultLogger = new e
                        }
                        static logActionNoStrip(e, t, n, s) {
                            e.logAction(t, n, s)
                        }
                        logAction(e, t, n) {
                            this.shouldLog(e) && (1 === e ? this.logErrorHandler : this.logHandler)("Ably: " + t + ": " + n, e)
                        }
                        renamedClientOption(e, t) {
                            this.deprecationWarning(`The \`${e}\` client option has been renamed to \`${t}\`. Please update your code to use \`${t}\` instead. \`${e}\` will be removed in a future version.`)
                        }
                        renamedMethod(e, t, n) {
                            this.deprecationWarning(`\`${e}\`’s \`${t}\` method has been renamed to \`${n}\`. Please update your code to use \`${n}\` instead. \`${t}\` will be removed in a future version.`)
                        }
                        deprecationWarning(e) {
                            this.shouldLog(1) && this.logErrorHandler(`Ably: Deprecation warning - ${e}`, 1)
                        }
                    };
                    C.defaultLogLevel = 1, C.LOG_NONE = 0, C.LOG_ERROR = 1, C.LOG_MAJOR = 2, C.LOG_MINOR = 3, C.LOG_MICRO = 4, C.logAction = (e, t, n, s) => {
                        C.logActionNoStrip(e, t, n, s)
                    };
                    var O = C,
                        R = {};

                    function I(e) {
                        let t = "[" + e.constructor.name;
                        return e.message && (t += ": " + e.message), e.statusCode && (t += "; statusCode=" + e.statusCode), e.code && (t += "; code=" + e.code), e.cause && (t += "; cause=" + X(e.cause)), !e.href || e.message && e.message.indexOf("help.ably.io") > -1 || (t += "; see " + e.href + " "), t += "]", t
                    }
                    f(R, {
                        Format: () => z,
                        allSame: () => K,
                        allToLowerCase: () => ae,
                        allToUpperCase: () => ce,
                        arrChooseN: () => se,
                        arrDeleteValue: () => H,
                        arrEquals: () => me,
                        arrIntersect: () => D,
                        arrIntersectOb: () => q,
                        arrPopRandomElement: () => J,
                        arrSubtract: () => B,
                        arrWithoutValue: () => j,
                        cheapRandStr: () => te,
                        containsValue: () => x,
                        copy: () => T,
                        createMissingPluginError: () => ye,
                        dataSizeBytes: () => ee,
                        decodeBody: () => oe,
                        encodeBody: () => re,
                        ensureArray: () => M,
                        forInOwnNonNullProperties: () => V,
                        getBackoffCoefficient: () => le,
                        getGlobalObject: () => de,
                        getJitterCoefficient: () => he,
                        getRetryTime: () => ue,
                        inherits: () => N,
                        inspectBody: () => Z,
                        inspectError: () => X,
                        intersect: () => G,
                        isEmpty: () => P,
                        isErrorInfoOrPartialErrorInfo: () => Y,
                        isNil: () => _,
                        isObject: () => E,
                        keysArray: () => W,
                        matchDerivedChannel: () => pe,
                        mixin: () => A,
                        parseQueryString: () => Q,
                        prototypicalClone: () => U,
                        randomString: () => ne,
                        shallowClone: () => L,
                        shallowEquals: () => ge,
                        throwMissingPluginError: () => ve,
                        toBase64: () => fe,
                        toQueryString: () => $,
                        valuesArray: () => F,
                        whenPromiseSettles: () => ie,
                        withTimeoutAsync: () => we
                    });
                    var k = class e extends Error {
                            constructor(t, n, s, i) {
                                super(t), void 0 !== Object.setPrototypeOf && Object.setPrototypeOf(this, e.prototype), this.code = n, this.statusCode = s, this.cause = i
                            }
                            toString() {
                                return I(this)
                            }
                            static fromValues(t) {
                                const {
                                    message: n,
                                    code: s,
                                    statusCode: i
                                } = t;
                                if ("string" != typeof n || "number" != typeof s || "number" != typeof i) throw new Error("ErrorInfo.fromValues(): invalid values: " + y.Config.inspect(t));
                                const o = Object.assign(new e(n, s, i), t);
                                return o.code && !o.href && (o.href = "https://help.ably.io/error/" + o.code), o
                            }
                        },
                        S = class e extends Error {
                            constructor(t, n, s, i) {
                                super(t), void 0 !== Object.setPrototypeOf && Object.setPrototypeOf(this, e.prototype), this.code = n, this.statusCode = s, this.cause = i
                            }
                            toString() {
                                return I(this)
                            }
                            static fromValues(t) {
                                const {
                                    message: n,
                                    code: s,
                                    statusCode: i
                                } = t;
                                if ("string" != typeof n || !_(s) && "number" != typeof s || !_(i) && "number" != typeof i) throw new Error("PartialErrorInfo.fromValues(): invalid values: " + y.Config.inspect(t));
                                const o = Object.assign(new e(n, s, i), t);
                                return o.code && !o.href && (o.href = "https://help.ably.io/error/" + o.code), o
                            }
                        };

                    function A(e, ...t) {
                        for (let n = 0; n < t.length; n++) {
                            const s = t[n];
                            if (!s) break;
                            for (const t in s) Object.prototype.hasOwnProperty.call(s, t) && (e[t] = s[t])
                        }
                        return e
                    }

                    function T(e) {
                        return A({}, e)
                    }

                    function M(e) {
                        return _(e) ? [] : Array.isArray(e) ? e : [e]
                    }

                    function E(e) {
                        return "[object Object]" == Object.prototype.toString.call(e)
                    }

                    function P(e) {
                        for (const t in e) return !1;
                        return !0
                    }

                    function _(e) {
                        return null == e
                    }

                    function L(e) {
                        const t = new Object;
                        for (const n in e) t[n] = e[n];
                        return t
                    }

                    function U(e, t) {
                        class n {}
                        n.prototype = e;
                        const s = new n;
                        return t && A(s, t), s
                    }
                    var N = function(e, t) {
                        y.Config.inherits ? y.Config.inherits(e, t) : (e.super_ = t, e.prototype = U(t.prototype, {
                            constructor: e
                        }))
                    };

                    function x(e, t) {
                        for (const n in e)
                            if (e[n] == t) return !0;
                        return !1
                    }

                    function G(e, t) {
                        return Array.isArray(t) ? D(e, t) : q(e, t)
                    }

                    function D(e, t) {
                        const n = [];
                        for (let s = 0; s < e.length; s++) {
                            const i = e[s]; - 1 != t.indexOf(i) && n.push(i)
                        }
                        return n
                    }

                    function q(e, t) {
                        const n = [];
                        for (let s = 0; s < e.length; s++) {
                            const i = e[s];
                            i in t && n.push(i)
                        }
                        return n
                    }

                    function B(e, t) {
                        const n = [];
                        for (let s = 0; s < e.length; s++) {
                            const i = e[s]; - 1 == t.indexOf(i) && n.push(i)
                        }
                        return n
                    }

                    function H(e, t) {
                        const n = e.indexOf(t),
                            s = -1 != n;
                        return s && e.splice(n, 1), s
                    }

                    function j(e, t) {
                        const n = e.slice();
                        return H(n, t), n
                    }

                    function W(e, t) {
                        const n = [];
                        for (const s in e) t && !Object.prototype.hasOwnProperty.call(e, s) || n.push(s);
                        return n
                    }

                    function F(e, t) {
                        const n = [];
                        for (const s in e) t && !Object.prototype.hasOwnProperty.call(e, s) || n.push(e[s]);
                        return n
                    }

                    function V(e, t) {
                        for (const n in e) Object.prototype.hasOwnProperty.call(e, n) && e[n] && t(n)
                    }

                    function K(e, t) {
                        if (0 === e.length) return !0;
                        const n = e[0][t];
                        return e.every(function(e) {
                            return e[t] === n
                        })
                    }
                    var z = /* @__PURE__ */ (e => (e.msgpack = "msgpack", e.json = "json", e))(z || {});

                    function J(e) {
                        return e.splice((t = e, Math.floor(Math.random() * t.length)), 1)[0];
                        var t
                    }

                    function $(e) {
                        const t = [];
                        if (e)
                            for (const n in e) t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e[n]));
                        return t.length ? "?" + t.join("&") : ""
                    }

                    function Q(e) {
                        let t;
                        const n = /([^?&=]+)=?([^&]*)/g,
                            s = {};
                        for (; t = n.exec(e);) s[decodeURIComponent(t[1])] = decodeURIComponent(t[2]);
                        return s
                    }

                    function Y(e) {
                        return "object" == typeof e && null !== e && (e instanceof k || e instanceof S)
                    }

                    function X(e) {
                        var t, n;
                        return e instanceof Error || "ErrorInfo" === (null == (t = null == e ? void 0 : e.constructor) ? void 0 : t.name) || "PartialErrorInfo" === (null == (n = null == e ? void 0 : e.constructor) ? void 0 : n.name) ? e.toString() : y.Config.inspect(e)
                    }

                    function Z(e) {
                        return y.BufferUtils.isBuffer(e) ? e.toString() : "string" == typeof e ? e : y.Config.inspect(e)
                    }

                    function ee(e) {
                        if (y.BufferUtils.isBuffer(e)) return y.BufferUtils.byteLength(e);
                        if ("string" == typeof e) return y.Config.stringByteSize(e);
                        throw new Error("Expected input of Utils.dataSizeBytes to be a buffer or string, but was: " + typeof e)
                    }

                    function te() {
                        return String(Math.random()).substr(2)
                    }
                    var ne = async e => {
                        const t = await y.Config.getRandomArrayBuffer(e);
                        return y.BufferUtils.base64Encode(t)
                    };

                    function se(e, t) {
                        const n = Math.min(t, e.length),
                            s = e.slice(),
                            i = [];
                        for (let e = 0; e < n; e++) i.push(J(s));
                        return i
                    }

                    function ie(e, t) {
                        e.then(e => {
                            null == t || t(null, e)
                        }).catch(e => {
                            null == t || t(e)
                        })
                    }

                    function oe(e, t, n) {
                        return "msgpack" == n ? (t || ve("MsgPack"), t.decode(e)) : JSON.parse(String(e))
                    }

                    function re(e, t, n) {
                        return "msgpack" == n ? (t || ve("MsgPack"), t.encode(e, !0)) : JSON.stringify(e)
                    }

                    function ae(e) {
                        return e.map(function(e) {
                            return e && e.toLowerCase()
                        })
                    }

                    function ce(e) {
                        return e.map(function(e) {
                            return e && e.toUpperCase()
                        })
                    }

                    function le(e) {
                        return Math.min((e + 2) / 3, 2)
                    }

                    function he() {
                        return 1 - .2 * Math.random()
                    }

                    function ue(e, t) {
                        return e * le(t) * he()
                    }

                    function de() {
                        return void 0 !== e ? e : "undefined" != typeof window ? window : self
                    }

                    function ge(e, t) {
                        return Object.keys(e).every(n => e[n] === t[n]) && Object.keys(t).every(n => t[n] === e[n])
                    }

                    function pe(e) {
                        const t = e.match(/^(\[([^?]*)(?:(.*))\])?(.+)$/);
                        if (!t || !t.length || t.length < 5) throw new k("regex match failed", 400, 40010);
                        if (t[2]) throw new k(`cannot use a derived option with a ${t[2]} channel`, 400, 40010);
                        return {
                            qualifierParam: t[3] || "",
                            channelName: t[4]
                        }
                    }

                    function fe(e) {
                        const t = y.BufferUtils,
                            n = t.utf8Encode(e);
                        return t.base64Encode(n)
                    }

                    function me(e, t) {
                        return e.length === t.length && e.every(function(e, n) {
                            return e === t[n]
                        })
                    }

                    function ye(e) {
                        return new k(`${e} plugin not provided`, 40019, 400)
                    }

                    function ve(e) {
                        throw ye(e)
                    }
                    async function we(e, t = 5e3, n = "Timeout expired") {
                        const s = new k(n, 5e4, 500);
                        return Promise.race([e, new Promise((e, n) => setTimeout(() => n(s), t))])
                    }
                    var be = {
                        ENVIRONMENT: "",
                        REST_HOST: "rest.ably.io",
                        REALTIME_HOST: "realtime.ably.io",
                        FALLBACK_HOSTS: ["A.ably-realtime.com", "B.ably-realtime.com", "C.ably-realtime.com", "D.ably-realtime.com", "E.ably-realtime.com"],
                        PORT: 80,
                        TLS_PORT: 443,
                        TIMEOUTS: {
                            disconnectedRetryTimeout: 15e3,
                            suspendedRetryTimeout: 3e4,
                            httpRequestTimeout: 1e4,
                            httpMaxRetryDuration: 15e3,
                            channelRetryTimeout: 15e3,
                            fallbackRetryTimeout: 6e5,
                            connectionStateTtl: 12e4,
                            realtimeRequestTimeout: 1e4,
                            recvTimeout: 9e4,
                            webSocketConnectTimeout: 1e4,
                            webSocketSlowTimeout: 4e3
                        },
                        httpMaxRetryCount: 3,
                        maxMessageSize: 65536,
                        version: "2.4.1",
                        protocolVersion: 3,
                        agent: "ably-js/2.4.1",
                        getHost: Ce,
                        getPort: function(e, t) {
                            return t || e.tls ? e.tlsPort : e.port
                        },
                        getHttpScheme: function(e) {
                            return e.tls ? "https://" : "http://"
                        },
                        environmentFallbackHosts: Oe,
                        getFallbackHosts: Re,
                        getHosts: function(e, t) {
                            const n = [e.restHost].concat(Re(e));
                            return t ? n.map(t => Ce(e, t, !0)) : n
                        },
                        checkHost: Ie,
                        objectifyOptions: function(e, t, n, s, i) {
                            if (void 0 === e) {
                                const e = t ? `${n} must be initialized with either a client options object, an Ably API key, or an Ably Token` : `${n} must be initialized with a client options object`;
                                throw O.logAction(s, O.LOG_ERROR, `${n}()`, e), new Error(e)
                            }
                            let o;
                            if ("string" == typeof e)
                                if (-1 == e.indexOf(":")) {
                                    if (!t) {
                                        const e = `${n} cannot be initialized with just an Ably Token; you must provide a client options object with a \`plugins\` property. (Set this Ably Token as the object’s \`token\` property.)`;
                                        throw O.logAction(s, O.LOG_ERROR, `${n}()`, e), new Error(e)
                                    }
                                    o = {
                                        token: e
                                    }
                                } else {
                                    if (!t) {
                                        const e = `${n} cannot be initialized with just an Ably API key; you must provide a client options object with a \`plugins\` property. (Set this Ably API key as the object’s \`key\` property.)`;
                                        throw O.logAction(s, O.LOG_ERROR, `${n}()`, e), new Error(e)
                                    }
                                    o = {
                                        key: e
                                    }
                                }
                            else o = e;
                            return i && (o = p(g({}, o), {
                                plugins: g(g({}, i), o.plugins)
                            })), o
                        },
                        normaliseOptions: function(e, t, n) {
                            const s = null != n ? n : O.defaultLogger;
                            "function" == typeof e.recover && !0 === e.closeOnUnload && (O.logAction(s, O.LOG_ERROR, "Defaults.normaliseOptions", "closeOnUnload was true and a session recovery function was set - these are mutually exclusive, so unsetting the latter"), e.recover = void 0), "closeOnUnload" in e || (e.closeOnUnload = !e.recover), "queueMessages" in e || (e.queueMessages = !0);
                            const i = e.environment && String(e.environment).toLowerCase() || be.ENVIRONMENT,
                                o = !i || "production" === i;
                            e.fallbackHosts || e.restHost || e.realtimeHost || e.port || e.tlsPort || (e.fallbackHosts = o ? be.FALLBACK_HOSTS : Oe(i));
                            const r = e.restHost || (o ? be.REST_HOST : i + "-" + be.REST_HOST),
                                a = function(e, t, n, s) {
                                    return e.realtimeHost ? e.realtimeHost : e.restHost ? (O.logAction(s, O.LOG_MINOR, "Defaults.normaliseOptions", 'restHost is set to "' + e.restHost + '" but realtimeHost is not set, so setting realtimeHost to "' + e.restHost + '" too. If this is not what you want, please set realtimeHost explicitly.'), e.restHost) : t ? be.REALTIME_HOST : n + "-" + be.REALTIME_HOST
                                }(e, o, i, s);
                            (e.fallbackHosts || []).concat(r, a).forEach(Ie), e.port = e.port || be.PORT, e.tlsPort = e.tlsPort || be.TLS_PORT, "tls" in e || (e.tls = !0);
                            const c = function(e) {
                                const t = {};
                                for (const n in be.TIMEOUTS) t[n] = e[n] || be.TIMEOUTS[n];
                                return t
                            }(e);
                            e.useBinaryProtocol = !!t && ("useBinaryProtocol" in e ? y.Config.supportsBinary && e.useBinaryProtocol : y.Config.preferBinary);
                            const l = {};
                            e.clientId && (l["X-Ably-ClientId"] = y.BufferUtils.base64Encode(y.BufferUtils.utf8Encode(e.clientId))), "idempotentRestPublishing" in e || (e.idempotentRestPublishing = !0);
                            let h = null,
                                u = e.connectivityCheckUrl;
                            if (e.connectivityCheckUrl) {
                                let [t, n] = e.connectivityCheckUrl.split("?");
                                h = n ? Q(n) : {}, -1 === t.indexOf("://") && (t = "https://" + t), u = t
                            }
                            let d = e.wsConnectivityCheckUrl;
                            return d && -1 === d.indexOf("://") && (d = "wss://" + d), p(g({}, e), {
                                realtimeHost: a,
                                restHost: r,
                                maxMessageSize: e.maxMessageSize || be.maxMessageSize,
                                timeouts: c,
                                connectivityCheckParams: h,
                                connectivityCheckUrl: u,
                                wsConnectivityCheckUrl: d,
                                headers: l
                            })
                        },
                        defaultGetHeaders: function(e, {
                            format: t = Te,
                            protocolVersion: n = Me
                        } = {}) {
                            return {
                                accept: Ae[t],
                                "X-Ably-Version": n.toString(),
                                "Ably-Agent": ke(e)
                            }
                        },
                        defaultPostHeaders: function(e, {
                            format: t = Te,
                            protocolVersion: n = Me
                        } = {}) {
                            let s;
                            return {
                                accept: s = Ae[t],
                                "content-type": s,
                                "X-Ably-Version": n.toString(),
                                "Ably-Agent": ke(e)
                            }
                        }
                    };

                    function Ce(e, t, n) {
                        return n ? t == e.restHost && e.realtimeHost || t || e.realtimeHost : t || e.restHost
                    }

                    function Oe(e) {
                        return [e + "-a-fallback.ably-realtime.com", e + "-b-fallback.ably-realtime.com", e + "-c-fallback.ably-realtime.com", e + "-d-fallback.ably-realtime.com", e + "-e-fallback.ably-realtime.com"]
                    }

                    function Re(e) {
                        const t = e.fallbackHosts;
                        return t ? se(t, void 0 !== e.httpMaxRetryCount ? e.httpMaxRetryCount : be.httpMaxRetryCount) : []
                    }

                    function Ie(e) {
                        if ("string" != typeof e) throw new k("host must be a string; was a " + typeof e, 4e4, 400);
                        if (!e.length) throw new k("host must not be zero-length", 4e4, 400)
                    }

                    function ke(e) {
                        let t = be.agent;
                        if (e.agents)
                            for (var n in e.agents) t += " " + n + "/" + e.agents[n];
                        return t
                    }

                    function Se(e, t, n) {
                        const s = n || {};
                        if (s.cipher) {
                            e || ve("Crypto");
                            const n = e.getCipher(s.cipher, t);
                            s.cipher = n.cipherParams, s.channelCipher = n.cipher
                        } else "cipher" in s && (s.cipher = void 0, s.channelCipher = null);
                        return s
                    }
                    var Ae = {
                            json: "application/json",
                            xml: "application/xml",
                            html: "text/html",
                            msgpack: "application/x-msgpack",
                            text: "text/plain"
                        },
                        Te = "json",
                        Me = be.protocolVersion,
                        Ee = be,
                        Pe = class e {
                            constructor(e, t) {
                                this.logger = e, this.members = t || []
                            }
                            call(e, t) {
                                for (const n of this.members)
                                    if (n) try {
                                        n(e, t)
                                    } catch (e) {
                                        O.logAction(this.logger, O.LOG_ERROR, "Multicaster multiple callback handler", "Unexpected exception: " + e + "; stack = " + e.stack)
                                    }
                            }
                            push(...e) {
                                this.members.push(...e)
                            }
                            createPromise() {
                                return new Promise((e, t) => {
                                    this.push((n, s) => {
                                        n ? t(n) : e(s)
                                    })
                                })
                            }
                            resolveAll(e) {
                                this.call(null, e)
                            }
                            rejectAll(e) {
                                this.call(e)
                            }
                            static create(t, n) {
                                const s = new e(t, n);
                                return Object.assign((e, t) => s.call(e, t), {
                                    push: e => s.push(e),
                                    createPromise: () => s.createPromise(),
                                    resolveAll: e => s.resolveAll(e),
                                    rejectAll: e => s.rejectAll(e)
                                })
                            }
                        },
                        _e = /* @__PURE__ */ (e => (e.Get = "get", e.Delete = "delete", e.Post = "post", e.Put = "put", e.Patch = "patch", e))(_e || {}),
                        Le = _e,
                        Ue = /* @__PURE__ */ (e => (e[e.Success = 200] = "Success", e[e.NoContent = 204] = "NoContent", e[e.BadRequest = 400] = "BadRequest", e[e.Unauthorized = 401] = "Unauthorized", e[e.Forbidden = 403] = "Forbidden", e[e.RequestTimeout = 408] = "RequestTimeout", e[e.InternalServerError = 500] = "InternalServerError", e))(Ue || {}),
                        Ne = Ue,
                        xe = Math.pow(2, 17);

                    function Ge(e) {
                        return Y(e) ? (e.code || (403 === e.statusCode ? e.code = 40300 : (e.code = 40170, e.statusCode = 401)), e) : new k(X(e), e.code || 40170, e.statusCode || 401)
                    }

                    function De(e) {
                        if (!e) return "";
                        "string" == typeof e && (e = JSON.parse(e));
                        const t = /* @__PURE__ */ Object.create(null),
                            n = W(e, !0);
                        if (!n) return "";
                        n.sort();
                        for (let s = 0; s < n.length; s++) t[n[s]] = e[n[s]].sort();
                        return JSON.stringify(t)
                    }

                    function qe(e, t) {
                        if (e.authCallback) O.logAction(t, O.LOG_MINOR, "Auth()", "using token auth with authCallback");
                        else if (e.authUrl) O.logAction(t, O.LOG_MINOR, "Auth()", "using token auth with authUrl");
                        else if (e.key) O.logAction(t, O.LOG_MINOR, "Auth()", "using token auth with client-side signing");
                        else {
                            if (!e.tokenDetails) {
                                const e = "authOptions must include valid authentication parameters";
                                throw O.logAction(t, O.LOG_ERROR, "Auth()", e), new Error(e)
                            }
                            O.logAction(t, O.LOG_MINOR, "Auth()", "using token auth with supplied token only")
                        }
                    }

                    function Be(e) {
                        return e.useTokenAuth || ! function(e) {
                            return "useTokenAuth" in e && !e.useTokenAuth
                        }(e) && (e.authCallback || e.authUrl || e.token || e.tokenDetails)
                    }
                    var He = 0,
                        je = class {
                            constructor(e, t) {
                                if (this.authOptions = {}, this.client = e, this.tokenParams = t.defaultTokenParams || {}, this.currentTokenRequestId = null, this.waitingForTokenRequest = null, Be(t))(function(e) {
                                    return !e.key && !e.authCallback && !e.authUrl
                                })(t) && O.logAction(this.logger, O.LOG_ERROR, "Auth()", "Warning: library initialized with a token literal without any way to renew the token when it expires (no authUrl, authCallback, or key). See https://help.ably.io/error/40171 for help"), this._saveTokenOptions(t.defaultTokenParams, t), qe(this.authOptions, this.logger);
                                else {
                                    if (!t.key) {
                                        const e = "No authentication options provided; need one of: key, authUrl, or authCallback (or for testing only, token or tokenDetails)";
                                        throw O.logAction(this.logger, O.LOG_ERROR, "Auth()", e), new k(e, 40160, 401)
                                    }
                                    O.logAction(this.logger, O.LOG_MINOR, "Auth()", "anonymous, using basic auth"), this._saveBasicOptions(t)
                                }
                            }
                            get logger() {
                                return this.client.logger
                            }
                            async authorize(e, t) {
                                if (t && t.key && this.authOptions.key !== t.key) throw new k("Unable to update auth options with incompatible key", 40102, 401);
                                try {
                                    let n = await this._forceNewToken(null != e ? e : null, null != t ? t : null);
                                    return this.client.connection ? new Promise((e, t) => {
                                        this.client.connection.connectionManager.onAuthUpdated(n, (n, s) => n ? t(n) : e(s))
                                    }) : n
                                } catch (e) {
                                    throw this.client.connection && e.statusCode === Ne.Forbidden && this.client.connection.connectionManager.actOnErrorFromAuthorize(e), e
                                }
                            }
                            async _forceNewToken(e, t) {
                                this.tokenDetails = null, this._saveTokenOptions(e, t), qe(this.authOptions, this.logger);
                                try {
                                    return this._ensureValidAuthCredentials(!0)
                                } finally {
                                    delete this.tokenParams.timestamp, delete this.authOptions.queryTime
                                }
                            }
                            async requestToken(e, t) {
                                const n = t || this.authOptions,
                                    s = e || T(this.tokenParams);
                                let i, o = this.client;
                                if (n.authCallback) O.logAction(this.logger, O.LOG_MINOR, "Auth.requestToken()", "using token auth with authCallback"), i = n.authCallback;
                                else if (n.authUrl) O.logAction(this.logger, O.LOG_MINOR, "Auth.requestToken()", "using token auth with authUrl"), i = (e, t) => {
                                    const s = A({
                                            accept: "application/json, text/plain"
                                        }, n.authHeaders),
                                        i = n.authMethod && "post" === n.authMethod.toLowerCase();
                                    let o;
                                    const r = n.authUrl.indexOf("?");
                                    r > -1 && (o = Q(n.authUrl.slice(r)), n.authUrl = n.authUrl.slice(0, r), i || (n.authParams = A(o, n.authParams)));
                                    const a = A({}, n.authParams || {}, e),
                                        c = e => {
                                            var n, s;
                                            let i = null != (n = e.body) ? n : null,
                                                o = null;
                                            if (e.error) O.logAction(this.logger, O.LOG_MICRO, "Auth.requestToken().tokenRequestCallback", "Received Error: " + X(e.error));
                                            else {
                                                const t = null != (s = e.headers["content-type"]) ? s : null;
                                                o = Array.isArray(t) ? t.join(", ") : t, O.logAction(this.logger, O.LOG_MICRO, "Auth.requestToken().tokenRequestCallback", "Received; content-type: " + o + "; body: " + Z(i))
                                            }
                                            if (e.error) return void t(e.error, null);
                                            if (e.unpacked) return void t(null, i);
                                            if (y.BufferUtils.isBuffer(i) && (i = i.toString()), !o) return void t(new k("authUrl response is missing a content-type header", 40170, 401), null);
                                            const r = o.indexOf("application/json") > -1,
                                                a = o.indexOf("text/plain") > -1 || o.indexOf("application/jwt") > -1;
                                            if (r || a) {
                                                if (r) {
                                                    if (i.length > xe) return void t(new k("authUrl response exceeded max permitted length", 40170, 401), null);
                                                    try {
                                                        i = JSON.parse(i)
                                                    } catch (e) {
                                                        return void t(new k("Unexpected error processing authURL response; err = " + e.message, 40170, 401), null)
                                                    }
                                                }
                                                t(null, i, o)
                                            } else t(new k("authUrl responded with unacceptable content-type " + o + ", should be either text/plain, application/jwt or application/json", 40170, 401), null)
                                        };
                                    if (O.logAction(this.logger, O.LOG_MICRO, "Auth.requestToken().tokenRequestCallback", "Requesting token from " + n.authUrl + "; Params: " + JSON.stringify(a) + "; method: " + (i ? "POST" : "GET")), i) {
                                        const e = s || {};
                                        e["content-type"] = "application/x-www-form-urlencoded";
                                        const t = $(a).slice(1);
                                        ie(this.client.http.doUri(Le.Post, n.authUrl, e, t, o), (e, t) => c(e || t))
                                    } else ie(this.client.http.doUri(Le.Get, n.authUrl, s || {}, null, a), (e, t) => c(e || t))
                                };
                                else {
                                    if (!n.key) {
                                        const e = "Need a new token, but authOptions does not include any way to request one (no authUrl, authCallback, or key)";
                                        throw O.logAction(this.logger, O.LOG_ERROR, "Auth()", "library initialized with a token literal without any way to renew the token when it expires (no authUrl, authCallback, or key). See https://help.ably.io/error/40171 for help"), new k(e, 40171, 403)
                                    }
                                    O.logAction(this.logger, O.LOG_MINOR, "Auth.requestToken()", "using token auth with client-side signing"), i = (e, t) => {
                                        ie(this.createTokenRequest(e, n), (e, n) => t(e, null != n ? n : null))
                                    }
                                }
                                "capability" in s && (s.capability = De(s.capability));
                                const r = (e, t) => {
                                    const s = "/keys/" + e.keyName + "/requestToken",
                                        i = Ee.defaultPostHeaders(this.client.options);
                                    n.requestHeaders && A(i, n.requestHeaders), O.logAction(this.logger, O.LOG_MICRO, "Auth.requestToken().requestToken", "Sending POST to " + s + "; Token params: " + JSON.stringify(e)), ie(this.client.http.do(Le.Post, function(e) {
                                        return o.baseUri(e) + s
                                    }, i, JSON.stringify(e), null), (e, n) => e ? t(e) : t(n.error, n.body, n.unpacked))
                                };
                                return new Promise((e, t) => {
                                    let o = !1,
                                        a = this.client.options.timeouts.realtimeRequestTimeout,
                                        c = setTimeout(() => {
                                            o = !0;
                                            const e = "Token request callback timed out after " + a / 1e3 + " seconds";
                                            O.logAction(this.logger, O.LOG_ERROR, "Auth.requestToken()", e), t(new k(e, 40170, 401))
                                        }, a);
                                    i(s, (s, i, a) => {
                                        if (o) return;
                                        if (clearTimeout(c), s) return O.logAction(this.logger, O.LOG_ERROR, "Auth.requestToken()", "token request signing call returned error; err = " + X(s)), void t(Ge(s));
                                        if ("string" == typeof i) return void(0 === i.length ? t(new k("Token string is empty", 40170, 401)) : i.length > xe ? t(new k("Token string exceeded max permitted length (was " + i.length + " bytes)", 40170, 401)) : "undefined" === i || "null" === i ? t(new k("Token string was literal null/undefined", 40170, 401)) : "{" !== i[0] || a && a.indexOf("application/jwt") > -1 ? e({
                                            token: i
                                        }) : t(new k("Token was double-encoded; make sure you're not JSON-encoding an already encoded token request or details", 40170, 401)));
                                        if ("object" != typeof i || null === i) {
                                            const e = "Expected token request callback to call back with a token string or token request/details object, but got a " + typeof i;
                                            return O.logAction(this.logger, O.LOG_ERROR, "Auth.requestToken()", e), void t(new k(e, 40170, 401))
                                        }
                                        const l = JSON.stringify(i).length;
                                        if (l > xe && !n.suppressMaxLengthCheck) t(new k("Token request/details object exceeded max permitted stringified size (was " + l + " bytes)", 40170, 401));
                                        else if ("issued" in i) e(i);
                                        else {
                                            if (!("keyName" in i)) {
                                                const e = "Expected token request callback to call back with a token string, token request object, or token details object";
                                                return O.logAction(this.logger, O.LOG_ERROR, "Auth.requestToken()", e), void t(new k(e, 40170, 401))
                                            }
                                            r(i, (n, s, i) => {
                                                if (n) return O.logAction(this.logger, O.LOG_ERROR, "Auth.requestToken()", "token request API call returned error; err = " + X(n)), void t(Ge(n));
                                                i || (s = JSON.parse(s)), O.logAction(this.logger, O.LOG_MINOR, "Auth.getToken()", "token received"), e(s)
                                            })
                                        }
                                    })
                                })
                            }
                            async createTokenRequest(e, t) {
                                t = t || this.authOptions, e = e || T(this.tokenParams);
                                const n = t.key;
                                if (!n) throw new k("No key specified", 40101, 403);
                                const s = n.split(":"),
                                    i = s[0],
                                    o = s[1];
                                if (!o) throw new k("Invalid key specified", 40101, 403);
                                if ("" === e.clientId) throw new k("clientId can’t be an empty string", 40012, 400);
                                "capability" in e && (e.capability = De(e.capability));
                                const r = A({
                                        keyName: i
                                    }, e),
                                    a = e.clientId || "",
                                    c = e.ttl || "",
                                    l = e.capability || "";
                                r.timestamp || (r.timestamp = await this.getTimestamp(t && t.queryTime));
                                const h = r.nonce || (r.nonce = ("000000" + Math.floor(1e16 * Math.random())).slice(-16));
                                return r.mac = r.mac || ((e, t) => {
                                    const n = y.BufferUtils,
                                        s = n.utf8Encode(e),
                                        i = n.utf8Encode(t),
                                        o = n.hmacSha256(s, i);
                                    return n.base64Encode(o)
                                })(r.keyName + "\n" + c + "\n" + l + "\n" + a + "\n" + r.timestamp + "\n" + h + "\n", o), O.logAction(this.logger, O.LOG_MINOR, "Auth.getTokenRequest()", "generated signed request"), r
                            }
                            async getAuthParams() {
                                if ("basic" == this.method) return {
                                    key: this.key
                                }; {
                                    let e = await this._ensureValidAuthCredentials(!1);
                                    if (!e) throw new Error("Auth.getAuthParams(): _ensureValidAuthCredentials returned no error or tokenDetails");
                                    return {
                                        access_token: e.token
                                    }
                                }
                            }
                            async getAuthHeaders() {
                                if ("basic" == this.method) return {
                                    authorization: "Basic " + this.basicKey
                                }; {
                                    const e = await this._ensureValidAuthCredentials(!1);
                                    if (!e) throw new Error("Auth.getAuthParams(): _ensureValidAuthCredentials returned no error or tokenDetails");
                                    return {
                                        authorization: "Bearer " + fe(e.token)
                                    }
                                }
                            }
                            async getTimestamp(e) {
                                return this.isTimeOffsetSet() || !e && !this.authOptions.queryTime ? this.getTimestampUsingOffset() : this.client.time()
                            }
                            getTimestampUsingOffset() {
                                return Date.now() + (this.client.serverTimeOffset || 0)
                            }
                            isTimeOffsetSet() {
                                return null !== this.client.serverTimeOffset
                            }
                            _saveBasicOptions(e) {
                                this.method = "basic", this.key = e.key, this.basicKey = fe(e.key), this.authOptions = e || {}, "clientId" in e && this._userSetClientId(e.clientId)
                            }
                            _saveTokenOptions(e, t) {
                                this.method = "token", e && (this.tokenParams = e), t && (t.token && (t.tokenDetails = "string" == typeof t.token ? {
                                    token: t.token
                                } : t.token), t.tokenDetails && (this.tokenDetails = t.tokenDetails), "clientId" in t && this._userSetClientId(t.clientId), this.authOptions = t)
                            }
                            async _ensureValidAuthCredentials(e) {
                                const t = this.tokenDetails;
                                if (t) {
                                    if (this._tokenClientIdMismatch(t.clientId)) throw new k("Mismatch between clientId in token (" + t.clientId + ") and current clientId (" + this.clientId + ")", 40102, 403);
                                    if (!this.isTimeOffsetSet() || !t.expires || t.expires >= this.getTimestampUsingOffset()) return O.logAction(this.logger, O.LOG_MINOR, "Auth.getToken()", "using cached token; expires = " + t.expires), t;
                                    O.logAction(this.logger, O.LOG_MINOR, "Auth.getToken()", "deleting expired token"), this.tokenDetails = null
                                }
                                const n = (this.waitingForTokenRequest || (this.waitingForTokenRequest = Pe.create(this.logger))).createPromise();
                                if (null !== this.currentTokenRequestId && !e) return n;
                                const s = this.currentTokenRequestId = He++;
                                let i, o = null;
                                try {
                                    i = await this.requestToken(this.tokenParams, this.authOptions)
                                } catch (e) {
                                    o = e
                                }
                                if (this.currentTokenRequestId > s) return O.logAction(this.logger, O.LOG_MINOR, "Auth._ensureValidAuthCredentials()", "Discarding token request response; overtaken by newer one"), n;
                                this.currentTokenRequestId = null;
                                const r = this.waitingForTokenRequest;
                                return this.waitingForTokenRequest = null, o ? (null == r || r.rejectAll(o), n) : (null == r || r.resolveAll(this.tokenDetails = i), n)
                            }
                            _userSetClientId(e) {
                                if ("string" != typeof e && null !== e) throw new k("clientId must be either a string or null", 40012, 400);
                                if ("*" === e) throw new k('Can’t use "*" as a clientId as that string is reserved. (To change the default token request behaviour to use a wildcard clientId, instantiate the library with {defaultTokenParams: {clientId: "*"}}), or if calling authorize(), pass it in as a tokenParam: authorize({clientId: "*"}, authOptions)', 40012, 400); {
                                    const t = this._uncheckedSetClientId(e);
                                    if (t) throw t
                                }
                            }
                            _uncheckedSetClientId(e) {
                                if (this._tokenClientIdMismatch(e)) {
                                    const t = "Unexpected clientId mismatch: client has " + this.clientId + ", requested " + e,
                                        n = new k(t, 40102, 401);
                                    return O.logAction(this.logger, O.LOG_ERROR, "Auth._uncheckedSetClientId()", t), n
                                }
                                return this.clientId = this.tokenParams.clientId = e, null
                            }
                            _tokenClientIdMismatch(e) {
                                return !(!this.clientId || "*" === this.clientId || !e || "*" === e || this.clientId === e)
                            }
                            static isTokenErr(e) {
                                return e.code && e.code >= 40140 && e.code < 40150
                            }
                            revokeTokens(e, t) {
                                return this.client.rest.revokeTokens(e, t)
                            }
                        };

                    function We(e) {
                        const t = [];
                        if (e)
                            for (const n in e) t.push(n + "=" + e[n]);
                        return t.join("&")
                    }

                    function Fe(e, t) {
                        return e + (t ? "?" : "") + We(t)
                    }
                    var Ve = class {
                            constructor(e) {
                                this.client = e, this.platformHttp = new y.Http(e), this.checkConnectivity = this.platformHttp.checkConnectivity ? () => this.platformHttp.checkConnectivity() : void 0
                            }
                            get logger() {
                                var e, t;
                                return null != (t = null == (e = this.client) ? void 0 : e.logger) ? t : O.defaultLogger
                            }
                            get supportsAuthHeaders() {
                                return this.platformHttp.supportsAuthHeaders
                            }
                            get supportsLinkHeaders() {
                                return this.platformHttp.supportsLinkHeaders
                            }
                            _getHosts(e) {
                                const t = e.connection,
                                    n = t && t.connectionManager.host;
                                return n ? [n].concat(Ee.getFallbackHosts(e.options)) : Ee.getHosts(e.options)
                            }
                            async do(e, t, n, s, i) {
                                try {
                                    const o = this.client;
                                    if (!o) return {
                                        error: new k("http.do called without client", 5e4, 500)
                                    };
                                    const r = "function" == typeof t ? t : function(e) {
                                            return o.baseUri(e) + t
                                        },
                                        a = o._currentFallback;
                                    if (a) {
                                        if (a.validUntil > Date.now()) {
                                            const c = await this.doUri(e, r(a.host), n, s, i);
                                            return c.error && this.platformHttp.shouldFallback(c.error) ? (o._currentFallback = null, this.do(e, t, n, s, i)) : c
                                        }
                                        o._currentFallback = null
                                    }
                                    const c = this._getHosts(o);
                                    if (1 === c.length) return this.doUri(e, r(c[0]), n, s, i);
                                    let l = null;
                                    const h = async (t, a) => {
                                        const c = t.shift();
                                        l = null != l ? l : /* @__PURE__ */ new Date;
                                        const u = await this.doUri(e, r(c), n, s, i);
                                        return u.error && this.platformHttp.shouldFallback(u.error) && t.length ? Date.now() - l.getTime() > o.options.timeouts.httpMaxRetryDuration ? {
                                            error: new k(`Timeout for trying fallback hosts retries. Total elapsed time exceeded the ${o.options.timeouts.httpMaxRetryDuration}ms limit`, 50003, 500)
                                        } : h(t, !0) : (a && (o._currentFallback = {
                                            host: c,
                                            validUntil: Date.now() + o.options.timeouts.fallbackRetryTimeout
                                        }), u)
                                    };
                                    return h(c)
                                } catch (e) {
                                    return {
                                        error: new k(`Unexpected error in Http.do: ${X(e)}`, 500, 5e4)
                                    }
                                }
                            }
                            async
                            doUri(e, t, n, s, i) {
                                try {
                                    ! function(e, t, n, s, i) {
                                        i.shouldLog(O.LOG_MICRO) && O.logActionNoStrip(i, O.LOG_MICRO, "Http." + e + "()", "Sending; " + Fe(t, s) + "; Body" + (y.BufferUtils.isBuffer(n) ? " (Base64): " + y.BufferUtils.base64Encode(n) : ": " + n))
                                    }(e, t, s, i, this.logger);
                                    const o = await this.platformHttp.doUri(e, t, n, s, i);
                                    return this.logger.shouldLog(O.LOG_MICRO) && function(e, t, n, s, i) {
                                        O.logActionNoStrip(i, O.LOG_MICRO, "Http." + t + "()", e.error ? "Received Error; " + Fe(n, s) + "; Error: " + X(e.error) : "Received; " + Fe(n, s) + "; Headers: " + We(e.headers) + "; StatusCode: " + e.statusCode + "; Body" + (y.BufferUtils.isBuffer(e.body) ? " (Base64): " + y.BufferUtils.base64Encode(e.body) : ": " + e.body))
                                    }(o, e, t, i, this.logger), o
                                } catch (e) {
                                    return {
                                        error: new k(`Unexpected error in Http.doUri: ${X(e)}`, 500, 5e4)
                                    }
                                }
                            }
                        },
                        Ke = class {
                            constructor(e) {
                                var t, n, s, i, o, r, a, c;
                                this.Platform = y, this.ErrorInfo = k, this.Logger = O, this.Defaults = Ee, this.Utils = R, this._additionalHTTPRequestImplementations = null != (t = e.plugins) ? t : null, this.logger = new O, this.logger.setLog(e.logLevel, e.logHandler), O.logAction(this.logger, O.LOG_MICRO, "BaseClient()", "initialized with clientOptions " + y.Config.inspect(e)), this._MsgPack = null != (s = null == (n = e.plugins) ? void 0 : n.MsgPack) ? s : null;
                                const l = this.options = Ee.normaliseOptions(e, this._MsgPack, this.logger);
                                if (l.key) {
                                    const e = l.key.match(/^([^:\s]+):([^:.\s]+)$/);
                                    if (!e) {
                                        const e = "invalid key parameter";
                                        throw O.logAction(this.logger, O.LOG_ERROR, "BaseClient()", e), new k(e, 40400, 404)
                                    }
                                    l.keyName = e[1], l.keySecret = e[2]
                                }
                                if ("clientId" in l) {
                                    if ("string" != typeof l.clientId && null !== l.clientId) throw new k("clientId must be either a string or null", 40012, 400);
                                    if ("*" === l.clientId) throw new k('Can’t use "*" as a clientId as that string is reserved. (To change the default token request behaviour to use a wildcard clientId, use {defaultTokenParams: {clientId: "*"}})', 40012, 400)
                                }
                                O.logAction(this.logger, O.LOG_MINOR, "BaseClient()", "started; version = " + Ee.version), this._currentFallback = null, this.serverTimeOffset = null, this.http = new Ve(this), this.auth = new je(this, l), this._rest = (null == (i = e.plugins) ? void 0 : i.Rest) ? new e.plugins.Rest(this) : null, this._Crypto = null != (r = null == (o = e.plugins) ? void 0 : o.Crypto) ? r : null, this.__FilteredSubscriptions = null != (c = null == (a = e.plugins) ? void 0 : a.MessageInteractions) ? c : null
                            }
                            get rest() {
                                return this._rest || ve("Rest"), this._rest
                            }
                            get _FilteredSubscriptions() {
                                return this.__FilteredSubscriptions || ve("MessageInteractions"), this.__FilteredSubscriptions
                            }
                            get channels() {
                                return this.rest.channels
                            }
                            get push() {
                                return this.rest.push
                            }
                            get device() {
                                var e;
                                return (null == (e = this.options.plugins) ? void 0 : e.Push) && this.push.LocalDevice || ve("Push"), this._device || (this._device = this.push.LocalDevice.load(this)), this._device
                            }
                            baseUri(e) {
                                return Ee.getHttpScheme(this.options) + e + ":" + Ee.getPort(this.options, !1)
                            }
                            async stats(e) {
                                return this.rest.stats(e)
                            }
                            async time(e) {
                                return this.rest.time(e)
                            }
                            async request(e, t, n, s, i, o) {
                                return this.rest.request(e, t, n, s, i, o)
                            }
                            batchPublish(e) {
                                return this.rest.batchPublish(e)
                            }
                            batchPresence(e) {
                                return this.rest.batchPresence(e)
                            }
                            setLog(e) {
                                this.logger.setLog(e.level, e.handler)
                            }
                        };
                    Ke.Platform = y;
                    var ze = Ke,
                        Je = class e {
                            toJSON() {
                                var e, t, n;
                                return {
                                    id: this.id,
                                    deviceSecret: this.deviceSecret,
                                    platform: this.platform,
                                    formFactor: this.formFactor,
                                    clientId: this.clientId,
                                    metadata: this.metadata,
                                    deviceIdentityToken: this.deviceIdentityToken,
                                    push: {
                                        recipient: null == (e = this.push) ? void 0 : e.recipient,
                                        state: null == (t = this.push) ? void 0 : t.state,
                                        error: null == (n = this.push) ? void 0 : n.error
                                    }
                                }
                            }
                            toString() {
                                var e, t, n, s;
                                let i = "[DeviceDetails";
                                return this.id && (i += "; id=" + this.id), this.platform && (i += "; platform=" + this.platform), this.formFactor && (i += "; formFactor=" + this.formFactor), this.clientId && (i += "; clientId=" + this.clientId), this.metadata && (i += "; metadata=" + this.metadata), this.deviceIdentityToken && (i += "; deviceIdentityToken=" + JSON.stringify(this.deviceIdentityToken)), (null == (e = this.push) ? void 0 : e.recipient) && (i += "; push.recipient=" + JSON.stringify(this.push.recipient)), (null == (t = this.push) ? void 0 : t.state) && (i += "; push.state=" + this.push.state), (null == (n = this.push) ? void 0 : n.error) && (i += "; push.error=" + JSON.stringify(this.push.error)), (null == (s = this.push) ? void 0 : s.metadata) && (i += "; push.metadata=" + this.push.metadata), i += "]", i
                            }
                            static toRequestBody(e, t, n) {
                                return re(e, t, n)
                            }
                            static fromResponseBody(t, n, s) {
                                return s && (t = oe(t, n, s)), Array.isArray(t) ? e.fromValuesArray(t) : e.fromValues(t)
                            }
                            static fromValues(t) {
                                return t.error = t.error && k.fromValues(t.error), Object.assign(new e, t)
                            }
                            static fromLocalDevice(t) {
                                return Object.assign(new e, t)
                            }
                            static fromValuesArray(t) {
                                const n = t.length,
                                    s = new Array(n);
                                for (let i = 0; i < n; i++) s[i] = e.fromValues(t[i]);
                                return s
                            }
                        };
                    async function $e(e, t, n, s) {
                        return e.http.supportsAuthHeaders ? s(A(await e.auth.getAuthHeaders(), t), n) : s(t, A(await e.auth.getAuthParams(), n))
                    }
                    var Qe = class e {
                        static async get(t, n, s, i, o, r) {
                            return e.do(Le.Get, t, n, null, s, i, o, null != r && r)
                        }
                        static async delete(t, n, s, i, o, r) {
                            return e.do(Le.Delete, t, n, null, s, i, o, r)
                        }
                        static async post(t, n, s, i, o, r, a) {
                            return e.do(Le.Post, t, n, s, i, o, r, a)
                        }
                        static async patch(t, n, s, i, o, r, a) {
                            return e.do(Le.Patch, t, n, s, i, o, r, a)
                        }
                        static async put(t, n, s, i, o, r, a) {
                            return e.do(Le.Put, t, n, s, i, o, r, a)
                        }
                        static async do(e, t, n, s, i, o, r, a) {
                            r && ((o = o || {}).envelope = r);
                            const c = t.logger;
                            let l = await $e(t, i, o, async function i(o, r) {
                                var a;
                                if (c.shouldLog(O.LOG_MICRO)) {
                                    let i = s;
                                    if ((null == (a = o["content-type"]) ? void 0 : a.indexOf("msgpack")) > 0) try {
                                        t._MsgPack || ve("MsgPack"), i = t._MsgPack.decode(s)
                                    } catch (t) {
                                        O.logAction(c, O.LOG_MICRO, "Resource." + e + "()", "Sending MsgPack Decoding Error: " + X(t))
                                    }
                                    O.logAction(c, O.LOG_MICRO, "Resource." + e + "()", "Sending; " + Fe(n, r) + "; Body: " + i)
                                }
                                const l = await t.http.do(e, n, o, s, r);
                                return l.error && je.isTokenErr(l.error) ? (await t.auth.authorize(null, null), $e(t, o, r, i)) : {
                                    err: l.error,
                                    body: l.body,
                                    headers: l.headers,
                                    unpacked: l.unpacked,
                                    statusCode: l.statusCode
                                }
                            });
                            if (r && (l = function(e, t, n) {
                                    if (e.err && !e.body) return {
                                        err: e.err
                                    };
                                    if (e.statusCode === Ne.NoContent) return p(g({}, e), {
                                        body: [],
                                        unpacked: !0
                                    });
                                    let s = e.body;
                                    if (!e.unpacked) try {
                                        s = oe(s, t, n)
                                    } catch (e) {
                                        return Y(e) ? {
                                            err: e
                                        } : {
                                            err: new S(X(e), null)
                                        }
                                    }
                                    if (!s) return {
                                        err: new S("unenvelope(): Response body is missing", null)
                                    };
                                    const {
                                        statusCode: i,
                                        response: o,
                                        headers: r
                                    } = s;
                                    if (void 0 === i) return p(g({}, e), {
                                        body: s,
                                        unpacked: !0
                                    });
                                    if (i < 200 || i >= 300) {
                                        let t = o && o.error || e.err;
                                        return t || (t = new Error("Error in unenveloping " + s), t.statusCode = i), {
                                            err: t,
                                            body: o,
                                            headers: r,
                                            unpacked: !0,
                                            statusCode: i
                                        }
                                    }
                                    return {
                                        err: e.err,
                                        body: o,
                                        headers: r,
                                        unpacked: !0,
                                        statusCode: i
                                    }
                                }(l, t._MsgPack, r)), c.shouldLog(O.LOG_MICRO) && function(e, t, n, s, i) {
                                    O.logAction(i, O.LOG_MICRO, "Resource." + t + "()", e.err ? "Received Error; " + Fe(n, s) + "; Error: " + X(e.err) : "Received; " + Fe(n, s) + "; Headers: " + We(e.headers) + "; StatusCode: " + e.statusCode + "; Body: " + (y.BufferUtils.isBuffer(e.body) ? " (Base64): " + y.BufferUtils.base64Encode(e.body) : ": " + y.Config.inspect(e.body)))
                                }(l, e, n, o, c), a) {
                                if (l.err) throw l.err; {
                                    const e = g({}, l);
                                    return delete e.err, e
                                }
                            }
                            return l
                        }
                    };

                    function Ye(e) {
                        const t = e.match(/^\.\/(\w+)\?(.*)$/);
                        return t && t[2] && Q(t[2])
                    }
                    var Xe = class {
                            constructor(e, t, n) {
                                this.resource = e, this.items = t;
                                const s = this;
                                n && ("first" in n && (this.first = async function() {
                                    return s.get(n.first)
                                }), "current" in n && (this.current = async function() {
                                    return s.get(n.current)
                                }), this.next = async function() {
                                    return "next" in n ? s.get(n.next) : null
                                }, this.hasNext = function() {
                                    return "next" in n
                                }, this.isLast = () => {
                                    var e;
                                    return !(null == (e = this.hasNext) ? void 0 : e.call(this))
                                })
                            }
                            async get(e) {
                                const t = this.resource,
                                    n = await Qe.get(t.client, t.path, t.headers, e, t.envelope, !1);
                                return t.handlePage(n)
                            }
                        },
                        Ze = class extends Xe {
                            constructor(e, t, n, s, i, o) {
                                super(e, t, i), this.statusCode = s, this.success = s < 300 && s >= 200, this.headers = n, this.errorCode = o && o.code, this.errorMessage = o && o.message
                            }
                            toJSON() {
                                return {
                                    items: this.items,
                                    statusCode: this.statusCode,
                                    success: this.success,
                                    headers: this.headers,
                                    errorCode: this.errorCode,
                                    errorMessage: this.errorMessage
                                }
                            }
                        },
                        et = class {
                            constructor(e, t, n, s, i, o) {
                                this.client = e, this.path = t, this.headers = n, this.envelope = null != s ? s : null, this.bodyHandler = i, this.useHttpPaginatedResponse = o || !1
                            }
                            get logger() {
                                return this.client.logger
                            }
                            async get(e) {
                                const t = await Qe.get(this.client, this.path, this.headers, e, this.envelope, !1);
                                return this.handlePage(t)
                            }
                            async delete(e) {
                                const t = await Qe.delete(this.client, this.path, this.headers, e, this.envelope, !1);
                                return this.handlePage(t)
                            }
                            async post(e, t) {
                                const n = await Qe.post(this.client, this.path, t, this.headers, e, this.envelope, !1);
                                return this.handlePage(n)
                            }
                            async put(e, t) {
                                const n = await Qe.put(this.client, this.path, t, this.headers, e, this.envelope, !1);
                                return this.handlePage(n)
                            }
                            async patch(e, t) {
                                const n = await Qe.patch(this.client, this.path, t, this.headers, e, this.envelope, !1);
                                return this.handlePage(n)
                            }
                            async handlePage(e) {
                                if (e.err && (!this.useHttpPaginatedResponse || !e.body && "number" != typeof e.err.code)) throw O.logAction(this.logger, O.LOG_ERROR, "PaginatedResource.handlePage()", "Unexpected error getting resource: err = " + X(e.err)), e.err;
                                let t, n, s;
                                try {
                                    t = e.statusCode == Ne.NoContent ? [] : await this.bodyHandler(e.body, e.headers || {}, e.unpacked)
                                } catch (t) {
                                    throw e.err || t
                                }
                                return e.headers && (n = e.headers.Link || e.headers.link) && (s = function(e) {
                                    "string" == typeof e && (e = e.split(","));
                                    const t = {};
                                    for (let n = 0; n < e.length; n++) {
                                        const s = e[n].match(/^\s*<(.+)>;\s*rel="(\w+)"$/);
                                        if (s) {
                                            const e = Ye(s[1]);
                                            e && (t[s[2]] = e)
                                        }
                                    }
                                    return t
                                }(n)), this.useHttpPaginatedResponse ? new Ze(this, t, e.headers || {}, e.statusCode, s, e.err) : new Xe(this, t, s)
                            }
                        },
                        tt = class e {
                            toJSON() {
                                return {
                                    channel: this.channel,
                                    deviceId: this.deviceId,
                                    clientId: this.clientId
                                }
                            }
                            toString() {
                                let e = "[PushChannelSubscription";
                                return this.channel && (e += "; channel=" + this.channel), this.deviceId && (e += "; deviceId=" + this.deviceId), this.clientId && (e += "; clientId=" + this.clientId), e += "]", e
                            }
                            static fromResponseBody(t, n, s) {
                                return s && (t = oe(t, n, s)), Array.isArray(t) ? e.fromValuesArray(t) : e.fromValues(t)
                            }
                            static fromValues(t) {
                                return Object.assign(new e, t)
                            }
                            static fromValuesArray(t) {
                                const n = t.length,
                                    s = new Array(n);
                                for (let i = 0; i < n; i++) s[i] = e.fromValues(t[i]);
                                return s
                            }
                        };
                    tt.toRequestBody = re;
                    var nt = tt;

                    function st(e) {
                        let t = 0;
                        return e.name && (t += e.name.length), e.clientId && (t += e.clientId.length), e.extras && (t += JSON.stringify(e.extras).length), e.data && (t += ee(e.data)), t
                    }
                    async function it(e, t, n, s) {
                        const i = lt(n),
                            o = function(e, t, n) {
                                if (n && n.cipher) {
                                    e || ve("Crypto");
                                    const s = e.getCipher(n.cipher, t);
                                    return {
                                        cipher: s.cipherParams,
                                        channelCipher: s.cipher
                                    }
                                }
                                return null != n ? n : {}
                            }(t, e, null != s ? s : null);
                        try {
                            await ct(i, o)
                        } catch (t) {
                            O.logAction(e, O.LOG_ERROR, "Message.fromEncoded()", t.toString())
                        }
                        return i
                    }
                    async function ot(e, t) {
                        const n = e.data;
                        if ("string" != typeof n && !y.BufferUtils.isBuffer(n) && null != n) {
                            if (!E(n) && !Array.isArray(n)) throw new k("Data type is unsupported", 40013, 400);
                            e.data = JSON.stringify(n), e.encoding = e.encoding ? e.encoding + "/json" : "json"
                        }
                        return null != t && t.cipher ? async function(e, t) {
                            let n = e.data,
                                s = e.encoding,
                                i = t.channelCipher;
                            s = s ? s + "/" : "", y.BufferUtils.isBuffer(n) || (n = y.BufferUtils.utf8Encode(String(n)), s += "utf-8/");
                            const o = await i.encrypt(n);
                            return e.data = o, e.encoding = s + "cipher+" + i.algorithm, e
                        }(e, t) : e
                    }
                    async function rt(e, t) {
                        return Promise.all(e.map(e => ot(e, t)))
                    }
                    var at = re;
                    async function ct(e, t) {
                        const n = function(e) {
                            return e && e.channelOptions ? e : {
                                channelOptions: e,
                                plugins: {},
                                baseEncodedPreviousPayload: void 0
                            }
                        }(t);
                        let s = e.data;
                        const i = e.encoding;
                        if (i) {
                            const t = i.split("/");
                            let o, r = t.length,
                                a = e.data,
                                c = "";
                            try {
                                for (;
                                    (o = r) > 0;) {
                                    const e = t[--r].match(/([-\w]+)(\+([\w-]+))?/);
                                    if (!e) break;
                                    switch (c = e[1], c) {
                                        case "base64":
                                            a = y.BufferUtils.base64Decode(String(a)), o == t.length && (s = a);
                                            continue;
                                        case "utf-8":
                                            a = y.BufferUtils.utf8Decode(a);
                                            continue;
                                        case "json":
                                            a = JSON.parse(a);
                                            continue;
                                        case "cipher":
                                            if (null != n.channelOptions && n.channelOptions.cipher && n.channelOptions.channelCipher) {
                                                const t = n.channelOptions.channelCipher;
                                                if (e[3] != t.algorithm) throw new Error("Unable to decrypt message with given cipher; incompatible cipher params");
                                                a = await t.decrypt(a);
                                                continue
                                            }
                                            throw new Error("Unable to decrypt message; not an encrypted channel");
                                        case "vcdiff":
                                            if (!n.plugins || !n.plugins.vcdiff) throw new k("Missing Vcdiff decoder (https://github.com/ably-forks/vcdiff-decoder)", 40019, 400);
                                            if ("undefined" == typeof Uint8Array) throw new k("Delta decoding not supported on this browser (need ArrayBuffer & Uint8Array)", 40020, 400);
                                            try {
                                                let e = n.baseEncodedPreviousPayload;
                                                "string" == typeof e && (e = y.BufferUtils.utf8Encode(e));
                                                const t = y.BufferUtils.toBuffer(e);
                                                a = y.BufferUtils.toBuffer(a), a = y.BufferUtils.arrayBufferViewToBuffer(n.plugins.vcdiff.decode(a, t)), s = a
                                            } catch (e) {
                                                throw new k("Vcdiff delta decode failed with " + e, 40018, 400)
                                            }
                                            continue;
                                        default:
                                            throw new Error("Unknown encoding")
                                    }
                                }
                            } catch (e) {
                                throw new k("Error processing the " + c + " encoding, decoder returned ‘" + e.message + "’", e.code || 40013, 400)
                            } finally {
                                e.encoding = o <= 0 ? null : t.slice(0, o).join("/"), e.data = a
                            }
                        }
                        n.baseEncodedPreviousPayload = s
                    }

                    function lt(e) {
                        return Object.assign(new dt, e)
                    }

                    function ht(e) {
                        const t = e.length,
                            n = new Array(t);
                        for (let s = 0; s < t; s++) n[s] = lt(e[s]);
                        return n
                    }

                    function ut(e) {
                        let t, n = 0;
                        for (let s = 0; s < e.length; s++) t = e[s], n += t.size || (t.size = st(t));
                        return n
                    }
                    var dt = class {
                            toJSON() {
                                let e = this.encoding,
                                    t = this.data;
                                return t && y.BufferUtils.isBuffer(t) && (arguments.length > 0 ? (e = e ? e + "/base64" : "base64", t = y.BufferUtils.base64Encode(t)) : t = y.BufferUtils.toBuffer(t)), {
                                    name: this.name,
                                    id: this.id,
                                    clientId: this.clientId,
                                    connectionId: this.connectionId,
                                    connectionKey: this.connectionKey,
                                    extras: this.extras,
                                    encoding: e,
                                    data: t
                                }
                            }
                            toString() {
                                let e = "[Message";
                                return this.name && (e += "; name=" + this.name), this.id && (e += "; id=" + this.id), this.timestamp && (e += "; timestamp=" + this.timestamp), this.clientId && (e += "; clientId=" + this.clientId), this.connectionId && (e += "; connectionId=" + this.connectionId), this.encoding && (e += "; encoding=" + this.encoding), this.extras && (e += "; extras =" + JSON.stringify(this.extras)), this.data && ("string" == typeof this.data ? e += "; data=" + this.data : y.BufferUtils.isBuffer(this.data) ? e += "; data (buffer)=" + y.BufferUtils.base64Encode(this.data) : e += "; data (json)=" + JSON.stringify(this.data)), this.extras && (e += "; extras=" + JSON.stringify(this.extras)), e += "]", e
                            }
                        },
                        gt = dt,
                        pt = ["absent", "present", "enter", "leave", "update"];
                    async function ft(e, t, n) {
                        const s = mt(t, !0);
                        try {
                            await yt(s, null != n ? n : {})
                        } catch (t) {
                            O.logAction(e, O.LOG_ERROR, "PresenceMessage.fromEncoded()", t.toString())
                        }
                        return s
                    }

                    function mt(e, t) {
                        return t && (e.action = pt[e.action]), Object.assign(new Ct, e)
                    }
                    var yt = ct;
                    async function vt(e, t, n, s, i) {
                        const o = [];
                        i && (e = oe(e, s, i));
                        for (let s = 0; s < e.length; s++) {
                            const i = o[s] = mt(e[s], !0);
                            try {
                                await yt(i, t)
                            } catch (e) {
                                O.logAction(n, O.LOG_ERROR, "PresenceMessage.fromResponseBody()", e.toString())
                            }
                        }
                        return o
                    }

                    function wt(e) {
                        const t = e.length,
                            n = new Array(t);
                        for (let s = 0; s < t; s++) n[s] = mt(e[s]);
                        return n
                    }

                    function bt(e) {
                        return e instanceof Ct ? e : mt({
                            data: e
                        })
                    }
                    var Ct = class {
                            isSynthesized() {
                                return !this.id || !this.connectionId || this.id.substring(this.connectionId.length, 0) !== this.connectionId
                            }
                            parseId() {
                                if (!this.id) throw new Error("parseId(): Presence message does not contain an id");
                                const e = this.id.split(":");
                                return {
                                    connectionId: e[0],
                                    msgSerial: parseInt(e[1], 10),
                                    index: parseInt(e[2], 10)
                                }
                            }
                            toJSON() {
                                let e = this.data,
                                    t = this.encoding;
                                return e && y.BufferUtils.isBuffer(e) && (arguments.length > 0 ? (t = t ? t + "/base64" : "base64", e = y.BufferUtils.base64Encode(e)) : e = y.BufferUtils.toBuffer(e)), {
                                    id: this.id,
                                    clientId: this.clientId,
                                    action: (n = this.action, pt.indexOf(n)),
                                    data: e,
                                    encoding: t,
                                    extras: this.extras
                                };
                                var n
                            }
                            toString() {
                                let e = "[PresenceMessage";
                                return e += "; action=" + this.action, this.id && (e += "; id=" + this.id), this.timestamp && (e += "; timestamp=" + this.timestamp), this.clientId && (e += "; clientId=" + this.clientId), this.connectionId && (e += "; connectionId=" + this.connectionId), this.encoding && (e += "; encoding=" + this.encoding), this.data && ("string" == typeof this.data ? e += "; data=" + this.data : y.BufferUtils.isBuffer(this.data) ? e += "; data (buffer)=" + y.BufferUtils.base64Encode(this.data) : e += "; data (json)=" + JSON.stringify(this.data)), this.extras && (e += "; extras=" + JSON.stringify(this.extras)), e += "]", e
                            }
                        },
                        Ot = Ct,
                        Rt = class e {
                            constructor(e) {
                                this.entries = e && e.entries || void 0, this.schema = e && e.schema || void 0, this.appId = e && e.appId || void 0, this.inProgress = e && e.inProgress || void 0, this.unit = e && e.unit || void 0, this.intervalId = e && e.intervalId || void 0
                            }
                            static fromValues(t) {
                                return new e(t)
                            }
                        },
                        It = class {
                            static basePath(e) {
                                return "/channels/" + encodeURIComponent(e.name)
                            }
                            static history(e, t) {
                                const n = e.client,
                                    s = n.options.useBinaryProtocol ? "msgpack" : "json",
                                    i = e.client.http.supportsLinkHeaders ? void 0 : s,
                                    o = Ee.defaultGetHeaders(n.options, {
                                        format: s
                                    });
                                A(o, n.options.headers);
                                const r = e.channelOptions;
                                return new et(n, this.basePath(e) + "/messages", o, i, async function(t, i, o) {
                                    return await async function(e, t, n, s, i) {
                                        i && (e = oe(e, s, i));
                                        for (let s = 0; s < e.length; s++) {
                                            const i = e[s] = lt(e[s]);
                                            try {
                                                await ct(i, t)
                                            } catch (e) {
                                                O.logAction(n, O.LOG_ERROR, "Message.fromResponseBody()", e.toString())
                                            }
                                        }
                                        return e
                                    }(t, r, e.logger, n._MsgPack, o ? void 0 : s)
                                }).get(t)
                            }
                            static async status(e) {
                                const t = e.client.options.useBinaryProtocol ? "msgpack" : "json",
                                    n = Ee.defaultPostHeaders(e.client.options, {
                                        format: t
                                    });
                                return (await Qe.get(e.client, this.basePath(e), n, {}, t, !0)).body
                            }
                        },
                        kt = class {
                            static basePath(e) {
                                return It.basePath(e.channel) + "/presence"
                            }
                            static async history(e, t) {
                                const n = e.channel.client,
                                    s = n.options.useBinaryProtocol ? "msgpack" : "json",
                                    i = e.channel.client.http.supportsLinkHeaders ? void 0 : s,
                                    o = Ee.defaultGetHeaders(n.options, {
                                        format: s
                                    });
                                A(o, n.options.headers);
                                const r = e.channel.channelOptions;
                                return new et(n, this.basePath(e) + "/history", o, i, async function(t, i, o) {
                                    return await vt(t, r, e.logger, n._MsgPack, o ? void 0 : s)
                                }).get(t)
                            }
                        },
                        St = class {
                            constructor(e) {
                                this.channelMixin = It, this.presenceMixin = kt, this.Resource = Qe, this.DeviceDetails = Je, this.client = e, this.channels = new At(this.client), this.push = new class {
                                    constructor(e) {
                                        var t;
                                        this.client = e, this.admin = new class {
                                            constructor(e) {
                                                this.client = e, this.deviceRegistrations = new class {
                                                    constructor(e) {
                                                        this.client = e
                                                    }
                                                    async save(e) {
                                                        const t = this.client,
                                                            n = Je.fromValues(e),
                                                            s = t.options.useBinaryProtocol ? "msgpack" : "json",
                                                            i = Ee.defaultPostHeaders(t.options, {
                                                                format: s
                                                            }),
                                                            o = {};
                                                        A(i, t.options.headers), t.options.pushFullWait && A(o, {
                                                            fullWait: "true"
                                                        });
                                                        const r = re(n, t._MsgPack, s),
                                                            a = await Qe.put(t, "/push/deviceRegistrations/" + encodeURIComponent(e.id), r, i, o, null, !0);
                                                        return Je.fromResponseBody(a.body, t._MsgPack, a.unpacked ? void 0 : s)
                                                    }
                                                    async get(e) {
                                                        const t = this.client,
                                                            n = t.options.useBinaryProtocol ? "msgpack" : "json",
                                                            s = Ee.defaultGetHeaders(t.options, {
                                                                format: n
                                                            }),
                                                            i = e.id || e;
                                                        if ("string" != typeof i || !i.length) throw new k("First argument to DeviceRegistrations#get must be a deviceId string or DeviceDetails", 4e4, 400);
                                                        A(s, t.options.headers);
                                                        const o = await Qe.get(t, "/push/deviceRegistrations/" + encodeURIComponent(i), s, {}, null, !0);
                                                        return Je.fromResponseBody(o.body, t._MsgPack, o.unpacked ? void 0 : n)
                                                    }
                                                    async list(e) {
                                                        const t = this.client,
                                                            n = t.options.useBinaryProtocol ? "msgpack" : "json",
                                                            s = this.client.http.supportsLinkHeaders ? void 0 : n,
                                                            i = Ee.defaultGetHeaders(t.options, {
                                                                format: n
                                                            });
                                                        return A(i, t.options.headers), new et(t, "/push/deviceRegistrations", i, s, async function(e, s, i) {
                                                            return Je.fromResponseBody(e, t._MsgPack, i ? void 0 : n)
                                                        }).get(e)
                                                    }
                                                    async remove(e) {
                                                        const t = this.client,
                                                            n = Ee.defaultGetHeaders(t.options, {
                                                                format: t.options.useBinaryProtocol ? "msgpack" : "json"
                                                            }),
                                                            s = {},
                                                            i = e.id || e;
                                                        if ("string" != typeof i || !i.length) throw new k("First argument to DeviceRegistrations#remove must be a deviceId string or DeviceDetails", 4e4, 400);
                                                        A(n, t.options.headers), t.options.pushFullWait && A(s, {
                                                            fullWait: "true"
                                                        }), await Qe.delete(t, "/push/deviceRegistrations/" + encodeURIComponent(i), n, s, null, !0)
                                                    }
                                                    async removeWhere(e) {
                                                        const t = this.client,
                                                            n = Ee.defaultGetHeaders(t.options, {
                                                                format: t.options.useBinaryProtocol ? "msgpack" : "json"
                                                            });
                                                        A(n, t.options.headers), t.options.pushFullWait && A(e, {
                                                            fullWait: "true"
                                                        }), await Qe.delete(t, "/push/deviceRegistrations", n, e, null, !0)
                                                    }
                                                }(e), this.channelSubscriptions = new class e {
                                                    constructor(t) {
                                                        this.remove = e.prototype.removeWhere, this.client = t
                                                    }
                                                    async save(e) {
                                                        const t = this.client,
                                                            n = nt.fromValues(e),
                                                            s = t.options.useBinaryProtocol ? "msgpack" : "json",
                                                            i = Ee.defaultPostHeaders(t.options, {
                                                                format: s
                                                            }),
                                                            o = {};
                                                        A(i, t.options.headers), t.options.pushFullWait && A(o, {
                                                            fullWait: "true"
                                                        });
                                                        const r = re(n, t._MsgPack, s),
                                                            a = await Qe.post(t, "/push/channelSubscriptions", r, i, o, null, !0);
                                                        return nt.fromResponseBody(a.body, t._MsgPack, a.unpacked ? void 0 : s)
                                                    }
                                                    async list(e) {
                                                        const t = this.client,
                                                            n = t.options.useBinaryProtocol ? "msgpack" : "json",
                                                            s = this.client.http.supportsLinkHeaders ? void 0 : n,
                                                            i = Ee.defaultGetHeaders(t.options, {
                                                                format: n
                                                            });
                                                        return A(i, t.options.headers), new et(t, "/push/channelSubscriptions", i, s, async function(e, s, i) {
                                                            return nt.fromResponseBody(e, t._MsgPack, i ? void 0 : n)
                                                        }).get(e)
                                                    }
                                                    async removeWhere(e) {
                                                        const t = this.client,
                                                            n = Ee.defaultGetHeaders(t.options, {
                                                                format: t.options.useBinaryProtocol ? "msgpack" : "json"
                                                            });
                                                        A(n, t.options.headers), t.options.pushFullWait && A(e, {
                                                            fullWait: "true"
                                                        }), await Qe.delete(t, "/push/channelSubscriptions", n, e, null, !0)
                                                    }
                                                    async listChannels(e) {
                                                        const t = this.client,
                                                            n = t.options.useBinaryProtocol ? "msgpack" : "json",
                                                            s = this.client.http.supportsLinkHeaders ? void 0 : n,
                                                            i = Ee.defaultGetHeaders(t.options, {
                                                                format: n
                                                            });
                                                        return A(i, t.options.headers), t.options.pushFullWait && A(e, {
                                                            fullWait: "true"
                                                        }), new et(t, "/push/channels", i, s, async function(e, s, i) {
                                                            const o = !i && n ? oe(e, t._MsgPack, n) : e;
                                                            for (let e = 0; e < o.length; e++) o[e] = String(o[e]);
                                                            return o
                                                        }).get(e)
                                                    }
                                                }(e)
                                            }
                                            async publish(e, t) {
                                                const n = this.client,
                                                    s = n.options.useBinaryProtocol ? "msgpack" : "json",
                                                    i = Ee.defaultPostHeaders(n.options, {
                                                        format: s
                                                    }),
                                                    o = {},
                                                    r = A({
                                                        recipient: e
                                                    }, t);
                                                A(i, n.options.headers), n.options.pushFullWait && A(o, {
                                                    fullWait: "true"
                                                });
                                                const a = re(r, n._MsgPack, s);
                                                await Qe.post(n, "/push/publish", a, i, o, null, !0)
                                            }
                                        }(e), y.Config.push && (null == (t = e.options.plugins) ? void 0 : t.Push) && (this.stateMachine = new e.options.plugins.Push.ActivationStateMachine(e), this.LocalDevice = e.options.plugins.Push.localDeviceFactory(Je))
                                    }
                                    async activate(e, t) {
                                        await new Promise((n, s) => {
                                            var i;
                                            (null == (i = this.client.options.plugins) ? void 0 : i.Push) ? this.stateMachine ? this.stateMachine.activatedCallback ? s(new k("Activation already in progress", 4e4, 400)) : (this.stateMachine.activatedCallback = e => {
                                                e ? s(e) : n()
                                            }, this.stateMachine.updateFailedCallback = t, this.stateMachine.handleEvent(new this.client.options.plugins.Push.CalledActivate(this.stateMachine, e))) : s(new k("This platform is not supported as a target of push notifications", 4e4, 400)): s(ye("Push"))
                                        })
                                    }
                                    async deactivate(e) {
                                        await new Promise((t, n) => {
                                            var s;
                                            (null == (s = this.client.options.plugins) ? void 0 : s.Push) ? this.stateMachine ? this.stateMachine.deactivatedCallback ? n(new k("Deactivation already in progress", 4e4, 400)) : (this.stateMachine.deactivatedCallback = e => {
                                                e ? n(e) : t()
                                            }, this.stateMachine.handleEvent(new this.client.options.plugins.Push.CalledDeactivate(this.stateMachine, e))) : n(new k("This platform is not supported as a target of push notifications", 4e4, 400)): n(ye("Push"))
                                        })
                                    }
                                }(this.client)
                            }
                            async stats(e) {
                                const t = Ee.defaultGetHeaders(this.client.options),
                                    n = this.client.http.supportsLinkHeaders ? void 0 : this.client.options.useBinaryProtocol ? "msgpack" : "json";
                                return A(t, this.client.options.headers), new et(this.client, "/stats", t, n, function(e, t, n) {
                                    const s = n ? e : JSON.parse(e);
                                    for (let e = 0; e < s.length; e++) s[e] = Rt.fromValues(s[e]);
                                    return s
                                }).get(e)
                            }
                            async time(e) {
                                const t = Ee.defaultGetHeaders(this.client.options);
                                this.client.options.headers && A(t, this.client.options.headers);
                                let {
                                    error: n,
                                    body: s,
                                    unpacked: i
                                } = await this.client.http.do(Le.Get, e => this.client.baseUri(e) + "/time", t, null, e);
                                if (n) throw n;
                                i || (s = JSON.parse(s));
                                const o = s[0];
                                if (!o) throw new k("Internal error (unexpected result type from GET /time)", 5e4, 500);
                                return this.client.serverTimeOffset = o - Date.now(), o
                            }
                            async request(e, t, n, s, i, o) {
                                var r;
                                const [a, c, l] = (() => this.client.options.useBinaryProtocol ? (this.client._MsgPack || ve("MsgPack"), [this.client._MsgPack.encode, this.client._MsgPack.decode, "msgpack"]) : [JSON.stringify, JSON.parse, "json"])(), h = this.client.http.supportsLinkHeaders ? void 0 : l;
                                s = s || {};
                                const u = e.toLowerCase(),
                                    d = "get" == u ? Ee.defaultGetHeaders(this.client.options, {
                                        format: l,
                                        protocolVersion: n
                                    }) : Ee.defaultPostHeaders(this.client.options, {
                                        format: l,
                                        protocolVersion: n
                                    });
                                "string" != typeof i && (i = null != (r = a(i)) ? r : null), A(d, this.client.options.headers), o && A(d, o);
                                const g = new et(this.client, t, d, h, async function(e, t, n) {
                                    return M(n ? e : c(e))
                                }, !0);
                                if (!y.Http.methods.includes(u)) throw new k("Unsupported method " + u, 40500, 405);
                                return y.Http.methodsWithBody.includes(u) ? g[u](s, i) : g[u](s)
                            }
                            async batchPublish(e) {
                                let t, n;
                                Array.isArray(e) ? (t = e, n = !1) : (t = [e], n = !0);
                                const s = this.client.options.useBinaryProtocol ? "msgpack" : "json",
                                    i = Ee.defaultPostHeaders(this.client.options, {
                                        format: s
                                    });
                                this.client.options.headers && A(i, this.client.options.headers);
                                const o = re(t, this.client._MsgPack, s),
                                    r = await Qe.post(this.client, "/messages", o, i, {}, null, !0),
                                    a = r.unpacked ? r.body : oe(r.body, this.client._MsgPack, s);
                                return n ? a[0] : a
                            }
                            async batchPresence(e) {
                                const t = this.client.options.useBinaryProtocol ? "msgpack" : "json",
                                    n = Ee.defaultPostHeaders(this.client.options, {
                                        format: t
                                    });
                                this.client.options.headers && A(n, this.client.options.headers);
                                const s = e.join(","),
                                    i = await Qe.get(this.client, "/presence", n, {
                                        channels: s
                                    }, null, !0);
                                return i.unpacked ? i.body : oe(i.body, this.client._MsgPack, t)
                            }
                            async revokeTokens(e, t) {
                                if (Be(this.client.options)) throw new k("Cannot revoke tokens when using token auth", 40162, 401);
                                const n = this.client.options.keyName;
                                let s = null != t ? t : {};
                                const i = g({
                                        targets: e.map(e => `${e.type}:${e.value}`)
                                    }, s),
                                    o = this.client.options.useBinaryProtocol ? "msgpack" : "json",
                                    r = Ee.defaultPostHeaders(this.client.options, {
                                        format: o
                                    });
                                this.client.options.headers && A(r, this.client.options.headers);
                                const a = re(i, this.client._MsgPack, o),
                                    c = await Qe.post(this.client, `/keys/${n}/revokeTokens`, a, r, {}, null, !0);
                                return c.unpacked ? c.body : oe(c.body, this.client._MsgPack, o)
                            }
                        },
                        At = class {
                            constructor(e) {
                                this.client = e, this.all = /* @__PURE__ */ Object.create(null)
                            }
                            get(e, t) {
                                e = String(e);
                                let n = this.all[e];
                                return n ? t && n.setOptions(t) : this.all[e] = n = new class {
                                    constructor(e, t, n) {
                                        var s, i;
                                        O.logAction(e.logger, O.LOG_MINOR, "RestChannel()", "started; name = " + t), this.name = t, this.client = e, this.presence = new class {
                                            constructor(e) {
                                                this.channel = e
                                            }
                                            get logger() {
                                                return this.channel.logger
                                            }
                                            async get(e) {
                                                O.logAction(this.logger, O.LOG_MICRO, "RestPresence.get()", "channel = " + this.channel.name);
                                                const t = this.channel.client,
                                                    n = t.options.useBinaryProtocol ? "msgpack" : "json",
                                                    s = this.channel.client.http.supportsLinkHeaders ? void 0 : n,
                                                    i = Ee.defaultGetHeaders(t.options, {
                                                        format: n
                                                    });
                                                A(i, t.options.headers);
                                                const o = this.channel.channelOptions;
                                                return new et(t, this.channel.client.rest.presenceMixin.basePath(this), i, s, async (e, s, i) => await vt(e, o, this.logger, t._MsgPack, i ? void 0 : n)).get(e)
                                            }
                                            async history(e) {
                                                return O.logAction(this.logger, O.LOG_MICRO, "RestPresence.history()", "channel = " + this.channel.name), this.channel.client.rest.presenceMixin.history(this, e)
                                            }
                                        }(this), this.channelOptions = Se(null != (s = e._Crypto) ? s : null, this.logger, n), (null == (i = e.options.plugins) ? void 0 : i.Push) && (this._push = new e.options.plugins.Push.PushChannel(this))
                                    }
                                    get push() {
                                        return this._push || ve("Push"), this._push
                                    }
                                    get logger() {
                                        return this.client.logger
                                    }
                                    setOptions(e) {
                                        var t;
                                        this.channelOptions = Se(null != (t = this.client._Crypto) ? t : null, this.logger, e)
                                    }
                                    async history(e) {
                                        return O.logAction(this.logger, O.LOG_MICRO, "RestChannel.history()", "channel = " + this.name), this.client.rest.channelMixin.history(this, e)
                                    }
                                    async publish(...e) {
                                        const t = e[0];
                                        let n, s;
                                        if ("string" == typeof t || null === t) n = [lt({
                                            name: t,
                                            data: e[1]
                                        })], s = e[2];
                                        else if (E(t)) n = [lt(t)], s = e[1];
                                        else {
                                            if (!Array.isArray(t)) throw new k("The single-argument form of publish() expects a message object or an array of message objects", 40013, 400);
                                            n = ht(t), s = e[1]
                                        }
                                        s || (s = {});
                                        const i = this.client,
                                            o = i.options,
                                            r = o.useBinaryProtocol ? "msgpack" : "json",
                                            a = i.options.idempotentRestPublishing,
                                            c = Ee.defaultPostHeaders(i.options, {
                                                format: r
                                            });
                                        if (A(c, o.headers), a && function(e) {
                                                return e.every(function(e) {
                                                    return !e.id
                                                })
                                            }(n)) {
                                            const e = await ne(9);
                                            n.forEach(function(t, n) {
                                                t.id = e + ":" + n.toString()
                                            })
                                        }
                                        await rt(n, this.channelOptions);
                                        const l = ut(n),
                                            h = o.maxMessageSize;
                                        if (l > h) throw new k("Maximum size of messages that can be published at once exceeded ( was " + l + " bytes; limit is " + h + " bytes)", 40009, 400);
                                        await this._publish(at(n, i._MsgPack, r), c, s)
                                    }
                                    async _publish(e, t, n) {
                                        await Qe.post(this.client, this.client.rest.channelMixin.basePath(this) + "/messages", e, t, n, null, !0)
                                    }
                                    async status() {
                                        return this.client.rest.channelMixin.status(this)
                                    }
                                }(this.client, e, t), n
                            }
                            release(e) {
                                delete this.all[String(e)]
                            }
                        },
                        Tt = class extends ze {
                            constructor(e) {
                                super(Ee.objectifyOptions(e, !1, "BaseRest", O.defaultLogger, {
                                    Rest: St
                                }))
                            }
                        },
                        Mt = {
                            Rest: St
                        },
                        Et = class extends gt {
                            static async fromEncoded(e, t) {
                                return it(O.defaultLogger, y.Crypto, e, t)
                            }
                            static async fromEncodedArray(e, t) {
                                return async function(e, t, n, s) {
                                    return Promise.all(n.map(function(n) {
                                        return it(e, t, n, s)
                                    }))
                                }(O.defaultLogger, y.Crypto, e, t)
                            }
                            static fromValues(e) {
                                return Object.assign(new gt, e)
                            }
                            static async encode(e, t) {
                                return ot(e, t)
                            }
                            static async decode(e, t) {
                                return ct(e, t)
                            }
                        },
                        Pt = class extends Ot {
                            static async fromEncoded(e, t) {
                                return ft(O.defaultLogger, e, t)
                            }
                            static async fromEncodedArray(e, t) {
                                return async function(e, t, n) {
                                    return Promise.all(t.map(function(t) {
                                        return ft(e, t, n)
                                    }))
                                }(O.defaultLogger, e, t)
                            }
                            static fromValues(e, t) {
                                return mt(e, t)
                            }
                        },
                        _t = class e extends Tt {
                            constructor(t) {
                                var n, s;
                                if (!e._MsgPack) throw new Error("Expected DefaultRest._MsgPack to have been set");
                                super(Ee.objectifyOptions(t, !0, "Rest", O.defaultLogger, p(g({}, Mt), {
                                    Crypto: null != (n = e.Crypto) ? n : void 0,
                                    MsgPack: null != (s = e._MsgPack) ? s : void 0
                                })))
                            }
                            static get Crypto() {
                                if (null === this._Crypto) throw new Error("Encryption not enabled; use ably.encryption.js instead");
                                return this._Crypto
                            }
                            static set Crypto(e) {
                                this._Crypto = e
                            }
                        };
                    _t._Crypto = null, _t.Message = Et, _t.PresenceMessage = Pt, _t._MsgPack = null, _t._Http = Ve;
                    var Lt = _t;

                    function Ut(e, t, n) {
                        let s, i, o;
                        for (let r = 0; r < e.length; r++)
                            if (s = e[r], n && (s = s[n]), Array.isArray(s)) {
                                for (; - 1 !== (i = s.indexOf(t));) s.splice(i, 1);
                                n && 0 === s.length && delete e[r][n]
                            } else if (E(s))
                            for (o in s) Object.prototype.hasOwnProperty.call(s, o) && Array.isArray(s[o]) && Ut([s], t, o)
                    }
                    var Nt = class {
                            constructor(e) {
                                this.logger = e, this.any = [], this.events = /* @__PURE__ */ Object.create(null), this.anyOnce = [], this.eventsOnce = /* @__PURE__ */ Object.create(null)
                            }
                            on(...e) {
                                if (1 === e.length) {
                                    const t = e[0];
                                    if ("function" != typeof t) throw new Error("EventListener.on(): Invalid arguments: " + y.Config.inspect(e));
                                    this.any.push(t)
                                }
                                if (2 === e.length) {
                                    const [t, n] = e;
                                    if ("function" != typeof n) throw new Error("EventListener.on(): Invalid arguments: " + y.Config.inspect(e));
                                    if (_(t)) this.any.push(n);
                                    else if (Array.isArray(t)) t.forEach(e => {
                                        this.on(e, n)
                                    });
                                    else {
                                        if ("string" != typeof t) throw new Error("EventListener.on(): Invalid arguments: " + y.Config.inspect(e));
                                        (this.events[t] || (this.events[t] = [])).push(n)
                                    }
                                }
                            }
                            off(...e) {
                                if (0 == e.length || _(e[0]) && _(e[1])) return this.any = [], this.events = /* @__PURE__ */ Object.create(null), this.anyOnce = [], void(this.eventsOnce = /* @__PURE__ */ Object.create(null));
                                const [t, n] = e;
                                let s = null,
                                    i = null;
                                if (1 !== e.length && n) {
                                    if ("function" != typeof n) throw new Error("EventEmitter.off(): invalid arguments:" + y.Config.inspect(e));
                                    [i, s] = [t, n]
                                } else "function" == typeof t ? s = t : i = t;
                                if (s && _(i)) Ut([this.any, this.events, this.anyOnce, this.eventsOnce], s);
                                else if (Array.isArray(i)) i.forEach(e => {
                                    this.off(e, s)
                                });
                                else {
                                    if ("string" != typeof i) throw new Error("EventEmitter.off(): invalid arguments:" + y.Config.inspect(e));
                                    s ? Ut([this.events, this.eventsOnce], s, i) : (delete this.events[i], delete this.eventsOnce[i])
                                }
                            }
                            listeners(e) {
                                if (e) {
                                    const t = this.events[e] || [];
                                    return this.eventsOnce[e] && Array.prototype.push.apply(t, this.eventsOnce[e]), t.length ? t : null
                                }
                                return this.any.length ? this.any : null
                            }
                            emit(e, ...t) {
                                const n = {
                                        event: e
                                    },
                                    s = [];
                                this.anyOnce.length && (Array.prototype.push.apply(s, this.anyOnce), this.anyOnce = []), this.any.length && Array.prototype.push.apply(s, this.any);
                                const i = this.eventsOnce[e];
                                i && (Array.prototype.push.apply(s, i), delete this.eventsOnce[e]);
                                const o = this.events[e];
                                o && Array.prototype.push.apply(s, o), s.forEach(e => {
                                    ! function(e, t, n, s) {
                                        try {
                                            n.apply(t, s)
                                        } catch (t) {
                                            O.logAction(e, O.LOG_ERROR, "EventEmitter.emit()", "Unexpected listener exception: " + t + "; stack = " + (t && t.stack))
                                        }
                                    }(this.logger, n, e, t)
                                })
                            }
                            once(...e) {
                                const t = e.length;
                                if (0 === t || 1 === t && "function" != typeof e[0]) {
                                    const t = e[0];
                                    return new Promise(e => {
                                        this.once(t, e)
                                    })
                                }
                                const [n, s] = e;
                                if (1 === e.length && "function" == typeof n) this.anyOnce.push(n);
                                else if (_(n)) {
                                    if ("function" != typeof s) throw new Error("EventEmitter.once(): Invalid arguments:" + y.Config.inspect(e));
                                    this.anyOnce.push(s)
                                } else if (Array.isArray(n)) {
                                    const t = this,
                                        i = function() {
                                            const o = Array.prototype.slice.call(arguments);
                                            if (n.forEach(function(e) {
                                                    t.off(e, i)
                                                }), "function" != typeof s) throw new Error("EventEmitter.once(): Invalid arguments:" + y.Config.inspect(e));
                                            s.apply(this, o)
                                        };
                                    n.forEach(function(e) {
                                        t.on(e, i)
                                    })
                                } else {
                                    if ("string" != typeof n) throw new Error("EventEmitter.once(): Invalid arguments:" + y.Config.inspect(e));
                                    const t = this.eventsOnce[n] || (this.eventsOnce[n] = []);
                                    if (s) {
                                        if ("function" != typeof s) throw new Error("EventEmitter.once(): Invalid arguments:" + y.Config.inspect(e));
                                        t.push(s)
                                    }
                                }
                            }
                            async whenState(e, t) {
                                if ("string" != typeof e || "string" != typeof t) throw new Error("whenState requires a valid state String argument");
                                return e === t ? null : this.once(e)
                            }
                        },
                        xt = {
                            HEARTBEAT: 0,
                            ACK: 1,
                            NACK: 2,
                            CONNECT: 3,
                            CONNECTED: 4,
                            DISCONNECT: 5,
                            DISCONNECTED: 6,
                            CLOSE: 7,
                            CLOSED: 8,
                            ERROR: 9,
                            ATTACH: 10,
                            ATTACHED: 11,
                            DETACH: 12,
                            DETACHED: 13,
                            PRESENCE: 14,
                            MESSAGE: 15,
                            SYNC: 16,
                            AUTH: 17,
                            ACTIVATE: 18
                        },
                        Gt = [];
                    Object.keys(xt).forEach(function(e) {
                        Gt[xt[e]] = e
                    });
                    var Dt = {
                            HAS_PRESENCE: 1,
                            HAS_BACKLOG: 2,
                            RESUMED: 4,
                            TRANSIENT: 16,
                            ATTACH_RESUME: 32,
                            PRESENCE: 65536,
                            PUBLISH: 1 << 17,
                            SUBSCRIBE: 1 << 18,
                            PRESENCE_SUBSCRIBE: 1 << 19
                        },
                        qt = Object.keys(Dt);

                    function Bt(e) {
                        const t = [];
                        if (e)
                            for (let n = 0; n < e.length; n++) t.push(e[n].toString());
                        return "[ " + t.join(", ") + " ]"
                    }
                    Dt.MODE_ALL = Dt.PRESENCE | Dt.PUBLISH | Dt.SUBSCRIBE | Dt.PRESENCE_SUBSCRIBE;
                    var Ht = ["PRESENCE", "PUBLISH", "SUBSCRIBE", "PRESENCE_SUBSCRIBE"],
                        jt = re;

                    function Wt(e, t) {
                        const n = e.error;
                        n && (e.error = k.fromValues(n));
                        const s = e.messages;
                        if (s)
                            for (let e = 0; e < s.length; e++) s[e] = lt(s[e]);
                        const i = t ? e.presence : void 0;
                        if (t && i && t)
                            for (let e = 0; e < i.length; e++) i[e] = t.presenceMessageFromValues(i[e], !0);
                        return Object.assign(new $t, p(g({}, e), {
                            presence: i
                        }))
                    }

                    function Ft(e) {
                        return Wt(e, {
                            presenceMessageFromValues: mt,
                            presenceMessagesFromValuesArray: wt
                        })
                    }

                    function Vt(e) {
                        return Object.assign(new $t, e)
                    }

                    function Kt(e, t) {
                        let n = "[ProtocolMessage";
                        void 0 !== e.action && (n += "; action=" + Gt[e.action] || e.action);
                        const s = ["id", "channel", "channelSerial", "connectionId", "count", "msgSerial", "timestamp"];
                        let i;
                        for (let t = 0; t < s.length; t++) i = s[t], void 0 !== e[i] && (n += "; " + i + "=" + e[i]);
                        if (e.messages && (n += "; messages=" + Bt(ht(e.messages))), e.presence && t && (n += "; presence=" + Bt(t.presenceMessagesFromValuesArray(e.presence))), e.error && (n += "; error=" + k.fromValues(e.error).toString()), e.auth && e.auth.accessToken && (n += "; token=" + e.auth.accessToken), e.flags && (n += "; flags=" + qt.filter(e.hasFlag).join(",")), e.params) {
                            let t = "";
                            V(e.params, function(n) {
                                t.length > 0 && (t += "; "), t += n + "=" + e.params[n]
                            }), t.length > 0 && (n += "; params=[" + t + "]")
                        }
                        return n += "]", n
                    }
                    var zt, Jt, $t = class {
                            constructor() {
                                this.hasFlag = e => (this.flags & Dt[e]) > 0
                            }
                            setFlag(e) {
                                return this.flags = this.flags | Dt[e]
                            }
                            getMode() {
                                return this.flags && this.flags & Dt.MODE_ALL
                            }
                            encodeModesToFlags(e) {
                                e.forEach(e => this.setFlag(e))
                            }
                            decodeModesFromFlags() {
                                const e = [];
                                return Ht.forEach(t => {
                                    this.hasFlag(t) && e.push(t)
                                }), e.length > 0 ? e : void 0
                            }
                        },
                        Qt = $t,
                        Yt = class extends Nt {
                            constructor(e) {
                                super(e), this.messages = []
                            }
                            count() {
                                return this.messages.length
                            }
                            push(e) {
                                this.messages.push(e)
                            }
                            shift() {
                                return this.messages.shift()
                            }
                            last() {
                                return this.messages[this.messages.length - 1]
                            }
                            copyAll() {
                                return this.messages.slice()
                            }
                            append(e) {
                                this.messages.push.apply(this.messages, e)
                            }
                            prepend(e) {
                                this.messages.unshift.apply(this.messages, e)
                            }
                            completeMessages(e, t, n) {
                                O.logAction(this.logger, O.LOG_MICRO, "MessageQueue.completeMessages()", "serial = " + e + "; count = " + t), n = n || null;
                                const s = this.messages;
                                if (0 === s.length) throw new Error("MessageQueue.completeMessages(): completeMessages called on any empty MessageQueue");
                                const i = s[0];
                                if (i) {
                                    const o = i.message.msgSerial,
                                        r = e + t;
                                    if (r > o) {
                                        const e = s.splice(0, r - o);
                                        for (const t of e) t.callback(n)
                                    }
                                    0 == s.length && this.emit("idle")
                                }
                            }
                            completeAllMessages(e) {
                                this.completeMessages(0, Number.MAX_SAFE_INTEGER || Number.MAX_VALUE, e)
                            }
                            resetSendAttempted() {
                                for (let e of this.messages) e.sendAttempted = !1
                            }
                            clear() {
                                O.logAction(this.logger, O.LOG_MICRO, "MessageQueue.clear()", "clearing " + this.messages.length + " messages"), this.messages = [], this.emit("idle")
                            }
                        },
                        Xt = class {
                            constructor(e, t) {
                                this.message = e, this.callback = t, this.merged = !1;
                                const n = e.action;
                                this.sendAttempted = !1, this.ackRequired = n == xt.MESSAGE || n == xt.PRESENCE
                            }
                        },
                        Zt = class extends Nt {
                            constructor(e) {
                                super(e.logger), this.transport = e, this.messageQueue = new Yt(this.logger), e.on("ack", (e, t) => {
                                    this.onAck(e, t)
                                }), e.on("nack", (e, t, n) => {
                                    this.onNack(e, t, n)
                                })
                            }
                            onAck(e, t) {
                                O.logAction(this.logger, O.LOG_MICRO, "Protocol.onAck()", "serial = " + e + "; count = " + t), this.messageQueue.completeMessages(e, t)
                            }
                            onNack(e, t, n) {
                                O.logAction(this.logger, O.LOG_ERROR, "Protocol.onNack()", "serial = " + e + "; count = " + t + "; err = " + X(n)), n || (n = new k("Unable to send message; channel not responding", 50001, 500)), this.messageQueue.completeMessages(e, t, n)
                            }
                            onceIdle(e) {
                                const t = this.messageQueue;
                                0 !== t.count() ? t.once("idle", e) : e()
                            }
                            send(e) {
                                e.ackRequired && this.messageQueue.push(e), this.logger.shouldLog(O.LOG_MICRO) && O.logActionNoStrip(this.logger, O.LOG_MICRO, "Protocol.send()", "sending msg; " + Kt(e.message, this.transport.connectionManager.realtime._RealtimePresence)), e.sendAttempted = !0, this.transport.send(e.message)
                            }
                            getTransport() {
                                return this.transport
                            }
                            getPendingMessages() {
                                return this.messageQueue.copyAll()
                            }
                            clearPendingMessages() {
                                return this.messageQueue.clear()
                            }
                            finish() {
                                const e = this.transport;
                                this.onceIdle(function() {
                                    e.disconnect()
                                })
                            }
                        },
                        en = class {
                            constructor(e, t, n, s) {
                                this.previous = e, this.current = t, n && (this.retryIn = n), s && (this.reason = s)
                            }
                        },
                        tn = {
                            DISCONNECTED: 80003,
                            SUSPENDED: 80002,
                            FAILED: 8e4,
                            CLOSING: 80017,
                            CLOSED: 80017,
                            UNKNOWN_CONNECTION_ERR: 50002,
                            UNKNOWN_CHANNEL_ERR: 50001
                        },
                        nn = {
                            disconnected: () => k.fromValues({
                                statusCode: 400,
                                code: tn.DISCONNECTED,
                                message: "Connection to server temporarily unavailable"
                            }),
                            suspended: () => k.fromValues({
                                statusCode: 400,
                                code: tn.SUSPENDED,
                                message: "Connection to server unavailable"
                            }),
                            failed: () => k.fromValues({
                                statusCode: 400,
                                code: tn.FAILED,
                                message: "Connection failed or disconnected by server"
                            }),
                            closing: () => k.fromValues({
                                statusCode: 400,
                                code: tn.CLOSING,
                                message: "Connection closing"
                            }),
                            closed: () => k.fromValues({
                                statusCode: 400,
                                code: tn.CLOSED,
                                message: "Connection closed"
                            }),
                            unknownConnectionErr: () => k.fromValues({
                                statusCode: 500,
                                code: tn.UNKNOWN_CONNECTION_ERR,
                                message: "Internal connection error"
                            }),
                            unknownChannelErr: () => k.fromValues({
                                statusCode: 500,
                                code: tn.UNKNOWN_CONNECTION_ERR,
                                message: "Internal channel error"
                            })
                        },
                        sn = Vt({
                            action: xt.CLOSE
                        }),
                        on = Vt({
                            action: xt.DISCONNECT
                        }),
                        rn = class extends Nt {
                            constructor(e, t, n, s) {
                                super(e.logger), s && (n.format = void 0, n.heartbeats = !0), this.connectionManager = e, this.auth = t, this.params = n, this.timeouts = n.options.timeouts, this.format = n.format, this.isConnected = !1, this.isFinished = !1, this.isDisposed = !1, this.maxIdleInterval = null, this.idleTimer = null, this.lastActivity = null
                            }
                            connect() {}
                            close() {
                                this.isConnected && this.requestClose(), this.finish("closed", nn.closed())
                            }
                            disconnect(e) {
                                this.isConnected && this.requestDisconnect(), this.finish("disconnected", e || nn.disconnected())
                            }
                            fail(e) {
                                this.isConnected && this.requestDisconnect(), this.finish("failed", e || nn.failed())
                            }
                            finish(e, t) {
                                var n;
                                this.isFinished || (this.isFinished = !0, this.isConnected = !1, this.maxIdleInterval = null, clearTimeout(null != (n = this.idleTimer) ? n : void 0), this.idleTimer = null, this.emit(e, t), this.dispose())
                            }
                            onProtocolMessage(e) {
                                switch (this.logger.shouldLog(O.LOG_MICRO) && O.logActionNoStrip(this.logger, O.LOG_MICRO, "Transport.onProtocolMessage()", "received on " + this.shortName + ": " + Kt(e, this.connectionManager.realtime._RealtimePresence) + "; connectionId = " + this.connectionManager.connectionId), this.onActivity(), e.action) {
                                    case xt.HEARTBEAT:
                                        O.logActionNoStrip(this.logger, O.LOG_MICRO, "Transport.onProtocolMessage()", this.shortName + " heartbeat; connectionId = " + this.connectionManager.connectionId), this.emit("heartbeat", e.id);
                                        break;
                                    case xt.CONNECTED:
                                        this.onConnect(e), this.emit("connected", e.error, e.connectionId, e.connectionDetails, e);
                                        break;
                                    case xt.CLOSED:
                                        this.onClose(e);
                                        break;
                                    case xt.DISCONNECTED:
                                        this.onDisconnect(e);
                                        break;
                                    case xt.ACK:
                                        this.emit("ack", e.msgSerial, e.count);
                                        break;
                                    case xt.NACK:
                                        this.emit("nack", e.msgSerial, e.count, e.error);
                                        break;
                                    case xt.SYNC:
                                        this.connectionManager.onChannelMessage(e, this);
                                        break;
                                    case xt.ACTIVATE:
                                        break;
                                    case xt.AUTH:
                                        ie(this.auth.authorize(), e => {
                                            e && O.logAction(this.logger, O.LOG_ERROR, "Transport.onProtocolMessage()", "Ably requested re-authentication, but unable to obtain a new token: " + X(e))
                                        });
                                        break;
                                    case xt.ERROR:
                                        if (O.logAction(this.logger, O.LOG_MINOR, "Transport.onProtocolMessage()", "received error action; connectionId = " + this.connectionManager.connectionId + "; err = " + y.Config.inspect(e.error) + (e.channel ? ", channel: " + e.channel : "")), void 0 === e.channel) {
                                            this.onFatalError(e);
                                            break
                                        }
                                        this.connectionManager.onChannelMessage(e, this);
                                        break;
                                    default:
                                        this.connectionManager.onChannelMessage(e, this)
                                }
                            }
                            onConnect(e) {
                                if (this.isConnected = !0, !e.connectionDetails) throw new Error("Transport.onConnect(): Connect message recieved without connectionDetails");
                                const t = e.connectionDetails.maxIdleInterval;
                                t && (this.maxIdleInterval = t + this.timeouts.realtimeRequestTimeout, this.onActivity())
                            }
                            onDisconnect(e) {
                                const t = e && e.error;
                                O.logAction(this.logger, O.LOG_MINOR, "Transport.onDisconnect()", "err = " + X(t)), this.finish("disconnected", t)
                            }
                            onFatalError(e) {
                                const t = e && e.error;
                                O.logAction(this.logger, O.LOG_MINOR, "Transport.onFatalError()", "err = " + X(t)), this.finish("failed", t)
                            }
                            onClose(e) {
                                const t = e && e.error;
                                O.logAction(this.logger, O.LOG_MINOR, "Transport.onClose()", "err = " + X(t)), this.finish("closed", t)
                            }
                            requestClose() {
                                O.logAction(this.logger, O.LOG_MINOR, "Transport.requestClose()", ""), this.send(sn)
                            }
                            requestDisconnect() {
                                O.logAction(this.logger, O.LOG_MINOR, "Transport.requestDisconnect()", ""), this.send(on)
                            }
                            ping(e) {
                                const t = {
                                    action: xt.HEARTBEAT
                                };
                                e && (t.id = e), this.send(Vt(t))
                            }
                            dispose() {
                                O.logAction(this.logger, O.LOG_MINOR, "Transport.dispose()", ""), this.isDisposed = !0, this.off()
                            }
                            onActivity() {
                                this.maxIdleInterval && (this.lastActivity = this.connectionManager.lastActivity = Date.now(), this.setIdleTimer(this.maxIdleInterval + 100))
                            }
                            setIdleTimer(e) {
                                this.idleTimer || (this.idleTimer = setTimeout(() => {
                                    this.onIdleTimerExpire()
                                }, e))
                            }
                            onIdleTimerExpire() {
                                if (!this.lastActivity || !this.maxIdleInterval) throw new Error("Transport.onIdleTimerExpire(): lastActivity/maxIdleInterval not set");
                                this.idleTimer = null;
                                const e = Date.now() - this.lastActivity,
                                    t = this.maxIdleInterval - e;
                                if (t <= 0) {
                                    const t = "No activity seen from realtime in " + e + "ms; assuming connection has dropped";
                                    O.logAction(this.logger, O.LOG_ERROR, "Transport.onIdleTimerExpire()", t), this.disconnect(new k(t, 80003, 408))
                                } else this.setIdleTimer(t + 100)
                            }
                            static tryConnect(e, t, n, s, i) {
                                const o = new e(t, n, s);
                                let r;
                                const a = function(e) {
                                    clearTimeout(r), i({
                                        event: this.event,
                                        error: e
                                    })
                                };
                                return r = setTimeout(() => {
                                    o.off(["preconnect", "disconnected", "failed"]), o.dispose(), a.call({
                                        event: "disconnected"
                                    }, new k("Timeout waiting for transport to indicate itself viable", 5e4, 500))
                                }, t.options.timeouts.realtimeRequestTimeout), o.on(["failed", "disconnected"], a), o.on("preconnect", function() {
                                    O.logAction(t.logger, O.LOG_MINOR, "Transport.tryConnect()", "viable transport " + o), clearTimeout(r), o.off(["failed", "disconnected"], a), i(null, o)
                                }), o.connect(), o
                            }
                            static isAvailable() {
                                throw new k("isAvailable not implemented for transport", 5e4, 500)
                            }
                        };
                    (Jt = zt || (zt = {})).WebSocket = "web_socket", Jt.Comet = "comet", Jt.XhrPolling = "xhr_polling";
                    var an = void 0 !== e ? e : "undefined" != typeof window ? window : self,
                        cn = () => {
                            var e;
                            return void 0 !== y.WebStorage && (null == (e = y.WebStorage) ? void 0 : e.localSupported)
                        },
                        ln = () => {
                            var e;
                            return void 0 !== y.WebStorage && (null == (e = y.WebStorage) ? void 0 : e.sessionSupported)
                        },
                        hn = function() {},
                        un = "ably-transport-preference";

                    function dn(e) {
                        try {
                            return JSON.parse(e)
                        } catch (e) {
                            return null
                        }
                    }
                    var gn = class e extends Nt {
                            constructor(e, t) {
                                super(e.logger), this.supportedTransports = {}, this.disconnectedRetryCount = 0, this.pendingChannelMessagesState = {
                                    isProcessing: !1,
                                    queue: []
                                }, this.realtime = e, this.initTransports(), this.options = t;
                                const n = t.timeouts;
                                if (this.states = {
                                        initialized: {
                                            state: "initialized",
                                            terminal: !1,
                                            queueEvents: !0,
                                            sendEvents: !1,
                                            failState: "disconnected"
                                        },
                                        connecting: {
                                            state: "connecting",
                                            terminal: !1,
                                            queueEvents: !0,
                                            sendEvents: !1,
                                            retryDelay: n.webSocketConnectTimeout + n.realtimeRequestTimeout,
                                            failState: "disconnected"
                                        },
                                        connected: {
                                            state: "connected",
                                            terminal: !1,
                                            queueEvents: !1,
                                            sendEvents: !0,
                                            failState: "disconnected"
                                        },
                                        disconnected: {
                                            state: "disconnected",
                                            terminal: !1,
                                            queueEvents: !0,
                                            sendEvents: !1,
                                            retryDelay: n.disconnectedRetryTimeout,
                                            failState: "disconnected"
                                        },
                                        suspended: {
                                            state: "suspended",
                                            terminal: !1,
                                            queueEvents: !1,
                                            sendEvents: !1,
                                            retryDelay: n.suspendedRetryTimeout,
                                            failState: "suspended"
                                        },
                                        closing: {
                                            state: "closing",
                                            terminal: !1,
                                            queueEvents: !1,
                                            sendEvents: !1,
                                            retryDelay: n.realtimeRequestTimeout,
                                            failState: "closed"
                                        },
                                        closed: {
                                            state: "closed",
                                            terminal: !0,
                                            queueEvents: !1,
                                            sendEvents: !1,
                                            failState: "closed"
                                        },
                                        failed: {
                                            state: "failed",
                                            terminal: !0,
                                            queueEvents: !1,
                                            sendEvents: !1,
                                            failState: "failed"
                                        }
                                    }, this.state = this.states.initialized, this.errorReason = null, this.queuedMessages = new Yt(this.logger), this.msgSerial = 0, this.connectionDetails = void 0, this.connectionId = void 0, this.connectionKey = void 0, this.connectionStateTtl = n.connectionStateTtl, this.maxIdleInterval = null, this.transports = G(t.transports || Ee.defaultTransports, this.supportedTransports), this.transportPreference = null, this.transports.includes(zt.WebSocket) && (this.webSocketTransportAvailable = !0), this.transports.includes(zt.XhrPolling) ? this.baseTransport = zt.XhrPolling : this.transports.includes(zt.Comet) && (this.baseTransport = zt.Comet), this.httpHosts = Ee.getHosts(t), this.wsHosts = Ee.getHosts(t, !0), this.activeProtocol = null, this.host = null, this.lastAutoReconnectAttempt = null, this.lastActivity = null, this.forceFallbackHost = !1, this.connectCounter = 0, this.wsCheckResult = null, this.webSocketSlowTimer = null, this.webSocketGiveUpTimer = null, this.abandonedWebSocket = !1, O.logAction(this.logger, O.LOG_MINOR, "Realtime.ConnectionManager()", "started"), O.logAction(this.logger, O.LOG_MICRO, "Realtime.ConnectionManager()", "requested transports = [" + (t.transports || Ee.defaultTransports) + "]"), O.logAction(this.logger, O.LOG_MICRO, "Realtime.ConnectionManager()", "available transports = [" + this.transports + "]"), O.logAction(this.logger, O.LOG_MICRO, "Realtime.ConnectionManager()", "http hosts = [" + this.httpHosts + "]"), !this.transports.length) {
                                    const e = "no requested transports available";
                                    throw O.logAction(this.logger, O.LOG_ERROR, "realtime.ConnectionManager()", e), new Error(e)
                                }
                                const s = y.Config.addEventListener;
                                s && (ln() && "function" == typeof t.recover && s("beforeunload", this.persistConnection.bind(this)), !0 === t.closeOnUnload && s("beforeunload", () => {
                                    O.logAction(this.logger, O.LOG_MAJOR, "Realtime.ConnectionManager()", "beforeunload event has triggered the connection to close as closeOnUnload is true"), this.requestState({
                                        state: "closing"
                                    })
                                }), s("online", () => {
                                    var e;
                                    this.state == this.states.disconnected || this.state == this.states.suspended ? (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager caught browser ‘online’ event", "reattempting connection"), this.requestState({
                                        state: "connecting"
                                    })) : this.state == this.states.connecting && (null == (e = this.pendingTransport) || e.off(), this.disconnectAllTransports(), this.startConnect())
                                }), s("offline", () => {
                                    this.state == this.states.connected && (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager caught browser ‘offline’ event", "disconnecting active transport"), this.disconnectAllTransports())
                                }))
                            }
                            static supportedTransports(e) {
                                const t = {
                                    supportedTransports: {}
                                };
                                return this.initTransports(e, t), t.supportedTransports
                            }
                            static initTransports(e, t) {
                                const n = g(g({}, y.Transports.bundledImplementations), e);
                                [zt.WebSocket, ...y.Transports.order].forEach(e => {
                                    const s = n[e];
                                    s && s.isAvailable() && (t.supportedTransports[e] = s)
                                })
                            }
                            initTransports() {
                                e.initTransports(this.realtime._additionalTransportImplementations, this)
                            }
                            createTransportParams(e, t) {
                                return new class {
                                    constructor(e, t, n, s) {
                                        this.options = e, this.host = t, this.mode = n, this.connectionKey = s, this.format = e.useBinaryProtocol ? "msgpack" : "json"
                                    }
                                    getConnectParams(e) {
                                        const t = e ? T(e) : {},
                                            n = this.options;
                                        switch (this.mode) {
                                            case "resume":
                                                t.resume = this.connectionKey;
                                                break;
                                            case "recover":
                                                {
                                                    const e = dn(n.recover);e && (t.recover = e.connectionKey);
                                                    break
                                                }
                                        }
                                        return void 0 !== n.clientId && (t.clientId = n.clientId), !1 === n.echoMessages && (t.echo = "false"), void 0 !== this.format && (t.format = this.format), void 0 !== this.stream && (t.stream = this.stream), void 0 !== this.heartbeats && (t.heartbeats = this.heartbeats), t.v = Ee.protocolVersion, t.agent = ke(this.options), void 0 !== n.transportParams && A(t, n.transportParams), t
                                    }
                                    toString() {
                                        let e = "[mode=" + this.mode;
                                        return this.host && (e += ",host=" + this.host), this.connectionKey && (e += ",connectionKey=" + this.connectionKey), this.format && (e += ",format=" + this.format), e += "]", e
                                    }
                                }(this.options, e, t, this.connectionKey)
                            }
                            getTransportParams(e) {
                                (e => {
                                    if (this.connectionKey) return void e("resume");
                                    if ("string" == typeof this.options.recover) return void e("recover");
                                    const t = this.options.recover,
                                        n = this.getSessionRecoverData(),
                                        s = this.sessionRecoveryName();
                                    if (n && "function" == typeof t) return O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.getTransportParams()", "Calling clientOptions-provided recover function with last session data (recovery scope: " + s + ")"), void t(n, t => {
                                        t ? (this.options.recover = n.recoveryKey, e("recover")) : e("clean")
                                    });
                                    e("clean")
                                })(t => {
                                    const n = this.createTransportParams(null, t);
                                    if ("recover" === t) {
                                        O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.getTransportParams()", "Transport recovery mode = recover; recoveryKey = " + this.options.recover);
                                        const e = dn(this.options.recover);
                                        e && (this.msgSerial = e.msgSerial)
                                    } else O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.getTransportParams()", "Transport params = " + n.toString());
                                    e(n)
                                })
                            }
                            tryATransport(e, t, n) {
                                O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.tryATransport()", "trying " + t), this.proposedTransport = rn.tryConnect(this.supportedTransports[t], this, this.realtime.auth, e, (s, i) => {
                                    const o = this.state;
                                    return o == this.states.closing || o == this.states.closed || o == this.states.failed ? (i && (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.tryATransport()", "connection " + o.state + " while we were attempting the transport; closing " + i), i.close()), void n(!0)) : s ? (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.tryATransport()", "transport " + t + " " + s.event + ", err: " + s.error.toString()), void(!je.isTokenErr(s.error) || this.errorReason && je.isTokenErr(this.errorReason) ? "failed" === s.event ? (this.notifyState({
                                        state: "failed",
                                        error: s.error
                                    }), n(!0)) : "disconnected" === s.event && (!(r = s.error).statusCode || !r.code || r.statusCode >= 500 || Object.values(tn).includes(r.code) ? n(!1) : (this.notifyState({
                                        state: this.states.connecting.failState,
                                        error: s.error
                                    }), n(!0))) : (this.errorReason = s.error, ie(this.realtime.auth._forceNewToken(null, null), s => {
                                        s ? this.actOnErrorFromAuthorize(s) : this.tryATransport(e, t, n)
                                    })))) : (O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.tryATransport()", "viable transport " + t + "; setting pending"), this.setTransportPending(i, e), void n(null, i));
                                    var r
                                })
                            }
                            setTransportPending(e, t) {
                                const n = t.mode;
                                O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.setTransportPending()", "transport = " + e + "; mode = " + n), this.pendingTransport = e, this.cancelWebSocketSlowTimer(), this.cancelWebSocketGiveUpTimer(), e.once("connected", (t, s, i) => {
                                    this.activateTransport(t, e, s, i), "recover" === n && this.options.recover && (delete this.options.recover, this.unpersistConnection())
                                });
                                const s = this;
                                e.on(["disconnected", "closed", "failed"], function(t) {
                                    s.deactivateTransport(e, this.event, t)
                                }), this.emit("transport.pending", e)
                            }
                            activateTransport(e, t, n, s) {
                                O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.activateTransport()", "transport = " + t), e && O.logAction(this.logger, O.LOG_ERROR, "ConnectionManager.activateTransport()", "error = " + e), n && O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.activateTransport()", "connectionId =  " + n), s && O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.activateTransport()", "connectionDetails =  " + JSON.stringify(s)), this.persistTransportPreference(t);
                                const i = this.state,
                                    o = this.states.connected.state;
                                if (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.activateTransport()", "current state = " + i.state), i.state == this.states.closing.state || i.state == this.states.closed.state || i.state == this.states.failed.state) return O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.activateTransport()", "Disconnecting transport and abandoning"), t.disconnect(), !1;
                                if (delete this.pendingTransport, !t.isConnected) return O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.activateTransport()", "Declining to activate transport " + t + " since it appears to no longer be connected"), !1;
                                const r = this.activeProtocol;
                                this.activeProtocol = new Zt(t), this.host = t.params.host;
                                const a = s.connectionKey;
                                if (a && this.connectionKey != a && this.setConnection(n, s, !!e), this.onConnectionDetailsUpdate(s, t), y.Config.nextTick(() => {
                                        t.on("connected", (e, n, s) => {
                                            this.onConnectionDetailsUpdate(s, t), this.emit("update", new en(o, o, null, e))
                                        })
                                    }), i.state === this.states.connected.state ? e && (this.errorReason = this.realtime.connection.errorReason = e, this.emit("update", new en(o, o, null, e))) : (this.notifyState({
                                        state: "connected",
                                        error: e
                                    }), this.errorReason = this.realtime.connection.errorReason = e || null), this.emit("transport.active", t), r)
                                    if (r.messageQueue.count() > 0 && O.logAction(this.logger, O.LOG_ERROR, "ConnectionManager.activateTransport()", "Previous active protocol (for transport " + r.transport.shortName + ", new one is " + t.shortName + ") finishing with " + r.messageQueue.count() + " messages still pending"), r.transport === t) {
                                        const e = "Assumption violated: activating a transport that was also the transport for the previous active protocol; transport = " + t.shortName + "; stack = " + (new Error).stack;
                                        O.logAction(this.logger, O.LOG_ERROR, "ConnectionManager.activateTransport()", e)
                                    } else r.finish();
                                return !0
                            }
                            deactivateTransport(e, t, n) {
                                const s = this.activeProtocol,
                                    i = s && s.getTransport() === e,
                                    o = e === this.pendingTransport,
                                    r = this.noTransportsScheduledForActivation();
                                if (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.deactivateTransport()", "transport = " + e), O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.deactivateTransport()", "state = " + t + (i ? "; was active" : o ? "; was pending" : "") + (r ? "" : "; another transport is scheduled for activation")), n && n.message && O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.deactivateTransport()", "reason =  " + n.message), i && (O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.deactivateTransport()", "Getting, clearing, and requeuing " + this.activeProtocol.messageQueue.count() + " pending messages"), this.queuePendingMessages(s.getPendingMessages()), s.clearPendingMessages(), this.activeProtocol = this.host = null), this.emit("transport.inactive", e), i && r || i && "failed" === t || "closed" === t || null === s && o) {
                                    if ("disconnected" === t && n && n.statusCode > 500 && this.httpHosts.length > 1) return this.unpersistTransportPreference(), this.forceFallbackHost = !0, void this.notifyState({
                                        state: t,
                                        error: n,
                                        retryImmediately: !0
                                    });
                                    const e = "failed" === t && je.isTokenErr(n) ? "disconnected" : t;
                                    this.notifyState({
                                        state: e,
                                        error: n
                                    })
                                }
                            }
                            noTransportsScheduledForActivation() {
                                return !this.pendingTransport || !this.pendingTransport.isConnected
                            }
                            setConnection(e, t, n) {
                                const s = this.connectionId;
                                (s && s !== e || !s && n) && (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.setConnection()", "Resetting msgSerial"), this.msgSerial = 0, this.queuedMessages.resetSendAttempted()), this.connectionId !== e && O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.setConnection()", "New connectionId; reattaching any attached channels"), this.realtime.connection.id = this.connectionId = e, this.realtime.connection.key = this.connectionKey = t.connectionKey
                            }
                            clearConnection() {
                                this.realtime.connection.id = this.connectionId = void 0, this.realtime.connection.key = this.connectionKey = void 0, this.msgSerial = 0, this.unpersistConnection()
                            }
                            createRecoveryKey() {
                                return this.connectionKey ? JSON.stringify({
                                    connectionKey: this.connectionKey,
                                    msgSerial: this.msgSerial,
                                    channelSerials: this.realtime.channels.channelSerials()
                                }) : null
                            }
                            checkConnectionStateFreshness() {
                                if (!this.lastActivity || !this.connectionId) return;
                                const e = Date.now() - this.lastActivity;
                                e > this.connectionStateTtl + this.maxIdleInterval && (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.checkConnectionStateFreshness()", "Last known activity from realtime was " + e + "ms ago; discarding connection state"), this.clearConnection(), this.states.connecting.failState = "suspended")
                            }
                            persistConnection() {
                                if (ln()) {
                                    const e = this.createRecoveryKey();
                                    e && this.setSessionRecoverData({
                                        recoveryKey: e,
                                        disconnectedAt: Date.now(),
                                        location: an.location,
                                        clientId: this.realtime.auth.clientId
                                    })
                                }
                            }
                            unpersistConnection() {
                                this.clearSessionRecoverData()
                            }
                            getError() {
                                if (this.errorReason) {
                                    const e = S.fromValues(this.errorReason);
                                    return e.cause = this.errorReason, e
                                }
                                return this.getStateError()
                            }
                            getStateError() {
                                var e, t;
                                return null == (t = (e = nn)[this.state.state]) ? void 0 : t.call(e)
                            }
                            activeState() {
                                return this.state.queueEvents || this.state.sendEvents
                            }
                            enactStateChange(e) {
                                O.logAction(this.logger, "failed" === e.current ? O.LOG_ERROR : O.LOG_MAJOR, "Connection state", e.current + (e.reason ? "; reason: " + e.reason : "")), O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.enactStateChange", "setting new state: " + e.current + "; reason = " + (e.reason && e.reason.message));
                                const t = this.state = this.states[e.current];
                                e.reason && (this.errorReason = e.reason, this.realtime.connection.errorReason = e.reason), (t.terminal || "suspended" === t.state) && this.clearConnection(), this.emit("connectionstate", e)
                            }
                            startTransitionTimer(e) {
                                O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.startTransitionTimer()", "transitionState: " + e.state), this.transitionTimer && (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.startTransitionTimer()", "clearing already-running timer"), clearTimeout(this.transitionTimer)), this.transitionTimer = setTimeout(() => {
                                    this.transitionTimer && (this.transitionTimer = null, O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager " + e.state + " timer expired", "requesting new state: " + e.failState), this.notifyState({
                                        state: e.failState
                                    }))
                                }, e.retryDelay)
                            }
                            cancelTransitionTimer() {
                                O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.cancelTransitionTimer()", ""), this.transitionTimer && (clearTimeout(this.transitionTimer), this.transitionTimer = null)
                            }
                            startSuspendTimer() {
                                this.suspendTimer || (this.suspendTimer = setTimeout(() => {
                                    this.suspendTimer && (this.suspendTimer = null, O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager suspend timer expired", "requesting new state: suspended"), this.states.connecting.failState = "suspended", this.notifyState({
                                        state: "suspended"
                                    }))
                                }, this.connectionStateTtl))
                            }
                            checkSuspendTimer(e) {
                                "disconnected" !== e && "suspended" !== e && "connecting" !== e && this.cancelSuspendTimer()
                            }
                            cancelSuspendTimer() {
                                this.states.connecting.failState = "disconnected", this.suspendTimer && (clearTimeout(this.suspendTimer), this.suspendTimer = null)
                            }
                            startRetryTimer(e) {
                                this.retryTimer = setTimeout(() => {
                                    O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager retry timer expired", "retrying"), this.retryTimer = null, this.requestState({
                                        state: "connecting"
                                    })
                                }, e)
                            }
                            cancelRetryTimer() {
                                this.retryTimer && (clearTimeout(this.retryTimer), this.retryTimer = null)
                            }
                            startWebSocketSlowTimer() {
                                this.webSocketSlowTimer = setTimeout(() => {
                                    O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager WebSocket slow timer", "checking connectivity"), this.checkWsConnectivity().then(() => {
                                        O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager WebSocket slow timer", "ws connectivity check succeeded"), this.wsCheckResult = !0
                                    }).catch(() => {
                                        O.logAction(this.logger, O.LOG_MAJOR, "ConnectionManager WebSocket slow timer", "ws connectivity check failed"), this.wsCheckResult = !1
                                    }), this.realtime.http.checkConnectivity && ie(this.realtime.http.checkConnectivity(), (e, t) => {
                                        e || !t ? (O.logAction(this.logger, O.LOG_MAJOR, "ConnectionManager WebSocket slow timer", "http connectivity check failed"), this.cancelWebSocketGiveUpTimer(), this.notifyState({
                                            state: "disconnected",
                                            error: new k("Unable to connect (network unreachable)", 80003, 404)
                                        })) : O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager WebSocket slow timer", "http connectivity check succeeded")
                                    })
                                }, this.options.timeouts.webSocketSlowTimeout)
                            }
                            cancelWebSocketSlowTimer() {
                                this.webSocketSlowTimer && (clearTimeout(this.webSocketSlowTimer), this.webSocketSlowTimer = null)
                            }
                            startWebSocketGiveUpTimer(e) {
                                this.webSocketGiveUpTimer = setTimeout(() => {
                                    var t, n;
                                    this.wsCheckResult || (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager WebSocket give up timer", "websocket connection took more than 10s; " + (this.baseTransport ? "trying base transport" : "")), this.baseTransport ? (this.abandonedWebSocket = !0, null == (t = this.proposedTransport) || t.dispose(), null == (n = this.pendingTransport) || n.dispose(), this.connectBase(e, ++this.connectCounter)) : O.logAction(this.logger, O.LOG_MAJOR, "ConnectionManager WebSocket give up timer", "websocket connectivity appears to be unavailable but no other transports to try"))
                                }, this.options.timeouts.webSocketConnectTimeout)
                            }
                            cancelWebSocketGiveUpTimer() {
                                this.webSocketGiveUpTimer && (clearTimeout(this.webSocketGiveUpTimer), this.webSocketGiveUpTimer = null)
                            }
                            notifyState(e) {
                                var t, n;
                                const s = e.state,
                                    i = "disconnected" === s && (this.state === this.states.connected || e.retryImmediately || this.state === this.states.connecting && e.error && je.isTokenErr(e.error) && !(this.errorReason && je.isTokenErr(this.errorReason)));
                                if (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.notifyState()", "new state: " + s + (i ? "; will retry connection immediately" : "")), s == this.state.state) return;
                                if (this.cancelTransitionTimer(), this.cancelRetryTimer(), this.cancelWebSocketSlowTimer(), this.cancelWebSocketGiveUpTimer(), this.checkSuspendTimer(e.state), "suspended" !== s && "connected" !== s || (this.disconnectedRetryCount = 0), this.state.terminal) return;
                                const o = this.states[e.state];
                                let r = o.retryDelay;
                                "disconnected" === o.state && (this.disconnectedRetryCount++, r = ue(o.retryDelay, this.disconnectedRetryCount));
                                const a = new en(this.state.state, o.state, r, e.error || (null == (n = (t = nn)[o.state]) ? void 0 : n.call(t)));
                                if (i) {
                                    const e = () => {
                                            this.state === this.states.disconnected && (this.lastAutoReconnectAttempt = Date.now(), this.requestState({
                                                state: "connecting"
                                            }))
                                        },
                                        t = this.lastAutoReconnectAttempt && Date.now() - this.lastAutoReconnectAttempt + 1;
                                    t && t < 1e3 ? (O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.notifyState()", "Last reconnect attempt was only " + t + "ms ago, waiting another " + (1e3 - t) + "ms before trying again"), setTimeout(e, 1e3 - t)) : y.Config.nextTick(e)
                                } else "disconnected" !== s && "suspended" !== s || this.startRetryTimer(r);
                                ("disconnected" === s && !i || "suspended" === s || o.terminal) && y.Config.nextTick(() => {
                                    this.disconnectAllTransports()
                                }), "connected" != s || this.activeProtocol || O.logAction(this.logger, O.LOG_ERROR, "ConnectionManager.notifyState()", "Broken invariant: attempted to go into connected state, but there is no active protocol"), this.enactStateChange(a), this.state.sendEvents ? this.sendQueuedMessages() : this.state.queueEvents || (this.realtime.channels.propogateConnectionInterruption(s, a.reason), this.failQueuedMessages(a.reason))
                            }
                            requestState(e) {
                                var t, n;
                                const s = e.state;
                                if (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.requestState()", "requested state: " + s + "; current state: " + this.state.state), s == this.state.state) return;
                                if (this.cancelWebSocketSlowTimer(), this.cancelWebSocketGiveUpTimer(), this.cancelTransitionTimer(), this.cancelRetryTimer(), this.checkSuspendTimer(s), "connecting" == s && "connected" == this.state.state) return;
                                if ("closing" == s && "closed" == this.state.state) return;
                                const i = this.states[s],
                                    o = new en(this.state.state, i.state, null, e.error || (null == (n = (t = nn)[i.state]) ? void 0 : n.call(t)));
                                this.enactStateChange(o), "connecting" == s && y.Config.nextTick(() => {
                                    this.startConnect()
                                }), "closing" == s && this.closeImpl()
                            }
                            startConnect() {
                                if (this.state !== this.states.connecting) return void O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.startConnect()", "Must be in connecting state to connect, but was " + this.state.state);
                                const e = this.realtime.auth,
                                    t = ++this.connectCounter,
                                    n = () => {
                                        this.checkConnectionStateFreshness(), this.getTransportParams(e => {
                                            if ("recover" === e.mode && e.options.recover) {
                                                const t = dn(e.options.recover);
                                                t && this.realtime.channels.recoverChannels(t.channelSerials)
                                            }
                                            t === this.connectCounter && this.connectImpl(e, t)
                                        })
                                    };
                                if (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.startConnect()", "starting connection"), this.startSuspendTimer(), this.startTransitionTimer(this.states.connecting), "basic" === e.method) n();
                                else {
                                    const s = e => {
                                        t === this.connectCounter && (e ? this.actOnErrorFromAuthorize(e) : n())
                                    };
                                    this.errorReason && je.isTokenErr(this.errorReason) ? ie(e._forceNewToken(null, null), s) : ie(e._ensureValidAuthCredentials(!1), s)
                                }
                            }
                            connectImpl(e, t) {
                                const n = this.state.state;
                                if (n !== this.states.connecting.state) return void O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.connectImpl()", "Must be in connecting state to connect, but was " + n);
                                const s = this.getTransportPreference();
                                s && s === this.baseTransport && this.webSocketTransportAvailable && this.checkWsConnectivity().then(() => {
                                    this.unpersistTransportPreference(), this.state === this.states.connecting && (O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.connectImpl():", "web socket connectivity available, cancelling connection attempt with " + this.baseTransport), this.disconnectAllTransports(), this.connectWs(e, ++this.connectCounter))
                                }).catch(hn), s && s === this.baseTransport || this.baseTransport && !this.webSocketTransportAvailable ? this.connectBase(e, t) : this.connectWs(e, t)
                            }
                            connectWs(e, t) {
                                O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.connectWs()"), this.wsCheckResult = null, this.abandonedWebSocket = !1, this.startWebSocketSlowTimer(), this.startWebSocketGiveUpTimer(e), this.tryTransportWithFallbacks("web_socket", e, !0, t, () => !1 !== this.wsCheckResult && !this.abandonedWebSocket)
                            }
                            connectBase(e, t) {
                                O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.connectBase()"), this.baseTransport ? this.tryTransportWithFallbacks(this.baseTransport, e, !1, t, () => !0) : this.notifyState({
                                    state: "disconnected",
                                    error: new k("No transports left to try", 8e4, 404)
                                })
                            }
                            tryTransportWithFallbacks(e, t, n, s, i) {
                                O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.tryTransportWithFallbacks()", e);
                                const o = e => {
                                        this.notifyState({
                                            state: this.states.connecting.failState,
                                            error: e
                                        })
                                    },
                                    r = n ? this.wsHosts.slice() : this.httpHosts.slice(),
                                    a = (e, t) => {
                                        s === this.connectCounter && (i() ? t || e || l() : t && t.dispose())
                                    },
                                    c = r.shift();
                                if (!c) return void o(new k("Unable to connect (no available host)", 80003, 404));
                                t.host = c;
                                const l = () => {
                                    r.length ? this.realtime.http.checkConnectivity ? ie(this.realtime.http.checkConnectivity(), (n, c) => {
                                        s === this.connectCounter && i() && (n ? o(n) : c ? (t.host = J(r), this.tryATransport(t, e, a)) : o(new k("Unable to connect (network unreachable)", 80003, 404)))
                                    }) : o(new S("Internal error: Http.checkConnectivity not set", null, 500)) : o(new k("Unable to connect (and no more fallback hosts to try)", 80003, 404))
                                };
                                if (this.forceFallbackHost && r.length) return this.forceFallbackHost = !1, void l();
                                this.tryATransport(t, e, a)
                            }
                            closeImpl() {
                                O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.closeImpl()", "closing connection"), this.cancelSuspendTimer(), this.startTransitionTimer(this.states.closing), this.pendingTransport && (O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.closeImpl()", "Closing pending transport: " + this.pendingTransport), this.pendingTransport.close()), this.activeProtocol && (O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.closeImpl()", "Closing active transport: " + this.activeProtocol.getTransport()), this.activeProtocol.getTransport().close()), this.notifyState({
                                    state: "closed"
                                })
                            }
                            onAuthUpdated(e, t) {
                                var n;
                                switch (this.state.state) {
                                    case "connected":
                                        {
                                            O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.onAuthUpdated()", "Sending AUTH message on active transport");
                                            const s = null == (n = this.activeProtocol) ? void 0 : n.getTransport();s && s.onAuthUpdated && s.onAuthUpdated(e);
                                            const i = Vt({
                                                action: xt.AUTH,
                                                auth: {
                                                    accessToken: e.token
                                                }
                                            });this.send(i);
                                            const o = () => {
                                                    this.off(r), t(null, e)
                                                },
                                                r = e => {
                                                    "failed" === e.current && (this.off(o), this.off(r), t(e.reason || this.getStateError()))
                                                };this.once("connectiondetails", o),
                                            this.on("connectionstate", r);
                                            break
                                        }
                                    case "connecting":
                                        O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.onAuthUpdated()", "Aborting current connection attempts in order to start again with the new auth details"), this.disconnectAllTransports();
                                    default:
                                        {
                                            O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.onAuthUpdated()", "Connection state is " + this.state.state + "; waiting until either connected or failed");
                                            const n = s => {
                                                switch (s.current) {
                                                    case "connected":
                                                        this.off(n), t(null, e);
                                                        break;
                                                    case "failed":
                                                    case "closed":
                                                    case "suspended":
                                                        this.off(n), t(s.reason || this.getStateError())
                                                }
                                            };this.on("connectionstate", n),
                                            "connecting" === this.state.state ? this.startConnect() : this.requestState({
                                                state: "connecting"
                                            })
                                        }
                                }
                            }
                            disconnectAllTransports() {
                                O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.disconnectAllTransports()", "Disconnecting all transports"), this.connectCounter++, this.pendingTransport && (O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.disconnectAllTransports()", "Disconnecting pending transport: " + this.pendingTransport), this.pendingTransport.disconnect()), delete this.pendingTransport, this.proposedTransport && (O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.disconnectAllTransports()", "Disconnecting proposed transport: " + this.pendingTransport), this.proposedTransport.disconnect()), delete this.pendingTransport, this.activeProtocol && (O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.disconnectAllTransports()", "Disconnecting active transport: " + this.activeProtocol.getTransport()), this.activeProtocol.getTransport().disconnect())
                            }
                            send(e, t, n) {
                                n = n || hn;
                                const s = this.state;
                                if (s.sendEvents) return O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.send()", "sending event"), void this.sendImpl(new Xt(e, n));
                                if (!t || !s.queueEvents) {
                                    const e = "rejecting event, queueEvent was " + t + ", state was " + s.state;
                                    return O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.send()", e), void n(this.errorReason || new k(e, 9e4, 400))
                                }
                                this.logger.shouldLog(O.LOG_MICRO) && O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.send()", "queueing msg; " + Kt(e, this.realtime._RealtimePresence)), this.queue(e, n)
                            }
                            sendImpl(e) {
                                e.ackRequired && !e.sendAttempted && (e.message.msgSerial = this.msgSerial++);
                                try {
                                    this.activeProtocol.send(e)
                                } catch (e) {
                                    O.logAction(this.logger, O.LOG_ERROR, "ConnectionManager.sendImpl()", "Unexpected exception in transport.send(): " + e.stack)
                                }
                            }
                            queue(e, t) {
                                O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.queue()", "queueing event");
                                const n = this.queuedMessages.last();
                                n && !n.sendAttempted && function(e, t, n) {
                                    let s;
                                    if (e.channel !== t.channel) return !1;
                                    if ((s = e.action) !== xt.PRESENCE && s !== xt.MESSAGE) return !1;
                                    if (s !== t.action) return !1;
                                    const i = s === xt.PRESENCE ? "presence" : "messages",
                                        o = e[i].concat(t[i]);
                                    return !(ut(o) > n || !K(o, "clientId") || !o.every(function(e) {
                                        return !e.id
                                    }) || (e[i] = o, 0))
                                }(n.message, e, this.options.maxMessageSize) ? (n.merged || (n.callback = Pe.create(this.logger, [n.callback]), n.merged = !0), n.callback.push(t)) : this.queuedMessages.push(new Xt(e, t))
                            }
                            sendQueuedMessages() {
                                let e;
                                for (O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.sendQueuedMessages()", "sending " + this.queuedMessages.count() + " queued messages"); e = this.queuedMessages.shift();) this.sendImpl(e)
                            }
                            queuePendingMessages(e) {
                                e && e.length && (O.logAction(this.logger, O.LOG_MICRO, "ConnectionManager.queuePendingMessages()", "queueing " + e.length + " pending messages"), this.queuedMessages.prepend(e))
                            }
                            failQueuedMessages(e) {
                                const t = this.queuedMessages.count();
                                t > 0 && (O.logAction(this.logger, O.LOG_ERROR, "ConnectionManager.failQueuedMessages()", "failing " + t + " queued messages, err = " + X(e)), this.queuedMessages.completeAllMessages(e))
                            }
                            onChannelMessage(e, t) {
                                this.pendingChannelMessagesState.queue.push({
                                    message: e,
                                    transport: t
                                }), this.pendingChannelMessagesState.isProcessing || this.processNextPendingChannelMessage()
                            }
                            processNextPendingChannelMessage() {
                                if (this.pendingChannelMessagesState.queue.length > 0) {
                                    this.pendingChannelMessagesState.isProcessing = !0;
                                    const e = this.pendingChannelMessagesState.queue.shift();
                                    this.processChannelMessage(e.message).catch(e => {
                                        O.logAction(this.logger, O.LOG_ERROR, "ConnectionManager.processNextPendingChannelMessage() received error ", e)
                                    }).finally(() => {
                                        this.pendingChannelMessagesState.isProcessing = !1, this.processNextPendingChannelMessage()
                                    })
                                }
                            }
                            async processChannelMessage(e) {
                                await this.realtime.channels.processChannelMessage(e)
                            }
                            async ping() {
                                var e;
                                if ("connected" !== this.state.state) throw new k("Unable to ping service; not connected", 4e4, 400);
                                const t = null == (e = this.activeProtocol) ? void 0 : e.getTransport();
                                if (!t) throw this.getStateError();
                                O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.ping()", "transport = " + t);
                                const n = Date.now(),
                                    s = te();
                                return we(new Promise(e => {
                                    const i = o => {
                                        o === s && (t.off("heartbeat", i), e(Date.now() - n))
                                    };
                                    t.on("heartbeat", i), t.ping(s)
                                }), this.options.timeouts.realtimeRequestTimeout, "Timeout waiting for heartbeat response")
                            }
                            abort(e) {
                                this.activeProtocol.getTransport().fail(e)
                            }
                            getTransportPreference() {
                                var e, t;
                                return this.transportPreference || cn() && (null == (t = null == (e = y.WebStorage) ? void 0 : e.get) ? void 0 : t.call(e, un))
                            }
                            persistTransportPreference(e) {
                                var t, n;
                                this.transportPreference = e.shortName, cn() && (null == (n = null == (t = y.WebStorage) ? void 0 : t.set) || n.call(t, un, e.shortName))
                            }
                            unpersistTransportPreference() {
                                var e, t;
                                this.transportPreference = null, cn() && (null == (t = null == (e = y.WebStorage) ? void 0 : e.remove) || t.call(e, un))
                            }
                            actOnErrorFromAuthorize(e) {
                                if (40171 === e.code) this.notifyState({
                                    state: "failed",
                                    error: e
                                });
                                else if (40102 === e.code) this.notifyState({
                                    state: "failed",
                                    error: e
                                });
                                else if (e.statusCode === Ne.Forbidden) {
                                    const t = "Client configured authentication provider returned 403; failing the connection";
                                    O.logAction(this.logger, O.LOG_ERROR, "ConnectionManager.actOnErrorFromAuthorize()", t), this.notifyState({
                                        state: "failed",
                                        error: new k(t, 80019, 403, e)
                                    })
                                } else {
                                    const t = "Client configured authentication provider request failed";
                                    O.logAction(this.logger, O.LOG_MINOR, "ConnectionManager.actOnErrorFromAuthorize", t), this.notifyState({
                                        state: this.state.failState,
                                        error: new k(t, 80019, 401, e)
                                    })
                                }
                            }
                            onConnectionDetailsUpdate(e, t) {
                                if (!e) return;
                                this.connectionDetails = e, e.maxMessageSize && (this.options.maxMessageSize = e.maxMessageSize);
                                const n = e.clientId;
                                if (n) {
                                    const e = this.realtime.auth._uncheckedSetClientId(n);
                                    if (e) return O.logAction(this.logger, O.LOG_ERROR, "ConnectionManager.onConnectionDetailsUpdate()", e.message), void t.fail(e)
                                }
                                const s = e.connectionStateTtl;
                                s && (this.connectionStateTtl = s), this.maxIdleInterval = e.maxIdleInterval, this.emit("connectiondetails", e)
                            }
                            checkWsConnectivity() {
                                const e = new y.Config.WebSocket(this.options.wsConnectivityCheckUrl || Ee.wsConnectivityCheckUrl);
                                return new Promise((t, n) => {
                                    let s = !1;
                                    e.onopen = () => {
                                        s || (s = !0, t(), e.close())
                                    }, e.onclose = e.onerror = () => {
                                        s || (s = !0, n())
                                    }
                                })
                            }
                            sessionRecoveryName() {
                                return this.options.recoveryKeyStorageName || "ably-connection-recovery"
                            }
                            getSessionRecoverData() {
                                var e, t;
                                return ln() && (null == (t = null == (e = y.WebStorage) ? void 0 : e.getSession) ? void 0 : t.call(e, this.sessionRecoveryName()))
                            }
                            setSessionRecoverData(e) {
                                var t, n;
                                return ln() && (null == (n = null == (t = y.WebStorage) ? void 0 : t.setSession) ? void 0 : n.call(t, this.sessionRecoveryName(), e))
                            }
                            clearSessionRecoverData() {
                                var e, t;
                                return ln() && (null == (t = null == (e = y.WebStorage) ? void 0 : e.removeSession) ? void 0 : t.call(e, this.sessionRecoveryName()))
                            }
                        },
                        pn = class extends Nt {
                            constructor(e, t) {
                                super(e.logger), this.whenState = e => Nt.prototype.whenState.call(this, e, this.state), this.ably = e, this.connectionManager = new gn(e, t), this.state = this.connectionManager.state.state, this.key = void 0, this.id = void 0, this.errorReason = null, this.connectionManager.on("connectionstate", e => {
                                    const t = this.state = e.current;
                                    y.Config.nextTick(() => {
                                        this.emit(t, e)
                                    })
                                }), this.connectionManager.on("update", e => {
                                    y.Config.nextTick(() => {
                                        this.emit("update", e)
                                    })
                                })
                            }
                            connect() {
                                O.logAction(this.logger, O.LOG_MINOR, "Connection.connect()", ""), this.connectionManager.requestState({
                                    state: "connecting"
                                })
                            }
                            async ping() {
                                return O.logAction(this.logger, O.LOG_MINOR, "Connection.ping()", ""), this.connectionManager.ping()
                            }
                            close() {
                                O.logAction(this.logger, O.LOG_MINOR, "Connection.close()", "connectionKey = " + this.key), this.connectionManager.requestState({
                                    state: "closing"
                                })
                            }
                            get recoveryKey() {
                                return this.logger.deprecationWarning("The `Connection.recoveryKey` attribute has been replaced by the `Connection.createRecoveryKey()` method. Replace your usage of `recoveryKey` with the return value of `createRecoveryKey()`. `recoveryKey` will be removed in a future version."), this.createRecoveryKey()
                            }
                            createRecoveryKey() {
                                return this.connectionManager.createRecoveryKey()
                            }
                        },
                        fn = class {
                            constructor(e, t, n, s, i) {
                                this.previous = e, this.current = t, "attached" === t && (this.resumed = n, this.hasBacklog = s), i && (this.reason = i)
                            }
                        },
                        mn = function() {};

                    function yn(e) {
                        return ((e, t) => {
                            var n = {};
                            for (var s in e) h.call(e, s) && t.indexOf(s) < 0 && (n[s] = e[s]);
                            if (null != e && l)
                                for (var s of l(e)) t.indexOf(s) < 0 && u.call(e, s) && (n[s] = e[s]);
                            return n
                        })(e || {}, ["agent"])
                    }
                    var vn = class e extends Nt {
                            constructor(e, t, n) {
                                var s, i;
                                super(e.logger), this.retryCount = 0, this.history = async function(e) {
                                    O.logAction(this.logger, O.LOG_MICRO, "RealtimeChannel.history()", "channel = " + this.name);
                                    const t = this.client.rest.channelMixin;
                                    if (e && e.untilAttach) {
                                        if ("attached" !== this.state) throw new k("option untilAttach requires the channel to be attached", 4e4, 400);
                                        if (!this.properties.attachSerial) throw new k("untilAttach was specified and channel is attached, but attachSerial is not defined", 4e4, 400);
                                        delete e.untilAttach, e.from_serial = this.properties.attachSerial
                                    }
                                    return t.history(this, e)
                                }, this.whenState = e => Nt.prototype.whenState.call(this, e, this.state), O.logAction(this.logger, O.LOG_MINOR, "RealtimeChannel()", "started; name = " + t), this.name = t, this.channelOptions = Se(null != (s = e._Crypto) ? s : null, this.logger, n), this.client = e, this._presence = e._RealtimePresence ? new e._RealtimePresence.RealtimePresence(this) : null, this.connectionManager = e.connection.connectionManager, this.state = "initialized", this.subscriptions = new Nt(this.logger), this.syncChannelSerial = void 0, this.properties = {
                                    attachSerial: void 0,
                                    channelSerial: void 0
                                }, this.setOptions(n), this.errorReason = null, this._requestedFlags = null, this._mode = null, this._attachResume = !1, this._decodingContext = {
                                    channelOptions: this.channelOptions,
                                    plugins: e.options.plugins || {},
                                    baseEncodedPreviousPayload: void 0
                                }, this._lastPayload = {
                                    messageId: null,
                                    protocolMessageChannelSerial: null,
                                    decodeFailureRecoveryInProgress: null
                                }, this._allChannelChanges = new Nt(this.logger), (null == (i = e.options.plugins) ? void 0 : i.Push) && (this._push = new e.options.plugins.Push.PushChannel(this))
                            }
                            get presence() {
                                return this._presence || ve("RealtimePresence"), this._presence
                            }
                            get push() {
                                return this._push || ve("Push"), this._push
                            }
                            invalidStateError() {
                                return new k("Channel operation failed as channel state is " + this.state, 90001, 400, this.errorReason || void 0)
                            }
                            static processListenerArgs(e) {
                                return "function" == typeof(e = Array.prototype.slice.call(e))[0] && e.unshift(null), e
                            }
                            async setOptions(e) {
                                var t;
                                const n = this.channelOptions,
                                    s = function(e) {
                                        if (e && "params" in e && !E(e.params)) return new k("options.params must be an object", 4e4, 400);
                                        if (e && "modes" in e) {
                                            if (!Array.isArray(e.modes)) return new k("options.modes must be an array", 4e4, 400);
                                            for (let t = 0; t < e.modes.length; t++) {
                                                const n = e.modes[t];
                                                if (!n || "string" != typeof n || !Ht.includes(String.prototype.toUpperCase.call(n))) return new k("Invalid channel mode: " + n, 4e4, 400)
                                            }
                                        }
                                    }(e);
                                if (s) throw s;
                                if (this.channelOptions = Se(null != (t = this.client._Crypto) ? t : null, this.logger, e), this._decodingContext && (this._decodingContext.channelOptions = this.channelOptions), this._shouldReattachToSetOptions(e, n)) return this.attachImpl(), new Promise((e, t) => {
                                    this._allChannelChanges.once(["attached", "update", "detached", "failed"], function(n) {
                                        switch (this.event) {
                                            case "update":
                                            case "attached":
                                                e();
                                                break;
                                            default:
                                                t(n.reason)
                                        }
                                    })
                                })
                            }
                            _shouldReattachToSetOptions(e, t) {
                                if ("attached" !== this.state && "attaching" !== this.state) return !1;
                                if (null == e ? void 0 : e.params) {
                                    const n = yn(e.params),
                                        s = yn(t.params);
                                    if (Object.keys(n).length !== Object.keys(s).length) return !0;
                                    if (!ge(s, n)) return !0
                                }
                                return !(!(null == e ? void 0 : e.modes) || t.modes && me(e.modes, t.modes))
                            }
                            async publish(...e) {
                                let t = e[0],
                                    n = e.length;
                                if (!this.connectionManager.activeState()) throw this.connectionManager.getError();
                                if (1 == n)
                                    if (E(t)) t = [lt(t)];
                                    else {
                                        if (!Array.isArray(t)) throw new k("The single-argument form of publish() expects a message object or an array of message objects", 40013, 400);
                                        t = ht(t)
                                    }
                                else t = [lt({
                                    name: e[0],
                                    data: e[1]
                                })];
                                const s = this.client.options.maxMessageSize;
                                await rt(t, this.channelOptions);
                                const i = ut(t);
                                if (i > s) throw new k("Maximum size of messages that can be published at once exceeded ( was " + i + " bytes; limit is " + s + " bytes)", 40009, 400);
                                return new Promise((e, n) => {
                                    this._publish(t, t => t ? n(t) : e())
                                })
                            }
                            _publish(e, t) {
                                O.logAction(this.logger, O.LOG_MICRO, "RealtimeChannel.publish()", "message count = " + e.length);
                                const n = this.state;
                                switch (n) {
                                    case "failed":
                                    case "suspended":
                                        t(k.fromValues(this.invalidStateError()));
                                        break;
                                    default:
                                        {
                                            O.logAction(this.logger, O.LOG_MICRO, "RealtimeChannel.publish()", "sending message; channel state is " + n);
                                            const s = new Qt;s.action = xt.MESSAGE,
                                            s.channel = this.name,
                                            s.messages = e,
                                            this.sendMessage(s, t);
                                            break
                                        }
                                }
                            }
                            onEvent(e) {
                                O.logAction(this.logger, O.LOG_MICRO, "RealtimeChannel.onEvent()", "received message");
                                const t = this.subscriptions;
                                for (let n = 0; n < e.length; n++) {
                                    const s = e[n];
                                    t.emit(s.name, s)
                                }
                            }
                            async attach() {
                                return "attached" === this.state ? null : new Promise((e, t) => {
                                    this._attach(!1, null, (n, s) => n ? t(n) : e(s))
                                })
                            }
                            _attach(e, t, n) {
                                n || (n = e => {
                                    e && O.logAction(this.logger, O.LOG_ERROR, "RealtimeChannel._attach()", "Channel attach failed: " + e.toString())
                                });
                                const s = this.connectionManager;
                                s.activeState() ? (("attaching" !== this.state || e) && this.requestState("attaching", t), this.once(function(e) {
                                    switch (this.event) {
                                        case "attached":
                                            null == n || n(null, e);
                                            break;
                                        case "detached":
                                        case "suspended":
                                        case "failed":
                                            null == n || n(e.reason || s.getError() || new k("Unable to attach; reason unknown; state = " + this.event, 9e4, 500));
                                            break;
                                        case "detaching":
                                            null == n || n(new k("Attach request superseded by a subsequent detach request", 9e4, 409))
                                    }
                                })) : n(s.getError())
                            }
                            attachImpl() {
                                O.logAction(this.logger, O.LOG_MICRO, "RealtimeChannel.attachImpl()", "sending ATTACH message");
                                const e = Vt({
                                    action: xt.ATTACH,
                                    channel: this.name,
                                    params: this.channelOptions.params,
                                    channelSerial: this.properties.channelSerial
                                });
                                this._requestedFlags ? e.encodeModesToFlags(this._requestedFlags) : this.channelOptions.modes && e.encodeModesToFlags(ce(this.channelOptions.modes)), this._attachResume && e.setFlag("ATTACH_RESUME"), this._lastPayload.decodeFailureRecoveryInProgress && (e.channelSerial = this._lastPayload.protocolMessageChannelSerial), this.sendMessage(e, mn)
                            }
                            async detach() {
                                const e = this.connectionManager;
                                if (!e.activeState()) throw e.getError();
                                switch (this.state) {
                                    case "suspended":
                                        return void this.notifyState("detached");
                                    case "detached":
                                        return;
                                    case "failed":
                                        throw new k("Unable to detach; channel state = failed", 90001, 400);
                                    default:
                                        this.requestState("detaching");
                                    case "detaching":
                                        return new Promise((t, n) => {
                                            this.once(function(s) {
                                                switch (this.event) {
                                                    case "detached":
                                                        t();
                                                        break;
                                                    case "attached":
                                                    case "suspended":
                                                    case "failed":
                                                        n(s.reason || e.getError() || new k("Unable to detach; reason unknown; state = " + this.event, 9e4, 500));
                                                        break;
                                                    case "attaching":
                                                        n(new k("Detach request superseded by a subsequent attach request", 9e4, 409))
                                                }
                                            })
                                        })
                                }
                            }
                            detachImpl(e) {
                                O.logAction(this.logger, O.LOG_MICRO, "RealtimeChannel.detach()", "sending DETACH message");
                                const t = Vt({
                                    action: xt.DETACH,
                                    channel: this.name
                                });
                                this.sendMessage(t, e || mn)
                            }
                            async subscribe(...t) {
                                const [n, s] = e.processListenerArgs(t);
                                if ("failed" === this.state) throw k.fromValues(this.invalidStateError());
                                return n && "object" == typeof n && !Array.isArray(n) ? this.client._FilteredSubscriptions.subscribeFilter(this, n, s) : this.subscriptions.on(n, s), this.attach()
                            }
                            unsubscribe(...t) {
                                var n;
                                const [s, i] = e.processListenerArgs(t);
                                "object" == typeof s && !i || (null == (n = this.filteredSubscriptions) ? void 0 : n.has(i)) ? this.client._FilteredSubscriptions.getAndDeleteFilteredSubscriptions(this, s, i).forEach(e => this.subscriptions.off(e)) : this.subscriptions.off(s, i)
                            }
                            sync() {
                                switch (this.state) {
                                    case "initialized":
                                    case "detaching":
                                    case "detached":
                                        throw new S("Unable to sync to channel; not attached", 4e4)
                                }
                                const e = this.connectionManager;
                                if (!e.activeState()) throw e.getError();
                                const t = Vt({
                                    action: xt.SYNC,
                                    channel: this.name
                                });
                                this.syncChannelSerial && (t.channelSerial = this.syncChannelSerial), e.send(t)
                            }
                            sendMessage(e, t) {
                                this.connectionManager.send(e, this.client.options.queueMessages, t)
                            }
                            sendPresence(e, t) {
                                const n = Vt({
                                    action: xt.PRESENCE,
                                    channel: this.name,
                                    presence: Array.isArray(e) ? this.client._RealtimePresence.presenceMessagesFromValuesArray(e) : [this.client._RealtimePresence.presenceMessageFromValues(e)]
                                });
                                this.sendMessage(n, t)
                            }
                            async processMessage(e) {
                                e.action !== xt.ATTACHED && e.action !== xt.MESSAGE && e.action !== xt.PRESENCE || this.setChannelSerial(e.channelSerial);
                                let t, n = !1;
                                switch (e.action) {
                                    case xt.ATTACHED:
                                        {
                                            this.properties.attachSerial = e.channelSerial,
                                            this._mode = e.getMode(),
                                            this.params = e.params || {};
                                            const t = e.decodeModesFromFlags();this.modes = t && ae(t) || void 0;
                                            const n = e.hasFlag("RESUMED"),
                                                s = e.hasFlag("HAS_PRESENCE"),
                                                i = e.hasFlag("HAS_BACKLOG");
                                            if ("attached" === this.state) {
                                                n || this._presence && this._presence.onAttached(s);
                                                const t = new fn(this.state, this.state, n, i, e.error);
                                                this._allChannelChanges.emit("update", t), n && !this.channelOptions.updateOnAttached || this.emit("update", t)
                                            } else "detaching" === this.state ? this.checkPendingState() : this.notifyState("attached", e.error, n, s, i);
                                            break
                                        }
                                    case xt.DETACHED:
                                        {
                                            const t = e.error ? k.fromValues(e.error) : new k("Channel detached", 90001, 404);
                                            "detaching" === this.state ? this.notifyState("detached", t) : "attaching" === this.state ? this.notifyState("suspended", t) : "attached" !== this.state && "suspended" !== this.state || this.requestState("attaching", t);
                                            break
                                        }
                                    case xt.SYNC:
                                        if (n = !0, t = this.syncChannelSerial = e.channelSerial, !e.presence) break;
                                    case xt.PRESENCE:
                                        {
                                            const s = e.presence;
                                            if (!s) break;
                                            const {
                                                id: i,
                                                connectionId: o,
                                                timestamp: r
                                            } = e,
                                            a = this.channelOptions;
                                            let c;
                                            for (let e = 0; e < s.length; e++) try {
                                                c = s[e], await yt(c, a), c.connectionId || (c.connectionId = o), c.timestamp || (c.timestamp = r), c.id || (c.id = i + ":" + e)
                                            } catch (e) {
                                                O.logAction(this.logger, O.LOG_ERROR, "RealtimeChannel.processMessage()", e.toString())
                                            }
                                            this._presence && this._presence.setPresence(s, n, t);
                                            break
                                        }
                                    case xt.MESSAGE:
                                        {
                                            if ("attached" !== this.state) return void O.logAction(this.logger, O.LOG_MAJOR, "RealtimeChannel.processMessage()", 'Message "' + e.id + '" skipped as this channel "' + this.name + '" state is not "attached" (state is "' + this.state + '").');
                                            const t = e.messages,
                                                n = t[0],
                                                s = t[t.length - 1],
                                                i = e.id,
                                                o = e.connectionId,
                                                r = e.timestamp;
                                            if (n.extras && n.extras.delta && n.extras.delta.from !== this._lastPayload.messageId) {
                                                const t = 'Delta message decode failure - previous message not available for message "' + e.id + '" on this channel "' + this.name + '".';
                                                O.logAction(this.logger, O.LOG_ERROR, "RealtimeChannel.processMessage()", t), this._startDecodeFailureRecovery(new k(t, 40018, 400));
                                                break
                                            }
                                            for (let e = 0; e < t.length; e++) {
                                                const n = t[e];
                                                try {
                                                    await ct(n, this._decodingContext)
                                                } catch (e) {
                                                    switch (O.logAction(this.logger, O.LOG_ERROR, "RealtimeChannel.processMessage()", e.toString()), e.code) {
                                                        case 40018:
                                                            return void this._startDecodeFailureRecovery(e);
                                                        case 40019:
                                                        case 40021:
                                                            return void this.notifyState("failed", e)
                                                    }
                                                }
                                                n.connectionId || (n.connectionId = o), n.timestamp || (n.timestamp = r), n.id || (n.id = i + ":" + e)
                                            }
                                            this._lastPayload.messageId = s.id,
                                            this._lastPayload.protocolMessageChannelSerial = e.channelSerial,
                                            this.onEvent(t);
                                            break
                                        }
                                    case xt.ERROR:
                                        {
                                            const t = e.error;t && 80016 == t.code ? this.checkPendingState() : this.notifyState("failed", k.fromValues(t));
                                            break
                                        }
                                    default:
                                        O.logAction(this.logger, O.LOG_ERROR, "RealtimeChannel.processMessage()", "Fatal protocol error: unrecognised action (" + e.action + ")"), this.connectionManager.abort(nn.unknownChannelErr())
                                }
                            }
                            _startDecodeFailureRecovery(e) {
                                this._lastPayload.decodeFailureRecoveryInProgress || (O.logAction(this.logger, O.LOG_MAJOR, "RealtimeChannel.processMessage()", "Starting decode failure recovery process."), this._lastPayload.decodeFailureRecoveryInProgress = !0, this._attach(!0, e, () => {
                                    this._lastPayload.decodeFailureRecoveryInProgress = !1
                                }))
                            }
                            onAttached() {
                                O.logAction(this.logger, O.LOG_MINOR, "RealtimeChannel.onAttached", "activating channel; name = " + this.name)
                            }
                            notifyState(e, t, n, s, i) {
                                if (O.logAction(this.logger, O.LOG_MICRO, "RealtimeChannel.notifyState", "name = " + this.name + ", current state = " + this.state + ", notifying state " + e), this.clearStateTimer(), ["detached", "suspended", "failed"].includes(e) && (this.properties.channelSerial = null), e === this.state) return;
                                this._presence && this._presence.actOnChannelState(e, s, t), "suspended" === e && this.connectionManager.state.sendEvents ? this.startRetryTimer() : this.cancelRetryTimer(), t && (this.errorReason = t);
                                const o = new fn(this.state, e, n, i, t);
                                O.logAction(this.logger, "failed" === e ? O.LOG_ERROR : O.LOG_MAJOR, 'Channel state for channel "' + this.name + '"', e + (t ? "; reason: " + t : "")), "attaching" !== e && "suspended" !== e && (this.retryCount = 0), "attached" === e && this.onAttached(), "attached" === e ? this._attachResume = !0 : "detaching" !== e && "failed" !== e || (this._attachResume = !1), this.state = e, this._allChannelChanges.emit(e, o), this.emit(e, o)
                            }
                            requestState(e, t) {
                                O.logAction(this.logger, O.LOG_MINOR, "RealtimeChannel.requestState", "name = " + this.name + ", state = " + e), this.notifyState(e, t), this.checkPendingState()
                            }
                            checkPendingState() {
                                if (this.connectionManager.state.sendEvents) switch (O.logAction(this.logger, O.LOG_MINOR, "RealtimeChannel.checkPendingState", "name = " + this.name + ", state = " + this.state), this.state) {
                                    case "attaching":
                                        this.startStateTimerIfNotRunning(), this.attachImpl();
                                        break;
                                    case "detaching":
                                        this.startStateTimerIfNotRunning(), this.detachImpl();
                                        break;
                                    case "attached":
                                        this.sync()
                                } else O.logAction(this.logger, O.LOG_MINOR, "RealtimeChannel.checkPendingState", "sendEvents is false; state is " + this.connectionManager.state.state)
                            }
                            timeoutPendingState() {
                                switch (this.state) {
                                    case "attaching":
                                        {
                                            const e = new k("Channel attach timed out", 90007, 408);this.notifyState("suspended", e);
                                            break
                                        }
                                    case "detaching":
                                        {
                                            const e = new k("Channel detach timed out", 90007, 408);this.notifyState("attached", e);
                                            break
                                        }
                                    default:
                                        this.checkPendingState()
                                }
                            }
                            startStateTimerIfNotRunning() {
                                this.stateTimer || (this.stateTimer = setTimeout(() => {
                                    O.logAction(this.logger, O.LOG_MINOR, "RealtimeChannel.startStateTimerIfNotRunning", "timer expired"), this.stateTimer = null, this.timeoutPendingState()
                                }, this.client.options.timeouts.realtimeRequestTimeout))
                            }
                            clearStateTimer() {
                                const e = this.stateTimer;
                                e && (clearTimeout(e), this.stateTimer = null)
                            }
                            startRetryTimer() {
                                if (this.retryTimer) return;
                                this.retryCount++;
                                const e = ue(this.client.options.timeouts.channelRetryTimeout, this.retryCount);
                                this.retryTimer = setTimeout(() => {
                                    "suspended" === this.state && this.connectionManager.state.sendEvents && (this.retryTimer = null, O.logAction(this.logger, O.LOG_MINOR, "RealtimeChannel retry timer expired", "attempting a new attach"), this.requestState("attaching"))
                                }, e)
                            }
                            cancelRetryTimer() {
                                this.retryTimer && (clearTimeout(this.retryTimer), this.retryTimer = null)
                            }
                            getReleaseErr() {
                                const e = this.state;
                                return "initialized" === e || "detached" === e || "failed" === e ? null : new k("Can only release a channel in a state where there is no possibility of further updates from the server being received (initialized, detached, or failed); was " + e, 90001, 400)
                            }
                            setChannelSerial(e) {
                                O.logAction(this.logger, O.LOG_MICRO, "RealtimeChannel.setChannelSerial()", "Updating channel serial; serial = " + e + "; previous = " + this.properties.channelSerial), e && (this.properties.channelSerial = e)
                            }
                            async status() {
                                return this.client.rest.channelMixin.status(this)
                            }
                        },
                        wn = class e extends ze {
                            constructor(t) {
                                var n, s;
                                if (super(Ee.objectifyOptions(t, !1, "BaseRealtime", O.defaultLogger)), O.logAction(this.logger, O.LOG_MINOR, "Realtime()", ""), "string" == typeof EdgeRuntime) throw new k('Ably.Realtime instance cannot be used in Vercel Edge runtime. If you are running Vercel Edge functions, please replace your "new Ably.Realtime()" with "new Ably.Rest()" and use Ably Rest API instead of the Realtime API. If you are server-rendering your application in the Vercel Edge runtime, please use the condition "if (typeof EdgeRuntime === \'string\')" to prevent instantiating Ably.Realtime instance during SSR in the Vercel Edge runtime.', 4e4, 400);
                                this._additionalTransportImplementations = e.transportImplementationsFromPlugins(this.options.plugins), this._RealtimePresence = null != (s = null == (n = this.options.plugins) ? void 0 : n.RealtimePresence) ? s : null, this.connection = new pn(this, this.options), this._channels = new Cn(this), !1 !== this.options.autoConnect && this.connect()
                            }
                            static transportImplementationsFromPlugins(e) {
                                const t = {};
                                return (null == e ? void 0 : e.WebSocketTransport) && (t[zt.WebSocket] = e.WebSocketTransport), (null == e ? void 0 : e.XHRPolling) && (t[zt.XhrPolling] = e.XHRPolling), t
                            }
                            get channels() {
                                return this._channels
                            }
                            connect() {
                                O.logAction(this.logger, O.LOG_MINOR, "Realtime.connect()", ""), this.connection.connect()
                            }
                            close() {
                                O.logAction(this.logger, O.LOG_MINOR, "Realtime.close()", ""), this.connection.close()
                            }
                        };
                    wn.EventEmitter = Nt;
                    var bn = wn,
                        Cn = class extends Nt {
                            constructor(e) {
                                super(e.logger), this.realtime = e, this.all = /* @__PURE__ */ Object.create(null), e.connection.connectionManager.on("transport.active", () => {
                                    this.onTransportActive()
                                })
                            }
                            channelSerials() {
                                let e = {};
                                for (const t of W(this.all, !0)) {
                                    const n = this.all[t];
                                    n.properties.channelSerial && (e[t] = n.properties.channelSerial)
                                }
                                return e
                            }
                            recoverChannels(e) {
                                for (const t of W(e, !0)) this.get(t).properties.channelSerial = e[t]
                            }
                            async processChannelMessage(e) {
                                const t = e.channel;
                                if (void 0 === t) return void O.logAction(this.logger, O.LOG_ERROR, "Channels.processChannelMessage()", "received event unspecified channel, action = " + e.action);
                                const n = this.all[t];
                                n ? await n.processMessage(e) : O.logAction(this.logger, O.LOG_ERROR, "Channels.processChannelMessage()", "received event for non-existent channel: " + t)
                            }
                            onTransportActive() {
                                for (const e in this.all) {
                                    const t = this.all[e];
                                    "attaching" === t.state || "detaching" === t.state ? t.checkPendingState() : "suspended" === t.state ? t._attach(!1, null) : "attached" === t.state && t.requestState("attaching")
                                }
                            }
                            propogateConnectionInterruption(e, t) {
                                const n = ["attaching", "attached", "detaching", "suspended"],
                                    s = {
                                        closing: "detached",
                                        closed: "detached",
                                        failed: "failed",
                                        suspended: "suspended"
                                    }[e];
                                for (const e in this.all) {
                                    const i = this.all[e];
                                    n.includes(i.state) && i.notifyState(s, t)
                                }
                            }
                            get(e, t) {
                                e = String(e);
                                let n = this.all[e];
                                if (n) {
                                    if (t) {
                                        if (n._shouldReattachToSetOptions(t, n.channelOptions)) throw new k("Channels.get() cannot be used to set channel options that would cause the channel to reattach. Please, use RealtimeChannel.setOptions() instead.", 4e4, 400);
                                        n.setOptions(t)
                                    }
                                } else n = this.all[e] = new vn(this.realtime, e, t);
                                return n
                            }
                            getDerived(e, t, n) {
                                if (t.filter) {
                                    const n = fe(t.filter),
                                        s = pe(e);
                                    e = `[filter=${n}${s.qualifierParam}]${s.channelName}`
                                }
                                return this.get(e, n)
                            }
                            release(e) {
                                e = String(e);
                                const t = this.all[e];
                                if (!t) return;
                                const n = t.getReleaseErr();
                                if (n) throw n;
                                delete this.all[e]
                            }
                        },
                        On = bn;

                    function Rn(e) {
                        const t = e.channel.client,
                            n = t.auth.clientId;
                        return (!n || "*" === n) && "connected" === t.connection.state
                    }

                    function In(e, t) {
                        if (e.isSynthesized() || t.isSynthesized()) return e.timestamp >= t.timestamp;
                        const n = e.parseId(),
                            s = t.parseId();
                        return n.msgSerial === s.msgSerial ? n.index > s.index : n.msgSerial > s.msgSerial
                    }
                    var kn = class extends Nt {
                            constructor(e, t) {
                                super(e.logger), this.presence = e, this.map = /* @__PURE__ */ Object.create(null), this.syncInProgress = !1, this.residualMembers = null, this.memberKey = t
                            }
                            get(e) {
                                return this.map[e]
                            }
                            getClient(e) {
                                const t = this.map,
                                    n = [];
                                for (const s in t) {
                                    const i = t[s];
                                    i.clientId == e && "absent" != i.action && n.push(i)
                                }
                                return n
                            }
                            list(e) {
                                const t = this.map,
                                    n = e && e.clientId,
                                    s = e && e.connectionId,
                                    i = [];
                                for (const e in t) {
                                    const o = t[e];
                                    "absent" !== o.action && (n && n != o.clientId || s && s != o.connectionId || i.push(o))
                                }
                                return i
                            }
                            put(e) {
                                "enter" !== e.action && "update" !== e.action || ((e = mt(e)).action = "present");
                                const t = this.map,
                                    n = this.memberKey(e);
                                this.residualMembers && delete this.residualMembers[n];
                                const s = t[n];
                                return !(s && !In(e, s) || (t[n] = e, 0))
                            }
                            values() {
                                const e = this.map,
                                    t = [];
                                for (const n in e) {
                                    const s = e[n];
                                    "absent" != s.action && t.push(s)
                                }
                                return t
                            }
                            remove(e) {
                                const t = this.map,
                                    n = this.memberKey(e),
                                    s = t[n];
                                return !(s && !In(e, s) || (this.syncInProgress ? ((e = mt(e)).action = "absent", t[n] = e) : delete t[n], 0))
                            }
                            startSync() {
                                const e = this.map;
                                O.logAction(this.logger, O.LOG_MINOR, "PresenceMap.startSync()", "channel = " + this.presence.channel.name + "; syncInProgress = " + this.syncInProgress), this.syncInProgress || (this.residualMembers = T(e), this.setInProgress(!0))
                            }
                            endSync() {
                                const e = this.map,
                                    t = this.syncInProgress;
                                if (O.logAction(this.logger, O.LOG_MINOR, "PresenceMap.endSync()", "channel = " + this.presence.channel.name + "; syncInProgress = " + t), t) {
                                    for (const t in e) "absent" === e[t].action && delete e[t];
                                    this.presence._synthesizeLeaves(F(this.residualMembers));
                                    for (const t in this.residualMembers) delete e[t];
                                    this.residualMembers = null, this.setInProgress(!1)
                                }
                                this.emit("sync")
                            }
                            waitSync(e) {
                                const t = this.syncInProgress;
                                O.logAction(this.logger, O.LOG_MINOR, "PresenceMap.waitSync()", "channel = " + this.presence.channel.name + "; syncInProgress = " + t), t ? this.once("sync", e) : e()
                            }
                            clear() {
                                this.map = {}, this.setInProgress(!1), this.residualMembers = null
                            }
                            setInProgress(e) {
                                O.logAction(this.logger, O.LOG_MICRO, "PresenceMap.setInProgress()", "inProgress = " + e), this.syncInProgress = e, this.presence.syncComplete = !e
                            }
                        },
                        Sn = class extends Nt {
                            constructor(e) {
                                super(e.logger), this.channel = e, this.syncComplete = !1, this.members = new kn(this, e => e.clientId + ":" + e.connectionId), this._myMembers = new kn(this, e => e.clientId), this.subscriptions = new Nt(this.logger), this.pendingPresence = []
                            }
                            async enter(e) {
                                if (Rn(this)) throw new k("clientId must be specified to enter a presence channel", 40012, 400);
                                return this._enterOrUpdateClient(void 0, void 0, e, "enter")
                            }
                            async update(e) {
                                if (Rn(this)) throw new k("clientId must be specified to update presence data", 40012, 400);
                                return this._enterOrUpdateClient(void 0, void 0, e, "update")
                            }
                            async enterClient(e, t) {
                                return this._enterOrUpdateClient(void 0, e, t, "enter")
                            }
                            async updateClient(e, t) {
                                return this._enterOrUpdateClient(void 0, e, t, "update")
                            }
                            async _enterOrUpdateClient(e, t, n, s) {
                                const i = this.channel;
                                if (!i.connectionManager.activeState()) throw i.connectionManager.getError();
                                O.logAction(this.logger, O.LOG_MICRO, "RealtimePresence." + s + "Client()", "channel = " + i.name + ", id = " + e + ", client = " + (t || "(implicit) " + this.channel.client.auth.clientId));
                                const o = bt(n);
                                switch (o.action = s, e && (o.id = e), t && (o.clientId = t), await ot(o, i.channelOptions), i.state) {
                                    case "attached":
                                        return new Promise((e, t) => {
                                            i.sendPresence(o, n => n ? t(n) : e())
                                        });
                                    case "initialized":
                                    case "detached":
                                        i.attach();
                                    case "attaching":
                                        return new Promise((e, t) => {
                                            this.pendingPresence.push({
                                                presence: o,
                                                callback: n => n ? t(n) : e()
                                            })
                                        });
                                    default:
                                        {
                                            const e = new S("Unable to " + s + " presence channel while in " + i.state + " state", 90001);
                                            throw e.code = 90001,
                                            e
                                        }
                                }
                            }
                            async leave(e) {
                                if (Rn(this)) throw new k("clientId must have been specified to enter or leave a presence channel", 40012, 400);
                                return this.leaveClient(void 0, e)
                            }
                            async leaveClient(e, t) {
                                const n = this.channel;
                                if (!n.connectionManager.activeState()) throw n.connectionManager.getError();
                                O.logAction(this.logger, O.LOG_MICRO, "RealtimePresence.leaveClient()", "leaving; channel = " + this.channel.name + ", client = " + e);
                                const s = bt(t);
                                return s.action = "leave", e && (s.clientId = e), new Promise((e, t) => {
                                    switch (n.state) {
                                        case "attached":
                                            n.sendPresence(s, n => n ? t(n) : e());
                                            break;
                                        case "attaching":
                                            this.pendingPresence.push({
                                                presence: s,
                                                callback: n => n ? t(n) : e()
                                            });
                                            break;
                                        case "initialized":
                                        case "failed":
                                            {
                                                const e = new S("Unable to leave presence channel (incompatible state)", 90001);t(e);
                                                break
                                            }
                                        default:
                                            t(n.invalidStateError())
                                    }
                                })
                            }
                            async get(e) {
                                const t = !e || !("waitForSync" in e) || e.waitForSync;
                                return new Promise((n, s) => {
                                    function i(t) {
                                        n(e ? t.list(e) : t.values())
                                    }
                                    "suspended" !== this.channel.state ? function(e, t, n) {
                                        switch (e.state) {
                                            case "attached":
                                            case "suspended":
                                                n();
                                                break;
                                            case "initialized":
                                            case "detached":
                                            case "detaching":
                                            case "attaching":
                                                ie(e.attach(), function(e) {
                                                    e ? t(e) : n()
                                                });
                                                break;
                                            default:
                                                t(k.fromValues(e.invalidStateError()))
                                        }
                                    }(this.channel, e => s(e), () => {
                                        const e = this.members;
                                        t ? e.waitSync(function() {
                                            i(e)
                                        }) : i(e)
                                    }) : t ? s(k.fromValues({
                                        statusCode: 400,
                                        code: 91005,
                                        message: "Presence state is out of sync due to channel being in the SUSPENDED state"
                                    })) : i(this.members)
                                })
                            }
                            async history(e) {
                                O.logAction(this.logger, O.LOG_MICRO, "RealtimePresence.history()", "channel = " + this.name);
                                const t = this.channel.client.rest.presenceMixin;
                                if (e && e.untilAttach) {
                                    if ("attached" !== this.channel.state) throw new k("option untilAttach requires the channel to be attached, was: " + this.channel.state, 4e4, 400);
                                    delete e.untilAttach, e.from_serial = this.channel.properties.attachSerial
                                }
                                return t.history(this, e)
                            }
                            setPresence(e, t, n) {
                                let s, i;
                                O.logAction(this.logger, O.LOG_MICRO, "RealtimePresence.setPresence()", "received presence for " + e.length + " participants; syncChannelSerial = " + n);
                                const o = this.members,
                                    r = this._myMembers,
                                    a = [],
                                    c = this.channel.connectionManager.connectionId;
                                t && (this.members.startSync(), n && (i = n.match(/^[\w-]+:(.*)$/)) && (s = i[1]));
                                for (let t = 0; t < e.length; t++) {
                                    const n = mt(e[t]);
                                    switch (n.action) {
                                        case "leave":
                                            o.remove(n) && a.push(n), n.connectionId !== c || n.isSynthesized() || r.remove(n);
                                            break;
                                        case "enter":
                                        case "present":
                                        case "update":
                                            o.put(n) && a.push(n), n.connectionId === c && r.put(n)
                                    }
                                }
                                t && !s && (o.endSync(), this.channel.syncChannelSerial = null);
                                for (let e = 0; e < a.length; e++) {
                                    const t = a[e];
                                    this.subscriptions.emit(t.action, t)
                                }
                            }
                            onAttached(e) {
                                O.logAction(this.logger, O.LOG_MINOR, "RealtimePresence.onAttached()", "channel = " + this.channel.name + ", hasPresence = " + e), e ? this.members.startSync() : (this._synthesizeLeaves(this.members.values()), this.members.clear()), this._ensureMyMembersPresent();
                                const t = this.pendingPresence,
                                    n = t.length;
                                if (n) {
                                    this.pendingPresence = [];
                                    const e = [],
                                        s = Pe.create(this.logger);
                                    O.logAction(this.logger, O.LOG_MICRO, "RealtimePresence.onAttached", "sending " + n + " queued presence messages");
                                    for (let i = 0; i < n; i++) {
                                        const n = t[i];
                                        e.push(n.presence), s.push(n.callback)
                                    }
                                    this.channel.sendPresence(e, s)
                                }
                            }
                            actOnChannelState(e, t, n) {
                                switch (e) {
                                    case "attached":
                                        this.onAttached(t);
                                        break;
                                    case "detached":
                                    case "failed":
                                        this._clearMyMembers(), this.members.clear();
                                    case "suspended":
                                        this.failPendingPresence(n)
                                }
                            }
                            failPendingPresence(e) {
                                if (this.pendingPresence.length) {
                                    O.logAction(this.logger, O.LOG_MINOR, "RealtimeChannel.failPendingPresence", "channel; name = " + this.channel.name + ", err = " + X(e));
                                    for (let t = 0; t < this.pendingPresence.length; t++) try {
                                        this.pendingPresence[t].callback(e)
                                    } catch (e) {}
                                    this.pendingPresence = []
                                }
                            }
                            _clearMyMembers() {
                                this._myMembers.clear()
                            }
                            _ensureMyMembersPresent() {
                                const e = this._myMembers,
                                    t = e => {
                                        if (e) {
                                            const t = "Presence auto-re-enter failed: " + e.toString(),
                                                n = new k(t, 91004, 400);
                                            O.logAction(this.logger, O.LOG_ERROR, "RealtimePresence._ensureMyMembersPresent()", t);
                                            const s = new fn(this.channel.state, this.channel.state, !0, !1, n);
                                            this.channel.emit("update", s)
                                        }
                                    };
                                for (const n in e.map) {
                                    const s = e.map[n];
                                    O.logAction(this.logger, O.LOG_MICRO, "RealtimePresence._ensureMyMembersPresent()", 'Auto-reentering clientId "' + s.clientId + '" into the presence set'), ie(this._enterOrUpdateClient(s.id, s.clientId, s.data, "enter"), t)
                                }
                            }
                            _synthesizeLeaves(e) {
                                const t = this.subscriptions;
                                e.forEach(function(e) {
                                    const n = mt({
                                        action: "leave",
                                        connectionId: e.connectionId,
                                        clientId: e.clientId,
                                        data: e.data,
                                        encoding: e.encoding,
                                        timestamp: Date.now()
                                    });
                                    t.emit("leave", n)
                                })
                            }
                            async subscribe(...e) {
                                const t = vn.processListenerArgs(e),
                                    n = t[0],
                                    s = t[1],
                                    i = this.channel;
                                if ("failed" === i.state) throw k.fromValues(i.invalidStateError());
                                this.subscriptions.on(n, s), await i.attach()
                            }
                            unsubscribe(...e) {
                                const t = vn.processListenerArgs(e);
                                this.subscriptions.off(t[0], t[1])
                            }
                        },
                        An = zt.WebSocket,
                        Tn = class extends rn {
                            constructor(e, t, n) {
                                super(e, t, n), this.shortName = An, n.heartbeats = y.Config.useProtocolHeartbeats, this.wsHost = n.host
                            }
                            static isAvailable() {
                                return !!y.Config.WebSocket
                            }
                            createWebSocket(e, t) {
                                return this.uri = e + $(t), new y.Config.WebSocket(this.uri)
                            }
                            toString() {
                                return "WebSocketTransport; uri=" + this.uri
                            }
                            connect() {
                                O.logAction(this.logger, O.LOG_MINOR, "WebSocketTransport.connect()", "starting"), rn.prototype.connect.call(this);
                                const e = this,
                                    t = this.params,
                                    n = t.options,
                                    s = (n.tls ? "wss://" : "ws://") + this.wsHost + ":" + Ee.getPort(n) + "/";
                                O.logAction(this.logger, O.LOG_MINOR, "WebSocketTransport.connect()", "uri: " + s), ie(this.auth.getAuthParams(), function(n, i) {
                                    if (e.isDisposed) return;
                                    let o = "";
                                    for (const e in i) o += " " + e + ": " + i[e] + ";";
                                    if (O.logAction(e.logger, O.LOG_MINOR, "WebSocketTransport.connect()", "authParams:" + o + " err: " + n), n) return void e.disconnect(n);
                                    const r = t.getConnectParams(i);
                                    try {
                                        const t = e.wsConnection = e.createWebSocket(s, r);
                                        t.binaryType = y.Config.binaryType, t.onopen = function() {
                                            e.onWsOpen()
                                        }, t.onclose = function(t) {
                                            e.onWsClose(t)
                                        }, t.onmessage = function(t) {
                                            e.onWsData(t.data)
                                        }, t.onerror = function(t) {
                                            e.onWsError(t)
                                        }, t.on && t.on("ping", function() {
                                            e.onActivity()
                                        })
                                    } catch (t) {
                                        O.logAction(e.logger, O.LOG_ERROR, "WebSocketTransport.connect()", "Unexpected exception creating websocket: err = " + (t.stack || t.message)), e.disconnect(t)
                                    }
                                })
                            }
                            send(e) {
                                const t = this.wsConnection;
                                if (t) try {
                                    t.send(jt(e, this.connectionManager.realtime._MsgPack, this.params.format))
                                } catch (e) {
                                    const t = "Exception from ws connection when trying to send: " + X(e);
                                    O.logAction(this.logger, O.LOG_ERROR, "WebSocketTransport.send()", t), this.finish("disconnected", new k(t, 5e4, 500))
                                } else O.logAction(this.logger, O.LOG_ERROR, "WebSocketTransport.send()", "No socket connection")
                            }
                            onWsData(e) {
                                O.logAction(this.logger, O.LOG_MICRO, "WebSocketTransport.onWsData()", "data received; length = " + e.length + "; type = " + typeof e);
                                try {
                                    this.onProtocolMessage((t = this.connectionManager.realtime._RealtimePresence, Wt(oe(e, this.connectionManager.realtime._MsgPack, this.format), t)))
                                } catch (e) {
                                    O.logAction(this.logger, O.LOG_ERROR, "WebSocketTransport.onWsData()", "Unexpected exception handing channel message: " + e.stack)
                                }
                                var t
                            }
                            onWsOpen() {
                                O.logAction(this.logger, O.LOG_MINOR, "WebSocketTransport.onWsOpen()", "opened WebSocket"), this.emit("preconnect")
                            }
                            onWsClose(e) {
                                let t, n;
                                if ("object" == typeof e ? (n = e.code, t = e.wasClean || 1e3 === n) : (n = e, t = 1e3 == n), delete this.wsConnection, t) {
                                    O.logAction(this.logger, O.LOG_MINOR, "WebSocketTransport.onWsClose()", "Cleanly closed WebSocket");
                                    const e = new k("Websocket closed", 80003, 400);
                                    this.finish("disconnected", e)
                                } else {
                                    const e = "Unclean disconnection of WebSocket ; code = " + n,
                                        t = new k(e, 80003, 400);
                                    O.logAction(this.logger, O.LOG_MINOR, "WebSocketTransport.onWsClose()", e), this.finish("disconnected", t)
                                }
                                this.emit("disposed")
                            }
                            onWsError(e) {
                                O.logAction(this.logger, O.LOG_MINOR, "WebSocketTransport.onError()", "Error from WebSocket: " + e.message), y.Config.nextTick(() => {
                                    this.disconnect(Error(e.message))
                                })
                            }
                            dispose() {
                                O.logAction(this.logger, O.LOG_MINOR, "WebSocketTransport.dispose()", ""), this.isDisposed = !0;
                                const e = this.wsConnection;
                                e && (e.onmessage = function() {}, delete this.wsConnection, y.Config.nextTick(() => {
                                    if (O.logAction(this.logger, O.LOG_MICRO, "WebSocketTransport.dispose()", "closing websocket"), !e) throw new Error("WebSocketTransport.dispose(): wsConnection is not defined");
                                    e.close()
                                }))
                            }
                        },
                        Mn = class {
                            static subscribeFilter(e, t, n) {
                                const s = e => {
                                    var s, i, o, r, a, c;
                                    const l = {
                                        name: e.name,
                                        refTimeserial: null == (i = null == (s = e.extras) ? void 0 : s.ref) ? void 0 : i.timeserial,
                                        refType: null == (r = null == (o = e.extras) ? void 0 : o.ref) ? void 0 : r.type,
                                        isRef: !!(null == (c = null == (a = e.extras) ? void 0 : a.ref) ? void 0 : c.timeserial),
                                        clientId: e.clientId
                                    };
                                    Object.entries(t).find(([e, t]) => void 0 !== t && l[e] !== t) || n(e)
                                };
                                this.addFilteredSubscription(e, t, n, s), e.subscriptions.on(s)
                            }
                            static addFilteredSubscription(e, t, n, s) {
                                var i;
                                if (e.filteredSubscriptions || (e.filteredSubscriptions = /* @__PURE__ */ new Map), e.filteredSubscriptions.has(n)) {
                                    const o = e.filteredSubscriptions.get(n);
                                    o.set(t, (null == (i = null == o ? void 0 : o.get(t)) ? void 0 : i.concat(s)) || [s])
                                } else e.filteredSubscriptions.set(n, /* @__PURE__ */ new Map([
                                    [t, [s]]
                                ]))
                            }
                            static getAndDeleteFilteredSubscriptions(e, t, n) {
                                if (!e.filteredSubscriptions) return [];
                                if (!n && t) return Array.from(e.filteredSubscriptions.entries()).map(([n, s]) => {
                                    var i;
                                    let o = s.get(t);
                                    return s.delete(t), 0 === s.size && (null == (i = e.filteredSubscriptions) || i.delete(n)), o
                                }).reduce((e, t) => t ? e.concat(...t) : e, []);
                                if (!n || !e.filteredSubscriptions.has(n)) return [];
                                const s = e.filteredSubscriptions.get(n);
                                if (!t) {
                                    const t = Array.from(s.values()).reduce((e, t) => e.concat(...t), []);
                                    return e.filteredSubscriptions.delete(n), t
                                }
                                let i = s.get(t);
                                return s.delete(t), i || []
                            }
                        },
                        En = class e extends On {
                            constructor(t) {
                                var n;
                                const s = e._MsgPack;
                                if (!s) throw new Error("Expected DefaultRealtime._MsgPack to have been set");
                                super(Ee.objectifyOptions(t, !0, "Realtime", O.defaultLogger, p(g({}, Mt), {
                                    Crypto: null != (n = e.Crypto) ? n : void 0,
                                    MsgPack: s,
                                    RealtimePresence: {
                                        RealtimePresence: Sn,
                                        presenceMessageFromValues: mt,
                                        presenceMessagesFromValuesArray: wt
                                    },
                                    WebSocketTransport: Tn,
                                    MessageInteractions: Mn
                                })))
                            }
                            static get Crypto() {
                                if (null === this._Crypto) throw new Error("Encryption not enabled; use ably.encryption.js instead");
                                return this._Crypto
                            }
                            static set Crypto(e) {
                                this._Crypto = e
                            }
                        };
                    En.Utils = R, En.ConnectionManager = gn, En.ProtocolMessage = Qt, En._Crypto = null, En.Message = Et, En.PresenceMessage = Pt, En._MsgPack = null, En._Http = Ve;
                    var Pn = En,
                        _n = Uint8Array,
                        Ln = Uint32Array,
                        Un = Math.pow,
                        Nn = new Ln(8),
                        xn = [],
                        Gn = new Ln(64);

                    function Dn(e) {
                        return (e - (0 | e)) * Un(2, 32) | 0
                    }
                    for (var qn, Bn, Hn = 2, jn = 0; jn < 64;) {
                        for (qn = !0, Bn = 2; Bn <= Hn / 2; Bn++) Hn % Bn == 0 && (qn = !1);
                        qn && (jn < 8 && (Nn[jn] = Dn(Un(Hn, .5))), xn[jn] = Dn(Un(Hn, 1 / 3)), jn++), Hn++
                    }
                    var Wn = !!new _n(new Ln([1]).buffer)[0];

                    function Fn(e) {
                        return Wn ? e >>> 24 | (e >>> 16 & 255) << 8 | (65280 & e) << 8 | e << 24 : e
                    }

                    function Vn(e, t) {
                        return e >>> t | e << 32 - t
                    }

                    function Kn(e) {
                        var t, n = Nn.slice(),
                            s = e.length,
                            i = 8 * s,
                            o = 512 - (i + 64) % 512 - 1 + i + 65,
                            r = new _n(o / 8),
                            a = new Ln(r.buffer);
                        r.set(e, 0), r[s] = 128, a[a.length - 1] = Fn(i);
                        for (var c = 0; c < o / 32; c += 16) {
                            var l = n.slice();
                            for (t = 0; t < 64; t++) {
                                var h;
                                if (t < 16) h = Fn(a[c + t]);
                                else {
                                    var u = Gn[t - 15],
                                        d = Gn[t - 2];
                                    h = Gn[t - 7] + Gn[t - 16] + (Vn(u, 7) ^ Vn(u, 18) ^ u >>> 3) + (Vn(d, 17) ^ Vn(d, 19) ^ d >>> 10)
                                }
                                Gn[t] = h |= 0;
                                for (var g = (Vn(l[4], 6) ^ Vn(l[4], 11) ^ Vn(l[4], 25)) + (l[4] & l[5] ^ ~l[4] & l[6]) + l[7] + h + xn[t], p = (Vn(l[0], 2) ^ Vn(l[0], 13) ^ Vn(l[0], 22)) + (l[0] & l[1] ^ l[2] & (l[0] ^ l[1])), f = 7; f > 0; f--) l[f] = l[f - 1];
                                l[0] = g + p | 0, l[4] = l[4] + g | 0
                            }
                            for (t = 0; t < 8; t++) n[t] = n[t] + l[t] | 0
                        }
                        return new _n(new Ln(n.map(function(e) {
                            return Fn(e)
                        })).buffer)
                    }
                    var zn, Jn = new class {
                            constructor() {
                                this.base64CharSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", this.hexCharSet = "0123456789abcdef"
                            }
                            uint8ViewToBase64(e) {
                                let t = "";
                                const n = this.base64CharSet,
                                    s = e.byteLength,
                                    i = s % 3,
                                    o = s - i;
                                let r, a, c, l, h;
                                for (let s = 0; s < o; s += 3) h = e[s] << 16 | e[s + 1] << 8 | e[s + 2], r = (16515072 & h) >> 18, a = (258048 & h) >> 12, c = (4032 & h) >> 6, l = 63 & h, t += n[r] + n[a] + n[c] + n[l];
                                return 1 == i ? (h = e[o], r = (252 & h) >> 2, a = (3 & h) << 4, t += n[r] + n[a] + "==") : 2 == i && (h = e[o] << 8 | e[o + 1], r = (64512 & h) >> 10, a = (1008 & h) >> 4, c = (15 & h) << 2, t += n[r] + n[a] + n[c] + "="), t
                            }
                            base64ToArrayBuffer(e) {
                                const t = null == atob ? void 0 : atob(e),
                                    n = t.length,
                                    s = new Uint8Array(n);
                                for (let e = 0; e < n; e++) {
                                    const n = t.charCodeAt(e);
                                    s[e] = n
                                }
                                return this.toArrayBuffer(s)
                            }
                            isBuffer(e) {
                                return e instanceof ArrayBuffer || ArrayBuffer.isView(e)
                            }
                            toBuffer(e) {
                                if (!ArrayBuffer) throw new Error("Can't convert to Buffer: browser does not support the necessary types");
                                if (e instanceof ArrayBuffer) return new Uint8Array(e);
                                if (ArrayBuffer.isView(e)) return new Uint8Array(this.toArrayBuffer(e));
                                throw new Error("BufferUtils.toBuffer expected an ArrayBuffer or a view onto one")
                            }
                            toArrayBuffer(e) {
                                if (!ArrayBuffer) throw new Error("Can't convert to ArrayBuffer: browser does not support the necessary types");
                                if (e instanceof ArrayBuffer) return e;
                                if (ArrayBuffer.isView(e)) return e.buffer.slice(e.byteOffset, e.byteOffset + e.byteLength);
                                throw new Error("BufferUtils.toArrayBuffer expected an ArrayBuffer or a view onto one")
                            }
                            base64Encode(e) {
                                return this.uint8ViewToBase64(this.toBuffer(e))
                            }
                            base64Decode(e) {
                                if (ArrayBuffer && y.Config.atob) return this.base64ToArrayBuffer(e);
                                throw new Error("Expected ArrayBuffer to exist and Platform.Config.atob to be configured")
                            }
                            hexEncode(e) {
                                return this.toBuffer(e).reduce((e, t) => e + t.toString(16).padStart(2, "0"), "")
                            }
                            hexDecode(e) {
                                if (e.length % 2 != 0) throw new Error("Can't create a byte array from a hex string of odd length");
                                const t = new Uint8Array(e.length / 2);
                                for (let n = 0; n < t.length; n++) t[n] = parseInt(e.slice(2 * n, 2 * (n + 1)), 16);
                                return this.toArrayBuffer(t)
                            }
                            utf8Encode(e) {
                                if (y.Config.TextEncoder) {
                                    const t = (new y.Config.TextEncoder).encode(e);
                                    return this.toArrayBuffer(t)
                                }
                                throw new Error("Expected TextEncoder to be configured")
                            }
                            utf8Decode(e) {
                                if (!this.isBuffer(e)) throw new Error("Expected input of utf8decode to be an arraybuffer or typed array");
                                if (TextDecoder) return (new TextDecoder).decode(e);
                                throw new Error("Expected TextDecoder to be configured")
                            }
                            areBuffersEqual(e, t) {
                                if (!e || !t) return !1;
                                const n = this.toArrayBuffer(e),
                                    s = this.toArrayBuffer(t);
                                if (n.byteLength != s.byteLength) return !1;
                                const i = new Uint8Array(n),
                                    o = new Uint8Array(s);
                                for (var r = 0; r < i.length; r++)
                                    if (i[r] != o[r]) return !1;
                                return !0
                            }
                            byteLength(e) {
                                return e instanceof ArrayBuffer || ArrayBuffer.isView(e) ? e.byteLength : -1
                            }
                            arrayBufferViewToBuffer(e) {
                                return this.toArrayBuffer(e)
                            }
                            hmacSha256(e, t) {
                                const n = function(e, t) {
                                    if (e.length > 64 && (e = Kn(e)), e.length < 64) {
                                        const t = new Uint8Array(64);
                                        t.set(e, 0), e = t
                                    }
                                    for (var n = new Uint8Array(64), s = new Uint8Array(64), i = 0; i < 64; i++) n[i] = 54 ^ e[i], s[i] = 92 ^ e[i];
                                    var o = new Uint8Array(t.length + 64);
                                    o.set(n, 0), o.set(t, 64);
                                    var r = new Uint8Array(96);
                                    return r.set(s, 0), r.set(Kn(o), 64), Kn(r)
                                }(this.toBuffer(t), this.toBuffer(e));
                                return this.toArrayBuffer(n)
                            }
                        },
                        $n = /* @__PURE__ */ (e => (e[e.REQ_SEND = 0] = "REQ_SEND", e[e.REQ_RECV = 1] = "REQ_RECV", e[e.REQ_RECV_POLL = 2] = "REQ_RECV_POLL", e[e.REQ_RECV_STREAM = 3] = "REQ_RECV_STREAM", e))($n || {}),
                        Qn = $n;

                    function Yn() {
                        return new k("No HTTP request plugin provided. Provide at least one of the FetchRequest or XHRRequest plugins.", 400, 4e4)
                    }
                    var Xn = ((zn = class {
                            constructor(e) {
                                var t;
                                this.checksInProgress = null, this.checkConnectivity = void 0, this.supportsAuthHeaders = !1, this.supportsLinkHeaders = !1, this.client = null != e ? e : null;
                                const n = (null == e ? void 0 : e.options.connectivityCheckUrl) || Ee.connectivityCheckUrl,
                                    s = null != (t = null == e ? void 0 : e.options.connectivityCheckParams) ? t : null,
                                    i = !(null == e ? void 0 : e.options.connectivityCheckUrl),
                                    o = g(g({}, Xn.bundledRequestImplementations), null == e ? void 0 : e._additionalHTTPRequestImplementations),
                                    r = o.XHRRequest,
                                    a = o.FetchRequest,
                                    c = !(!r && !a);
                                if (!c) throw Yn();
                                y.Config.xhrSupported && r ? (this.supportsAuthHeaders = !0, this.Request = async function(t, n, s, i, o) {
                                    return new Promise(a => {
                                        var c;
                                        const l = r.createRequest(n, s, i, o, Qn.REQ_SEND, null != (c = e && e.options.timeouts) ? c : null, this.logger, t);
                                        l.once("complete", (e, t, n, s, i) => a({
                                            error: e,
                                            body: t,
                                            headers: n,
                                            unpacked: s,
                                            statusCode: i
                                        })), l.exec()
                                    })
                                }, this.checkConnectivity = (null == e ? void 0 : e.options.disableConnectivityCheck) ? async function() {
                                    return !0
                                } : async function() {
                                    var e;
                                    O.logAction(this.logger, O.LOG_MICRO, "(XHRRequest)Http.checkConnectivity()", "Sending; " + n);
                                    const t = await this.doUri(Le.Get, n, null, null, s);
                                    let o = !1;
                                    var r;
                                    return o = i ? !t.error && "yes" == (null == (e = t.body) ? void 0 : e.replace(/\n/, "")) : !t.error && (r = t.statusCode) >= 200 && r < 400, O.logAction(this.logger, O.LOG_MICRO, "(XHRRequest)Http.checkConnectivity()", "Result: " + o), o
                                }) : y.Config.fetchSupported && a ? (this.supportsAuthHeaders = !0, this.Request = async (t, n, s, i, o) => a(t, null != e ? e : null, n, s, i, o), this.checkConnectivity = async function() {
                                    var e;
                                    O.logAction(this.logger, O.LOG_MICRO, "(Fetch)Http.checkConnectivity()", "Sending; " + n);
                                    const t = await this.doUri(Le.Get, n, null, null, null),
                                        s = !t.error && "yes" == (null == (e = t.body) ? void 0 : e.replace(/\n/, ""));
                                    return O.logAction(this.logger, O.LOG_MICRO, "(Fetch)Http.checkConnectivity()", "Result: " + s), s
                                }) : this.Request = async () => ({
                                    error: c ? new S("no supported HTTP transports available", null, 400) : Yn()
                                })
                            }
                            get logger() {
                                var e, t;
                                return null != (t = null == (e = this.client) ? void 0 : e.logger) ? t : O.defaultLogger
                            }
                            async doUri(e, t, n, s, i) {
                                return this.Request ? this.Request(e, t, n, i, s) : {
                                    error: new S("Request invoked before assigned to", null, 500)
                                }
                            }
                            shouldFallback(e) {
                                const t = e.statusCode;
                                return 408 === t && !e.code || 400 === t && !e.code || t >= 500 && t <= 504
                            }
                        }).methods = [Le.Get, Le.Delete, Le.Post, Le.Put, Le.Patch], zn.methodsWithoutBody = [Le.Get, Le.Delete], zn.methodsWithBody = [Le.Post, Le.Put, Le.Patch], zn),
                        Zn = Xn,
                        es = "ablyjs-storage-test",
                        ts = void 0 !== e ? e : "undefined" != typeof window ? window : self,
                        ns = new class {
                            constructor() {
                                try {
                                    ts.sessionStorage.setItem(es, es), ts.sessionStorage.removeItem(es), this.sessionSupported = !0
                                } catch (e) {
                                    this.sessionSupported = !1
                                }
                                try {
                                    ts.localStorage.setItem(es, es), ts.localStorage.removeItem(es), this.localSupported = !0
                                } catch (e) {
                                    this.localSupported = !1
                                }
                            }
                            get(e) {
                                return this._get(e, !1)
                            }
                            getSession(e) {
                                return this._get(e, !0)
                            }
                            remove(e) {
                                return this._remove(e, !1)
                            }
                            removeSession(e) {
                                return this._remove(e, !0)
                            }
                            set(e, t, n) {
                                return this._set(e, t, n, !1)
                            }
                            setSession(e, t, n) {
                                return this._set(e, t, n, !0)
                            }
                            _set(e, t, n, s) {
                                const i = {
                                    value: t
                                };
                                return n && (i.expires = Date.now() + n), this.storageInterface(s).setItem(e, JSON.stringify(i))
                            }
                            _get(e, t) {
                                if (t && !this.sessionSupported) throw new Error("Session Storage not supported");
                                if (!t && !this.localSupported) throw new Error("Local Storage not supported");
                                const n = this.storageInterface(t).getItem(e);
                                if (!n) return null;
                                const s = JSON.parse(n);
                                return s.expires && s.expires < Date.now() ? (this.storageInterface(t).removeItem(e), null) : s.value
                            }
                            _remove(e, t) {
                                return this.storageInterface(t).removeItem(e)
                            }
                            storageInterface(e) {
                                return e ? ts.sessionStorage : ts.localStorage
                            }
                        },
                        ss = de(),
                        is = "string" == typeof EdgeRuntime;
                    "undefined" != typeof Window || "undefined" != typeof WorkerGlobalScope || is || console.log("Warning: this distribution of Ably is intended for browsers. On nodejs, please use the 'ably' package on npm");
                    var os = {
                        agent: "browser",
                        logTimestamps: !0,
                        userAgent: ss.navigator && ss.navigator.userAgent.toString(),
                        currentUrl: ss.location && ss.location.href,
                        binaryType: "arraybuffer",
                        WebSocket: ss.WebSocket,
                        fetchSupported: !!ss.fetch,
                        xhrSupported: ss.XMLHttpRequest && "withCredentials" in new XMLHttpRequest,
                        allowComet: function() {
                            const e = ss.location;
                            return !ss.WebSocket || !e || !e.origin || e.origin.indexOf("http") > -1
                        }(),
                        useProtocolHeartbeats: !0,
                        supportsBinary: !!ss.TextDecoder,
                        preferBinary: !1,
                        ArrayBuffer: ss.ArrayBuffer,
                        atob: ss.atob,
                        nextTick: void 0 !== ss.setImmediate ? ss.setImmediate.bind(ss) : function(e) {
                            setTimeout(e, 0)
                        },
                        addEventListener: ss.addEventListener,
                        inspect: JSON.stringify,
                        stringByteSize: function(e) {
                            return ss.TextDecoder && (new ss.TextEncoder).encode(e).length || e.length
                        },
                        TextEncoder: ss.TextEncoder,
                        TextDecoder: ss.TextDecoder,
                        getRandomArrayBuffer: async function(e) {
                            const t = new Uint8Array(e);
                            return ss.crypto.getRandomValues(t), t.buffer
                        },
                        isWebworker: "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope,
                        push: {
                            platform: "browser",
                            formFactor: "desktop",
                            storage: ns
                        }
                    };

                    function rs(e) {
                        return function(e) {
                            return !!e.code && !je.isTokenErr(e) && (!![80015, 80017, 80030].includes(e.code) || e.code >= 4e4 && e.code < 5e4)
                        }(e) ? [Vt({
                            action: xt.ERROR,
                            error: e
                        })] : [Vt({
                            action: xt.DISCONNECTED,
                            error: e
                        })]
                    }
                    var as = class extends rn {
                            constructor(e, t, n) {
                                super(e, t, n, !0), this.onAuthUpdated = e => {
                                    this.authParams = {
                                        access_token: e.token
                                    }
                                }, this.stream = !("stream" in n) || n.stream, this.sendRequest = null, this.recvRequest = null, this.pendingCallback = null, this.pendingItems = null
                            }
                            connect() {
                                O.logAction(this.logger, O.LOG_MINOR, "CometTransport.connect()", "starting"), rn.prototype.connect.call(this);
                                const e = this.params,
                                    t = e.options,
                                    n = Ee.getHost(t, e.host),
                                    s = Ee.getPort(t);
                                this.baseUri = (t.tls ? "https://" : "http://") + n + ":" + s + "/comet/";
                                const i = this.baseUri + "connect";
                                O.logAction(this.logger, O.LOG_MINOR, "CometTransport.connect()", "uri: " + i), ie(this.auth.getAuthParams(), (e, t) => {
                                    if (e) return void this.disconnect(e);
                                    if (this.isDisposed) return;
                                    this.authParams = t;
                                    const n = this.params.getConnectParams(t);
                                    "stream" in n && (this.stream = n.stream), O.logAction(this.logger, O.LOG_MINOR, "CometTransport.connect()", "connectParams:" + $(n));
                                    let s = !1;
                                    const o = this.recvRequest = this.createRequest(i, null, n, null, this.stream ? Qn.REQ_RECV_STREAM : Qn.REQ_RECV);
                                    o.on("data", e => {
                                        this.recvRequest && (s || (s = !0, this.emit("preconnect")), this.onData(e))
                                    }), o.on("complete", e => {
                                        this.recvRequest || (e = e || new k("Request cancelled", 80003, 400)), this.recvRequest = null, s || e || (s = !0, this.emit("preconnect")), this.onActivity(), e ? e.code ? this.onData(rs(e)) : this.disconnect(e) : y.Config.nextTick(() => {
                                            this.recv()
                                        })
                                    }), o.exec()
                                })
                            }
                            requestClose() {
                                O.logAction(this.logger, O.LOG_MINOR, "CometTransport.requestClose()"), this._requestCloseOrDisconnect(!0)
                            }
                            requestDisconnect() {
                                O.logAction(this.logger, O.LOG_MINOR, "CometTransport.requestDisconnect()"), this._requestCloseOrDisconnect(!1)
                            }
                            _requestCloseOrDisconnect(e) {
                                const t = e ? this.closeUri : this.disconnectUri;
                                if (t) {
                                    const n = this.createRequest(t, null, this.authParams, null, Qn.REQ_SEND);
                                    n.on("complete", t => {
                                        t && (O.logAction(this.logger, O.LOG_ERROR, "CometTransport.request" + (e ? "Close()" : "Disconnect()"), "request returned err = " + X(t)), this.finish("disconnected", t))
                                    }), n.exec()
                                }
                            }
                            dispose() {
                                O.logAction(this.logger, O.LOG_MINOR, "CometTransport.dispose()", ""), this.isDisposed || (this.isDisposed = !0, this.recvRequest && (O.logAction(this.logger, O.LOG_MINOR, "CometTransport.dispose()", "aborting recv request"), this.recvRequest.abort(), this.recvRequest = null), this.finish("disconnected", nn.disconnected()), y.Config.nextTick(() => {
                                    this.emit("disposed")
                                }))
                            }
                            onConnect(e) {
                                var t;
                                if (this.isDisposed) return;
                                const n = null == (t = e.connectionDetails) ? void 0 : t.connectionKey;
                                rn.prototype.onConnect.call(this, e);
                                const s = this.baseUri + n;
                                O.logAction(this.logger, O.LOG_MICRO, "CometTransport.onConnect()", "baseUri = " + s), this.sendUri = s + "/send", this.recvUri = s + "/recv", this.closeUri = s + "/close", this.disconnectUri = s + "/disconnect"
                            }
                            send(e) {
                                if (this.sendRequest) return this.pendingItems = this.pendingItems || [], void this.pendingItems.push(e);
                                const t = this.pendingItems || [];
                                t.push(e), this.pendingItems = null, this.sendItems(t)
                            }
                            sendAnyPending() {
                                const e = this.pendingItems;
                                e && (this.pendingItems = null, this.sendItems(e))
                            }
                            sendItems(e) {
                                const t = this.sendRequest = this.createRequest(this.sendUri, null, this.authParams, this.encodeRequest(e), Qn.REQ_SEND);
                                t.on("complete", (e, t) => {
                                    e && O.logAction(this.logger, O.LOG_ERROR, "CometTransport.sendItems()", "on complete: err = " + X(e)), this.sendRequest = null, e ? e.code ? this.onData(rs(e)) : this.disconnect(e) : (t && this.onData(t), this.pendingItems && y.Config.nextTick(() => {
                                        this.sendRequest || this.sendAnyPending()
                                    }))
                                }), t.exec()
                            }
                            recv() {
                                if (this.recvRequest) return;
                                if (!this.isConnected) return;
                                const e = this.recvRequest = this.createRequest(this.recvUri, null, this.authParams, null, this.stream ? Qn.REQ_RECV_STREAM : Qn.REQ_RECV_POLL);
                                e.on("data", e => {
                                    this.onData(e)
                                }), e.on("complete", e => {
                                    this.recvRequest = null, this.onActivity(), e ? e.code ? this.onData(rs(e)) : this.disconnect(e) : y.Config.nextTick(() => {
                                        this.recv()
                                    })
                                }), e.exec()
                            }
                            onData(e) {
                                try {
                                    const t = this.decodeResponse(e);
                                    if (t && t.length)
                                        for (let e = 0; e < t.length; e++) this.onProtocolMessage(Wt(t[e], this.connectionManager.realtime._RealtimePresence))
                                } catch (e) {
                                    O.logAction(this.logger, O.LOG_ERROR, "CometTransport.onData()", "Unexpected exception handing channel event: " + e.stack)
                                }
                            }
                            encodeRequest(e) {
                                return JSON.stringify(e)
                            }
                            decodeResponse(e) {
                                return "string" == typeof e ? JSON.parse(e) : e
                            }
                        },
                        cs = function() {},
                        ls = 0,
                        hs = class e extends Nt {
                            constructor(e, t, n, s, i, o, r, a) {
                                super(r), (n = n || {}).rnd = te(), this.uri = e + $(n), this.headers = t || {}, this.body = s, this.method = a ? a.toUpperCase() : _(s) ? "GET" : "POST", this.requestMode = i, this.timeouts = o, this.timedOut = !1, this.requestComplete = !1, this.id = String(++ls)
                            }
                            static createRequest(t, n, s, i, o, r, a, c) {
                                const l = r || Ee.TIMEOUTS;
                                return new e(t, n, T(s), i, o, l, a, c)
                            }
                            complete(e, t, n, s, i) {
                                this.requestComplete || (this.requestComplete = !0, !e && t && this.emit("data", t), this.emit("complete", e, t, n, s, i), this.dispose())
                            }
                            abort() {
                                this.dispose()
                            }
                            exec() {
                                let e = this.headers;
                                const t = this.timer = setTimeout(() => {
                                        this.timedOut = !0, s.abort()
                                    }, this.requestMode == Qn.REQ_SEND ? this.timeouts.httpRequestTimeout : this.timeouts.recvTimeout),
                                    n = this.method,
                                    s = this.xhr = new XMLHttpRequest,
                                    i = e.accept;
                                let o = this.body,
                                    r = "text";
                                i ? 0 === i.indexOf("application/x-msgpack") && (r = "arraybuffer") : e.accept = "application/json", o && (e["content-type"] || (e["content-type"] = "application/json")).indexOf("application/json") > -1 && "string" != typeof o && (o = JSON.stringify(o)), s.open(n, this.uri, !0), s.responseType = r, "authorization" in e && (s.withCredentials = !0);
                                for (const t in e) s.setRequestHeader(t, e[t]);
                                const a = (e, t, n, s) => {
                                    var i;
                                    let o = t + " (event type: " + e.type + ")";
                                    (null == (i = null == this ? void 0 : this.xhr) ? void 0 : i.statusText) && (o += ", current statusText is " + this.xhr.statusText), O.logAction(this.logger, O.LOG_ERROR, "Request.on" + e.type + "()", o), this.complete(new S(o, n, s))
                                };
                                let c, l, h;
                                s.onerror = function(e) {
                                    a(e, "XHR error occurred", null, 400)
                                }, s.onabort = e => {
                                    this.timedOut ? a(e, "Request aborted due to request timeout expiring", null, 408) : a(e, "Request cancelled", null, 400)
                                }, s.ontimeout = function(e) {
                                    a(e, "Request timed out", null, 408)
                                };
                                let u = 0,
                                    d = !1;
                                const g = () => {
                                        clearTimeout(t), h = l < 400, 204 != l ? c = this.requestMode == Qn.REQ_RECV_STREAM && h && function(e) {
                                            return e.getResponseHeader && (e.getResponseHeader("transfer-encoding") || !e.getResponseHeader("content-length"))
                                        }(s) : this.complete(null, null, null, null, l)
                                    },
                                    p = () => {
                                        let t;
                                        try {
                                            const n = function(e, t) {
                                                return e.getResponseHeader && e.getResponseHeader("content-type")
                                            }(s);
                                            if (n ? n.indexOf("application/json") >= 0 : "text" == s.responseType) {
                                                const e = "arraybuffer" === s.responseType ? y.BufferUtils.utf8Decode(s.response) : String(s.responseText);
                                                t = e.length ? JSON.parse(e) : e, d = !0
                                            } else t = s.response;
                                            void 0 !== t.response ? (l = t.statusCode, h = l < 400, e = t.headers, t = t.response) : e = function(e) {
                                                const t = e.getAllResponseHeaders().trim().split("\r\n"),
                                                    n = {};
                                                for (let e = 0; e < t.length; e++) {
                                                    const s = t[e].split(":").map(e => e.trim());
                                                    n[s[0].toLowerCase()] = s[1]
                                                }
                                                return n
                                            }(s)
                                        } catch (e) {
                                            return void this.complete(new S("Malformed response body from server: " + e.message, null, 400))
                                        }
                                        if (h || Array.isArray(t)) return void this.complete(null, t, e, d, l);
                                        let n = function(e, t) {
                                            if (function(e, t) {
                                                    return ae(W(t)).includes("x-ably-errorcode")
                                                }(0, t)) return e.error && k.fromValues(e.error)
                                        }(t, e);
                                        n || (n = new S("Error response received from server: " + l + " body was: " + y.Config.inspect(t), null, l)), this.complete(n, t, e, d, l)
                                    };

                                function f() {
                                    const e = s.responseText,
                                        t = e.length - 1;
                                    let n, i;
                                    for (; u < t && (n = e.indexOf("\n", u)) > -1;) i = e.slice(u, n), u = n + 1, m(i)
                                }
                                const m = e => {
                                        try {
                                            e = JSON.parse(e)
                                        } catch (e) {
                                            return void this.complete(new S("Malformed response body from server: " + e.message, null, 400))
                                        }
                                        this.emit("data", e)
                                    },
                                    v = () => {
                                        f(), this.streamComplete = !0, y.Config.nextTick(() => {
                                            this.complete()
                                        })
                                    };
                                s.onreadystatechange = function() {
                                    const e = s.readyState;
                                    e < 3 || 0 !== s.status && (void 0 === l && (l = s.status, g()), 3 == e && c ? f() : 4 == e && (c ? v() : p()))
                                }, s.send(o)
                            }
                            dispose() {
                                const e = this.xhr;
                                if (e) {
                                    e.onreadystatechange = e.onerror = e.onabort = e.ontimeout = cs, this.xhr = null;
                                    const t = this.timer;
                                    t && (clearTimeout(t), this.timer = null), this.requestComplete || e.abort()
                                }
                            }
                        },
                        us = zt.XhrPolling,
                        ds = {
                            order: ["xhr_polling"],
                            bundledImplementations: {
                                web_socket: Tn,
                                xhr_polling: class extends as {
                                    constructor(e, t, n) {
                                        super(e, t, n), this.shortName = us, n.stream = !1, this.shortName = us
                                    }
                                    static isAvailable() {
                                        return !(!y.Config.xhrSupported || !y.Config.allowComet)
                                    }
                                    toString() {
                                        return "XHRPollingTransport; uri=" + this.baseUri + "; isConnected=" + this.isConnected
                                    }
                                    createRequest(e, t, n, s, i) {
                                        return hs.createRequest(e, t, n, s, i, this.timeouts, this.logger)
                                    }
                                }
                            }
                        },
                        gs = {
                            connectivityCheckUrl: "https://internet-up.ably-realtime.com/is-the-internet-up.txt",
                            wsConnectivityCheckUrl: "wss://ws-up.ably-realtime.com",
                            defaultTransports: [zt.XhrPolling, zt.WebSocket]
                        };

                    function ps(e, t, n) {
                        for (let s = 0, i = n.length; s < i; s++) {
                            const i = n.charCodeAt(s);
                            if (i < 128) e.setUint8(t++, i >>> 0 & 127 | 0);
                            else if (i < 2048) e.setUint8(t++, i >>> 6 & 31 | 192), e.setUint8(t++, i >>> 0 & 63 | 128);
                            else if (i < 65536) e.setUint8(t++, i >>> 12 & 15 | 224), e.setUint8(t++, i >>> 6 & 63 | 128), e.setUint8(t++, i >>> 0 & 63 | 128);
                            else {
                                if (!(i < 1114112)) throw new Error("bad codepoint " + i);
                                e.setUint8(t++, i >>> 18 & 7 | 240), e.setUint8(t++, i >>> 12 & 63 | 128), e.setUint8(t++, i >>> 6 & 63 | 128), e.setUint8(t++, i >>> 0 & 63 | 128)
                            }
                        }
                    }

                    function fs(e, t, n) {
                        let s = "";
                        for (let i = t, o = t + n; i < o; i++) {
                            const t = e.getUint8(i);
                            if (0 != (128 & t))
                                if (192 != (224 & t))
                                    if (224 != (240 & t)) {
                                        if (240 != (248 & t)) throw new Error("Invalid byte " + t.toString(16));
                                        s += String.fromCharCode((7 & t) << 18 | (63 & e.getUint8(++i)) << 12 | (63 & e.getUint8(++i)) << 6 | (63 & e.getUint8(++i)) << 0)
                                    } else s += String.fromCharCode((15 & t) << 12 | (63 & e.getUint8(++i)) << 6 | (63 & e.getUint8(++i)) << 0);
                            else s += String.fromCharCode((15 & t) << 6 | 63 & e.getUint8(++i));
                            else s += String.fromCharCode(t)
                        }
                        return s
                    }

                    function ms(e) {
                        let t = 0;
                        for (let n = 0, s = e.length; n < s; n++) {
                            const s = e.charCodeAt(n);
                            if (s < 128) t += 1;
                            else if (s < 2048) t += 2;
                            else if (s < 65536) t += 3;
                            else {
                                if (!(s < 1114112)) throw new Error("bad codepoint " + s);
                                t += 4
                            }
                        }
                        return t
                    }
                    var ys = 4294967296,
                        vs = 1 / ys;

                    function ws(e, t) {
                        return Object.keys(e).filter(function(n) {
                            const s = e[n];
                            return !(t && null == s || "function" == typeof s && !s.toJSON)
                        })
                    }

                    function bs(e, t, n, s) {
                        const i = typeof e;
                        if ("string" == typeof e) {
                            const s = ms(e);
                            if (s < 32) return t.setUint8(n, 160 | s), ps(t, n + 1, e), 1 + s;
                            if (s < 256) return t.setUint8(n, 217), t.setUint8(n + 1, s), ps(t, n + 2, e), 2 + s;
                            if (s < 65536) return t.setUint8(n, 218), t.setUint16(n + 1, s), ps(t, n + 3, e), 3 + s;
                            if (s < 4294967296) return t.setUint8(n, 219), t.setUint32(n + 1, s), ps(t, n + 5, e), 5 + s
                        }
                        if (ArrayBuffer.isView && ArrayBuffer.isView(e) && (e = e.buffer), e instanceof ArrayBuffer) {
                            const s = e.byteLength;
                            if (s < 256) return t.setUint8(n, 196), t.setUint8(n + 1, s), new Uint8Array(t.buffer).set(new Uint8Array(e), n + 2), 2 + s;
                            if (s < 65536) return t.setUint8(n, 197), t.setUint16(n + 1, s), new Uint8Array(t.buffer).set(new Uint8Array(e), n + 3), 3 + s;
                            if (s < 4294967296) return t.setUint8(n, 198), t.setUint32(n + 1, s), new Uint8Array(t.buffer).set(new Uint8Array(e), n + 5), 5 + s
                        }
                        if ("number" == typeof e) {
                            if (Math.floor(e) !== e) return t.setUint8(n, 203), t.setFloat64(n + 1, e), 9;
                            if (e >= 0) {
                                if (e < 128) return t.setUint8(n, e), 1;
                                if (e < 256) return t.setUint8(n, 204), t.setUint8(n + 1, e), 2;
                                if (e < 65536) return t.setUint8(n, 205), t.setUint16(n + 1, e), 3;
                                if (e < 4294967296) return t.setUint8(n, 206), t.setUint32(n + 1, e), 5;
                                if (e < 0x10000000000000000) return t.setUint8(n, 207),
                                    function(e, t, n) {
                                        n < 0x10000000000000000 ? (e.setUint32(t, Math.floor(n * vs)), e.setInt32(t + 4, -1 & n)) : (e.setUint32(t, 4294967295), e.setUint32(t + 4, 4294967295))
                                    }(t, n + 1, e), 9;
                                throw new Error("Number too big 0x" + e.toString(16))
                            }
                            if (e >= -32) return t.setInt8(n, e), 1;
                            if (e >= -128) return t.setUint8(n, 208), t.setInt8(n + 1, e), 2;
                            if (e >= -32768) return t.setUint8(n, 209), t.setInt16(n + 1, e), 3;
                            if (e >= -2147483648) return t.setUint8(n, 210), t.setInt32(n + 1, e), 5;
                            if (e >= -0x8000000000000000) return t.setUint8(n, 211),
                                function(e, t, n) {
                                    n < 0x8000000000000000 ? (e.setInt32(t, Math.floor(n * vs)), e.setInt32(t + 4, -1 & n)) : (e.setUint32(t, 2147483647), e.setUint32(t + 4, 2147483647))
                                }(t, n + 1, e), 9;
                            throw new Error("Number too small -0x" + (-e).toString(16).substr(1))
                        }
                        if ("undefined" === i) return s ? 0 : (t.setUint8(n, 212), t.setUint8(n + 1, 0), t.setUint8(n + 2, 0), 3);
                        if (null === e) return s ? 0 : (t.setUint8(n, 192), 1);
                        if ("boolean" === i) return t.setUint8(n, e ? 195 : 194), 1;
                        if ("function" == typeof e.toJSON) return bs(e.toJSON(), t, n, s);
                        if ("object" === i) {
                            let i, o, r = 0;
                            const a = Array.isArray(e);
                            if (a ? i = e.length : (o = ws(e, s), i = o.length), i < 16 ? (t.setUint8(n, i | (a ? 144 : 128)), r = 1) : i < 65536 ? (t.setUint8(n, a ? 220 : 222), t.setUint16(n + 1, i), r = 3) : i < 4294967296 && (t.setUint8(n, a ? 221 : 223), t.setUint32(n + 1, i), r = 5), a)
                                for (let o = 0; o < i; o++) r += bs(e[o], t, n + r, s);
                            else if (o)
                                for (let a = 0; a < i; a++) {
                                    const i = o[a];
                                    r += bs(i, t, n + r), r += bs(e[i], t, n + r, s)
                                }
                            return r
                        }
                        if ("function" === i) return 0;
                        throw new Error("Unknown type " + i)
                    }

                    function Cs(e, t) {
                        const n = typeof e;
                        if ("string" === n) {
                            const t = ms(e);
                            if (t < 32) return 1 + t;
                            if (t < 256) return 2 + t;
                            if (t < 65536) return 3 + t;
                            if (t < 4294967296) return 5 + t
                        }
                        if (ArrayBuffer.isView && ArrayBuffer.isView(e) && (e = e.buffer), e instanceof ArrayBuffer) {
                            const t = e.byteLength;
                            if (t < 256) return 2 + t;
                            if (t < 65536) return 3 + t;
                            if (t < 4294967296) return 5 + t
                        }
                        if ("number" == typeof e) {
                            if (Math.floor(e) !== e) return 9;
                            if (e >= 0) {
                                if (e < 128) return 1;
                                if (e < 256) return 2;
                                if (e < 65536) return 3;
                                if (e < 4294967296) return 5;
                                if (e < 0x10000000000000000) return 9;
                                throw new Error("Number too big 0x" + e.toString(16))
                            }
                            if (e >= -32) return 1;
                            if (e >= -128) return 2;
                            if (e >= -32768) return 3;
                            if (e >= -2147483648) return 5;
                            if (e >= -0x8000000000000000) return 9;
                            throw new Error("Number too small -0x" + e.toString(16).substr(1))
                        }
                        if ("boolean" === n) return 1;
                        if (null === e) return t ? 0 : 1;
                        if (void 0 === e) return t ? 0 : 3;
                        if ("function" == typeof e.toJSON) return Cs(e.toJSON(), t);
                        if ("object" === n) {
                            let n, s = 0;
                            if (Array.isArray(e)) {
                                n = e.length;
                                for (let i = 0; i < n; i++) s += Cs(e[i], t)
                            } else {
                                const i = ws(e, t);
                                n = i.length;
                                for (let o = 0; o < n; o++) {
                                    const n = i[o];
                                    s += Cs(n) + Cs(e[n], t)
                                }
                            }
                            if (n < 16) return 1 + s;
                            if (n < 65536) return 3 + s;
                            if (n < 4294967296) return 5 + s;
                            throw new Error("Array or object too long 0x" + n.toString(16))
                        }
                        if ("function" === n) return 0;
                        throw new Error("Unknown type " + n)
                    }
                    var Os = {
                            encode: function(e, t) {
                                const n = Cs(e, t);
                                if (0 === n) return;
                                const s = new ArrayBuffer(n);
                                return bs(e, new DataView(s), 0, t), s
                            },
                            decode: function(e) {
                                const t = new DataView(e),
                                    n = new class {
                                        constructor(e, t) {
                                            this.map = e => {
                                                const t = {};
                                                for (let n = 0; n < e; n++) t[this.parse()] = this.parse();
                                                return t
                                            }, this.bin = e => {
                                                const t = new ArrayBuffer(e);
                                                return new Uint8Array(t).set(new Uint8Array(this.view.buffer, this.offset, e), 0), this.offset += e, t
                                            }, this.buf = this.bin, this.str = e => {
                                                const t = fs(this.view, this.offset, e);
                                                return this.offset += e, t
                                            }, this.array = e => {
                                                const t = new Array(e);
                                                for (let n = 0; n < e; n++) t[n] = this.parse();
                                                return t
                                            }, this.ext = e => (this.offset += e, {
                                                type: this.view.getInt8(this.offset),
                                                data: this.buf(e)
                                            }), this.parse = () => {
                                                const e = this.view.getUint8(this.offset);
                                                let t, n;
                                                if (0 == (128 & e)) return this.offset++, e;
                                                if (128 == (240 & e)) return n = 15 & e, this.offset++, this.map(n);
                                                if (144 == (240 & e)) return n = 15 & e, this.offset++, this.array(n);
                                                if (160 == (224 & e)) return n = 31 & e, this.offset++, this.str(n);
                                                if (224 == (224 & e)) return t = this.view.getInt8(this.offset), this.offset++, t;
                                                switch (e) {
                                                    case 192:
                                                        return this.offset++, null;
                                                    case 193:
                                                        return void this.offset++;
                                                    case 194:
                                                        return this.offset++, !1;
                                                    case 195:
                                                        return this.offset++, !0;
                                                    case 196:
                                                        return n = this.view.getUint8(this.offset + 1), this.offset += 2, this.bin(n);
                                                    case 197:
                                                        return n = this.view.getUint16(this.offset + 1), this.offset += 3, this.bin(n);
                                                    case 198:
                                                        return n = this.view.getUint32(this.offset + 1), this.offset += 5, this.bin(n);
                                                    case 199:
                                                        return n = this.view.getUint8(this.offset + 1), this.offset += 2, this.ext(n);
                                                    case 200:
                                                        return n = this.view.getUint16(this.offset + 1), this.offset += 3, this.ext(n);
                                                    case 201:
                                                        return n = this.view.getUint32(this.offset + 1), this.offset += 5, this.ext(n);
                                                    case 202:
                                                        return t = this.view.getFloat32(this.offset + 1), this.offset += 5, t;
                                                    case 203:
                                                        return t = this.view.getFloat64(this.offset + 1), this.offset += 9, t;
                                                    case 204:
                                                        return t = this.view.getUint8(this.offset + 1), this.offset += 2, t;
                                                    case 205:
                                                        return t = this.view.getUint16(this.offset + 1), this.offset += 3, t;
                                                    case 206:
                                                        return t = this.view.getUint32(this.offset + 1), this.offset += 5, t;
                                                    case 207:
                                                        return t = function(e, t) {
                                                            return e.getUint32(t = t || 0) * ys + e.getUint32(t + 4)
                                                        }(this.view, this.offset + 1), this.offset += 9, t;
                                                    case 208:
                                                        return t = this.view.getInt8(this.offset + 1), this.offset += 2, t;
                                                    case 209:
                                                        return t = this.view.getInt16(this.offset + 1), this.offset += 3, t;
                                                    case 210:
                                                        return t = this.view.getInt32(this.offset + 1), this.offset += 5, t;
                                                    case 211:
                                                        return t = function(e, t) {
                                                            return e.getInt32(t = t || 0) * ys + e.getUint32(t + 4)
                                                        }(this.view, this.offset + 1), this.offset += 9, t;
                                                    case 212:
                                                        return n = 1, this.offset++, this.ext(n);
                                                    case 213:
                                                        return n = 2, this.offset++, this.ext(n);
                                                    case 214:
                                                        return n = 4, this.offset++, this.ext(n);
                                                    case 215:
                                                        return n = 8, this.offset++, this.ext(n);
                                                    case 216:
                                                        return n = 16, this.offset++, this.ext(n);
                                                    case 217:
                                                        return n = this.view.getUint8(this.offset + 1), this.offset += 2, this.str(n);
                                                    case 218:
                                                        return n = this.view.getUint16(this.offset + 1), this.offset += 3, this.str(n);
                                                    case 219:
                                                        return n = this.view.getUint32(this.offset + 1), this.offset += 5, this.str(n);
                                                    case 220:
                                                        return n = this.view.getUint16(this.offset + 1), this.offset += 3, this.array(n);
                                                    case 221:
                                                        return n = this.view.getUint32(this.offset + 1), this.offset += 5, this.array(n);
                                                    case 222:
                                                        return n = this.view.getUint16(this.offset + 1), this.offset += 3, this.map(n);
                                                    case 223:
                                                        return n = this.view.getUint32(this.offset + 1), this.offset += 5, this.map(n)
                                                }
                                                throw new Error("Unknown type 0x" + e.toString(16))
                                            }, this.offset = t || 0, this.view = e
                                        }
                                    }(t),
                                    s = n.parse();
                                if (n.offset !== e.byteLength) throw new Error(e.byteLength - n.offset + " trailing bytes");
                                return s
                            },
                            inspect: function(e) {
                                if (void 0 === e) return "undefined";
                                let t, n;
                                if (e instanceof ArrayBuffer ? (n = "ArrayBuffer", t = new DataView(e)) : e instanceof DataView && (n = "DataView", t = e), !t) return JSON.stringify(e);
                                const s = [];
                                for (let n = 0; n < e.byteLength; n++) {
                                    if (n > 20) {
                                        s.push("...");
                                        break
                                    }
                                    let e = t.getUint8(n).toString(16);
                                    1 === e.length && (e = "0" + e), s.push(e)
                                }
                                return "<" + n + " " + s.join(" ") + ">"
                            },
                            utf8Write: ps,
                            utf8Read: fs,
                            utf8ByteCount: ms
                        },
                        Rs = {
                            XHRRequest: hs,
                            FetchRequest: async function(e, t, n, s, i, o) {
                                const r = new Headers(s || {}),
                                    a = e ? e.toUpperCase() : _(o) ? "GET" : "POST",
                                    c = new AbortController;
                                let l;
                                const h = new Promise(e => {
                                        l = setTimeout(() => {
                                            c.abort(), e({
                                                error: new S("Request timed out", null, 408)
                                            })
                                        }, t ? t.options.timeouts.httpRequestTimeout : Ee.TIMEOUTS.httpRequestTimeout)
                                    }),
                                    u = {
                                        method: a,
                                        headers: r,
                                        body: o,
                                        signal: c.signal
                                    };
                                y.Config.isWebworker || (u.credentials = r.has("authorization") ? "include" : "same-origin");
                                const d = (async () => {
                                    try {
                                        const e = new URLSearchParams(i || {});
                                        e.set("rnd", te());
                                        const t = n + "?" + e,
                                            s = await de().fetch(t, u);
                                        if (clearTimeout(l), 204 == s.status) return {
                                            error: null,
                                            statusCode: s.status
                                        };
                                        const o = s.headers.get("Content-Type");
                                        let r;
                                        r = o && o.indexOf("application/x-msgpack") > -1 ? await s.arrayBuffer() : o && o.indexOf("application/json") > -1 ? await s.json() : await s.text();
                                        const a = !!o && -1 === o.indexOf("application/x-msgpack"),
                                            c = function(e) {
                                                const t = {};
                                                return e.forEach((e, n) => {
                                                    t[n] = e
                                                }), t
                                            }(s.headers);
                                        if (s.ok) return {
                                            error: null,
                                            body: r,
                                            headers: c,
                                            unpacked: a,
                                            statusCode: s.status
                                        }; {
                                            const e = function(e, t) {
                                                if (function(e, t) {
                                                        return !!t.get("x-ably-errorcode")
                                                    }(0, t)) return e.error && k.fromValues(e.error)
                                            }(r, s.headers) || new S("Error response received from server: " + s.status + " body was: " + y.Config.inspect(r), null, s.status);
                                            return {
                                                error: e,
                                                body: r,
                                                headers: c,
                                                unpacked: a,
                                                statusCode: s.status
                                            }
                                        }
                                    } catch (e) {
                                        return clearTimeout(l), {
                                            error: e
                                        }
                                    }
                                })();
                                return Promise.race([h, d])
                            }
                        },
                        Is = function(e, t) {
                            class n {
                                constructor(e, t, n, s) {
                                    this.algorithm = e, this.keyLength = t, this.mode = n, this.key = s
                                }
                            }
                            class s {
                                static getDefaultParams(e) {
                                    var s;
                                    if (!e.key) throw new Error("Crypto.getDefaultParams: a key is required");
                                    s = "string" == typeof e.key ? t.toArrayBuffer(t.base64Decode(e.key.replace("_", "/").replace("-", "+"))) : e.key instanceof ArrayBuffer ? e.key : t.toArrayBuffer(e.key);
                                    var i = new n(e.algorithm || "aes", 8 * s.byteLength, e.mode || "cbc", s);
                                    if (e.keyLength && e.keyLength !== i.keyLength) throw new Error("Crypto.getDefaultParams: a keyLength of " + e.keyLength + " was specified, but the key actually has length " + i.keyLength);
                                    return function(e) {
                                        if ("aes" === e.algorithm && "cbc" === e.mode) {
                                            if (128 === e.keyLength || 256 === e.keyLength) return;
                                            throw new Error("Unsupported key length " + e.keyLength + " for aes-cbc encryption. Encryption key must be 128 or 256 bits (16 or 32 ASCII characters)")
                                        }
                                    }(i), i
                                }
                                static async generateRandomKey(t) {
                                    try {
                                        return e.getRandomArrayBuffer((t || 256) / 8)
                                    } catch (e) {
                                        throw new k("Failed to generate random key: " + e.message, 400, 5e4, e)
                                    }
                                }
                                static getCipher(e, t) {
                                    var s, o = function(e) {
                                        return e instanceof n
                                    }(e) ? e : this.getDefaultParams(e);
                                    return {
                                        cipherParams: o,
                                        cipher: new i(o, null != (s = e.iv) ? s : null, t)
                                    }
                                }
                            }
                            s.CipherParams = n;
                            class i {
                                constructor(e, n, s) {
                                    if (this.logger = s, !crypto.subtle) throw isSecureContext ? new Error("Crypto operations are not possible since the browser’s SubtleCrypto class is unavailable (reason unknown).") : new Error("Crypto operations are is not possible since the current environment is a non-secure context and hence the browser’s SubtleCrypto class is not available.");
                                    this.algorithm = e.algorithm + "-" + String(e.keyLength) + "-" + e.mode, this.webCryptoAlgorithm = e.algorithm + "-" + e.mode, this.key = t.toArrayBuffer(e.key), this.iv = n ? t.toArrayBuffer(n) : null
                                }
                                concat(e, n) {
                                    const s = new ArrayBuffer(e.byteLength + n.byteLength),
                                        i = new DataView(s),
                                        o = new DataView(t.toArrayBuffer(e));
                                    for (let e = 0; e < o.byteLength; e++) i.setInt8(e, o.getInt8(e));
                                    const r = new DataView(t.toArrayBuffer(n));
                                    for (let e = 0; e < r.byteLength; e++) i.setInt8(o.byteLength + e, r.getInt8(e));
                                    return s
                                }
                                async encrypt(e) {
                                    O.logAction(this.logger, O.LOG_MICRO, "CBCCipher.encrypt()", "");
                                    const t = await this.getIv(),
                                        n = await crypto.subtle.importKey("raw", this.key, this.webCryptoAlgorithm, !1, ["encrypt"]),
                                        s = await crypto.subtle.encrypt({
                                            name: this.webCryptoAlgorithm,
                                            iv: t
                                        }, n, e);
                                    return this.concat(t, s)
                                }
                                async decrypt(e) {
                                    O.logAction(this.logger, O.LOG_MICRO, "CBCCipher.decrypt()", "");
                                    const n = t.toArrayBuffer(e),
                                        s = n.slice(0, 16),
                                        i = n.slice(16),
                                        o = await crypto.subtle.importKey("raw", this.key, this.webCryptoAlgorithm, !1, ["decrypt"]);
                                    return crypto.subtle.decrypt({
                                        name: this.webCryptoAlgorithm,
                                        iv: s
                                    }, o, i)
                                }
                                async getIv() {
                                    if (this.iv) {
                                        var n = this.iv;
                                        return this.iv = null, n
                                    }
                                    const s = await e.getRandomArrayBuffer(16);
                                    return t.toArrayBuffer(s)
                                }
                            }
                            return s
                        }(os, Jn);
                    y.Crypto = Is, y.BufferUtils = Jn, y.Http = Zn, y.Config = os, y.Transports = ds, y.WebStorage = ns;
                    for (const e of [Lt, Pn]) e.Crypto = Is, e._MsgPack = Os;
                    Zn.bundledRequestImplementations = Rs, O.initLogHandlers(), y.Defaults = Object.assign(be, gs), y.Config.agent && (y.Defaults.agent += " " + y.Config.agent);
                    var ks = {
                        ErrorInfo: k,
                        Rest: Lt,
                        Realtime: Pn,
                        msgpack: Os
                    };
                    return "object" == typeof s.exports && "object" == typeof n && (s.exports = ((e, t, n, s) => {
                        if (t && "object" == typeof t || "function" == typeof t)
                            for (let n of Object.getOwnPropertyNames(t)) Object.prototype.hasOwnProperty.call(e, n) || void 0 === n || Object.defineProperty(e, n, {
                                get: () => t[n],
                                enumerable: !(s = Object.getOwnPropertyDescriptor(t, n)) || s.enumerable
                            });
                        return e
                    })(s.exports, n)), s.exports
                }, t.exports = s()
            }(n), n.exports
        }();
    const n = ["widgetShow", "videoSent", "callCreated"];
    class s {
        constructor({
            apiKey: e,
            orgId: t,
            leadId: n,
            messageToken: s,
            presenceToken: i
        }) {
            this.messageRealtime = void 0, this.messageChannel = void 0, this.presenceRealtime = void 0, this.presenceChannel = void 0, this.apiKey = void 0, this.orgId = void 0, this.leadId = void 0, this.messageToken = void 0, this.presenceToken = void 0, this.didAnnouncePresence = !1, this.apiKey = e, this.orgId = t, this.leadId = n, this.messageToken = s, this.presenceToken = i
        }
        createPresenceChannel() {
            const e = this;
            if (!this.presenceToken) throw Error("Trying to use presence without a valid token");
            return new t.Realtime({
                token: this.presenceToken,
                logLevel: 0,
                authCallback: function(t, n) {
                    try {
                        return Promise.resolve(fetch(`https://api.getripe.com/core-backend/auth/ably/sdk/${e.leadId}/presence`, {
                            method: "GET",
                            headers: {
                                Authorization: `Basic ${btoa(e.apiKey)}`
                            }
                        })).then(function(e) {
                            if (200 === e.status) return Promise.resolve(e.json()).then(function(e) {
                                n(null, e.token)
                            });
                            n("Failed to fetch new Ably token", null)
                        })
                    } catch (e) {
                        return Promise.reject(e)
                    }
                }
            })
        }
        createMessageChannel(e) {
            const n = this;
            return new t.Realtime({
                token: this.messageToken,
                logLevel: 0,
                authCallback: function(t, s) {
                    try {
                        return Promise.resolve(fetch(`https://api.getripe.com/core-backend/auth/ably/sdk/${n.leadId}/message${e?"/anonymous":""}`, {
                            method: "GET",
                            headers: {
                                Authorization: `Basic ${btoa(n.apiKey)}`
                            }
                        })).then(function(e) {
                            if (200 === e.status) return Promise.resolve(e.json()).then(function(e) {
                                s(null, e.token)
                            });
                            s("Failed to fetch new Ably token", null)
                        })
                    } catch (e) {
                        return Promise.reject(e)
                    }
                }
            })
        }
        close() {
            this.messageRealtime ? .close(), this.presenceRealtime ? .close()
        }
        announcePresence(e) {
            try {
                const t = this;
                return t.didAnnouncePresence ? Promise.resolve() : (t.presenceRealtime || (t.presenceRealtime = t.createPresenceChannel()), t.presenceChannel = t.presenceRealtime ? .channels.get(`${t.orgId}-presence`, {
                    modes: ["PRESENCE"]
                }), Promise.resolve(t.presenceChannel ? .presence.get({
                    clientId: t.leadId
                })).then(function(n) {
                    if (0 === n ? .length) return Promise.resolve(t.presenceChannel ? .presence.enterClient(t.leadId, {
                        blockedPath: e
                    })).then(function() {
                        t.didAnnouncePresence = !0
                    })
                }))
            } catch (e) {
                return Promise.reject(e)
            }
        }
        updatePresence(e) {
            try {
                const t = this;
                return t.didAnnouncePresence ? (t.presenceChannel ? .presence.updateClient(t.leadId, {
                    blockedPath: e
                }), Promise.resolve()) : Promise.resolve()
            } catch (e) {
                return Promise.reject(e)
            }
        }
        waitForDeAnonymizationEvent() {
            try {
                const e = this;
                return e.messageRealtime || (e.messageRealtime = e.createMessageChannel(!0)), e.messageChannel = e.messageRealtime ? .channels.get(`${e.orgId}-anonymous`, {
                    modes: ["SUBSCRIBE"]
                }), Promise.resolve(new Promise(t => {
                    e.messageChannel ? .subscribe({
                        name: "leadDeAnonymized",
                        clientId: e.leadId
                    }, function(n) {
                        try {
                            return n.data ? .lead ? .id && t({
                                leadId: n.data.lead.id,
                                messageToken: n.data.ablyTokens.messageToken,
                                presenceToken: n.data.ablyTokens.presenceToken
                            }), Promise.resolve(e.messageChannel ? .detach()).then(function() {})
                        } catch (e) {
                            return Promise.reject(e)
                        }
                    })
                }))
            } catch (e) {
                return Promise.reject(e)
            }
        }
        waitForShowWidgetEvents() {
            try {
                const e = this;
                return e.messageRealtime || (e.messageRealtime = e.createMessageChannel(!1)), e.messageChannel = e.messageRealtime ? .channels.get(`${e.orgId}`, {
                    modes: ["SUBSCRIBE"]
                }), Promise.resolve(new Promise(t => {
                    n.forEach(n => {
                        e.messageChannel ? .subscribe({
                            name: n,
                            clientId: e.leadId
                        }, () => {
                            e.messageRealtime ? .close(), t(!0)
                        })
                    })
                }))
            } catch (e) {
                return Promise.reject(e)
            }
        }
    }
    const i = "https://api.getripe.com/core-backend",
        o = (e, t) => {
            l("/log/sdk", e, t).catch()
        },
        r = function(e) {
            try {
                return Promise.resolve((e => h(`lead/widget/path-allowed?url=${window.location.href}`, e))(e)).then(function(e) {
                    return !!e.ok && e.json()
                })
            } catch (e) {
                return Promise.reject(e)
            }
        },
        a = function(e, t, n) {
            try {
                return Promise.resolve(((e, t, n) => l("organization/settings/sdk", e, {
                    userId: t,
                    anonId: n,
                    url: window.location.href
                }))(e, t, n)).then(function(e) {
                    if (!e.ok) throw Error(e.statusText);
                    return Promise.resolve(e.json())
                })
            } catch (e) {
                return Promise.reject(e)
            }
        },
        c = (e, t, n) => fetch(`${i}/${e}`, {
            method: "POST",
            credentials: "include",
            headers: {
                Authorization: `Basic ${btoa(t)}`,
                "Content-Type": "application/json",
                "x-ripe-requestid": crypto.randomUUID()
            },
            body: JSON.stringify({ ...n,
                messageId: n.messageId ? ? `ripesdk-${crypto.randomUUID()}`,
                timestamp: new Date
            })
        }),
        l = (e, t, n) => fetch(`${i}/${e}`, {
            method: "POST",
            credentials: "include",
            headers: {
                Authorization: `Basic ${btoa(t)}`,
                "Content-Type": "application/json",
                "x-ripe-requestid": crypto.randomUUID()
            },
            body: JSON.stringify(n)
        }),
        h = (e, t) => fetch(`${i}/${e}`, {
            method: "GET",
            credentials: "include",
            headers: {
                Authorization: `Basic ${btoa(t)}`,
                "Content-Type": "application/json",
                "x-ripe-requestid": crypto.randomUUID()
            },
            cache: "no-cache"
        }),
        u = "ripe-widget-script";
    var d;
    ! function(e) {
        e.ANONYMOUS_ID_KEY = "ripe_anonymous_id", e.USER_ID_KEY = "ripe_user_id", e.GROUP_ID_KEY = "ripe_group_id", e.LEAD_ID_KEY = "ripe_lead_id", e.WIDGET_HIDDEN = "ripe_widget_hidden", e.API_KEY = "ripe_api_key"
    }(d || (d = {}));
    const g = e => window.localStorage.getItem(e) || window.sessionStorage.getItem(e) || void 0,
        p = (e, t) => {
            window.localStorage.setItem(e, t)
        },
        f = e => {
            window.localStorage.removeItem(e)
        },
        m = (e, {
            anonymousId: t,
            userId: n,
            groupId: s,
            leadId: i
        }) => {
            t && e.anonymousId !== t && (e.anonymousId = t, p(d.ANONYMOUS_ID_KEY, t)), null === n ? (e.userId = void 0, f(d.USER_ID_KEY)) : n && e.userId !== n && (e.userId = n, p(d.USER_ID_KEY, n)), null === s ? (e.groupId = void 0, f(d.GROUP_ID_KEY)) : s && e.groupId !== s && (e.groupId = s, p(d.GROUP_ID_KEY, s)), null === i ? (e.leadId = void 0, f(d.LEAD_ID_KEY)) : i && e.leadId !== i && (e.leadId = i, p(d.LEAD_ID_KEY, i))
        },
        y = e => ({
            messageId: t,
            userId: n,
            groupId: s,
            anonymousId: i,
            traits: o,
            context: r
        } = {
            groupId: ""
        }) => e.initialized ? s ? (m(e, {
            userId: n,
            groupId: s,
            anonymousId: i
        }), e._queue.enqueue(function() {
            try {
                return Promise.resolve((n = e.apiKey, i = {
                    traits: o,
                    messageId: t,
                    groupId: s,
                    userId: e.userId,
                    anonymousId: e.anonymousId,
                    context: { ...r,
                        page: {
                            url: window.location.href,
                            path: window.location.pathname,
                            search: window.location.search,
                            referrer: document.referrer,
                            title: document.title
                        }
                    }
                }, c("group", n, { ...i,
                    type: "group"
                }))).then(function() {})
            } catch (e) {
                return Promise.reject(e)
            }
            var n, i
        }), e) : (console.error("Missing groupId in group call."), e) : (console.warn("Ripe is not initialized"), e),
        v = e => ({
            messageId: t,
            userId: n,
            groupId: s,
            anonymousId: i,
            traits: o,
            context: r
        } = {}) => e.initialized ? (m(e, {
            userId: n,
            groupId: s,
            anonymousId: i
        }), e._queue.enqueue(function() {
            try {
                return Promise.resolve((n = e.apiKey, s = {
                    traits: o,
                    messageId: t,
                    userId: e.userId,
                    anonymousId: e.anonymousId,
                    context: { ...r,
                        groupId: e.groupId,
                        page: {
                            url: window.location.href,
                            path: window.location.pathname,
                            search: window.location.search,
                            referrer: document.referrer,
                            title: document.title
                        }
                    }
                }, c("identify", n, { ...s,
                    type: "identify"
                }))).then(function() {})
            } catch (e) {
                return Promise.reject(e)
            }
            var n, s
        }), e) : (console.warn("Ripe is not initialized"), e),
        w = e => ({
            messageId: t,
            userId: n,
            groupId: s,
            anonymousId: i,
            category: o,
            name: r,
            properties: a,
            context: l
        } = {}) => e.initialized ? (m(e, {
            userId: n,
            groupId: s,
            anonymousId: i
        }), e._queue.enqueue(function() {
            try {
                return Promise.resolve((n = e.apiKey, s = {
                    messageId: t,
                    anonymousId: e.anonymousId,
                    userId: e.userId,
                    context: { ...l,
                        groupId: e.groupId,
                        page: {
                            url: window.location.href,
                            path: window.location.pathname,
                            search: window.location.search,
                            referrer: document.referrer,
                            title: document.title
                        }
                    },
                    category: o,
                    properties: {
                        url: window.location.href,
                        path: window.location.pathname,
                        search: window.location.search,
                        referrer: document.referrer,
                        title: document.title,
                        ...a
                    },
                    name: r ? ? document.title
                }, c("page", n, { ...s
                }))).then(function() {})
            } catch (e) {
                return Promise.reject(e)
            }
            var n, s
        }), e) : (console.warn("Ripe is not initialized"), e),
        b = () => {
            const e = crypto.randomUUID();
            return p(d.ANONYMOUS_ID_KEY, e), e
        },
        C = e => ({
            messageId: t,
            userId: n,
            groupId: s,
            anonymousId: i,
            event: o,
            properties: r,
            context: a
        } = {
            event: ""
        }) => e.initialized ? o ? (m(e, {
            userId: n,
            groupId: s,
            anonymousId: i
        }), e._queue.enqueue(function() {
            try {
                return Promise.resolve((n = e.apiKey, s = {
                    event: o,
                    messageId: t,
                    properties: r,
                    anonymousId: e.anonymousId,
                    userId: e.userId,
                    context: { ...a,
                        groupId: e.groupId,
                        page: {
                            url: window.location.href,
                            path: window.location.pathname,
                            search: window.location.search,
                            referrer: document.referrer,
                            title: document.title
                        }
                    }
                }, c("track", n, { ...s
                }))).then(function() {})
            } catch (e) {
                return Promise.reject(e)
            }
            var n, s
        }), e) : (console.error("Missing or bad event name in track call."), e) : (console.warn("Ripe is not initialized"), e);
    class O {
        constructor() {
            this.ready = void 0, this.queue = [], this.ready = !1
        }
        enqueue(e) {
            this.queue.push(e), this.dequeue()
        }
        startConsuming() {
            this.ready = !0, this.dequeue()
        }
        dequeue() {
            try {
                const e = this;
                if (!e.ready) return Promise.resolve();
                const t = e.queue.shift();
                if (!t) return Promise.resolve();
                const n = function(n, s) {
                    try {
                        var i = function(n, s) {
                            try {
                                var i = (e.ready = !1, Promise.resolve(t()).then(function() {}))
                            } catch (e) {
                                return s(e)
                            }
                            return i && i.then ? i.then(void 0, s) : i
                        }(0, function(e) {
                            console.error("Ripe error:", e)
                        })
                    } catch (e) {
                        return s(!0, e)
                    }
                    return i && i.then ? i.then(s.bind(null, !1), s.bind(null, !0)) : s(!1, i)
                }(0, function(t, n) {
                    if (e.ready = !0, e.dequeue(), t) throw n;
                    return n
                });
                return Promise.resolve(n && n.then ? n.then(function() {}) : void 0)
            } catch (e) {
                return Promise.reject(e)
            }
        }
    }
    const R = function(e, t) {
            const n = Array.prototype.slice.call(t),
                s = n.shift();
            e[s] ? e[s](...n) : console.log("Ripe does not have a " + s + " function")
        },
        I = function(e) {
            if (window.Ripe ? .length)
                for (const t of window.Ripe) R(e, t)
        },
        k = (e, t = 50) => {
            let n = window.location.pathname;
            setInterval(function() {
                try {
                    const t = function() {
                        if (window.location.pathname !== n) return n = window.location.pathname, Promise.resolve(e()).then(function() {})
                    }();
                    return Promise.resolve(t && t.then ? t.then(function() {}) : void 0)
                } catch (e) {
                    return Promise.reject(e)
                }
            }, t)
        };

    function S(e, t) {
        try {
            var n = e()
        } catch (e) {
            return t(e)
        }
        return n && n.then ? n.then(void 0, t) : n
    }
    return function(e) {
        const t = {};
        let n = !0;
        t.init = function(i) {
            if (t.initialized) return console.warn("Ripe already initialized :)"), this;
            if (!i || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(i)) return console.error("Missing or invalid API Key"), this;
            const c = g(d.API_KEY);
            c && c !== i ? (f(d.USER_ID_KEY), f(d.GROUP_ID_KEY), f(d.ANONYMOUS_ID_KEY), f(d.LEAD_ID_KEY)) : c || p(d.API_KEY, i), t._queue = new O, t.anonymousId = g(d.ANONYMOUS_ID_KEY) ? ? b(), t.userId = g(d.USER_ID_KEY), t.groupId = g(d.GROUP_ID_KEY), t.apiKey = i, t.initialized = !0;
            const l = {};
            return a(i, t.userId, t.anonymousId).finally(() => {
                t._queue.startConsuming()
            }).then(function({
                orgId: a,
                leadId: c,
                anonymous: g,
                autoTrack: p,
                messageToken: m,
                presenceToken: y,
                blockedPath: v
            }) {
                try {
                    let b;

                    function w(s) {
                        if (b) return s;

                        function a() {
                            return k(function() {
                                try {
                                    return Promise.resolve(r(t.apiKey)).then(function(s) {
                                        const r = !s,
                                            a = function() {
                                                if (n !== r) {
                                                    const s = S(function() {
                                                        return Promise.resolve(C.updatePresence(r)).then(function() {
                                                            n = r
                                                        })
                                                    }, function(s) {
                                                        o(i, {
                                                            level: "warn",
                                                            message: "Error updating presence on path change",
                                                            vars: {
                                                                anonymousId: t.anonymousId,
                                                                userId: t.userId,
                                                                leadId: t.leadId,
                                                                blockedPath: n,
                                                                href: e.location.href,
                                                                ...l
                                                            },
                                                            error: s
                                                        })
                                                    });
                                                    if (s && s.then) return s.then(function() {})
                                                }
                                            }();
                                        if (a && a.then) return a.then(function() {})
                                    })
                                } catch (e) {
                                    return Promise.reject(e)
                                }
                            }), Promise.resolve(function(e, t) {
                                try {
                                    return Promise.resolve(((e, t) => h(`lead/widget/visibility/${e}`, t))(t, e)).then(function(e) {
                                        if (!e.ok) throw new Error("Unable to load widget");
                                        return Promise.resolve(e.json()).then(function(e) {
                                            return e.showWidget
                                        })
                                    })
                                } catch (e) {
                                    return Promise.reject(e)
                                }
                            }(i, t.leadId)).then(function(s) {
                                let r;

                                function a(e) {
                                    return r ? e : Promise.resolve(function() {
                                        try {
                                            const e = function() {
                                                if (!document.getElementById(u)) return Promise.resolve(Promise.resolve(function(e) {
                                                    try {
                                                        return Promise.resolve(fetch("https://storage.getripe.com/widget%2Fversion.txt?alt=media")).then(function(e) {
                                                            return e.text()
                                                        })
                                                    } catch (e) {
                                                        return Promise.reject(e)
                                                    }
                                                }()).then(function(e) {
                                                    return `https://storage.getripe.com/widget%2F${e}%2Fwidget.umd.js?alt=media`
                                                })).then(function(e) {
                                                    (e => {
                                                        const t = document.createElement("script"),
                                                            n = document.getElementsByTagName("script")[0];
                                                        t.async = !0, t.src = e, t.id = u, n ? .parentNode ? .insertBefore(t, n)
                                                    })(e)
                                                })
                                            }();
                                            return Promise.resolve(e && e.then ? e.then(function() {}) : void 0)
                                        } catch (e) {
                                            return Promise.reject(e)
                                        }
                                    }()).then(function() {})
                                }
                                const c = function() {
                                    if (!s) {
                                        const s = S(function() {
                                            return Promise.resolve(C.waitForShowWidgetEvents()).then(function() {
                                                f(d.WIDGET_HIDDEN)
                                            })
                                        }, function(s) {
                                            o(i, {
                                                level: "warn",
                                                message: "Error waiting for showWidgetEvents",
                                                vars: {
                                                    anonymousId: t.anonymousId,
                                                    userId: t.userId,
                                                    leadId: t.leadId,
                                                    blockedPath: n,
                                                    href: e.location.href,
                                                    ...l
                                                },
                                                error: s
                                            }), r = 1
                                        });
                                        if (s && s.then) return s.then(function() {})
                                    }
                                }();
                                return c && c.then ? c.then(a) : a(c)
                            })
                        }
                        const c = S(function() {
                            return Promise.resolve(C.announcePresence(v)).then(function() {})
                        }, function(s) {
                            o(i, {
                                level: "warn",
                                message: "Error announcing presence",
                                vars: {
                                    anonymousId: t.anonymousId,
                                    userId: t.userId,
                                    leadId: t.leadId,
                                    blockedPath: n,
                                    href: e.location.href,
                                    ...l
                                },
                                error: s
                            })
                        });
                        return c && c.then ? c.then(a) : a()
                    }
                    t.leadId = c, n = v, l.anonymous = g, l.orgId = a;
                    let C = new s({
                        orgId: a,
                        apiKey: i,
                        leadId: c,
                        messageToken: m,
                        presenceToken: y
                    });
                    p && k(() => e.Ripe.page());
                    const O = function() {
                        if (g) {
                            const r = S(function() {
                                return Promise.resolve(C.waitForDeAnonymizationEvent()).then(function(e) {
                                    t.leadId = e.leadId, C.close(), C = new s({
                                        orgId: a,
                                        apiKey: i,
                                        leadId: t.leadId,
                                        presenceToken: e.presenceToken,
                                        messageToken: e.messageToken
                                    })
                                })
                            }, function(s) {
                                o(i, {
                                    level: "warn",
                                    message: "Error waiting for deAnonymizationEvent",
                                    vars: {
                                        anonymousId: t.anonymousId,
                                        userId: t.userId,
                                        leadId: t.leadId,
                                        blockedPath: n,
                                        href: e.location.href,
                                        ...l
                                    },
                                    error: s
                                }), b = 1
                            });
                            if (r && r.then) return r.then(function() {})
                        }
                    }();
                    return Promise.resolve(O && O.then ? O.then(w) : w(O))
                } catch (R) {
                    return Promise.reject(R)
                }
            }).catch(function(s) {
                try {
                    return o(i, {
                        message: "Error in SDK",
                        level: "error",
                        error: s,
                        vars: {
                            anonymousId: t.anonymousId,
                            userId: t.userId,
                            leadId: t.leadId,
                            blockedPath: n,
                            href: e.location.href,
                            ...l
                        }
                    }), Promise.resolve()
                } catch (e) {
                    return Promise.reject(e)
                }
            }), this
        }, t.identify = v(t), t.group = y(t), t.track = C(t), t.page = w(t), t.reset = (e => () => (f(d.USER_ID_KEY), f(d.GROUP_ID_KEY), f(d.ANONYMOUS_ID_KEY), f(d.LEAD_ID_KEY), e.userId = void 0, e.groupId = void 0, e.anonymousId = b(), e))(t);
        let i = !1;
        t.push = e => {
            i || (console.warn("Are you calling a reference to Ripe instead of calling window.Ripe? If so you may be missing out on functionality."), i = !0), R(t, e)
        }, I(t), e.Ripe = t
    }(window)
});