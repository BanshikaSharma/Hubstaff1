import {
    c as g
} from "./base-543c3a70.js";
import {
    cM as c,
    cI as o,
    cN as E,
    Y as f,
    cO as h
} from "./shared-5f1b437f.js";
import {
    k as T,
    B as _,
    V as u,
    bq as p
} from "./vendor-f5db2be7.js";
import {
    s as S,
    a as b,
    b as A,
    c as y
} from "./mutations-2c62a19a.js";
const I = {
        async loadData({
            commit: e,
            state: i,
            getters: a
        }) {
            const s = "initial";
            try {
                e("SET_WIDGET_LOADING", {
                    key: s,
                    status: !0
                });
                const t = new URL(window.location.href).searchParams.get("time_zone");
                let d, l = i.user_id,
                    n = {};
                if (a.canSeeTeam) {
                    const m = new URL(window.location.href).searchParams;
                    d = m.has("team_id") ? m.get("team_id") : null, d === null && a.isTeamLead && a.teamsTotal && (d = a.teams[0].id), l = m.has("user_id") && !d ? m.get("user_id") : d ? null : "all"
                }
                n = { ...i.filters,
                    user_id: l,
                    time_zone: t,
                    team_id: d
                }, e("UPDATE_STATE", {
                    filters: n
                }), e("UPDATE_DASHBOARD_TYPE"), e("SET_QUERY")
            } catch (r) {
                throw new Error("Unable to fetch data for insights", r)
            } finally {
                e("SET_WIDGET_LOADING", {
                    key: s,
                    status: !1
                })
            }
        },
        async loadUsersAndTeams({
            commit: e,
            getters: i,
            state: a,
            dispatch: s
        }) {
            const r = "initial";
            if (i.canSeeTeam) try {
                e("SET_NAVIGATION_LOADING", {
                    key: r,
                    status: !0
                });
                const t = await c.load({
                    organizationId: a.organization.id
                });
                t && t.users && e("UPDATE_STATE", {
                    teams: {
                        total: t.teams.total_team_count,
                        teams: t.teams.teams
                    },
                    users: {
                        total: t.total_user_count,
                        users: a.lazy_members_select ? a.users.users : t.users
                    }
                })
            } catch (t) {
                throw new Error("Unable to fetch users for insights", t)
            } finally {
                e("SET_NAVIGATION_LOADING", {
                    key: r,
                    status: !1
                })
            }
        },
        setTimeZoneOptions({
            commit: e
        }, i) {
            e("SET_TIMEZONE_OPTIONS", i)
        },
        setActiveTimeZone({
            commit: e
        }, i) {
            e("SET_ACTIVE_TIMEZONE", i)
        },
        setSelectedFilter({
            commit: e
        }, i) {
            e("SET_SELECTED_FILTER", i)
        },
        setFilter({
            commit: e,
            dispatch: i,
            getters: a,
            state: s
        }, {
            key: r,
            value: t,
            filterQuery: d,
            multiple: l
        }) {
            e("SET_FILTER", {
                key: r,
                value: t,
                filterQuery: d,
                multiple: l
            }), e("UPDATE_DASHBOARD_TYPE"), e("SET_QUERY"), i("fetchBenchmarksAveragesLegend"), [o.api.highlights.workTimeClassification, o.api.highlights.activity, o.api.utilization, o.api.focusTime, o.api.meetings, o.api.collaborations, o.api.performanceHighlights, o.api.smartNotifications].forEach(n => {
                i("fetchWidgets", {
                    widgetKey: n
                })
            }), [o.api.ranking.categories].forEach(n => {
                i("fetchWidgets", {
                    widgetKey: n,
                    extraQueryParams: {
                        limit: o.parameters.rankingLimit
                    }
                })
            }), a.showOutputTab && [o.api.gitHubIntegration.hosting, o.api.gitHubIntegration.table].forEach(n => {
                i("fetchWidgets", {
                    widgetKey: n,
                    extraQueryParams: {
                        integration_type: "github"
                    }
                })
            }), [o.api.workTimeExpenditure].forEach(n => {
                i("fetchWidgets", {
                    widgetKey: n,
                    extraQueryParams: {
                        limit: o.parameters.workTimeExpenditureLimit
                    }
                })
            }), [o.api.highlights.tools].forEach(n => {
                i("fetchWidgets", {
                    widgetKey: n,
                    extraQueryParams: {
                        limit: o.parameters.highlightsRankingLimit
                    }
                })
            }), a.isAllMembersDashboard || [o.api.ranking.projects, o.api.ranking.tasks].forEach(n => {
                i("fetchWidgets", {
                    widgetKey: n,
                    extraQueryParams: {
                        limit: o.parameters.rankingLimit
                    }
                })
            }), a.isTeamDashboard && a.canSeeTeam && i("fetchWidgets", {
                widgetKey: "leaderboard"
            }), a.canSeeTeam && [o.api.unusualActivity.team].forEach(n => {
                i("fetchWidgets", {
                    widgetKey: n,
                    extraQueryParams: {
                        limit: o.parameters.unusualActivityLimit
                    }
                })
            })
        },
        setFullyLoaded({
            commit: e
        }, i) {
            e("SET_FULLY_LOADED", i)
        },
        setTimelineFilters({
            commit: e,
            state: i
        }, {
            from: a,
            to: s
        }) {
            const r = i.filters.date && i.filters.date.period !== "month" ? i.filters.date.period : "week";
            e("SET_TIMELINE_FILTERS", {
                from: a,
                to: s,
                period: r
            })
        },
        async enableMonitoringURLs({
            state: e
        }, {
            params: i
        }) {
            const a = "Unable to add the 'Monitoring URLs' addon";
            try {
                const s = await E.monitoring({
                    id: e.organization.id
                }, i);
                return s && s.success ? Promise.resolve(s) : Promise.reject(a)
            } catch {
                return Promise.reject(a)
            }
        },
        async enableAppsAndURLs({
            state: e
        }, {
            params: i
        }) {
            const a = "Unable to configure the Apps & URLs' settings";
            try {
                const s = await E.app_urls({
                    id: e.organization.id
                }, i);
                return s && s.success ? Promise.resolve(s) : Promise.reject(a)
            } catch {
                return Promise.reject(a)
            }
        },
        fetchTimeline({
            dispatch: e,
            state: i
        }) {
            const {
                from: a,
                to: s,
                period: r
            } = i.filters.timeline;
            e("fetchWidgets", {
                widgetKey: o.api.timeline,
                extraQueryParams: {
                    from: a,
                    to: s,
                    period: r
                }
            })
        },
        toggleNavigationSidebar({
            commit: e
        }) {
            e("TOGGLE_NAVIGATION_SIDEBAR")
        },
        setFilterQueryValue({
            commit: e
        }, {
            key: i,
            value: a
        }) {
            e("SET_FILTER_QUERY", {
                key: i,
                value: a
            })
        },
        setPreviousView({
            commit: e,
            state: i,
            getters: a
        }, {
            previousView: s,
            currentView: r
        }) {
            let t = i.previousView;
            (s != null && s.includes("all_user_id") || s != null && s.includes("team")) && (t = s), r.includes("all") && (t = null), e("SET_PREVIOUS_DASHBOARD", t)
        },
        async fetchEngagementScores({
            commit: e,
            state: i,
            getters: a
        }, {
            users: s
        } = {
            users: null
        }) {
            var r, t, d;
            if (a.engagementFlagEnabled) {
                let l;
                if (a.lazyMembersSelect ? (s || e("CLEAR_ENGAGEMENT_SCORES"), l = [...a.teams.map(n => n.team_member_ids).flat(), ...(s == null ? void 0 : s.map(n => n.id)) || []]) : l = (r = a.users) == null ? void 0 : r.map(n => n.id), a.canSeeTeam && (l != null && l.length) && i.query) {
                    const n = {
                        date_from: (t = i.query) == null ? void 0 : t.from,
                        date_to: (d = i.query) == null ? void 0 : d.to,
                        user_ids: l
                    };
                    e("SET_ENGAGEMENT_LOADING", !0);
                    try {
                        const m = await c.engagementScores({
                            organizationId: i.organization.id
                        }, n);
                        m && (e("SET_ENGAGEMENT_SCORES", m.scores), e("SET_ENGAGEMENT_EMPTY_REASONS", m.empty_reasons))
                    } catch (m) {
                        throw new Error("Unable to fetch engagement scores", m)
                    } finally {
                        e("SET_ENGAGEMENT_LOADING", !1)
                    }
                }
            }
        },
        setPaginatedUsers({
            commit: e,
            state: i
        }, {
            users: a,
            page: s
        }) {
            s > 1 ? e("UPDATE_STATE", {
                users: {
                    users: [...i.users.users || [], ...a]
                }
            }) : e("UPDATE_STATE", {
                users: {
                    users: a
                }
            })
        },
        setPaginatedItems({
            commit: e,
            state: i
        }, {
            items: a,
            page: s
        }) {
            s > 1 ? e("UPDATE_STATE", {
                items: [...i.items || [], ...a]
            }) : e("UPDATE_STATE", {
                items: a
            })
        }
    },
    D = {
        timeZoneOptions: e => e.tz_options,
        dashboardType: e => e.dashboard_type,
        isAllMembersDashboard: e => e.dashboard_type === "team" && e.filters.team_id === null && e.filters.user_id === "all",
        isIndividualTeamDashboard: (e, i) => !i.isAllMembersDashboard && e.dashboard_type === "team",
        isUserDashboard: e => e.dashboard_type === "individual",
        currentDashboard: (e, i) => i.isAllMembersDashboard ? "all" : e.dashboard_type,
        activeTimeZone: (e, i) => {
            var r;
            return T(e.filters.time_zone) || e.filters.time_zone.trim().length === 0 ? e.organization.time_zone : ((r = i.timeZoneOptions) == null ? void 0 : r.find(t => t.for === e.filters.time_zone)) || e.organization.time_zone
        },
        isTimeZoneDropDownAvailable: (e, i) => {
            var a, s;
            return ((s = (a = e.filters) == null ? void 0 : a.date) == null ? void 0 : s.period) === "day" && e.filters.user_id && e.filters.user_id !== "all" && i.timeZoneOptions[0].abbr !== i.timeZoneOptions[1].abbr
        },
        currentTimePeriod: e => {
            var i;
            return ((i = o.filters.date.find(a => {
                var s;
                return a.id === ((s = e.filters.date) == null ? void 0 : s.id)
            })) == null ? void 0 : i.text) || null
        },
        isDayTimePeriod: e => {
            var i;
            return ((i = e.filters.date) == null ? void 0 : i.period) === "day"
        },
        isTodayTimePeriod: (e, i) => {
            var a;
            return i.isDayTimePeriod && ((a = e.filters.date) == null ? void 0 : a.id) === "this-day"
        },
        users: e => {
            var i;
            return (i = e.users) != null && i.users ? [...e.users.users].sort((a, s) => a.name.localeCompare(s.name)) : []
        },
        usersTotal: e => {
            var i;
            return ((i = e.users) == null ? void 0 : i.total) || 0
        },
        teams: e => {
            var i;
            return ((i = e.teams) == null ? void 0 : i.teams) || []
        },
        teamsTotal: e => {
            var i;
            return ((i = e.teams) == null ? void 0 : i.total) || 0
        },
        hasUsers: e => !!(e.users.users && e.users.users.length),
        timeline: e => _(e, "widgets.productivity_timeline", []),
        leaderboard: e => _(e, "widgets.leaderboard", {}),
        utilization: e => _(e, "widgets.utilization_new", {}),
        gitHosting: e => _(e, "widgets.git_hostings", {}),
        smartNotifications: e => _(e, "widgets.smart_notifications", []),
        gitHostingTable: e => _(e, "widgets.git_hostings_table", {}),
        workTimeExpenditure: e => _(e, "widgets.work_time_expenditure", {}),
        collaborations: e => _(e, "widgets.collaborations", {}),
        performanceHighlights: e => _(e.widgets, o.api.performanceHighlights, null),
        collaborationsUnavailable: (e, i) => {
            var a;
            return ((a = i.collaborations) == null ? void 0 : a.collaboration_integration_status) === "unavailable"
        },
        startWeekOn: e => e.organization.start_week_on,
        addonsUrl: e => e.addons_url,
        billingUrl: e => e.billing_url,
        canManageSettings: e => e.can_manage_settings,
        isOwner: e => e.is_owner,
        isManager: e => e.can_manage_settings && !e.is_owner,
        plansUrl: e => e.plans_url,
        monitoringAddonEnabled: e => !!e.monitoring_addon_enabled,
        planOkForAppTracking: e => !!e.plan_ok_for_app_tracking,
        appTrackingUsed: e => !!e.app_tracking_used,
        organizationId: e => e.organization.id,
        showAlert: e => e.show_alert,
        showNavigationSidebar: e => e.showNavigationSidebar,
        previousDashboardId: e => {
            var i;
            return ((i = e.previousView) == null ? void 0 : i.split("_")[0]) || null
        },
        currentDashboardId: e => {
            var i;
            return ((i = e.selectedFilter) == null ? void 0 : i.split("_")[0]) || null
        },
        currentDashboardUser: (e, i) => {
            var a;
            return i.isUserDashboard ? (a = i.users) == null ? void 0 : a.find(s => {
                var r;
                return `${s.id}` === ((r = e.filters) == null ? void 0 : r.user_id)
            }) : null
        },
        currentUserBelongsToPrevTeam: (e, i) => {
            var a;
            return i.currentDashboardUser ? (a = i.currentDashboardUser.team_ids) == null ? void 0 : a.includes(parseInt(i.previousDashboardId)) : null
        },
        previousDashboardIsIndividualTeam: e => {
            var i, a;
            return ((i = e.previousView) == null ? void 0 : i.includes("team")) && !((a = e.previousView) != null && a.includes("all")) || null
        },
        previousDashboardTeamName: (e, i) => i.previousDashboardIsIndividualTeam ? i.teams.find(a => `${a.id}` === i.previousDashboardId).name : null,
        engagementFlagEnabled: e => e.engagement_score_enabled,
        showOutputTab: e => e.github_widget_enabled,
        insightsAvailable: e => e.insights_available,
        lazyMembersSelect: e => e.lazy_members_select
    },
    N = {
        SET_QUERY(e) {
            const i = {
                from: _(e, "filters.date.from", null),
                to: _(e, "filters.date.to", null),
                period: _(e, "filters.date.period", null),
                time_zone: _(e, "filters.time_zone", null)
            };
            e.dashboard_type === "individual" && e.filters.user_id ? e.query = { ...i,
                user_id: e.filters.user_id
            } : e.dashboard_type === "team" && e.filters.team_id ? e.query = { ...i,
                team_id: e.filters.team_id
            } : e.query = i
        },
        SET_TIMELINE_FILTERS(e, {
            from: i,
            to: a,
            period: s
        }) {
            u.set(e.filters, "timeline", {
                from: i,
                to: a,
                period: s
            })
        },
        SET_SELECTED_FILTER(e, i) {
            u.set(e, "selectedFilter", i)
        },
        SET_FILTER(e, {
            key: i,
            value: a,
            filterQuery: s,
            multiple: r
        }) {
            if (r && s) {
                Object.keys(s).forEach(t => {
                    u.set(e.filters, t, s[t])
                });
                return
            }
            u.set(e.filters, i, a)
        },
        SET_TIMEZONE_OPTIONS(e, i) {
            u.set(e, "tz_options", i)
        },
        SET_ACTIVE_TIMEZONE(e, i) {
            u.set(e, "active_tz", i)
        },
        UPDATE_DASHBOARD_TYPE(e) {
            const i = ["all", null].includes(e.filters.user_id) && e.can_see_team ? "team" : "individual";
            e.dashboard_type !== i && (e.dashboard_type = i)
        },
        SET_FULLY_LOADED(e, {
            widgetName: i,
            value: a
        }) {
            u.set(e.widgets[i], "isFullyLoaded", a)
        },
        TOGGLE_NAVIGATION_SIDEBAR(e) {
            e.showNavigationSidebar = !e.showNavigationSidebar
        },
        SET_FILTER_QUERY(e, {
            key: i,
            value: a
        }) {
            u.set(e.filterQuery, i, a)
        },
        SET_PREVIOUS_DASHBOARD(e, i) {
            e.previousView = i
        },
        SET_ENGAGEMENT_LOADING(e, i) {
            u.set(e, "loadingEngagement", i)
        },
        SET_ENGAGEMENT_SCORES(e, i) {
            const a = p((e == null ? void 0 : e.engagementScores) || [], i, "user_id");
            u.set(e, "engagementScores", a)
        },
        CLEAR_ENGAGEMENT_SCORES(e) {
            u.set(e, "engagementScores", [])
        },
        SET_ENGAGEMENT_EMPTY_REASONS(e, i) {
            u.set(e, "engagementEmptyReasons", i)
        }
    },
    w = {
        organization: {
            time_zone: {
                for: "America/New_York"
            }
        },
        tz_options: [],
        users: {},
        teams: {},
        selectedFilter: "all_user_id",
        showNavigationSidebar: !0,
        filterQuery: {},
        previousView: null
    },
    O = ["SET_QUERY"],
    U = e => {
        e.subscribe((i, a) => {
            if (O.includes(i.type)) {
                const s = f(h, {
                        organizationId: a.organization.id
                    }),
                    r = new URL(s, window.location.origin),
                    t = { ...a.query
                    };
                Object.keys(t).map(d => {
                    const l = t[d];
                    return !T(l) && l !== "" && r.searchParams.append(d, l), !0
                }), window.history.replaceState("", "", r.toString())
            }
        })
    },
    L = [U],
    P = { ...w,
        ...S
    },
    R = { ...D,
        ...b
    },
    G = { ...I,
        ...A
    },
    z = { ...N,
        ...y
    };

function Z(e = {}) {
    return g({
        state: { ...P,
            ...e.state
        },
        getters: R,
        mutations: z,
        actions: G,
        plugins: L
    })
}
export {
    Z as c
};