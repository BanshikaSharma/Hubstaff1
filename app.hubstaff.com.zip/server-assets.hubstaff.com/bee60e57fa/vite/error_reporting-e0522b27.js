import {
    ci as r,
    aI as o
} from "./shared-5f1b437f.js";
import "./vendor-f5db2be7.js";
r();
window.reportError = o;