import "./init-ef420420.js";
import {
    V as i
} from "./vendor-f5db2be7.js";
import {
    C as s
} from "./shared-5f1b437f.js";
document.addEventListener("add_widget:amounts_owed", () => {
    document.querySelectorAll(".overtime-popover-widgets").forEach((e, t) => {
        const o = JSON.parse(e.dataset.initialState).overtime;
        new i({
            el: e,
            name: `AmountsOwedWidget-row-${t}`,
            render: r => r(s, {
                props: {
                    overtime: o,
                    iconClasses: "mr-5 hi-16",
                    showFinancial: !0
                }
            })
        })
    })
});