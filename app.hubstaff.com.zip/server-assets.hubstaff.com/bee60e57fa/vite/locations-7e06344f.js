import "./init-ef420420.js";
import {
    E as l,
    B as d,
    D as c,
    a4 as m,
    V as a
} from "./vendor-f5db2be7.js";
import {
    ez as v,
    n as h,
    ce as u,
    bm as b,
    br as g,
    bo as f,
    du as A,
    dv as w,
    dw as C,
    dy as M,
    cY as _,
    l as S,
    bE as o
} from "./shared-5f1b437f.js";
import {
    T as D,
    A as n,
    c as L
} from "./index-b1c3925d.js";
import {
    G as W
} from "./google_maps-3f82c093.js";
import "./base-543c3a70.js";
var I = function() {
        var t = this,
            i = t._self._c;
        return i("div", {
            staticClass: "job-sites-widget-component",
            class: {
                "widget-is-mobile": t.widgetIsMobile
            }
        }, [t.mapEnabled ? i("ActivitiesLocationMap", {
            ref: "mapComponent",
            staticClass: "widget-map",
            attrs: {
                "is-dashboard-map": ""
            }
        }) : i("div", {
            staticClass: "full-page-map-wrapper widget-map-placeholder"
        }, [t.loading || !t.loading && !t.hasActiveSitesOrMembers ? i("div", {
            staticClass: "app-map-stats-box enable-map-box"
        }, [i("div", {
            directives: [{
                name: "loading",
                rawName: "v-loading",
                value: t.loading && !t.initialLoad,
                expression: "loading && !initialLoad"
            }],
            staticClass: "app-map-stats-box--content"
        }, [i("div", {
            staticClass: "text-center",
            class: {
                "hide-on-load": !t.initialLoad
            }
        }, [i("h6", [t._v("No active members or job sites")]), i("p", {
            staticClass: "actions"
        }, [i("AppButton", {
            attrs: {
                size: "sm",
                type: "outline"
            },
            on: {
                click: t.enableMap
            }
        }, [t._v("Enable map")])], 1)])])]) : t._e()]), t.initialLoad ? i("div", {
            staticClass: "app-map-stats-box"
        }, [i("div", {
            staticClass: "active-members"
        }, [i("div", {
            staticClass: "title"
        }, [t._v("Active members")]), i("div", {
            staticClass: "stats"
        }, [t._v(t._s(t.membersWithRecentLocationsCount))]), i("a", {
            staticClass: "link",
            attrs: {
                href: t.locationUrl
            }
        }, [t._v("View"), i("i", {
            staticClass: "hi hi-right hi-8"
        })])]), i("div", {
            staticClass: "active-job-sites"
        }, [i("div", {
            staticClass: "title"
        }, [t._v("Active job sites")]), i("div", {
            staticClass: "stats"
        }, [t._v(t._s(t.activeSitesCount))]), i("a", {
            staticClass: "link",
            attrs: {
                href: t.visitedJobSitesUrl
            }
        }, [t._v("View"), i("i", {
            staticClass: "hi hi-right hi-8"
        })])])]) : t._e(), i("AppMapDropdownButton", {
            staticClass: "app-map-button-dropdown"
        }, [i("li", {
            staticClass: "invite-members"
        }, [i("a", {
            attrs: {
                href: "#"
            },
            on: {
                click: function(s) {
                    return s.preventDefault(), t.showInviteMembersDialog.apply(null, arguments)
                }
            }
        }, [i("i", {
            staticClass: "hi hi-users hi-16"
        }), t._v("Invite members")])]), i("li", {
            staticClass: "add-job-site"
        }, [i("a", {
            attrs: {
                href: t.newJobSiteWizardUrl
            }
        }, [i("i", {
            staticClass: "hi hi-pin hi-16"
        }), t._v("Add job site")])])])], 1)
    },
    T = [];
const E = {
    name: "TheJobSitesWidget",
    extends: D,
    data() {
        return {
            pollOnEmptyUsers: !1,
            widgetIsMobile: !1,
            mapEnabled: !1,
            initialLoad: !1
        }
    },
    computed: { ...l({
            orgId: e => d(e, "organization.id")
        }),
        ...c(["membersWithRecentLocationsCount", "activeSitesCount", "visitedJobSitesUrl"]),
        locationUrl() {
            return `/organizations/${this.orgId}/activities/locations`
        },
        newJobSiteWizardUrl() {
            return `/organizations/${this.orgId}/job_sites?showNewJobSiteWizard`
        }
    },
    watch: {
        hasActiveSitesOrMembers: {
            handler(e) {
                e && !this.mapEnabled && (this.mapEnabled = !0)
            },
            immediate: !0
        },
        loading(e) {
            e || (this.initialLoad = !0)
        }
    },
    mounted() {
        this.isMobile && (this.widgetIsMobile = !0), this.setSitesViewMode(v.ALL)
    },
    methods: { ...m(["setSitesViewMode"]),
        showInviteMembersDialog() {
            AjaxDialog.run(`/organizations/${this.orgId}/invites/new.dialog?redirect=widget`)
        },
        enableMap() {
            this.mapEnabled || (this.mapEnabled = !0, this.$nextTick(() => {
                this.$refs.mapComponent.adjustInitialFitWithin()
            }))
        }
    }
};
var x = h(E, I, T, !1, null, null, null, null);
const z = x.exports;

function j() {
    return Promise.resolve()
}

function N(e) {
    $("div[data-vue=" + e + "]").each(async function() {
        await j(), a.directive("loading", u), a.component("AppButton", b), a.component("AppDialog", g), a.component("AppDropdown", f), a.component("AppMap", A), a.component("AppMapCluster", w), a.component("AppMapDropdownButton", C), a.component("AppMapMarker", M), a.component("HubAvatar", _), a.component("AppAvatar", S), a.filter("formatTimeWithZone", o.formatTimeWithZone), a.filter("formatTimeWithZoneFromNow", o.formatTimeWithZoneFromNow), a.filter("formatDuration", o.formatDuration), a.use(n), a.use(W, $(this).data("googleMapsKey"));
        const t = this,
            i = $(t).data("initialState"),
            s = L(),
            r = new a({
                el: t,
                store: s,
                name: "TheJobSitesWidget",
                render: p => p(z),
                mounted: n.mountedHook(),
                created: n.createdHook(i)
            });
        window.VueLocations = {
            app: r,
            store: s
        }
    })
}
export {
    N as l
};