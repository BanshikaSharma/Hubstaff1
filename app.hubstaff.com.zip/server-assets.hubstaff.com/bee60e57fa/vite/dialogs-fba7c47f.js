import {
    br as g,
    cd as h,
    bm as A,
    m as v,
    o as y,
    ce as D,
    t as f,
    cf as _,
    cg as w,
    _ as u,
    X as C
} from "./shared-5f1b437f.js";
import "./init-ef420420.js";
import {
    V as e
} from "./vendor-f5db2be7.js";
const z = () => u(() =>
        import ("./shared-5f1b437f.js").then(n => n.kM), ["shared-5f1b437f.js", "vendor-f5db2be7.js", "vendor-6448130c.css", "shared-1464d95e.css"]),
    O = () => u(() =>
        import ("./shared-5f1b437f.js").then(n => n.kN), ["shared-5f1b437f.js", "vendor-f5db2be7.js", "vendor-6448130c.css", "shared-1464d95e.css"]),
    d = () => u(() =>
        import ("./shared-5f1b437f.js").then(n => n.kO), ["shared-5f1b437f.js", "vendor-f5db2be7.js", "vendor-6448130c.css", "shared-1464d95e.css"]);
e.component("AppDialog", g);
e.component("AppTooltipIcon", h);
e.component("AppButton", A);
e.component("AppSelect", v);
e.component("AppInput", y);
e.directive("loading", D);
e.directive("tooltip", f);
window.Dialogs = {
    async open(n, {
        store: o,
        props: a,
        methods: i
    } = {
        props: {},
        methods: {}
    }) {
        const t = document.createElement("div");
        document.body.appendChild(t);
        const r = {
                component: n,
                props: a
            },
            p = e.extend(_);
        return new p({
            el: t,
            propsData: r,
            methods: i,
            store: o
        })
    },
    async RemoveCreditCard(n) {
        const {
            organizationId: o,
            showKeepCurrentPlanDialog: a,
            yearlyPlan: i,
            quarterlyPlan: t,
            yearlySignature: r,
            quarterlySignature: p,
            confirmationText: c
        } = n, s = () => {
            confirm(c) && C.removeCreditCard({
                id: o
            }).finally(() => window.location.reload())
        };
        if (!a) return s();
        const l = await d();
        return this.open(l.default, {
            props: {
                organizationId: o,
                yearlyPlan: i,
                quarterlyPlan: t,
                yearlySignature: r,
                quarterlySignature: p,
                cancelButtonText: "Cancel subscription"
            },
            methods: {
                onCancel: s
            }
        })
    },
    async ArchiveOrganizationDialog(n) {
        const {
            organizationId: o,
            showKeepCurrentPlanDialog: a,
            yearlyPlan: i,
            quarterlyPlan: t,
            yearlySignature: r,
            quarterlySignature: p,
            appSumo: c
        } = n, s = await z(), l = () => {
            this.open(s.default, {
                props: {
                    organizationId: o,
                    appSumo: c
                }
            })
        };
        if (!a) return l();
        const m = await d();
        return this.open(m.default, {
            props: {
                organizationId: o,
                yearlyPlan: i,
                quarterlyPlan: t,
                yearlySignature: r,
                quarterlySignature: p,
                cancelButtonText: "Archive organization and cancel subscription"
            },
            methods: {
                onCancel: l
            }
        })
    },
    async ArchiveOrganizationFlow(n) {
        const {
            currentPlan: o,
            hubstaffSgt: a,
            organizationId: i,
            plans: t,
            appSumo: r
        } = n, p = await O();
        return (() => {
            this.open(p.default, {
                props: {
                    currentPlan: o,
                    hubstaffSgt: a,
                    organizationId: i,
                    plans: t,
                    appSumo: r
                }
            })
        })()
    },
    ConfirmSeatIncreaseDialog({
        onConfirm: n
    }) {
        return this.open(w, {
            methods: {
                onConfirm: n
            }
        })
    }
};