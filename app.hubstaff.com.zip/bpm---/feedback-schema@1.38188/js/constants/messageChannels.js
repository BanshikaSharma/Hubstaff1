'use es6';

// editor to ui via injector
export const PREVIEW_EDITOR = 'PREVIEW_EDITOR';
export const PREVIEW_UI = 'PREVIEW_UI';
// injector to fetcher
export const FETCHER = 'FETCHER';
// injector to ui
export const UI = 'UI';