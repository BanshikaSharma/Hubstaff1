"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.V1 = exports.HIDE_WIDGET = void 0;
const V1 = exports.V1 = 'V1';
const HIDE_WIDGET = exports.HIDE_WIDGET = 'HIDE_WIDGET';