import {
    bi as a,
    bj as u,
    bk as I
} from "./vendor-f5db2be7.js";
import "./shared-5f1b437f.js";
window.AMPLITUDE_KEY && window.analytics && window.analytics.ready(async () => {
    const n = () => document.cookie.split("; ").reduce((e, o) => {
            const [i, t] = o.split("=");
            return e[i] = t, e
        }, {}).analytics_session_id || 0,
        d = n();
    await a(AMPLITUDE_KEY, {
        sessionId: d,
        deviceId: analytics.user().anonymousId(),
        sampleRate: .02
    }).promise, analytics.addSourceMiddleware(({
        payload: s,
        next: e,
        integrations: o
    }) => {
        var r, c;
        const i = n(),
            t = ((c = (r = s == null ? void 0 : s.obj) == null ? void 0 : r.integrations["Actions Amplitude"]) == null ? void 0 : c.session_id) || 0;
        i < t && (document.cookie = `analytics_session_id=${t}`, u(t)), e(s)
    }), analytics.addSourceMiddleware(({
        payload: s,
        next: e,
        integrations: o
    }) => {
        const i = I();
        s.type() === "track" && (s.obj.properties = { ...s.obj.properties,
            ...i
        }), e(s)
    })
});