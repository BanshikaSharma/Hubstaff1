"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RESET_WIDGET = void 0;
const RESET_WIDGET = exports.RESET_WIDGET = 'resetWidget';