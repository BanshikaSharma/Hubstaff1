import {
    A as a
} from "./app_messages-e83d8e06.js";
import {
    A as e,
    bu as r,
    bv as i,
    N as m,
    ab as A,
    bw as c,
    a$ as s,
    bg as l,
    bc as d
} from "./vendor-f5db2be7.js";
import {
    cY as g,
    l as b,
    cZ as T,
    bk as f,
    c_ as D,
    c$ as v,
    d0 as S,
    d1 as k,
    bm as I,
    d2 as w,
    d3 as P,
    bn as M,
    d4 as h,
    d5 as L,
    d6 as B,
    bv as C,
    d7 as R,
    d8 as G,
    cd as x,
    br as y,
    bs as H,
    bo as z,
    bp as F,
    bq as W,
    d9 as E,
    da as Z,
    bC as N,
    db as O,
    dc as q,
    dd as U,
    by as j,
    bz as Y,
    de as _,
    df as $,
    dg as J,
    dh as K,
    di as Q,
    bl as X,
    dj as u,
    x as V,
    o as pp,
    dk as op,
    dl as ep,
    dm as tp,
    dn as np,
    dp as ap,
    dq as rp,
    q as ip,
    dr as mp,
    ds as Ap,
    dt as cp,
    bi as sp,
    du as lp,
    dv as dp,
    dw as gp,
    dx as bp,
    dy as Tp,
    dz as fp,
    bf as Dp,
    dA as vp,
    bx as Sp,
    bw as kp,
    r as Ip,
    dB as wp,
    bA as Pp,
    dC as Mp,
    dD as hp,
    dE as Lp,
    bg as Bp,
    m as Cp,
    dF as Rp,
    dG as Gp,
    dH as xp,
    dI as yp,
    s as Hp,
    u as zp,
    dJ as Fp,
    dK as Wp,
    dL as Ep,
    bB as Zp,
    bu as Np,
    bt as Op,
    bh as qp,
    bj as Up,
    dM as jp,
    dN as Yp,
    dO as _p,
    dP as $p,
    dQ as Jp,
    dR as Kp,
    t as Qp,
    dS as Xp,
    ce as up,
    dT as Vp,
    dU as po,
    bD as oo,
    S as t,
    bE as o,
    dV as n,
    dW as eo,
    dX as to
} from "./shared-5f1b437f.js";
e("required", { ...A,
    message: "can't be blank"
});
e("integer", { ...c,
    message: "enter a valid number"
});
e("numeric", { ...s,
    message: "enter a positive number"
});
e("max_value", { ...l,
    message: "enter a smaller number"
});
e("between", {
    params: ["min", "max"],
    ...d,
    message: "enter a number between {min} and {max}"
});
const io = {
    install(p) {
        p.use(a), p.component("ValidationObserver", r), p.component("ValidationProvider", i), p.component("VuePopper", m), p.component("HubAvatar", g), p.component("AppAvatar", b), p.component("AppUpsellBanner", T), p.component("AppAvatarInitial", f), p.component("AppAchievementBadge", D), p.component("AppAchievementBadges", v), p.component("AppBatchActionsPanel", S), p.component("AppBlacklistedMessage", k), p.component("AppButton", I), p.component("AppChartDonut", w), p.component("AppChartLine", P), p.component("AppCheckbox", M), p.component("AppColumnToggle", h), p.component("AppConfirm", L), p.component("AppCopyInputValue", B), p.component("AppDatePicker", C), p.component("AppDateRangePicker", R), p.component("AppDatetimeRangePicker", G), p.component("AppTooltipIcon", x), p.component("AppDialog", y), p.component("AppDialogError", H), p.component("AppDropdown", z), p.component("AppDropdownItem", F), p.component("AppDropdownItemGroup", W), p.component("AppToggleDropdown", E), p.component("AppToggleDropdownItem", Z), p.component("AppDurationInput", N), p.component("AppExcerpt", O), p.component("AppExportMenu", q), p.component("AppExportMenuItem", U), p.component("AppFileImport", j), p.component("AppFilePicker", Y), p.component("AppFilterCount", _), p.component("AppGallery", $), p.component("AppGalleryItem", J), p.component("AppGettingStartedPopover", K), p.component("AppHintPopover", Q), p.component("AppHoverLink", X), p.component("AppImageUploader", u), p.component("AppInfiniteScroll", V), p.component("AppInput", pp), p.component("AppTimeInput", op), p.component("AppTimeSelect", ep), p.component("AppTimePicker", tp), p.component("AppTimeGrid", np), p.component("AppTimeZoneDropdown", ap), p.component("AppTimeGridHeaderTableData", rp), p.component("AppInputSearch", ip), p.component("AppIntervalDayPicker", mp), p.component("AppYearPicker", Ap), p.component("AppLink", cp), p.component("AppLoadingTable", sp), p.component("AppMap", lp), p.component("AppMapCluster", dp), p.component("AppMapDropdownButton", gp), p.component("AppMapGeolocationControl", bp), p.component("AppMapMarker", Tp), p.component("AppMarkdown", fp), p.component("AppNav", Dp), p.component("AppOnOffToggle", vp), p.component("AppToggleButton", Sp), p.component("AppToggleButtonGroup", kp), p.component("AppPagination", Ip), p.component("AppPopover", wp), p.component("AppProgressBar", Pp), p.component("AppRadioButton", Mp), p.component("AppRadioButtonGroup", hp), p.component("AppRangeSlider", Lp), p.component("AppScrollableTable", Bp), p.component("AppSelect", Cp), p.component("AppSelectDropdown", Rp), p.component("AppSelectList", Gp), p.component("AppMembersSelector", xp), p.component("AppMembersSelection", yp), p.component("AppLazySelect", Hp), p.component("AppLazySelectItem", zp), p.component("AppSelectListItem", Fp), p.component("AppSettingsLinkDropdown", Wp), p.component("AppSidebar", Ep), p.component("AppSwitch", Zp), p.component("AppTab", Np), p.component("AppTabs", Op), p.component("AppTable", qp), p.component("AppTableColumn", Up), p.component("AppTasksAlert", jp), p.component("AppWizard", Yp), p.component("AppWizardStep", _p), p.component("AppAlert", $p), p.component("AppVerticalNav", Jp), p.directive("ntooltip", Kp), p.directive("tooltip", Qp), p.directive("popover", Xp), p.directive("loading", up), p.directive("track", Vp), p.config.ignoredElements = ["hint"], p.filter("currency", po), p.filter("percentage", oo), p.filter("capitalize", t.capitalize), p.filter("formatDate", o.formatDate), p.filter("formatDateWithZone", o.formatDateWithZone), p.filter("formatDateTime", o.formatDateTime), p.filter("formatDatetimeRange", o.formatDatetimeRange), p.filter("formatDatetimeRangeWithZone", o.formatDatetimeRangeWithZone), p.filter("formatDateRange", o.formatDateRange), p.filter("formatTimeRange", o.formatTimeRange), p.filter("formatTimeRangeNoSeconds", o.formatTimeRangeNoSeconds), p.filter("formatDuration", o.formatDuration), p.filter("formatTime", o.formatTime), p.filter("formatTimeWithZone", o.formatTimeWithZone), p.filter("formatTimeWithZoneFromNow", o.formatTimeWithZoneFromNow), p.filter("pluralize", t.pluralize), p.filter("lowercase", t.lowercase), p.filter("stripHTML", n.stripHTML), p.filter("escapeHTML", n.escapeHTML), p.filter("projectFlavourLabel", eo), p.filter("taskFlavourLabel", to)
    }
};
export {
    io as H
};