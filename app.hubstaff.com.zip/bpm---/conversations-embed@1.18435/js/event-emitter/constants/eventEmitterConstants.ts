"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EVENT_NAMESPACE = void 0;
const EVENT_NAMESPACE = exports.EVENT_NAMESPACE = 'HubSpotConversations';