import {
    cI as h,
    e4 as A,
    cM as f,
    cX as m
} from "./shared-5f1b437f.js";
import {
    k as E,
    B as d,
    V as g,
    aG as k
} from "./vendor-f5db2be7.js";
const T = {
        query: null,
        loadingWidgets: {
            initial: !0
        },
        loadingUsers: {},
        widgets: {},
        filters: {},
        dashboard_type: "individual",
        hasBenchmarksAverages: !1,
        showBenchmarksAverages: !1,
        benchmarksAveragesLegend: {}
    },
    u = (e, s, r = null, t = "", l = !0) => {
        if (!e) return "";
        const i = `meeting${!l||e>1?"s":""}`;
        return r ? `<div>${e}${t} ${s} ${i}</div><div>Total time: ${r}</div>` : `${e}${t} ${s} ${i}`
    },
    y = {
        isTeamDashboard: e => e.dashboard_type === "team",
        isEverythingReady: e => Object.values(e.loadingWidgets).filter(s => !E(s) && s).length === 0,
        isDayPeriod: e => {
            var s;
            return ((s = e.filters.date) == null ? void 0 : s.period) === "day"
        },
        isBenchmarksToggleReady: e => !h.benchmarks_averages.widgets.every(s => e.loadingWidgets[s] === !0),
        status: e => e.status || null,
        loadingWidgets: e => e.loadingWidgets,
        loadingUsers: e => e.loadingUsers,
        canSeeTeam: e => !!e.can_see_team,
        isTeamLead: e => !!e.is_team_lead,
        filters: e => e.filters,
        insightsSettingsUrl: e => e.insights_settings_url,
        smartNotificationsSettingsUrl: e => e.smart_notification_settings_url,
        hasValidFilters: e => !!(e.filters && e.filters.date && e.filters.date.from && e.filters.date.to && e.filters.date.period && (e.filters.user_id || e.filters.team_id)),
        focusTime: e => d(e, "widgets.focus_time", null),
        workTimeClassification: e => d(e.widgets, h.api.highlights.workTimeClassification, null),
        meetings: e => {
            var r, t;
            const s = d(e, "widgets.meetings", null);
            if (s) {
                const l = [];
                let i = [],
                    o = [];
                if (s.shares && Object.keys(s.shares).length && Object.keys(s.shares).forEach(a => {
                        l.push({
                            label: h.meetings.labels.shares[a],
                            value: s.shares[a].value,
                            time: s.shares[a].time || ""
                        })
                    }), (r = s.time_of_day) != null && r.length && (i = s.time_of_day.map(a => ({
                        label: a.range.join("-"),
                        value: 1,
                        recurring: {
                            value: a.recurring,
                            tooltip: u(a.recurring, "recurring", null, "%", !1)
                        },
                        non_recurring: {
                            value: a.non_recurring,
                            tooltip: u(a.non_recurring, "non-recurring", null, "%", !1)
                        }
                    }))), (t = s.weekdays) != null && t.length) {
                    const a = [...Array(7).keys()].map(n => {
                        var c;
                        return moment().startOf("isoWeek").add(((c = e.organization) == null ? void 0 : c.start_week_on) || 0, "days").add(n, "days").format("ddd")
                    });
                    o = s.weekdays.map(n => ({
                        day: n.day,
                        value: 1,
                        label: a[n.day],
                        recurring: {
                            value: +n.recurring,
                            tooltip: u(n.recurring, "recurring", A(n.recurring_duration))
                        },
                        non_recurring: {
                            value: +n.non_recurring,
                            tooltip: u(n.non_recurring, "non-recurring", A(n.non_recurring_duration))
                        }
                    }))
                }
                return { ...s,
                    shares: l,
                    time_of_day: i,
                    weekdays: o
                }
            }
        },
        hasBenchmarksAverages: (e, s) => s.benchmarksAveragesLegend.length > 0,
        showBenchmarksAverages: e => e.showBenchmarksAverages,
        showWidgetBenchmarks: (e, s) => s.hasBenchmarksAverages && s.showBenchmarksAverages,
        benchmarksAveragesLegend: e => Object.entries(e.benchmarksAveragesLegend).filter(([, s]) => !!s).map(([s, r]) => ({
            key: s,
            ...r
        })),
        currentUserRole: e => e.current_user_role,
        insightsStatus: e => e.insights_status
    },
    v = {
        async fetchWidgets({
            commit: e,
            state: s
        }, {
            widgetKey: r = null,
            widgetName: t = null,
            extraQueryParams: l = {},
            persists: i = !1
        }) {
            let o;
            const a = t || r;
            e("SET_WIDGET_LOADING", {
                key: a,
                status: !0
            });
            try {
                const n = {
                        organizationId: s.organization.id,
                        dashboardType: s.dashboard_type
                    },
                    c = { ...s.query,
                        ...l
                    },
                    _ = {
                        abortReload: !0
                    };
                if (o = r ? await f.widget({ ...n,
                        widgetKey: r
                    }, c, { ..._,
                        abortDuplicateRequests: !0,
                        skippableAbortParams: ["limit"],
                        identifier: a
                    }) : await f.get(n, c, _), o) return e("SET_WIDGETS", {
                    widgetName: a,
                    widgetKey: r,
                    data: o,
                    persists: i
                }), o
            } catch (n) {
                if (n.status === 403 && (e("SET_WIDGETS", {
                        widgetName: a,
                        widgetKey: r
                    }), e("SET_WIDGET_LOADING", {
                        key: a,
                        status: !1
                    })), !m.isAbortedRequest(n)) throw new Error(`Unable to fetch ${r} for insights`)
            } finally {
                o && e("SET_WIDGET_LOADING", {
                    key: a,
                    status: !1
                })
            }
        },
        async fetchBenchmarksAveragesLegend({
            commit: e,
            state: s
        }) {
            try {
                const r = await f.benchmarksAveragesLegend({
                    organizationId: s.organization.id
                }, { ...s.query
                }, {
                    abortDuplicateRequests: !0
                });
                r.benchmarks && e("SET_BENCHMARKS_AVERAGES_LEGEND", r.benchmarks)
            } catch (r) {
                if (!m.isAbortedRequest(r)) throw new Error("Unable to fetch benchmarks' legend", r)
            }
        },
        setShowBenchmarksAverages({
            commit: e
        }, s) {
            e("SET_SHOW_BENCHMARKS_AVERAGES", s)
        }
    },
    p = {
        SET_WIDGET_LOADING(e, {
            key: s,
            status: r = !0
        }) {
            g.set(e.loadingWidgets, s, r)
        },
        SET_NAVIGATION_LOADING(e, {
            key: s,
            status: r = !0
        }) {
            g.set(e.loadingUsers, s, r)
        },
        UPDATE_STATE(e, s) {
            if (s)
                for (const r in s) s[r] && g.set(e, r, s[r])
        },
        SET_WIDGETS(e, {
            widgetName: s,
            widgetKey: r = null,
            data: t = null,
            persists: l = !1
        }) {
            if (r) {
                let i;
                if (t && l) {
                    const o = typeof l == "string" ? l : "data",
                        a = d(e.widgets[s], o, []),
                        n = d(t[r], o, []);
                    i = Object.assign({}, e.widgets[s]), k(i, o, [...a, ...n]), g.set(e.widgets, s, i);
                    return
                }
                i = t ? t[r] : null, g.set(e.widgets, s, i)
            } else g.set(e, "widgets", { ...e.widgets,
                ...t
            })
        },
        SET_SHOW_BENCHMARKS_AVERAGES(e, s) {
            g.set(e, "showBenchmarksAverages", s)
        },
        SET_BENCHMARKS_AVERAGES_LEGEND(e, s) {
            e.benchmarksAveragesLegend = s
        }
    };
export {
    y as a, v as b, p as c, T as s
};