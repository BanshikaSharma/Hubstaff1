"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.NOTIFICATION_INTERVAL_MS = void 0;
const NOTIFICATION_INTERVAL_MS = exports.NOTIFICATION_INTERVAL_MS = 1250;