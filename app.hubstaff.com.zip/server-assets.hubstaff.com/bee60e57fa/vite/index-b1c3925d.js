import {
    ec as ot,
    ed as at,
    ee as nt,
    ef as rt,
    eg as ct,
    eh as lt,
    ei as dt,
    ej as ut,
    ek as mt,
    el as ht,
    em as _t,
    en as St,
    eo as gt,
    ep as pt,
    eq as vt,
    er as bt,
    es as ft,
    et as Tt,
    eu as At,
    ev as Et,
    ew as wt,
    ex as Lt,
    ey as Dt,
    ez as P,
    eA as b,
    n as It,
    i as Mt,
    eB as M,
    eC as C,
    eD as Ot,
    eE as Rt,
    eF as kt,
    eG as U
} from "./shared-5f1b437f.js";
import {
    D as Pt,
    E as V,
    a4 as yt,
    B as o,
    b as T,
    a5 as Z,
    aw as Nt,
    a6 as O,
    aM as A,
    a8 as Ct,
    b6 as Ut,
    o as z,
    a_ as B,
    V as f,
    h as W,
    i as Vt
} from "./vendor-f5db2be7.js";
import {
    c as zt
} from "./base-543c3a70.js";
const Qt = {
        install(t) {
            t.component("ActivitiesLocationSelectJobSite", ot), t.component("ActivitiesLocationSidebar", at), t.component("ActivitiesLocationSortBy", nt), t.component("ActivitiesLocationMap", rt), t.component("ActivitiesLocationResetZoomControl", ct), t.component("ActivitiesLocationInfoWindow", lt), t.component("ActivitiesLocationMemberInfoWindow", dt), t.component("ActivitiesLocationJobSiteInfoWindow", ut), t.component("ActivitiesLocationInfoWindowListItem", mt), t.component("ActivitiesLocationSidebarMemberItem", ht), t.component("ActivitiesLocationMoveMarker", _t), t.component("ActivitiesLocationStartMarker", St), t.component("ActivitiesLocationAvatarMarker", gt), t.component("ActivitiesLocationJobSiteMarker", pt), t.component("ActivitiesLocationViewButton", vt), t.component("ActivitiesLocationDateTZControls", bt), t.component("ActivitiesLocationSidebarMembersTab", ft), t.component("ActivitiesLocationSidebarJobSitesTab", Tt), t.component("ActivitiesLocationNoDataDialog", At)
        },
        createdHook(t) {
            return function() {
                this.$store.dispatch("loadInitialState", t)
            }
        },
        mountedHook() {
            return function() {}
        }
    },
    Bt = {
        name: "TheActivitiesLocation",
        mixins: [Et],
        data() {
            return {
                mapEnabled: !0,
                pollOnEmptyUsers: !0,
                nextPoll: null,
                showDialog: !0,
                showSidebar: !0,
                showDialogCount: 0,
                pollingTimeout: null,
                locationViewData: null,
                forceCounterUpdate: 0,
                DEBUG_LOCATION_DATA_OPTIONS: wt,
                DEBUG_LOCATION_PATH_OPTIONS: Lt,
                views: Object.freeze(Dt),
                sidebarErrors: {},
                sidebarButtonVisible: !0
            }
        },
        beforeMount() {
            this.isMobile && (this.showSidebar = !1)
        },
        async mounted() {
            this.clickHandler = t => {
                var e;
                !this.sidebarButtonVisible && !((e = document.querySelector(".activities-location-component .table-actions-dropdown")) != null && e.contains(t.target)) && (this.sidebarButtonVisible = !0)
            }, document.addEventListener("click", this.clickHandler), await this.loadData(), this.forceCounterUpdate += 1, (this.hasActiveSitesOrMembers || this.pollOnEmptyUsers) && this.pollData()
        },
        beforeDestroy() {
            document.removeEventListener("click", this.clickHandler), this.stopPolling()
        },
        computed: { ...Pt(["hasActiveSitesOrMembers", "isPastView", "mapSettingsUrl", "hasMemberMarkers", "hasJobSiteMarkers", "jobSitesSettingsUrl", "activeTimeZoneName", "usersLoading", "sitesLoading", "apiErrors"]),
            ...V(["date", "currentView", "showingRoutes", "sitesViewMode", "selectedMember", "showLocationPoints"]),
            ...V({
                debugMode: "debug",
                isOwnerOrManager: "is_owner_or_manager",
                liveRefreshTimeout: "live_refresh_timeout"
            }),
            nextPollLabel() {
                return typeof this.nextPoll == "number" ? `in ${this.nextPoll}s` : null
            },
            showNoDataDialog() {
                const t = this.showDialog && !this.hasMemberMarkers && !(this.sitesViewMode === P.ALL && this.hasJobSiteMarkers);
                return t && this.showDialogCount === 0 || t && !this.loading
            },
            loading() {
                return this.usersLoading || this.sitesLoading
            },
            dropdownItems() {
                return [{
                    value: this.mapSettingsUrl,
                    name: "Map settings"
                }, {
                    value: this.jobSitesSettingsUrl,
                    name: "Job site settings"
                }]
            }
        },
        methods: { ...yt(["clearSelected", "setDebugOption", "setCurrentView", "setActiveRoutes", "setActiveInfoWindow", "loadUserRoute", "loadSitesResource", "loadUsersResource"]),
            onCloseDialog() {
                this.showDialog = !1
            },
            openSidebar() {
                this.showSidebar = !this.showSidebar
            },
            closeSidebar() {
                this.showSidebar = !1
            },
            changeLocationView(t) {
                this.setCurrentView(t)
            },
            async onDebugOptionToggle(t, e) {
                this.setDebugOption(t, e), t === "locationViewData" && await this.loadData()
            },
            loadData(t = !1) {
                const e = o(this.selectedMember, "id");
                return Promise.all([this.loadSitesResource(), this.loadUsersResource(t), ...this.showingRoutes && e ? [this.loadUserRoute(e)] : []])
            },
            destroyNextPollInterval() {
                this.interval && clearInterval(this.interval), this.nextPoll = 0
            },
            startNextPollInterval() {
                this.destroyNextPollInterval(), this.nextPoll = this.liveRefreshTimeout / 1e3, this.interval = setInterval(() => {
                    this.nextPoll - 1 <= 0 ? this.destroyNextPollInterval() : this.nextPoll -= 1
                }, 1e3)
            },
            destroyPollingTimeout() {
                this.pollingTimeout && clearTimeout(this.pollingTimeout)
            },
            pollData() {
                this.destroyPollingTimeout(), this.currentView === b.LIVE && (this.startNextPollInterval(), this.pollingTimeout = setTimeout(async () => {
                    await this.$nextTick(), await this.loadData(!0), this.pollData()
                }, this.liveRefreshTimeout))
            },
            stopPolling() {
                this.destroyPollingTimeout(), this.destroyNextPollInterval()
            },
            toggleSidebarButton() {
                this.sidebarButtonVisible = !this.sidebarButtonVisible
            }
        },
        watch: {
            isSmallScreen() {
                this.sidebarButtonVisible = !0
            },
            async date() {
                await this.loadData(!1)
            },
            async activeTimeZoneName() {
                await this.loadData(!1)
            },
            showNoDataDialog(t) {
                t && (this.showDialogCount += 1)
            },
            async currentView(t) {
                t === b.LIVE ? (this.clearSelected(), await this.$nextTick(), await this.loadData(), this.pollData()) : (this.stopPolling(), await this.loadData())
            }
        }
    };
var Wt = function() {
        var e = this,
            s = e._self._c;
        return s("div", {
            staticClass: "activities-location-component"
        }, [s("div", {
            staticClass: "page-header-wrapper"
        }, [s("div", {
            staticClass: "row"
        }, [s("div", {
            staticClass: "col-sm-4"
        }, [s("div", {
            staticClass: "d-flex align-items-center justify-content-between mb-30"
        }, [s("h2", {
            staticClass: "page-heading"
        }, [e._v("Map")]), e.isOwnerOrManager && e.isSmallScreen ? s("div", {
            on: {
                click: e.toggleSidebarButton
            }
        }, [s("AppSettingsLinkDropdown", {
            attrs: {
                items: e.dropdownItems
            }
        })], 1) : e._e()])]), s("div", {
            staticClass: "col-sm-4 text-center"
        }, [s("AppToggleButtonGroup", {
            attrs: {
                items: e.views,
                selected: e.currentView
            },
            on: {
                input: e.changeLocationView
            }
        })], 1), e.isOwnerOrManager && !e.isSmallScreen ? s("div", {
            on: {
                click: e.toggleSidebarButton
            }
        }, [s("AppSettingsLinkDropdown", {
            attrs: {
                items: e.dropdownItems
            }
        })], 1) : e._e()]), e.debugMode ? [s("div", {
            staticClass: "activity-filters-row"
        }, [s("AppRadioButtonGroup", {
            staticClass: "mr-15",
            attrs: {
                label: "Show recorded points",
                items: e.DEBUG_LOCATION_PATH_OPTIONS,
                selected: e.showLocationPoints
            },
            on: {
                input: function(i) {
                    return e.onDebugOptionToggle("showLocationPoints", i)
                }
            }
        }), s("AppRadioButtonGroup", {
            attrs: {
                label: "View location data",
                items: e.DEBUG_LOCATION_DATA_OPTIONS,
                selected: e.locationViewData
            },
            on: {
                input: function(i) {
                    return e.onDebugOptionToggle("locationViewData", i)
                }
            }
        })], 1)] : e._e(), s("ActivitiesLocationDateTZControls", {
            attrs: {
                "is-past": e.isPastView
            }
        }, [e.isPastView ? e._e() : s("p", {
            staticClass: "next-poll text-muted hint m-0"
        }, [s("strong", [e._v("Update:")]), e._v(" " + e._s(e.nextPollLabel) + " ")])])], 2), s("ActivitiesLocationMap", {
            key: e.forceCounterUpdate
        }), e.showNoDataDialog && !e.isPastView && !e.loading ? s("ActivitiesLocationNoDataDialog", {
            attrs: {
                show: e.showNoDataDialog
            },
            on: {
                close: e.onCloseDialog
            }
        }) : e._e(), s("ActivitiesLocationSidebar", {
            attrs: {
                "show-sidebar": e.showSidebar,
                "has-pull-btn": e.sidebarButtonVisible,
                errors: e.sidebarErrors
            },
            on: {
                show: e.openSidebar,
                close: e.closeSidebar
            }
        })], 1)
    },
    xt = [],
    jt = It(Bt, Wt, xt, !1, null, null, null, null);
const Kt = jt.exports,
    Zt = () => ({
        debug: !1,
        permission_denied: !1,
        is_owner_or_manager: !1,
        live_refresh_timeout: null,
        errors: null,
        loading: {
            sites: !0,
            users: !0,
            userRoute: !1,
            userDetails: !1,
            siteDetails: !1
        },
        time_zones: {},
        organization: null,
        date: null,
        min_date: null,
        max_date: null,
        selectedSite: null,
        selectedMember: null,
        currentView: b.LIVE,
        sitesViewMode: P.ALL,
        showingRoutes: !1,
        showingInfoWindow: !1,
        showLocationPoints: 0,
        sites: {},
        users: {},
        tasks: {},
        projects: {}
    }),
    R = "SET_DATE",
    v = "API_ERRORS",
    m = "SET_LOADING",
    k = "LOADED_STATE",
    $ = "SET_TIME_ZONE",
    G = "SITE_SELECTED",
    J = "CLEAR_SELECTED",
    F = "SET_USER_ROUTE",
    H = "MEMBER_SELECTED",
    q = "SET_SHOW_ROUTES",
    Y = "SET_DEBUG_OPTION",
    Q = "SET_CURRENT_VIEW",
    K = "SET_SITES_VIEW_MODE",
    X = "SET_SHOW_INFO_WINDOW",
    L = "UPDATE_ENTITY_STATES",
    tt = "UPDATE_SITES_GRANULARLY";

function E(t = {}) {
    const e = o(t, "date"),
        s = o(t, "time_zones.active");
    return o(t, "currentView") === b.LIVE ? {
        time_zone: s
    } : {
        date: e,
        time_zone: s
    }
}

function p(t = [], e = "id") {
    return t.reduce((s, i) => {
        const n = o(i, e);
        return { ...s,
            [n]: i
        }
    }, {})
}

function x(t = [], e = "user_id") {
    return Z(Nt(t, e), (s, [i], n) => ({ ...s,
        [n]: i
    }), {})
}
const $t = {
        setDebugOption: ({
            commit: t
        }, e) => {
            t(Y, e)
        },
        loadInitialState: ({
            commit: t
        }, e) => {
            t(k, e)
        },
        setCurrentView({
            commit: t,
            getters: e
        }, s) {
            if (t(Q, s), s === b.LIVE) {
                const i = e.activeTimeZoneName,
                    n = i ? moment.tz(new Date, i) : moment(),
                    a = Mt(n);
                t(R, a)
            }
        },
        setSitesViewMode: ({
            commit: t
        }, e) => {
            t(K, e)
        },
        showRoutes: ({
            commit: t
        }, e) => {
            t(q, e)
        },
        showInfoWindow: ({
            commit: t
        }, e) => {
            t(X, e)
        },
        selectSite: ({
            commit: t
        }, e = null) => {
            t(G, e)
        },
        selectMember: ({
            commit: t
        }, e = null) => {
            t(H, e)
        },
        clearSelected: ({
            commit: t
        }) => {
            t(J)
        },
        setDate: ({
            commit: t
        }, e) => {
            t(R, e)
        },
        setActiveTimeZone: ({
            commit: t
        }, e) => {
            t($, e)
        },
        loadUsersResource: async ({
            state: t,
            commit: e
        }, s = !1) => {
            e(m, ["users", !0]), e(v, {}, "users");
            const i = E(t),
                n = o(t, "organization.id"),
                a = t.currentView === b.LIVE;
            return M.get({
                orgId: n
            }, i).then(r => {
                const c = p(o(r, "tasks", [])),
                    l = a ? c : T({}, o(t, "latestTasks", {}), c),
                    h = p(o(r, "projects", [])),
                    _ = a ? h : T({}, o(t, "latestProjects", {}), h),
                    S = x(o(r, "locations", [])),
                    g = a ? S : T({}, o(t, "latestLocations", {}), S),
                    u = x(o(r, "activities", [])),
                    w = a ? u : T({}, o(t, "latestActivities", {}), u),
                    y = p(o(r, "users", [])),
                    et = a ? y : T({}, o(t, "latestUsers", {}), y),
                    D = Z(et, (st, it, I) => ({ ...st,
                        [I]: { ...it,
                            location: o(g, I),
                            lastActivity: o(w, I)
                        }
                    }), {}),
                    N = s ? L : k;
                a ? e(N, {
                    users: D,
                    tasks: l,
                    projects: _,
                    latestUsers: D,
                    latestTasks: l,
                    latestProjects: _,
                    latestLocations: g,
                    latestActivities: w
                }) : e(N, {
                    users: D,
                    tasks: l,
                    projects: _
                })
            }).catch(r => {
                const c = {
                    users: r
                };
                r.status && r.status === 500 && (c.users.message = "An error occurred while loading users. "), e(v, c)
            }).finally(() => e(m, ["users", !1]))
        },
        loadUserDetails: async ({
            state: t,
            commit: e
        }, s) => {
            e(m, ["userDetails", !0]);
            const i = E(t),
                n = o(t, "organization.id");
            return M.get({
                orgId: n,
                userId: s
            }, i).then(a => {
                const {
                    visits: r,
                    details: c
                } = a, l = p(a.sites), h = p(a.tasks), _ = p(a.projects);
                return e(L, {
                    sites: l,
                    tasks: h,
                    projects: _
                }), {
                    visits: r,
                    details: c
                }
            }).catch(a => {
                e(v, a)
            }).finally(() => e(m, ["userDetails", !1]))
        },
        loadUserRoute: async ({
            state: t,
            commit: e
        }, s) => {
            e(m, ["userRoute", !0]);
            const i = E(t),
                n = o(t, "organization.id");
            return M.locations({
                orgId: n,
                userId: s
            }, i).then(a => {
                const {
                    locations: r = []
                } = a;
                e(F, {
                    userId: s,
                    route: r
                })
            }).catch(a => {
                e(v, a)
            }).finally(() => e(m, ["userRoute", !1]))
        },
        loadSitesResource: async ({
            state: t,
            commit: e
        }) => {
            e(m, ["sites", !0]);
            const s = E(t),
                i = o(t, "organization.id");
            return C.get({
                orgId: i
            }, s).then(n => {
                e(tt, n.sites)
            }).catch(n => {
                e(v, n)
            }).finally(() => e(m, ["sites", !1]))
        },
        loadSiteDetails: async ({
            state: t,
            commit: e
        }, s) => {
            e(m, ["siteDetails", !0]);
            const i = E(t),
                n = o(t, "organization.id");
            return C.get({
                orgId: n,
                siteId: s
            }, i).then(a => {
                const {
                    visits: r,
                    updated_at: c
                } = a, l = p(a.users);
                return e(L, {
                    users: l
                }), {
                    visits: r,
                    updatedAt: c
                }
            }).catch(a => {
                e(v, a)
            }).finally(() => e(m, ["siteDetails", !1]))
        }
    },
    d = window.moment,
    j = 30,
    Gt = 50,
    Jt = {
        isPastView: t => t.currentView === b.PAST,
        allAvatars: (t, e) => e.users.reduce((s, i) => (s.set(i.id, i.avatar), s), new Map),
        users: (t, e) => {
            const s = e.timeZoneDate,
                i = e.activeTimeZoneName,
                n = o(t, "users", {}),
                a = i ? d.tz(d(), i) : d();
            return O(n, r => {
                const c = o(r, "location.recorded_at"),
                    l = c ? i ? d.tz(c, i) : d(c) : null,
                    h = l ? l.isSame(s, "day") : !1,
                    _ = l ? a.diff(l, "minutes") < U : !1,
                    S = o(r, "lastActivity.last_client_activity"),
                    g = S ? i ? d.tz(S, i) : d(S) : null,
                    u = g ? a.diff(g, "minutes") < U : !1;
                return { ...r,
                    activeNow: u,
                    trackedLocation: h,
                    trackedLocationRecently: _
                }
            })
        },
        usersByPartition: (t, e) => {
            const [s = [], i = []] = A(e.users, {
                trackedLocation: !0
            });
            return {
                tracked: s,
                notTracked: i
            }
        },
        sites: (t, e) => {
            const s = e.timeZoneDate,
                i = e.activeTimeZoneName,
                n = [];
            for (const [a, r] of Object.entries(o(t, "sites", {}))) {
                if (a === "__touched__") continue;
                const c = o(r, "last_visited_at"),
                    l = c ? (i ? d.tz(c, i) : d(c)).isSame(s, "day") : !1;
                n.push({ ...r,
                    visited: l
                })
            }
            return n
        },
        activeSitesCount: (t, e) => {
            let s = 0;
            const i = d(),
                n = e.activeTimeZoneName,
                {
                    visited: a
                } = e.sitesByPartition;
            for (const r of a) {
                const c = o(r, "last_visited_at"),
                    l = c ? n ? d.tz(c, n) : d(c) : null;
                l && i.diff(l, "minutes") < Ot && s++
            }
            return s
        },
        hasActiveSites: (t, e) => e.activeSitesCount > 0,
        sitesByPartition: (t, e) => {
            const [s = [], i = []] = A(e.sites, {
                visited: !0
            });
            return {
                visited: s,
                notVisited: i
            }
        },
        tasks: t => O(o(t, "tasks", {})),
        projects: t => O(o(t, "projects", {})),
        selectedSiteMarker: (t, e) => {
            const s = o(t, "selectedSite.id");
            return e.siteMarkers.find(i => i.id === s)
        },
        siteMarkers: (t, e) => {
            const s = [];
            for (const i of e.sites) s.push({ ...i,
                icon: Rt(kt(i.name)),
                position: {
                    lat: parseFloat(i.latitude),
                    lng: parseFloat(i.longitude)
                }
            });
            return s
        },
        siteMarkersByPartition: (t, e) => {
            const [s = [], i = []] = A(e.siteMarkers, {
                visited: !0
            });
            return {
                visited: s,
                notVisited: i
            }
        },
        hasJobSiteMarkers: ({
            sitesViewMode: t
        }, {
            siteMarkers: e,
            siteMarkersByPartition: s
        }) => {
            const {
                visited: i
            } = s, n = t === P.VISITED ? i : e;
            return !!o(n, "length", 0)
        },
        selectedMemberMarker: (t, e) => {
            const s = o(t, "selectedMember.id");
            return e.memberMarkers.find(i => i.id === s)
        },
        memberMarkers: (t, e) => {
            const s = [];
            for (const i of e.users) {
                const {
                    location: {
                        accuracy: n,
                        latitude: a,
                        longitude: r
                    } = {},
                    route: c
                } = i, l = n ? parseFloat(n) : Gt, h = o(i, "location", null), _ = Ct(c, "recorded_at"), S = Ut(_, ({
                    latitude: u,
                    longitude: w
                }) => [u, w].join("")), g = h ? S.filter(u => u.latitude !== h.latitude && u.longitude !== h.longitude) : S;
                s.push({ ...z(i, ["location"]),
                    position: {
                        lat: a ? parseFloat(a) : null,
                        lng: r ? parseFloat(r) : null
                    },
                    radius: l,
                    accuracy: l,
                    route: (g || []).map(u => ({ ...z(u, ["latitude", "longitude"]),
                        radius: j,
                        accuracy: j,
                        position: {
                            lat: parseFloat(u.latitude),
                            lng: parseFloat(u.longitude)
                        }
                    }))
                })
            }
            return s
        },
        memberMarkersByPartition: (t, e) => {
            const [s = [], i = []] = A(e.memberMarkers, {
                trackedLocation: !0
            });
            return {
                tracked: s,
                notTracked: i
            }
        },
        memberMarkersWithRecentLocations: (t, e) => {
            const [s = []] = A(e.memberMarkers, {
                trackedLocationRecently: !0
            });
            return s
        },
        membersWithRecentLocationsCount: (t, e) => o(e.memberMarkersWithRecentLocations, "length", 0),
        hasMembersWithRecentLocations: (t, e) => e.membersWithRecentLocationsCount > 0,
        hasActiveSitesOrMembers: (t, e) => e.hasMembersWithRecentLocations || e.hasActiveSites,
        hasMemberMarkers: (t, {
            memberMarkersByPartition: e
        }) => !!o(e, "tracked.length", 0),
        hasMemberProfilePage: t => o(t, "organization.has_member_profile_page", !1),
        timeZoneDate: (t, e) => {
            const s = o(t, "date"),
                i = e.activeTimeZoneName;
            return i ? d.tz(s, i) : d(s)
        },
        activeTimeZoneName: (t, e) => {
            const {
                name: s = null
            } = e.activeTimeZone || {};
            return s
        },
        activeTimeZone: (t, e) => {
            const s = o(t, "time_zones.active");
            return s ? e.timeZoneOptions.find(i => i.for === s) : null
        },
        timeZoneOptions: t => o(t, "time_zones.options", []),
        startWeekOn: t => o(t, "organization.start_week_on"),
        mapSettingsUrl: t => {
            const e = o(t, "organization.id", null);
            return B(e) ? "" : `/organizations/${e}/settings/map`
        },
        jobSitesSettingsUrl: t => {
            const e = o(t, "organization.id", null);
            return B(e) ? "" : `/organizations/${e}/settings/job_sites`
        },
        reportUrl: t => {
            const e = o(t, "organization.id"),
                {
                    date: s
                } = t;
            return `/reports/${e}/job_sites?date=${s}&date_end=${s}`
        },
        memberReportUrl: (t, e) => {
            const s = o(t, "selectedMember.id");
            return `${e.reportUrl}&filters[users]=${s}`
        },
        organizationId: t => o(t, "organization.id"),
        visitedJobSitesUrl: t => `/organizations/${o(t,"organization.id")}/activities/locations?showVisitedJobSites`,
        usersLoading: t => t.loading && t.loading.users,
        sitesLoading: t => t.loading && t.loading.sites,
        apiErrors: t => t.errors
    },
    Ft = {
        [Y]: (t, {
            key: e,
            value: s
        }) => {
            f.set(t, e, s)
        },
        [v]: (t, e, s) => {
            if (s) {
                t.errors = { ...t.errors,
                    [s]: e
                };
                return
            }
            t.errors = e
        },
        [m]: (t, [e, s]) => {
            f.set(t.loading, e, s)
        },
        [q]: (t, e) => {
            t.showingRoutes = e
        },
        [X]: (t, e) => {
            t.showingInfoWindow = e
        },
        [R]: (t, e) => {
            e && (t.date = e)
        },
        [$]: (t, e) => {
            e && f.set(t.time_zones, "active", e)
        },
        [K]: (t, e) => {
            t.sitesViewMode = e
        },
        [k]: (t, e) => {
            Object.keys(e).forEach(s => {
                f.set(t, s, e[s])
            })
        },
        [tt]: (t, e = []) => {
            let s = !1;
            for (const i of e)(!W(t.sites, i.id) || !Vt(o(t.sites, i.id), i)) && (s = !0, t.sites[i.id] = i);
            s && f.set(t.sites, "__touched__", new Date().getTime())
        },
        [L]: (t, e) => {
            Object.keys(e).forEach(s => {
                W(t, s) && Object.keys(e[s]).forEach(i => {
                    const n = `${s}.${i}`,
                        a = T({}, o(t, n, {}), o(e, n, {}));
                    t[s][i] = a
                })
            })
        },
        [F]: (t, {
            userId: e,
            route: s = []
        }) => {
            f.set(t.users, e, { ...o(t.users, e),
                route: s
            })
        },
        [G]: (t, e = null) => {
            t.selectedSite = e
        },
        [H]: (t, e = null) => {
            t.selectedMember = e
        },
        [Q]: (t, e) => {
            t.currentView = e
        },
        [J]: t => {
            t.showingRoutes = !1, t.showingInfoWindow = !1, t.selectedSite = null, t.selectedMember = null
        }
    };

function Xt(t = {}) {
    return t = Object.assign({
        state: Zt,
        getters: Jt,
        actions: $t,
        mutations: Ft
    }, t), zt(t)
}
export {
    Qt as A, Kt as T, Xt as c
};