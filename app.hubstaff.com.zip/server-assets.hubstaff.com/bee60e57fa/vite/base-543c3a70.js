import {
    V as r,
    by as e
} from "./vendor-f5db2be7.js";
r.use(e);
const c = !1;

function u(t = {}) {
    return t.strict = c, new e.Store(t)
}
export {
    u as c
};