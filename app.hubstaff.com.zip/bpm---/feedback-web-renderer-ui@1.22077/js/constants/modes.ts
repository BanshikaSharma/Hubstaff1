export const LIVE_PREVIEW = 'live-preview';
export const PREVIEW = 'preview';
export const STANDARD = 'standard';