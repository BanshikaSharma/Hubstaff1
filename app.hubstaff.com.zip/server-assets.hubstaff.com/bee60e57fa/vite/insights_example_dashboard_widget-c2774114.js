import "./init-ef420420.js";
import {
    V as e
} from "./vendor-f5db2be7.js";
import {
    H as a
} from "./hub_app-778c98e3.js";
import {
    t as n,
    cL as d
} from "./shared-5f1b437f.js";
import {
    c as m
} from "./index-613f2f45.js";
import "./app_messages-e83d8e06.js";
import "./base-543c3a70.js";
import "./mutations-2c62a19a.js";
e.directive("tooltip", n);
e.use(a);

function i(t) {
    const o = JSON.parse(t.dataset.organizationId);
    return new e({
        el: t,
        store: () => m({}),
        name: "InsightsExampleDashboardWidget",
        render: s => s(d, {
            props: {
                organizationId: o
            }
        })
    })
}
const r = document.querySelector("#insights-example-widget");
r && i(r);
document.addEventListener("add_widget:insights", () => {
    const t = document.querySelector("#insights-example-widget");
    t && i(t)
});