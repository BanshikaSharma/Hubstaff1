import {
    n,
    D as E,
    E as z,
    F as T,
    G as W,
    H as R,
    I as j,
    J as I,
    K as F,
    P as J,
    L as b,
    N as v,
    O as U,
    Q as $,
    T as N,
    r as L,
    U as c,
    V as m,
    X as q,
    Y as w,
    Z as V,
    $ as H,
    a0 as B,
    a1 as G,
    a2 as Z,
    a3 as K,
    a4 as Y,
    a5 as X,
    a6 as Q,
    a7 as ee,
    a8 as te,
    a9 as ie,
    aa as ae,
    ab as re,
    ac as se,
    ad as oe,
    ae as ne,
    af as le,
    ag as de,
    ah as ce,
    x as ue,
    ai as me,
    aj as ge,
    ak as he,
    al as pe,
    am as _,
    an as _e,
    ao as h,
    ap as be,
    _ as d,
    aq as fe,
    ar as ve,
    as as we,
    at as De,
    au as ye,
    av as D,
    aw as y,
    ax as Ce,
    ay as C,
    az as ke,
    aA as k,
    aB as Se,
    aC as l,
    aD as S,
    i as g,
    aE as O,
    aF as P,
    aG as M,
    aH as A,
    p as f,
    aI as Oe,
    aJ as Pe,
    aK as Me,
    aL as Ae,
    aM as xe,
    aN as Ee,
    aO as ze,
    aP as Te,
    aQ as We,
    aR as Re,
    aS as je,
    aT as Ie,
    aU as p,
    aV as Fe,
    aW as Je,
    aX as Ue
} from "./shared-5f1b437f.js";
import {
    _ as $e
} from "./WorkLimitsAndExpectations-eee58d45.js";
import {
    I as Ne,
    bl as Le,
    V as u,
    bm as qe
} from "./vendor-f5db2be7.js";
import "./init-ef420420.js";
import {
    G as Ve
} from "./google_maps-3f82c093.js";
import {
    H as He
} from "./hub_app-778c98e3.js";
import "./app_messages-e83d8e06.js";
const Be = {
    data: () => ({
        year: 2020,
        startYear: 2010
    }),
    computed: {},
    methods: {}
};
var Ge = function() {
        var e = this,
            t = e._self._c;
        return t("div", [t("h4", [e._v("Vue AppYearPicker")]), t("AppYearPicker", {
            attrs: {
                "start-year": e.startYear
            },
            model: {
                value: e.year,
                callback: function(a) {
                    e.year = a
                },
                expression: "year"
            }
        })], 1)
    },
    Ze = [],
    Ke = n(Be, Ge, Ze, !1, null, null, null, null);
const Ye = Ke.exports,
    Xe = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: Ye
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Qe = {
        components: {
            ReportTableAvatarIconInitial: E
        },
        data: () => ({
            avatarIconsMap: {
                holiday: "hi-gift",
                time_off: "hi-time-off"
            }
        }),
        computed: {},
        methods: {}
    };
var et = function() {
        var e = this,
            t = e._self._c;
        return t("div", [t("h4", [e._v("Vue ReportTableAvatarIconInitial")]), t("p", [e._v("Icon or fallback to ReportTableAvatarInitial")]), t("div", [t("ReportTableAvatarIconInitial", {
            attrs: {
                icons: e.avatarIconsMap,
                "icon-key": "time_off",
                text: "Text"
            }
        }), e._v(" Text ")], 1), t("div", [t("ReportTableAvatarIconInitial", {
            attrs: {
                icons: e.avatarIconsMap,
                "icon-key": "na",
                text: "Text"
            }
        }), e._v(" Text ")], 1), t("div", [t("ReportTableAvatarIconInitial", {
            attrs: {
                icons: e.avatarIconsMap,
                "icon-key": "holiday",
                text: "T"
            }
        }), e._v(" Hello ")], 1), t("div", [t("ReportTableAvatarIconInitial", {
            attrs: {
                icons: e.avatarIconsMap,
                "icon-key": "na",
                text: "Al"
            }
        }), t("ReportTableAvatarIconInitial", {
            attrs: {
                icons: e.avatarIconsMap,
                "icon-key": "time_off",
                text: "Text"
            }
        }), t("ReportTableAvatarIconInitial", {
            attrs: {
                icons: e.avatarIconsMap,
                "icon-key": "holiday",
                text: "Text"
            }
        })], 1)])
    },
    tt = [],
    it = n(Qe, et, tt, !1, null, null, null, null);
const at = it.exports,
    rt = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: at
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    st = {
        name: "GettingStartedIndex",
        components: {
            ApproveATimesheet: z,
            CreateTeams: T,
            CreateToDos: W,
            StepCard: R,
            SubscribeToAReport: j,
            InviteMembers: I,
            ReviewTeamInsights: F,
            PickProjects: J
        },
        props: {
            steps: {
                type: Array,
                required: !0,
                validator: i => i.every(e => e.title && e.subtitle && e.status && e.substeps.length > 0)
            },
            currentUser: {
                type: Object,
                required: !0,
                validator: i => !!i.first_name && !!i.id
            },
            organization: {
                type: Object,
                required: !0,
                validator: i => !!i.id
            },
            currentSubstep: {
                type: Object,
                required: !0,
                validator: i => !!i.id
            },
            nextSubstep: {
                type: Object,
                default: null,
                validator: i => !i || !!i.name
            }
        },
        data: () => ({
            substepData: null,
            updatedCurrentSubstep: null,
            loading: !0,
            substepsWithFinishedHandlers: ["pick_projects"]
        }),
        computed: {
            nextStepAllowed() {
                return (this.updatedCurrentSubstep || this.currentSubstep).status === "completed"
            },
            nextStepLinkText() {
                var i;
                return `➜ Continue to ${(i=this.nextSubstep)==null?void 0:i.name}`
            }
        },
        beforeMount() {
            this.getSubstepData()
        },
        methods: {
            async getSubstepData() {
                this.substepData || (this.loading = !0);
                const i = await b.substep({
                    organizationId: this.organization.id
                }, {
                    id: this.currentSubstep.id
                }, {
                    abortReload: !0
                });
                this.substepData = i, this.loading = !1
            },
            async continueToNextStep() {
                if (this.nextStepAllowed) this.substepsWithFinishedHandlers.includes(this.currentSubstep.id) ? this.$emit("userClickedContinue") : this.updateSubstep("finished");
                else return !1
            },
            handleFinishedSubstep() {},
            async updateSubstep(i) {
                try {
                    const e = await b.updateSubstep({
                        organizationId: this.organization.id
                    }, {
                        substep: this.currentSubstep.id,
                        status: i
                    }, {
                        abortReload: !0
                    });
                    e.success ? (this.updatedCurrentSubstep = e.current_substep, i === "finished" && window.location.reload()) : e.errors && this.$appMessage("Unexpected error. Please try again.")
                } catch (e) {
                    [401, 403].includes(e.status) || this.$appMessage("Unhandled error. Please try again.")
                }
            },
            async completeSubstep() {
                (this.updatedCurrentSubstep || this.currentSubstep).status !== "completed" && (await this.updateSubstep("completed"), this.substepCompleted = !0)
            },
            async finishSubstep() {
                await this.updateSubstep("finished")
            },
            async incompleteSubstep() {
                await this.updateSubstep("todo")
            },
            async reloadSubstep() {
                await this.getSubstepData()
            },
            async completeOnboarding() {
                await this.updateSubstep("finished"), window.location.href = "/dashboard"
            }
        }
    };
var ot = function() {
        var a;
        var e = this,
            t = e._self._c;
        return t("div", {
            staticClass: "getting-started-page"
        }, [t("div", {
            staticClass: "getting-started-section",
            attrs: {
                id: "getting-started-section-steps"
            }
        }, [t("div", {
            attrs: {
                id: "getting-started-header"
            }
        }, [t("p", {
            staticClass: "title"
        }, [e._v("👋 Welcome, " + e._s(e.currentUser.first_name) + "!")]), t("p", {
            staticClass: "subtitle"
        }, [e._v("Let’s get you started with Hubstaff so you can begin boosting your team’s productivity.")])]), t("div", {
            attrs: {
                id: "getting-started-steps-wrapper"
            }
        }, e._l(e.steps, function(r, s) {
            return t("StepCard", {
                key: r.title + s,
                attrs: {
                    "step-number": s + 1,
                    title: r.title,
                    subtitle: r.subtitle,
                    status: r.status,
                    substeps: r.substeps
                }
            })
        }), 1)]), t("div", {
            directives: [{
                name: "loading",
                rawName: "v-loading",
                value: e.loading,
                expression: "loading"
            }],
            staticClass: "loading static-curtain"
        }), e.substepData ? t("div", {
            staticClass: "getting-started-section",
            attrs: {
                id: "getting-started-section-substeps"
            }
        }, [e.nextSubstep ? t("a", {
            staticClass: "next-substep",
            attrs: {
                disabled: !e.nextStepAllowed,
                href: "#"
            },
            on: {
                click: function(r) {
                    return e.continueToNextStep()
                }
            }
        }, [e._v(" " + e._s(e.nextStepLinkText) + " ")]) : t("a", {
            staticClass: "next-substep",
            attrs: {
                href: "#"
            },
            on: {
                click: function(r) {
                    return e.completeOnboarding()
                }
            }
        }, [e._v(" ✓ Complete Onboarding ")]), e.currentSubstep.id == "subscribe_to_a_report" ? t("SubscribeToAReport", {
            attrs: {
                reports: e.substepData,
                "substep-status": (a = e.updatedCurrentSubstep) == null ? void 0 : a.status
            },
            on: {
                completeSubstep: e.completeSubstep,
                incompleteSubstep: e.incompleteSubstep,
                reloadSubstep: e.reloadSubstep
            }
        }) : e._e(), e.currentSubstep.id == "review_team_insights" ? t("ReviewTeamInsights", {
            attrs: {
                "insights-data": e.substepData.insights,
                "team-members": e.substepData.team_members
            },
            on: {
                completeSubstep: e.completeSubstep
            }
        }) : e._e(), e.currentSubstep.id == "approve_a_timesheet" ? t("ApproveATimesheet", {
            attrs: {
                activities: e.substepData.activities,
                "team-members": e.substepData.team_members
            },
            on: {
                completeSubstep: e.completeSubstep
            }
        }) : e._e(), e.currentSubstep.id == "pick_projects" ? t("PickProjects", {
            attrs: {
                projects: e.substepData.projects,
                organization: e.organization,
                "current-user": e.currentUser
            },
            on: {
                completeSubstep: e.completeSubstep,
                incompleteSubstep: e.incompleteSubstep,
                userClickedContinue: e.handleFinishedSubstep,
                finishSubstep: e.finishSubstep
            }
        }) : e._e(), e.currentSubstep.id == "create_to_dos" ? t("CreateToDos", {
            attrs: {
                projects: e.substepData,
                "current-user": e.currentUser
            },
            on: {
                completeSubstep: e.completeSubstep,
                reloadSubstep: e.reloadSubstep
            }
        }) : e._e(), e.currentSubstep.id == "create_teams" ? t("CreateTeams", {
            attrs: {
                teams: e.substepData,
                organization: e.organization
            },
            on: {
                completeSubstep: e.completeSubstep,
                reloadSubstep: e.reloadSubstep
            }
        }) : e._e(), e.currentSubstep.id == "invite_members" ? t("InviteMembers", {
            attrs: {
                invites: e.substepData,
                organization: e.organization
            },
            on: {
                completeSubstep: e.completeSubstep,
                reloadSubstep: e.reloadSubstep
            }
        }) : e._e()], 1) : e._e()])
    },
    nt = [],
    lt = n(st, ot, nt, !1, null, null, null, null);
const dt = lt.exports,
    ct = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: dt
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    ut = {
        name: "MemberProfiles",
        components: {
            MemberProfilesNav: v,
            MemberNotificationsTable: U,
            MemberChangeNotificationDialog: $,
            MemberUpdateOverridesDialog: N,
            AppPagination: L
        },
        mixins: [c, m],
        props: {
            feature: {
                type: Object,
                required: !0
            },
            members: {
                type: Array,
                required: !0
            },
            pagination: {
                type: Object,
                required: !0
            },
            search: {
                type: String,
                default: ""
            },
            match_default_members_count: {
                type: Number,
                default: 0
            },
            organization: {
                type: Object,
                required: !0
            }
        },
        data() {
            return {
                member: null,
                showMemberChangeNotificationDialog: !1,
                showMemberUpdateOverridesDialog: !1,
                confirmOverride: !1,
                changedKey: 0
            }
        },
        computed: {
            allowReceivingEmails() {
                return this.organization.allow_receiving_emails
            },
            billingLink() {
                return q.billingLink({
                    id: this.organization.id
                })
            },
            showPagination() {
                var i;
                return !this.loading && ((i = this.pagination) == null ? void 0 : i.total_pages) > 1
            }
        },
        methods: {
            onShowMemberChangeNotificationDialog() {
                this.showMemberChangeNotificationDialog = !0
            },
            onCloseMemberChangeNotificationDialog() {
                this.showMemberChangeNotificationDialog = !1, this.changedKey += 1, this.confirmOverride = !1
            },
            onOpenOverridesDialog() {
                this.showMemberUpdateOverridesDialog = !0
            },
            onCloseMemberUpdateOverridesDialog() {
                this.showMemberUpdateOverridesDialog = !1, this.onCloseMemberChangeNotificationDialog()
            },
            onConfirmOverride(i) {
                this.showMemberUpdateOverridesDialog = !1, this.confirmOverride = i
            },
            onChangeNotificationSetting(i, e) {
                const {
                    origin: t
                } = window.location, r = new URL(w(V, {
                    id: this.organization.id
                }), t).toString(), s = {
                    onSuccess: () => {
                        this.$appMessage(`Email notifications turned ${e?"on":"off"}`)
                    }
                };
                this.$inertia.post(r, {
                    organization: {
                        user_id: i,
                        allow_receiving_emails: e
                    }
                }, s)
            },
            onSearchTermUpdated(i) {
                this.refresh({
                    search: i,
                    page: 1
                })
            },
            onPageChanged(i) {
                this.refresh({
                    page: i
                })
            },
            refresh(i) {
                const e = new URL(window.location);
                for (const t in i) e.searchParams.set(t, i[t]);
                this.$inertia.visit(e.toString())
            }
        }
    };
var mt = function() {
        var e = this,
            t = e._self._c;
        return t("div", {
            staticClass: "row"
        }, [t("div", {
            staticClass: "col-md-3 mb-10"
        }, [t("MemberProfilesNav", {
            attrs: {
                "notifications-active": "",
                "account-provisioning-flag": "",
                "expected-work-enabled": "",
                "organization-id": e.organization.id
            }
        })], 1), t("div", {
            staticClass: "col-md-8 col-sm-12 setting_wrapper settings_panel"
        }, [e.feature.available ? e._e() : t("div", {
            staticClass: "alert alert-disabled"
        }, [t("div", {
            staticClass: "alert-inner-wrapper"
        }, [t("div", {
            staticClass: "alert-body d-flex align-items-center"
        }, [t("i", {
            staticClass: "hi hi-16 hi-lock ml-5 mr-15 text-blue"
        }), t("span", [e._v(e._s(e.feature.availability_message))])]), t("div", {
            staticClass: "alert-action"
        }, [t("a", {
            staticClass: "btn btn-sm btn-primary mr-15",
            attrs: {
                href: e.billingLink
            }
        }, [e._v(" View plans & add-ons ")])])])]), t("div", {
            class: {
                "section-disabled": !e.feature.available
            }
        }, [t("div", {
            staticClass: "mb-20"
        }, [t("h5", {
            staticClass: "setting-title"
        }, [e._v("Email notifications")]), t("p", {
            staticClass: "text-muted"
        }, [e._v(" When creating new accounts, this sets whether the members will receive ANY email communication from Hubstaff. This includes notifications about their own work as well as anyone they might manage. ")]), t("p", {
            staticClass: "text-muted"
        }, [e._v(" This setting can be altered when creating the accounts or individually overridden afterwards in the table below. ")]), t("div", {
            staticClass: "d-inline-flex flex-column mt-30"
        }, [t("label", {
            staticClass: "control-label setting-sub-title"
        }, [e._v(" Default "), t("i", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: {
                    placement: "right"
                },
                expression: "{ placement: 'right' }"
            }],
            staticClass: "hi-info text-default ml-5 a-tooltip",
            attrs: {
                title: "By turning on this setting, the default for new accounts will be to receive email communications from Hubstaff. This can be changed during account creation or overridden below."
            }
        })]), t("AppOnOffToggle", {
            key: e.changedKey,
            attrs: {
                value: e.allowReceivingEmails
            },
            on: {
                input: e.onShowMemberChangeNotificationDialog
            }
        }, [t("div", {
            staticClass: "d-flex align-items-center"
        }, [e._v(" Allow members to receive Hubstaff emails ")])])], 1)]), e.loading && e.feature.available ? t("AppLoadingTable", {
            attrs: {
                columns: 3
            }
        }) : e.feature.available ? t("MemberNotificationsTable", {
            attrs: {
                "show-loading": e.loading,
                members: e.members,
                "organization-id": e.organization.id,
                search: e.search
            },
            on: {
                "update-member": e.onChangeNotificationSetting,
                "search-updated": e.onSearchTermUpdated
            }
        }) : e._e(), e.showPagination ? t("AppPagination", {
            attrs: {
                pagination: e.pagination,
                resource: {
                    one: "member",
                    many: "members"
                }
            },
            on: {
                "page-changed": e.onPageChanged
            }
        }) : e._e(), e.showMemberChangeNotificationDialog ? t("MemberChangeNotificationDialog", {
            key: "confirm-change-notifications",
            attrs: {
                id: "confirm-change-notifications",
                "needs-confirm-change": e.match_default_members_count,
                "confirm-override": e.confirmOverride,
                "setting-value": !e.organization.allow_receiving_emails
            },
            on: {
                "open-confirm-override-dialog": e.onOpenOverridesDialog,
                close: e.onCloseMemberChangeNotificationDialog
            }
        }) : e._e(), e.showMemberUpdateOverridesDialog ? t("MemberUpdateOverridesDialog", {
            key: "update-overrides",
            attrs: {
                id: "update-overrides",
                "overrides-count": e.match_default_members_count
            },
            on: {
                close: e.onCloseMemberUpdateOverridesDialog,
                "close-confirmed": e.onConfirmOverride
            }
        }) : e._e()], 1)])])
    },
    gt = [],
    ht = n(ut, mt, gt, !1, null, null, null, null);
const pt = ht.exports,
    _t = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: pt
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    bt = {
        name: "MemberProfiles",
        components: {
            MemberProfilesNav: v,
            MemberProfileFieldsTable: H,
            MemberProfileFieldDialog: B,
            DeleteMemberProfileFieldDialog: G
        },
        mixins: [c, m],
        props: {
            member_profile_fields: {
                type: Array,
                required: !0
            },
            organization: {
                type: Object,
                required: !0
            },
            account_provisioning_flag: {
                type: Boolean,
                required: !0
            },
            settings_expected_work_flag: {
                type: Boolean,
                required: !0
            }
        },
        data() {
            return {
                memberProfileField: null,
                showNewMemberProfileFieldDialog: !1,
                showEditMemberProfileFieldDialog: !1,
                showDeleteMemberProfileFieldDialog: !1
            }
        },
        computed: {
            noMemberProfileFields() {
                return (this.member_profile_fields || []).length === 0
            }
        },
        methods: {
            onShowNewMemberProfileFieldDialog() {
                this.showNewMemberProfileFieldDialog = !0
            },
            onCloseNewMemberProfileFieldDialog() {
                this.showNewMemberProfileFieldDialog = !1
            },
            onShowEditMemberProfileFieldDialog(i) {
                this.memberProfileField = i, this.showEditMemberProfileFieldDialog = !0
            },
            onCloseEditMemberProfileFieldDialog() {
                this.showEditMemberProfileFieldDialog = !1
            },
            onShowDeleteMemberProfileFieldDialog(i) {
                this.memberProfileField = i, this.showDeleteMemberProfileFieldDialog = !0
            },
            onCloseDeleteMemberProfileFieldDialog() {
                this.showDeleteMemberProfileFieldDialog = !1
            }
        }
    };
var ft = function() {
        var e = this,
            t = e._self._c;
        return t("div", {
            staticClass: "row"
        }, [t("div", {
            staticClass: "col-md-3"
        }, [t("MemberProfilesNav", {
            attrs: {
                "profile-fields-active": "",
                "account-provisioning-flag": e.account_provisioning_flag,
                "expected-work-enabled": e.settings_expected_work_flag,
                "organization-id": e.organization.id
            }
        })], 1), t("div", {
            staticClass: "col-md-8 col-sm-9 setting_wrapper settings_panel"
        }, [t("div", {
            staticClass: "d-sm-flex justify-content-between"
        }, [e._m(0), t("div", {
            staticClass: "d-flex d-sm-block"
        }, [t("AppButton", {
            staticClass: "flex-1",
            attrs: {
                id: "new-member-field",
                type: "primary"
            },
            on: {
                click: e.onShowNewMemberProfileFieldDialog
            }
        }, [e._v(" Add custom field ")])], 1)]), e.noMemberProfileFields ? [e._m(1)] : [e.loading ? t("AppLoadingTable", {
            attrs: {
                columns: 4
            }
        }) : t("MemberProfileFieldsTable", {
            attrs: {
                "show-loading": e.loading,
                "member-profile-fields": e.member_profile_fields
            },
            on: {
                "open-edit-dialog": e.onShowEditMemberProfileFieldDialog,
                "open-delete-dialog": e.onShowDeleteMemberProfileFieldDialog
            }
        })], e.showNewMemberProfileFieldDialog ? t("MemberProfileFieldDialog", {
            key: "create-pf-dialog",
            attrs: {
                id: "new-member-profile-field"
            },
            on: {
                close: e.onCloseNewMemberProfileFieldDialog
            }
        }) : e._e(), e.showEditMemberProfileFieldDialog ? t("MemberProfileFieldDialog", {
            key: "edit-pf-dialog",
            attrs: {
                id: "edit-member-profile-field",
                editing: "",
                "member-profile-field": e.memberProfileField
            },
            on: {
                close: e.onCloseEditMemberProfileFieldDialog,
                "show-delete-dialog": e.onShowDeleteMemberProfileFieldDialog
            }
        }) : e._e(), e.showDeleteMemberProfileFieldDialog ? t("DeleteMemberProfileFieldDialog", {
            key: "delete-pf-dialog",
            attrs: {
                id: "delete-member-profile-field",
                "member-profile-field": e.memberProfileField
            },
            on: {
                close: e.onCloseDeleteMemberProfileFieldDialog,
                "close-edit-dialog": e.onCloseEditMemberProfileFieldDialog
            }
        }) : e._e()], 2)])
    },
    vt = [function() {
        var i = this,
            e = i._self._c;
        return e("div", {
            staticClass: "mb-10"
        }, [e("h5", {
            staticClass: "setting-title"
        }, [i._v("Member Profiles")]), e("p", {
            staticClass: "text-muted"
        }, [i._v("Add or edit custom fields that appear on member profiles")])])
    }, function() {
        var i = this,
            e = i._self._c;
        return e("div", {
            staticClass: "mt-20 text-center"
        }, [e("h4", {
            staticClass: "my-0"
        }, [i._v("No custom fields")])])
    }],
    wt = n(bt, ft, vt, !1, null, null, null, null);
const Dt = wt.exports,
    yt = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: Dt
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Ct = {
        name: "OvertimePolicies",
        components: {
            OvertimePoliciesNoData: Z,
            OvertimePoliciesTable: K,
            OvertimePoliciesDialog: Y,
            OvertimePoliciesMembersDialog: X,
            OvertimePoliciesMemberPayDialog: Q,
            OvertimePoliciesConfirmCreateDialog: ee
        },
        mixins: [c, m],
        props: {
            all_active_policies: {
                type: Array,
                required: !0
            },
            members: {
                type: Array,
                required: !0
            },
            organization: {
                type: Object,
                required: !0
            },
            overtime_policies: {
                type: Array,
                required: !0
            },
            overtime_policies_query: {
                type: Object,
                required: !0
            },
            pagination: {
                type: Object,
                required: !0
            }
        },
        data() {
            return {
                overtimePolicy: null,
                showNewOvertimePolicyDialog: !1,
                showEditOvertimePolicyDialog: !1,
                showEditMembersDialog: !1,
                showMemberPayDialog: !1,
                showConfirmCreateDialog: !1,
                member: {},
                confirmedCreate: !1,
                selectedTab: "active"
            }
        },
        computed: {
            overtimePoliciesEmpty() {
                return (this.overtime_policies || []).length === 0
            },
            showingActive() {
                return this.overtime_policies_query.status !== "archived"
            },
            currentParams() {
                return Object.entries(this.overtime_policies_query).filter(([, i]) => !!i)
            },
            overtimePoliciesUrl() {
                return ["/overtime_policies/:overtimePolicyId", this.showingActive ? "" : `?status=${this.overtime_policies_query.status}`].join("")
            }
        },
        methods: {
            onFiltersChange(i = {}) {
                const {
                    origin: e,
                    pathname: t
                } = window.location, a = new URL(t, e), r = new URLSearchParams(this.currentParams);
                Object.entries(i).forEach(([s, o]) => {
                    o ? r.set(s, o) : r.delete(s)
                }), a.search = r.toString(), this.$inertia.visit(a.toString())
            },
            onShowNewOvertimePolicyDialog() {
                this.showNewOvertimePolicyDialog = !0
            },
            onShowEditOvertimePolicyDialog(i) {
                this.overtimePolicy = i, this.showEditOvertimePolicyDialog = !0
            },
            onShowMemberPayDialog(i) {
                this.member = i, this.showMemberPayDialog = !0
            },
            onCloseNewOvertimePolicyDialog() {
                this.confirmedCreate = !1, this.showNewOvertimePolicyDialog = !1
            },
            onCloseEditOvertimePolicyDialog() {
                this.overtimePolicy = {}, this.showEditOvertimePolicyDialog = !1
            },
            onOpenEditMembersDialog(i) {
                this.overtimePolicy = i, this.showEditMembersDialog = !0
            },
            onOpenConfirmCreateDialog() {
                this.showConfirmCreateDialog = !0
            },
            onCloseOvertimeMembersDialog() {
                this.overtimePolicy = {}, this.showEditMembersDialog = !1
            },
            onCloseMemberPayDialog() {
                this.member = {}, this.showMemberPayDialog = !1
            },
            onCloseConfirmCreateDialog() {
                this.showConfirmCreateDialog = !1
            },
            onConfirmCreate() {
                this.showConfirmCreateDialog = !1, this.confirmedCreate = !0
            },
            selectTab(i) {
                this.onFiltersChange({
                    status: i,
                    page: 0
                })
            }
        }
    };
var kt = function() {
        var e = this,
            t = e._self._c;
        return t("div", {
            staticClass: "setting_wrapper"
        }, [t("div", {
            staticClass: "custom-app-tabs-wrapper"
        }, [t("ul", {
            staticClass: "nav nav-tabs"
        }, [t("li", {
            staticClass: "nav-item",
            class: {
                active: e.showingActive
            }
        }, [t("a", {
            staticClass: "nav-link",
            on: {
                click: function(a) {
                    return e.selectTab("active")
                }
            }
        }, [e._v(" Active ")])]), t("li", {
            staticClass: "nav-item",
            class: {
                active: !e.showingActive
            }
        }, [t("a", {
            staticClass: "nav-link",
            on: {
                click: function(a) {
                    return e.selectTab("archived")
                }
            }
        }, [e._v(" Archived ")])])])]), t("div", {
            staticClass: "d-sm-flex justify-content-between"
        }, [e._m(0), !e.overtimePoliciesEmpty && e.showingActive ? t("div", {
            staticClass: "d-flex d-sm-block"
        }, [t("AppButton", {
            staticClass: "flex-1",
            attrs: {
                id: "new-overtime-policy",
                type: "primary"
            },
            on: {
                click: e.onShowNewOvertimePolicyDialog
            }
        }, [e._v(" Add policy ")])], 1) : e._e()]), e.overtimePoliciesEmpty ? [e.showingActive ? [t("OvertimePoliciesNoData"), t("div", {
            staticClass: "row text-center"
        }, [t("AppButton", {
            staticClass: "mt-10",
            attrs: {
                id: "new-overtime-policy",
                type: "primary"
            },
            on: {
                click: e.onShowNewOvertimePolicyDialog
            }
        }, [e._v(" Add policy ")])], 1)] : [t("div", {
            staticClass: "alert alert-info h4 mt-50"
        }, [e._v(" No archived overtime policies ")])]] : [e.loading ? t("AppLoadingTable", {
            attrs: {
                columns: 4
            }
        }) : t("OvertimePoliciesTable", {
            attrs: {
                "show-loading": e.loading,
                pagination: e.pagination,
                "overtime-policies": e.overtime_policies,
                "showing-active": e.showingActive,
                "all-active-policies": e.all_active_policies
            },
            on: {
                "open-edit-dialog": e.onShowEditOvertimePolicyDialog,
                "open-edit-members-dialog": e.onOpenEditMembersDialog,
                "page-changed": function(a) {
                    return e.onFiltersChange({
                        page: a
                    })
                }
            }
        })], e.showNewOvertimePolicyDialog ? t("OvertimePoliciesDialog", {
            key: "create-op-dialog",
            attrs: {
                id: "new-overtime-policy",
                members: e.members,
                "overtime-policies": e.overtime_policies,
                "confirmed-create": e.confirmedCreate,
                "all-active-policies": e.all_active_policies,
                "overtime-policies-url": e.overtimePoliciesUrl
            },
            on: {
                "open-pay-dialog": e.onShowMemberPayDialog,
                "open-confirm-create-dialog": e.onOpenConfirmCreateDialog,
                close: e.onCloseNewOvertimePolicyDialog
            }
        }) : e._e(), e.showEditOvertimePolicyDialog ? t("OvertimePoliciesDialog", {
            key: "edit-op-dialog",
            attrs: {
                id: "edit-overtime-policy",
                "overtime-policy": e.overtimePolicy,
                "overtime-policies": e.overtime_policies,
                members: e.members,
                "all-active-policies": e.all_active_policies,
                "overtime-policies-url": e.overtimePoliciesUrl,
                editing: ""
            },
            on: {
                "open-pay-dialog": e.onShowMemberPayDialog,
                close: e.onCloseEditOvertimePolicyDialog
            }
        }) : e._e(), e.showEditMembersDialog ? t("OvertimePoliciesMembersDialog", {
            key: "edit-op-members-dialog",
            attrs: {
                id: "edit-overtime-members",
                "overtime-policy": e.overtimePolicy,
                "overtime-policies": e.overtime_policies,
                members: e.members,
                "all-active-policies": e.all_active_policies,
                "overtime-policies-url": e.overtimePoliciesUrl
            },
            on: {
                "open-pay-dialog": e.onShowMemberPayDialog,
                close: e.onCloseOvertimeMembersDialog
            }
        }) : e._e(), e.showMemberPayDialog ? t("OvertimePoliciesMemberPayDialog", {
            attrs: {
                member: e.member
            },
            on: {
                close: e.onCloseMemberPayDialog
            }
        }) : e._e(), e.showConfirmCreateDialog ? t("OvertimePoliciesConfirmCreateDialog", {
            key: "confirm-create-dialog",
            on: {
                close: e.onCloseConfirmCreateDialog,
                "close-confirmed": e.onConfirmCreate
            }
        }) : e._e()], 2)
    },
    St = [function() {
        var i = this,
            e = i._self._c;
        return e("div", {
            staticClass: "mb-10"
        }, [e("h5", {
            staticClass: "setting-title"
        }, [i._v("Overtime policies")]), e("p", {
            staticClass: "text-muted"
        }, [i._v("Set up automatic overtime policies")])])
    }],
    Ot = n(Ct, kt, St, !1, null, null, null, null);
const Pt = Ot.exports,
    Mt = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: Pt
    }, Symbol.toStringTag, {
        value: "Module"
    }));
var At = function() {
        var a, r;
        var e = this,
            t = e._self._c;
        return t("div", {
            staticClass: "schedules"
        }, [t("SchedulesFilters", {
            class: {
                loading: e.loading
            },
            attrs: {
                "more-users-to-load": e.moreUsersToLoad,
                "on-members-view": e.onMembersView
            },
            on: {
                "filter-change": e.updateFilters,
                "open-dialog": e.openDialog
            }
        }), t("div", {
            staticClass: "fullcalendar-wrapper mt-15",
            class: {
                loading: e.loading
            },
            attrs: {
                id: "schedules-fullcalendar"
            }
        }, [t("div", {
            staticClass: "d-flex align-items-center justify-content-between flex-sm-row flex-column"
        }, [t("div", {
            staticClass: "d-flex gap-15"
        }, [t("div", {
            staticClass: "sm-hide"
        }, [t("SchedulesFiltersViewToggles", {
            on: {
                "filter-change": e.updateFilters
            }
        })], 1), e.onWeekView ? t("SchedulesDropdown", {
            attrs: {
                label: "Group by",
                options: e.weekViewOptions,
                "initial-value": e.subtype,
                "param-name": "subtype"
            },
            on: {
                "filter-change": e.updateFilters
            }
        }) : e._e()], 1), e.moreUsersToLoad && !e.onMembersView ? t("div", {
            staticClass: "d-flex align-items-center max-members-warning text-muted gap-5"
        }, [t("i", {
            staticClass: "hi hi-12 hi-info-filled"
        }), e._v("A max of 20 members are shown in this view.")]) : e._e(), e.onMembersView ? [t("label", {
            staticClass: "unscheduled-toggle-wrapper toggle-switch-wrapper mt-sm-0 mt-10"
        }, [t("input", {
            staticClass: "custom-control-input",
            attrs: {
                type: "checkbox"
            },
            domProps: {
                checked: e.unscheduledToggle
            },
            on: {
                change: e.showUnscheduled
            }
        }), t("div", {
            staticClass: "toggle-switch-label text-transform-none"
        }, [e._v("Show unscheduled")]), t("div", {
            staticClass: "toggle-switch"
        })])] : e._e()], 2), e.hasMembersFilter ? t("AppInfiniteScroll", {
            staticClass: "infinite-scroll w-full",
            attrs: {
                "max-height": "auto",
                "show-more-link": e.showMoreLink
            },
            on: {
                loadmore: e.loadMoreData
            }
        }, [e.fullcalendarLoaded ? t("FullCalendar", {
            key: e.calendarKey,
            attrs: {
                options: { ...e.calendarOptions,
                    events: e.allEvents
                }
            },
            scopedSlots: e._u([{
                key: "eventContent",
                fn: function({
                    event: s
                }) {
                    return [t(e.eventComponent, {
                        tag: "component",
                        attrs: {
                            event: s
                        }
                    })]
                }
            }, e.onDayView ? null : {
                key: "dayHeaderContent",
                fn: function({
                    date: s
                }) {
                    return [e.onWeekView ? [t("div", {
                        staticClass: "fc-cell-content"
                    }, [t("div", {
                        staticClass: "scheduler-heading-date"
                    }, [t("div", {
                        staticClass: "scheduler-heading-date-day-of-month"
                    }, [e._v(e._s(e.formattedDay(s)))]), t("div", {
                        staticClass: "day-month-wrapper"
                    }, [t("div", {
                        staticClass: "scheduler-heading-date-day-of-week"
                    }, [e._v(e._s(e.formattedDayName(s)))]), t("div", {
                        staticClass: "scheduler-heading-date-month-name"
                    }, [e._v(e._s(e.formattedMonth(s)))])])])])] : e.onMonthView ? t("span", [e._v(e._s(e.formattedDayName(s)))]) : e._e()]
                }
            }, e.onMembersView ? {
                key: "slotLabelContent",
                fn: function({
                    date: s
                }) {
                    return [t("div", {
                        staticClass: "fc-cell-content"
                    }, [t("div", {
                        staticClass: "scheduler-heading-date"
                    }, [t("div", {
                        staticClass: "scheduler-heading-date-day-of-month"
                    }, [e._v(e._s(e.formattedDay(s)))]), t("div", {
                        staticClass: "day-month-wrapper"
                    }, [t("div", {
                        staticClass: "scheduler-heading-date-day-of-week"
                    }, [e._v(e._s(e.formattedDayName(s)))]), t("div", {
                        staticClass: "scheduler-heading-date-month-name"
                    }, [e._v(e._s(e.formattedMonth(s)))])])])])]
                }
            } : null, {
                key: "resourceAreaHeaderContent",
                fn: function() {},
                proxy: !0
            }, e.onMembersView ? {
                key: "resourceLabelContent",
                fn: function(s) {
                    return [t("a", {
                        attrs: {
                            href: `/organizations/${e.organization.id}/members/${s.resource.id}?tab=work%20hours`,
                            target: "_blank"
                        }
                    }, [t("img", {
                        staticClass: "avatar avatar-speck",
                        attrs: {
                            src: s.resource.extendedProps.avatar
                        }
                    }), t("span", {
                        staticClass: "member-name"
                    }, [e._v(e._s(s.fieldValue))])])]
                }
            } : null], null, !0)
        }) : e._e()], 1) : e._e(), !e.loading && (!e.hasMembersFilter || !e.users.length) ? t("div", {
            staticClass: "empty-results d-flex flex-column align-items-center justify-content-center height p-40"
        }, [t("img", {
            attrs: {
                src: e.IMAGE_EMPTY_BOX,
                alt: "No members selected; to view calendar data, please select members or teams"
            }
        }), t("div", {
            staticClass: "d-flex flex-column align-items-center gap-5"
        }, [t("h6", {
            staticClass: "m-0 font-normal"
        }, [e._v("No members selected")]), t("p", {
            staticClass: "text-muted"
        }, [e._v("To view calendar data, please select "), !e.hasTeamsFilter && !e.hasMembersFilter ? [e._v("teams or members")] : e.hasTeamsFilter && !e.hasMembersFilter ? [e._v("teams and members")] : [e._v("members")]], 2)])]) : e._e(), e.showNewScheduleDialog ? t("ScheduleDialog", {
            key: "create-schedule-dialog",
            attrs: {
                id: "new-schedule-form",
                "date-range": e.scheduleDateRange,
                "editing-attendance-schedule": {
                    user_id: e.selectedUserId,
                    filteredUsers: e.users
                }
            },
            on: {
                close: function(s) {
                    return e.closeScheduleDialog()
                }
            }
        }) : e._e(), e.showHolidayWizardDialog ? t("HolidayWizard", {
            attrs: {
                show: e.showHolidayWizardDialog,
                "organization-id": e.organization.id,
                "organization-tz": e.organization.time_zone.for,
                "redirect-path": e.redirectPath,
                "country-list": e.country_list
            },
            on: {
                close: function(s) {
                    return e.toggleScheduleDialog("showHolidayWizardDialog", !1)
                },
                loading: e.setLoading
            }
        }) : e._e(), e.showTimeOffDialog ? t("TimeOffRequestSetupDialog", {
            attrs: {
                show: e.showTimeOffDialog,
                "allow-manage": e.user_permissions.time_off_requests.manage,
                "organization-id": e.organization.id,
                "redirect-path": e.redirectPath,
                "current-user-dropdown-object": e.current_user_dropdown_object
            },
            on: {
                close: function(s) {
                    return e.toggleScheduleDialog("showTimeOffDialog", !1)
                },
                loading: e.setLoading
            }
        }) : e._e(), e.showAttendanceShiftDialog ? t("AttendanceShiftDialog", {
            attrs: {
                event: e.currentEvent
            },
            on: {
                close: e.closeDialogs
            }
        }) : e._e(), e.showDeleteSchedulesDialog ? t("RemoveMultipleAttendanceSchedulesDialog", {
            key: "remove-schedules-dialog",
            attrs: {
                "filtered-users": e.users
            },
            on: {
                close: function(s) {
                    return e.toggleScheduleDialog("showDeleteSchedulesDialog", !1)
                }
            }
        }) : e._e(), e.showTimeOffRequestDialog ? t("TimeOffRequestActionDialog", {
            attrs: {
                "organization-id": e.organization.id,
                "selected-time-off-request-id": (r = (a = e.currentEvent) == null ? void 0 : a.timeOffRequestAttributes) == null ? void 0 : r.id,
                "redirect-path": e.redirectPath,
                "show-original-time-zone": "",
                show: ""
            },
            on: {
                close: e.closeDialogs
            }
        }) : e._e(), e.showJobDialog ? t("JobDialog", {
            attrs: {
                event: e.currentEvent
            },
            on: {
                close: e.closeDialogs
            }
        }) : e._e(), e.showHolidayDialog ? t("HolidayDialog", {
            attrs: {
                event: e.currentEvent
            },
            on: {
                close: e.closeDialogs
            }
        }) : e._e(), e.showIcalendarDialog ? t("IcalendarDialog", {
            attrs: {
                id: "icalendar-dialog"
            },
            on: {
                close: function(s) {
                    return e.toggleScheduleDialog("showIcalendarDialog", !1)
                }
            }
        }) : e._e()], 1)], 1)
    },
    xt = [];
const Et = window.FULLCALENDAR_KEY,
    zt = {
        day: we,
        week: De,
        month: ye
    },
    Tt = {
        name: "SchedulesIndex",
        components: {
            FullCalendar: Ne,
            SchedulesFilters: te,
            AttendanceShiftDialog: ie,
            ScheduleDialog: ae,
            TimeOffRequestDialog: re,
            TimeOffRequestActionDialog: se,
            JobDialog: oe,
            HolidayDialog: ne,
            IcalendarDialog: le,
            SchedulesDropdown: de,
            RemoveMultipleAttendanceSchedulesDialog: ce,
            AppInfiniteScroll: ue,
            HolidayWizard: me,
            TimeOffRequestSetupDialog: ge,
            SchedulesFiltersViewToggles: he
        },
        mixins: [c, m],
        props: {
            events: {
                type: Array,
                required: !0
            },
            calendar_resources: {
                type: Object,
                required: !0
            },
            beta_dialog: {
                type: Object,
                required: !0
            },
            is_owner_manager: {
                type: Boolean,
                required: !0
            },
            clients: {
                type: Array,
                required: !0
            },
            visits_report_url: {
                type: String,
                required: !0
            },
            organization: {
                type: Object,
                required: !0
            },
            start_date: {
                type: String,
                required: !0
            },
            stop_date: {
                type: String,
                required: !0
            },
            time_zones: {
                type: Array,
                required: !0
            },
            time_zone: {
                type: Object,
                required: !0
            },
            active_view: {
                type: String,
                required: !0,
                validator: i => ["month", "week", "day"].includes(i)
            },
            events_filter: {
                type: Array,
                default () {
                    return []
                }
            },
            enabled_event_types: {
                type: Array,
                required: !0
            },
            filtered_team_ids: {
                type: Array,
                default () {
                    return []
                }
            },
            filtered_user_ids: {
                type: Array,
                default () {
                    return []
                }
            },
            select_all: {
                type: String,
                default: ""
            },
            teams_enabled: {
                type: Boolean,
                required: !0
            },
            user_permissions: {
                type: Object,
                required: !0
            },
            subtype: {
                type: String,
                default: "time",
                validator: i => ["time", "members"].includes(i)
            },
            promotions: {
                type: Array,
                default: () => []
            },
            country_list: {
                type: Array,
                required: !0,
                validator: i => i.length > 0
            },
            current_user_dropdown_object: {
                type: Object,
                required: !0
            }
        },
        data() {
            return {
                IMAGE_EMPTY_BOX: pe,
                fullcalendarLoaded: !1,
                fullcalendarPlugins: [],
                filters: null,
                showNewScheduleDialog: !1,
                showDeleteSchedulesDialog: !1,
                scheduleDateRange: null,
                showIcalendarDialog: !1,
                showHolidayWizardDialog: !1,
                showTimeOffDialog: !1,
                newScheduleDate: moment(),
                showEditScheduleDialog: !1,
                editingAttendanceSchedule: null,
                currentEvent: null,
                selectedUserId: null,
                showAttendanceShiftDialog: !1,
                showTimeOffRequestDialog: !1,
                showJobDialog: !1,
                showHolidayDialog: !1,
                loading: !1,
                unscheduledToggle: !0,
                allEvents: this.fullCalendarEvents(this.events),
                viewOptions: Object.freeze([{
                    id: "month",
                    text: "Month"
                }, {
                    id: "week",
                    text: "Week"
                }, {
                    id: "day",
                    text: "Day"
                }]),
                weekViewOptions: Object.freeze([{
                    id: "members",
                    text: "Members"
                }, {
                    id: "time",
                    text: "Time"
                }]),
                allResources: this.calendar_resources,
                page: 1
            }
        },
        computed: { ..._({
                modalDialogs: "modal_dialogs"
            }),
            hasMembersFilter() {
                var i, e;
                return ((i = this.select_all) == null ? void 0 : i.includes("users")) || !!((e = this.filtered_user_ids) != null && e.length)
            },
            hasTeamsFilter() {
                var i;
                return !!((i = this.filtered_team_ids) != null && i.length)
            },
            redirectPath() {
                return location.pathname + location.search
            },
            users() {
                return this.allResources.users || []
            },
            defaultFilters() {
                return {
                    start_date: this.start_date,
                    stop_date: this.stop_date,
                    events_filter: this.events_filter,
                    time_zone: this.time_zone.for,
                    active_view: this.active_view,
                    subtype: this.subtype,
                    filtered_user_ids: this.filtered_user_ids || this.users.map(i => i.id),
                    filtered_team_ids: this.filtered_team_ids,
                    select_all: this.select_all,
                    scheduled: this.unscheduledToggle ? 0 : 1
                }
            },
            calendarOptions() {
                return {
                    plugins: this.fullcalendarPlugins,
                    initialView: this.fetchInitialView,
                    now: moment().tz(this.time_zone.for).format(),
                    showNonCurrentDates: !1,
                    editable: !1,
                    selectable: !0,
                    selectMirror: !0,
                    dayMaxEvents: 2,
                    weekends: !0,
                    timeZone: this.time_zone.for,
                    headerToolbar: {
                        left: "",
                        end: ""
                    },
                    initialDate: this.start_date,
                    resources: this.users,
                    resourceOrder: "title",
                    stickyHeaderDates: !0,
                    scrollTime: "07:00",
                    firstDay: _e(this.organization.start_week_on),
                    resourceAreaWidth: "18%",
                    height: this.calendarHeight,
                    schedulerLicenseKey: Et,
                    views: {
                        resourceTimelineWeek: {
                            slotDuration: {
                                days: 1
                            },
                            type: "resourceTimeline",
                            slotLabelFormat: {
                                meridiem: "short"
                            },
                            eventMaxStack: 2
                        }
                    },
                    listDayFormat: {
                        month: "short",
                        day: "2-digit",
                        weekday: "short"
                    },
                    listDaySideFormat: !1,
                    slotLabelFormat: i => moment(i.date.marker).utc().format(h.time.hr_meridiem),
                    allDayText: "All day",
                    filterResourcesWithEvents: !this.unscheduledToggle,
                    select: i => this.handleDateSelect(i),
                    eventClick: i => this.handleEventClick(i),
                    eventsSet: i => this.handleEventsSet(i),
                    eventAdd: i => this.handleAdd(i),
                    eventChange: i => this.handleChange(i),
                    eventRemove: i => this.handleRemove(i),
                    selectAllow: () => this.user_permissions.schedules.bulk_manage
                }
            },
            fetchInitialView() {
                return this.active_view === "week" && this.subtype === "members" ? "resourceTimelineWeek" : {
                    day: "listWeek",
                    week: "timeGridWeek",
                    month: "dayGridMonth"
                }[this.active_view]
            },
            onDayView() {
                return this.active_view === "day"
            },
            onMonthView() {
                return this.active_view === "month"
            },
            onWeekView() {
                return this.active_view === "week" || this.active_view === "members"
            },
            onMembersView() {
                return this.active_view === "week" && this.subtype === "members"
            },
            eventComponent() {
                return this.onMembersView ? be : zt[this.active_view]
            },
            calendarKey() {
                return this.active_view + this.start_date + this.stop_date + this.subtype
            },
            eventTypeMap() {
                return {
                    Shift: {
                        dialog: "showAttendanceShiftDialog",
                        attributes: "shiftAttributes"
                    },
                    "Time off request": {
                        dialog: "showTimeOffRequestDialog",
                        attributes: "timeOffRequestAttributes"
                    },
                    Job: {
                        dialog: "showJobDialog",
                        attributes: "jobAttributes"
                    },
                    Holiday: {
                        dialog: "showHolidayDialog",
                        attributes: "holidayAttributes"
                    }
                }
            },
            moreUsersToLoad() {
                return this.page < this.pageCount
            },
            calendarHeight() {
                return this.onMonthView ? null : "auto"
            },
            pageCount() {
                return this.calendar_resources.page_count
            },
            showMoreLink() {
                return this.moreUsersToLoad && this.onMembersView
            }
        },
        watch: {
            events: function() {
                if (this.appendData) {
                    const i = [...this.allEvents, ...this.fullCalendarEvents(this.events)];
                    this.allEvents = [...new Map(i.map(e => [`${e.id}-${e.resourceId}`, e])).values()]
                } else this.allEvents = this.fullCalendarEvents(this.events), this.page !== 1 && this.updateFilters([{
                    key: "page",
                    value: 1
                }])
            },
            calendar_resources: function() {
                if (this.appendData) {
                    const i = [...this.allResources.users, ...this.calendar_resources.users];
                    this.allResources = this.calendar_resources, this.allResources.users = i
                } else this.allResources = this.calendar_resources
            }
        },
        mounted() {
            window.addEventListener("pageshow", i => {
                i.persisted || window.BannersEventEmitter.$emit("promotion-banners:init", this.promotions)
            })
        },
        async created() {
            await this.loadCalendarPlugins()
        },
        methods: {
            async loadCalendarPlugins() {
                const i = await Promise.all([d(() =>
                    import ("./main-b356a838.js"), ["main-b356a838.js", "vendor-f5db2be7.js", "shared-5f1b437f.js", "shared-1464d95e.css", "vendor-6448130c.css", "main-edace153.css"]).then(e => e.default), d(() =>
                    import ("./vendor-f5db2be7.js").then(e => e.dw), ["vendor-f5db2be7.js", "shared-5f1b437f.js", "shared-1464d95e.css", "vendor-6448130c.css"]).then(e => e.default), d(() =>
                    import ("./vendor-f5db2be7.js").then(e => e.dx), ["vendor-f5db2be7.js", "shared-5f1b437f.js", "shared-1464d95e.css", "vendor-6448130c.css"]).then(e => e.default), d(() =>
                    import ("./vendor-f5db2be7.js").then(e => e.dy), ["vendor-f5db2be7.js", "shared-5f1b437f.js", "shared-1464d95e.css", "vendor-6448130c.css"]).then(e => e.default), d(() =>
                    import ("./main-04116c81.js"), ["main-04116c81.js", "vendor-f5db2be7.js", "shared-5f1b437f.js", "shared-1464d95e.css", "vendor-6448130c.css", "main-2d9ca3d7.css"]).then(e => e.default), d(() =>
                    import ("./vendor-f5db2be7.js").then(e => e.dz), ["vendor-f5db2be7.js", "shared-5f1b437f.js", "shared-1464d95e.css", "vendor-6448130c.css"]).then(e => e.default)]);
                this.fullcalendarPlugins = i, this.fullcalendarLoaded = !0
            },
            handleDateSelect(i) {
                i.allDay ? this.scheduleDateRange = this.defaultScheduleDateRange(i.startStr) : this.scheduleDateRange = {
                    start: moment.tz(i.startStr, this.time_zone.for),
                    stop: moment.tz(i.endStr, this.time_zone.for)
                }, this.selectedUserId = i.resource ? parseInt(i.resource.id) : null, this.showNewScheduleDialog = !0
            },
            async handleEventClick({
                event: i
            }) {
                const e = { ...i.extendedProps,
                        startStr: i.startStr,
                        endStr: i.extendedProps.realEnd
                    },
                    t = e.type,
                    a = t === "Job" ? e.jobId : i.id,
                    r = {
                        time_zone: this.time_zone.for
                    };
                let s = {};
                try {
                    s = await this.eventDetails(a, t, r)
                } catch {
                    throw new Error("Unable to fetch event details in Schedules")
                } finally {
                    e[this.eventTypeMap[t].attributes] = s, this.currentEvent = e, this.toggleScheduleDialog(this.eventTypeMap[t].dialog, !0)
                }
            },
            handleEventsSet(i) {
                this.groupHolidaysAsOneEvent(), this.groupJobsAsOneEvent()
            },
            handleAdd(i) {
                console.log(i)
            },
            handleChange(i) {
                console.log(i)
            },
            handleRemove(i) {
                console.log(i)
            },
            updateFilters(i, e = {}) {
                const {
                    origin: t,
                    pathname: a
                } = window.location, r = new URL(a, t), s = [...i.map(({
                    key: o
                }) => o), "events", "flash", "calendar_resources", "attendanceIcalendarURL", "select_all", "filtered_user_ids", "filtered_team_ids"];
                this.page = 1, r.search = this.getSearchParams(i), this.$inertia.visit(r.toString(), {
                    only: s,
                    preserveState: !0,
                    ...e
                })
            },
            getSearchParams(i) {
                const e = { ...this.defaultFilters,
                    ...Object.fromEntries(i.map(({
                        key: t,
                        value: a
                    }) => [t, a]))
                };
                return ["filtered_user_ids", "filtered_team_ids"].forEach(t => {
                    Array.isArray(e[t]) && (e[t] = e[t].join("-"))
                }), Object.entries(e).reduce((t, [a, r]) => (Array.isArray(r) ? r.forEach(s => {
                    s && t.append(`${a}[]`, s)
                }) : r && t.set(a, r), t), new URLSearchParams).toString()
            },
            toggleScheduleDialog(i, e) {
                this[i] = e
            },
            setLoading(i) {
                this.loading = i
            },
            closeScheduleDialog() {
                this.toggleScheduleDialog("showNewScheduleDialog", !1), this.selectedUserId = null
            },
            closeDialogs() {
                this.currentEvent = null, this.showAttendanceShiftDialog = !1, this.showTimeOffRequestDialog = !1, this.showJobDialog = !1, this.showHolidayDialog = !1
            },
            formattedDay(i) {
                return moment(i).tz(this.time_zone.for).format(h.date.shortDay)
            },
            formattedDayName(i) {
                const e = this.onMonthView ? "UTC" : this.time_zone.for;
                return moment(i).tz(e).format(h.date.shortDayName)
            },
            formattedMonth(i) {
                return moment(i).tz(this.time_zone.for).format("MMM")
            },
            openDialog(i) {
                switch (i) {
                    case "shifts":
                        {
                            const e = moment().tz(this.time_zone.for).format("YYYY-MM-DD");this.scheduleDateRange = this.defaultScheduleDateRange(e),
                            this.toggleScheduleDialog("showNewScheduleDialog", !0);
                            break
                        }
                    case "delete_shifts":
                        {
                            this.toggleScheduleDialog("showDeleteSchedulesDialog", !0);
                            break
                        }
                    case "icalendar":
                        {
                            this.toggleScheduleDialog("showIcalendarDialog", !0);
                            break
                        }
                    case "holidays":
                        this.toggleScheduleDialog("showHolidayWizardDialog", !0);
                        break;
                    case "time_off_request":
                        {
                            this.toggleScheduleDialog("showTimeOffDialog", !0);
                            break
                        }
                }
            },
            fcDate(i) {
                return moment.tz(i, this.time_zone.for).format()
            },
            fullCalendarEvents(i) {
                return i.map(e => {
                    let t = this.fcDate(e.end);
                    const a = t;
                    return e.type === "Shift" && !this.onWeekTimeView() && (t = moment.tz(e.end, this.time_zone.for).isAfter(moment.tz(e.start, this.time_zone.for), "day") ? moment.tz(e.start, this.time_zone.for).endOf("day").format() : e.end), e.allDay && (t = moment.tz(e.end, this.time_zone.for).add(1, "day").format()), { ...e,
                        start: this.fcDate(e.start),
                        end: t,
                        realEnd: a
                    }
                })
            },
            eventDetails(i, e, t) {
                return e === "Time off request" ? fe.show({
                    id: i
                }, {
                    current_page_title: document.title,
                    current_url: document.URL
                }, {
                    abortReload: !0
                }) : ve.eventDetails({
                    organizationId: this.organization.id,
                    eventId: i,
                    eventType: e
                }, t)
            },
            showUnscheduled() {
                this.unscheduledToggle = !this.unscheduledToggle, this.updateFilters([])
            },
            defaultScheduleDateRange(i) {
                return {
                    start: moment.utc(i).set({
                        hour: 9,
                        minute: 0
                    }),
                    stop: moment.utc(i).set({
                        hour: 17,
                        minute: 0
                    })
                }
            },
            loadMoreData() {
                if (!this.onMembersView || !this.moreUsersToLoad) return;
                this.appendData = !0, this.loading = !0;
                const {
                    origin: i,
                    pathname: e
                } = window.location, t = new URL(e, i);
                t.search = this.getSearchParams([{
                    key: "page",
                    value: ++this.page
                }]), this.$inertia.put(t.toString(), {
                    only: ["events", "calendar_resources"],
                    preserveState: !0,
                    preserveScroll: !0,
                    onFinish: () => {
                        this.loading = !1, this.appendData = !1
                    }
                })
            },
            groupHolidaysAsOneEvent() {
                if (this.onMembersView) return;
                const i = {};
                this.allEvents.forEach(e => {
                    e.type === "Holiday" && (i[e.holidayId] = i[e.holidayId] || [], i[e.holidayId].push(e))
                }), Object.keys(i).forEach(e => {
                    const t = i[e],
                        a = t[0];
                    t.length <= 1 || (a.members = t.map(r => ({
                        avatar: r.avatar
                    })), t.slice(1, t.length).forEach(r => {
                        this.allEvents.splice(this.allEvents.indexOf(r), 1)
                    }))
                })
            },
            groupJobsAsOneEvent() {
                if (this.onMembersView) return;
                const i = [],
                    e = new Map;
                for (const t of this.allEvents) {
                    if (t.type.toLowerCase() !== "job") {
                        i.push(t);
                        continue
                    }
                    e.has(t.jobId) || (e.set(t.jobId, !0), i.push(t))
                }
                i.length !== this.allEvents.length && (this.allEvents = i)
            },
            onWeekTimeView() {
                return this.active_view === "week" && this.subtype === "time"
            }
        }
    };
var Wt = n(Tt, At, xt, !1, null, null, null, null);
const Rt = Wt.exports,
    jt = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: Rt
    }, Symbol.toStringTag, {
        value: "Module"
    }));
var It = function() {
        var e = this,
            t = e._self._c;
        return t("div", {
            staticClass: "work-orders-main-wrapper"
        }, [t("div", {
            staticClass: "work-orders-index"
        }, [t("h2", {
            staticClass: "page-heading"
        }, [e._v("Work orders")]), t("div", {
            staticClass: "nav nav-tabs mb-30"
        }, e._l(e.pageViews, function(a, r) {
            return t("li", {
                key: a.id,
                staticClass: "nav-item",
                class: {
                    active: a.isActive
                }
            }, [t("InertiaLink", {
                staticClass: "nav-link",
                attrs: {
                    href: a.url
                }
            }, [e._v(e._s(a.label))])], 1)
        }), 0), t("div", {
            staticClass: "row basic-filters"
        }, [t("div", {
            staticClass: "col-sm-6 col-md-4 col-lg-3"
        }, [t("div", {
            staticClass: "form-group has-icon-left"
        }, [t("AppInput", {
            attrs: {
                type: "search",
                placeholder: "Search work orders",
                value: e.work_orders_query.search
            },
            on: {
                input: function(a) {
                    return e.onFiltersChange({
                        search: a
                    })
                }
            }
        }), t("i", {
            staticClass: "hi hi-search"
        })], 1)]), t("div", {
            staticClass: "col-sm-6 col-md-4 col-lg-3 mt-20 mt-md-0",
            attrs: {
                id: "wos-table-range-selector"
            }
        }, [t("AppDateRangePicker", {
            attrs: {
                "has-clear": "",
                "empty-range-text": "All time",
                "start-week-on": e.start_week_on,
                "start-date": e.startDate,
                "end-date": e.endDate,
                async: ""
            },
            on: {
                change: e.onDateFilterChange,
                clear: function(a) {
                    return e.onFiltersChange({
                        page: 1,
                        date: null,
                        date_end: null
                    })
                }
            }
        })], 1)]), t("div", {
            staticClass: "row basic-filters"
        }, [t("div", {
            staticClass: "col-sm-6 col-md-4 col-lg-3"
        }, [t("WorkOrdersClientFilter", {
            staticClass: "client-filter",
            attrs: {
                options: e.groupedClientsForSelect,
                value: e.work_orders_query.client_id
            },
            on: {
                input: function(a) {
                    return e.onFiltersChange({
                        client_id: a
                    })
                }
            }
        })], 1), t("div", {
            staticClass: "col-sm-6 col-md-4 pull-right without-label"
        }, [e.closedWOsTab ? e._e() : t("div", {
            staticClass: "page-header-actions no-padding-right-sm"
        }, [t("AppButton", {
            attrs: {
                id: "add-work-order",
                type: "primary"
            },
            on: {
                click: e.onShowCreateWorkOrderDialog
            }
        }, [e._v("Add work order")])], 1)])]), e.loading ? t("AppLoadingTable", {
            attrs: {
                columns: 4
            }
        }) : t("WorkOrdersTable", {
            staticClass: "mt-20",
            attrs: {
                pagination: e.pagination,
                organization: e.organization,
                "users-avatars": e.usersAvatars,
                "all-work-orders": e.allWorkOrders,
                "domain-query": e.work_orders_query,
                "can-manage-budget": e.canManageBudget
            },
            on: {
                "open-edit-dialog": e.onShowEditWorkOrderDialog,
                "add-work-order": e.onShowCreateWorkOrderDialog,
                "page-changed": function(a) {
                    return e.onFiltersChange({
                        page: a
                    })
                }
            }
        })], 1), e.showNewWorkOrderDialog ? t("WorkOrdersDialog", {
            key: "create-wo-dialog",
            attrs: {
                id: "new-work-order-wizard",
                "can-manage-budget": e.canManageBudget,
                "grouped-clients": e.groupedClientsForSelect
            },
            on: {
                close: e.onCloseCreateWorkOrderDialog
            }
        }) : e._e(), e.showEditWorkOrderDialog ? t("WorkOrdersDialog", {
            key: "edit-wo-dialog",
            attrs: {
                id: "edit-work-order-wizard",
                editing: "",
                "editing-work-order": e.editingWorkOrder,
                "default-tab": e.workOrderDialogTab,
                "can-manage-budget": e.canManageBudget,
                "grouped-clients": e.groupedClientsForSelect
            },
            on: {
                close: e.onCloseEditWorkOrderDialog
            }
        }) : e._e(), e.showScheduleWorkConfirmation ? t("ScheduleWorkConfirmationDialog", {
            key: "schedule-work-confirmation",
            on: {
                close: e.onCloseScheduleWorkConfirmationDialog
            }
        }) : e._e(), e.showAddJobDialog ? t("JobsDialog", {
            key: "new-job-dialog",
            attrs: {
                id: "new-job-dialog",
                organization: e.organization,
                "time-zone": e.timeZone,
                "time-zone-abbr": e.timeZoneAbbr,
                "real-org-time-zone": e.realOrgTimeZone,
                "work-order": e.currentWorkOrder,
                "start-week-on": e.startWeekOn,
                "active-organization-members": e.activeOrganizationMembers
            },
            on: {
                close: e.onCloseAddJobDialog,
                processing: e.onProcessingJobDialog
            }
        }) : e._e(), t("RecurringJobsDialogManager")], 1)
    },
    Ft = [];
D();
const Jt = {
    name: "WorkOrdersIndex",
    mixins: [c, m],
    components: {
        JobsDialog: y,
        WorkOrdersTable: Ce,
        WorkOrdersDialog: C,
        WorkOrdersClientFilter: ke,
        RecurringJobsDialogManager: k,
        ScheduleWorkConfirmationDialog: Se
    },
    props: {
        current_user: Object,
        organization: Object,
        job_site_minimum_radius: Number,
        job_site_default_radius: Number,
        start_week_on: Number,
        organization_members: Array,
        active_org_members: Array,
        beta_dialog: Object,
        clients: Array,
        new_client_url: String,
        edit_client_url: String,
        pagination: Object,
        stats: Object,
        wo_assignees: Array,
        work_orders: Array,
        work_orders_query: Object
    },
    data() {
        return {
            currentWorkOrder: null,
            editingWorkOrder: null,
            showAddJobDialog: !1,
            processingJobDialog: !1,
            showNewWorkOrderDialog: !1,
            showEditWorkOrderDialog: !1,
            showScheduleWorkConfirmation: !1,
            workOrderDialogTab: l.general
        }
    },
    mounted() {
        new URL(this.$page.url, window.location.origin).searchParams.has("createDialog") && this.onShowCreateWorkOrderDialog(), this.showScheduleWorkConfirmation || this.removeScheduleWorkParamFromHistory()
    },
    computed: { ..._({
            canManageBudget: O,
            groupedClientsForSelect: P,
            activeOrganizationMembers: M,
            realOrgTimeZone: A,
            canEditJobs: "is_owner_manager",
            startWeekOn: "organization.start_week_on",
            startDate: ({
                work_orders_query: i
            }) => f(i.date),
            endDate: ({
                work_orders_query: i
            }) => f(i.date_end),
            usersAvatars: ({
                wo_assignees: i
            }) => i.reduce((e, t) => e.set(t.id, t.avatar), new Map)
        }),
        startWeekOn() {
            return this.organization.start_week_on
        },
        timeZone() {
            return this.organization.time_zone_name
        },
        timeZoneAbbr() {
            return this.organization.time_zone_abbr
        },
        organizationMembers() {
            return this.organization_members.map(({
                id: i,
                name: e
            }) => ({
                id: i,
                text: e
            })).sort((i, e) => i.text.localeCompare(e.text))
        },
        allWorkOrders() {
            const i = this.organization.time_zone_name,
                e = {
                    organizationMembers: this.organizationMembers
                },
                t = {
                    clients: this.clients,
                    wo_assignees: this.wo_assignees
                };
            return this.work_orders.map(a => S(a, t, e, i))
        },
        closedWOsTab() {
            return this.work_orders_query.wo_state === "closed"
        },
        currentTab() {
            return this.work_orders_query && this.work_orders_query.wo_state
        },
        currentParams() {
            return Object.entries(this.work_orders_query).filter(([, i]) => !!i)
        },
        pageViews() {
            const i = this.work_orders_query.wo_state,
                e = this.generateUrlForState("all", this.currentParams),
                t = this.generateUrlForState("open", this.currentParams),
                a = this.generateUrlForState("closed", this.currentParams);
            return [{
                id: "open",
                url: t,
                isActive: i === "open" || !i,
                label: `Open (${this.stats.open_count||0})`
            }, {
                id: "closed",
                url: a,
                isActive: i === "closed",
                label: `Closed (${this.stats.closed_count||0})`
            }, {
                id: "all",
                url: e,
                isActive: i === "all",
                label: `All (${this.stats.all_count||0})`
            }]
        }
    },
    methods: {
        generateUrlForState(i, e) {
            const {
                origin: t,
                pathname: a
            } = window.location, r = new URL(a, t), s = new URLSearchParams(e);
            return i === "open" ? s.delete("wo_state") : s.set("wo_state", i), r.search = s.toString(), r.toString()
        },
        onFiltersChange(i = {}) {
            const {
                origin: e,
                pathname: t
            } = window.location, a = new URL(t, e), r = new URLSearchParams(this.currentParams);
            Object.entries(i).forEach(([s, o]) => {
                o ? r.set(s, o) : r.delete(s)
            }), a.search = r.toString(), this.$inertia.visit(a.toString())
        },
        onDateFilterChange(i) {
            this.onFiltersChange({
                page: 1,
                date: i.start ? g(i.start) : null,
                date_end: i.end ? g(i.end) : null
            })
        },
        onShowEditWorkOrderDialog(i, e = l.general) {
            this.workOrderDialogTab = e, this.editingWorkOrder = i, this.showEditWorkOrderDialog = !0
        },
        onShowCreateWorkOrderDialog() {
            this.removeScheduleWorkParamFromHistory(), this.showNewWorkOrderDialog = !0
        },
        async onCloseCreateWorkOrderDialog() {
            this.showNewWorkOrderDialog = !1;
            const e = +new URL(this.$page.url, window.location.origin).searchParams.get("schedule_work");
            await this.$nextTick(), this.onShowScheduleWorkConfirmationDialog(e)
        },
        onCloseEditWorkOrderDialog() {
            this.showEditWorkOrderDialog = !1
        },
        onShowScheduleWorkConfirmationDialog(i) {
            if (i) {
                const e = this.allWorkOrders.find(t => t.id === i);
                e ? (this.currentWorkOrder = e, this.showScheduleWorkConfirmation = !0) : (console.error(`Work order with id ${i} not found`), Oe("Work order not found", {
                    workOrderId: i
                }))
            }
        },
        async onCloseScheduleWorkConfirmationDialog(i) {
            this.showScheduleWorkConfirmation = !1, this.removeScheduleWorkParamFromHistory(), await this.$nextTick(), i ? this.showAddJobDialog = !0 : (this.currentWorkOrder = null, this.completeGettingStartedStep())
        },
        removeScheduleWorkParamFromHistory() {
            const i = new URL(this.$page.url, window.location.origin);
            i.searchParams.has("schedule_work") && (i.searchParams.delete("schedule_work"), this.$page.url = i.href, window.history.replaceState(null, "", i.toString()))
        },
        onProcessingJobDialog() {
            this.processingJobDialog = !0
        },
        onCloseAddJobDialog() {
            this.editingWorkOrder = null, this.showAddJobDialog = !1, this.processingJobDialog = !1, this.completeGettingStartedStep()
        },
        completeGettingStartedStep() {
            new URL(window.location.href).searchParams.has("createDialog") && typeof GettingStarted == "object" && GettingStarted.skipOrCompleteStep(this.currentUserId, "create_work_order", void 0, void 0)
        },
        openEditWorkOrderDialog(i, e = l.general) {
            this.workOrderDialogTab = e, this.editingWorkOrder = i, this.setShowEditWorkOrderDialog(!0)
        },
        closeEditWorkOrderDialog() {
            this.editingWorkOrder = null, this.setShowEditWorkOrderDialog(!1), this.workOrderDialogTab = l.general
        }
    }
};
var Ut = n(Jt, It, Ft, !1, null, null, null, null);
const $t = Ut.exports,
    Nt = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: $t
    }, Symbol.toStringTag, {
        value: "Module"
    }));
var Lt = function() {
        var e = this,
            t = e._self._c;
        return t("div", {
            staticClass: "work-orders-main-wrapper"
        }, [t("div", {
            staticClass: "work-order-details"
        }, [t("div", {
            staticClass: "row"
        }, [t("div", {
            staticClass: "col-md-12"
        }, [t("InertiaLink", {
            staticClass: "action blank-link m-0",
            attrs: {
                href: e.workOrdersBackUrl
            }
        }, [t("i", {
            staticClass: "hi hi-left hi-16 mr-5 text-blue"
        }), e._v("Work orders")])], 1)]), t("div", {
            staticClass: "d-flex align-items-center justify-content-between mb-10 flex-wrap"
        }, [t("div", {
            staticClass: "work-order-name my-10"
        }, [t("h4", {
            staticClass: "m-0"
        }, [e._v(e._s(e.workOrderName))]), e._l(e.work_order.wo_states, function(a, r) {
            return t("small", {
                staticClass: "work-order-status label",
                class: e.woStatusStyleClass(a, r === e.lastWoStateIndex)
            }, [e._v(e._s(a ? a.name : "Open"))])
        })], 2), t("div", {
            staticClass: "table-actions-wrapper"
        }, [t("div", {
            staticClass: "table-actions-right d-flex align-items-center justify-content-start justify-content-md-end"
        }, [t("AppButton", {
            attrs: {
                type: "primary",
                size: "sm"
            },
            on: {
                click: function(a) {
                    return e.onOpenEditWorkOrderDialog(e.tabs.general)
                }
            }
        }, [e._v("Edit")]), t("AppButton", {
            attrs: {
                type: "success",
                size: "sm"
            },
            on: {
                click: function(a) {
                    return e.confirmArchiveWorkOrder(e.work_order, e.workOrdersBackUrl)
                }
            }
        }, [e._v("Mark as closed")])], 1)])]), t("div", {
            staticClass: "d-flex flex-wrap"
        }, [t("WorkOrderDetailsInfoBox", {
            staticClass: "client-info",
            attrs: {
                name: "Client",
                icon: "hi-user-big"
            },
            on: {
                edit: function(a) {
                    return e.onOpenEditWorkOrderDialog(e.tabs.general)
                }
            },
            scopedSlots: e._u([{
                key: "when-present",
                fn: function() {
                    return [t("div", {
                        staticClass: "client-name-row row"
                    }, [t("div", {
                        staticClass: "col-md-12"
                    }, [t("AppAvatarInitial", {
                        attrs: {
                            text: e.work_order.client.name
                        }
                    }), t("span", {
                        staticClass: "client-name"
                    }, [e._v(e._s(e.work_order.client.name))])], 1)]), t("div", {
                        staticClass: "client-phone-row row mt-5"
                    }, [t("div", {
                        staticClass: "col-md-12"
                    }, [e.work_order.client.phone ? t("div", {
                        staticClass: "client-phone"
                    }, [e._v(e._s(e.work_order.client.phone))]) : t("a", {
                        staticClass: "fake-ajax-link",
                        on: {
                            click: function(a) {
                                return a.stopPropagation(), e.onOpenEditClientDialog.apply(null, arguments)
                            }
                        }
                    }, [e._v("Add phone number")])])]), t("div", {
                        staticClass: "client-email-row row"
                    }, [t("div", {
                        staticClass: "col-md-12"
                    }, [e.work_order.client.email ? t("div", {
                        staticClass: "client-email ellipsis"
                    }, [e._v(e._s(e.work_order.client.email))]) : t("a", {
                        staticClass: "fake-ajax-link",
                        on: {
                            click: function(a) {
                                return a.stopPropagation(), e.onOpenEditClientDialog.apply(null, arguments)
                            }
                        }
                    }, [e._v("Add email")])])])]
                },
                proxy: !0
            }]),
            model: {
                value: e.work_order.client,
                callback: function(a) {
                    e.$set(e.work_order, "client", a)
                },
                expression: "work_order.client"
            }
        }), t("WorkOrderDetailsInfoBox", {
            attrs: {
                name: "Address",
                icon: "hi-pin"
            },
            on: {
                edit: function(a) {
                    return e.onOpenEditWorkOrderDialog(e.tabs.jobSite)
                }
            },
            scopedSlots: e._u([{
                key: "when-present",
                fn: function() {
                    return [t("div", {
                        staticClass: "row"
                    }, [t("div", {
                        staticClass: "col-md-12"
                    }, [t("div", {
                        staticClass: "work-order-address"
                    }, [e._v(e._s(e.address))])])])]
                },
                proxy: !0
            }, {
                key: "when-empty",
                fn: function() {
                    return [t("div", {
                        staticClass: "row mt-5"
                    }, [t("div", {
                        staticClass: "col-md-12 text-center"
                    }, [t("img", {
                        staticClass: "map-illustration",
                        attrs: {
                            src: e.addressMapImageUrl,
                            alt: "Add address",
                            height: "52"
                        }
                    })])]), t("div", {
                        staticClass: "row mt-20"
                    }, [t("div", {
                        staticClass: "col-md-12 text-center"
                    }, [t("a", {
                        staticClass: "add-address-link",
                        attrs: {
                            href: "#"
                        },
                        on: {
                            click: function(a) {
                                return a.stopPropagation(), e.onOpenEditWorkOrderDialog(e.tabs.jobSite)
                            }
                        }
                    }, [e._v("Add address")])])])]
                },
                proxy: !0
            }]),
            model: {
                value: e.address,
                callback: function(a) {
                    e.address = a
                },
                expression: "address"
            }
        }), t("WorkOrderDetailsInfoBox", {
            attrs: {
                name: "Next job",
                icon: "hi-attendance"
            },
            on: {
                edit: function(a) {
                    return e.onOpenEditNextJob(e.nextJob)
                }
            },
            scopedSlots: e._u([{
                key: "when-present",
                fn: function() {
                    return [t("div", {
                        staticClass: "row"
                    }, [t("div", {
                        staticClass: "next-job-info col-md-12"
                    }, [e._v(e._s(e._f("formatDate")(e.nextJob.startsAt))), t("br"), e._v(e._s(e._f("lowercase")(e._f("formatTimeRangeNoSeconds")(e.nextJob.startsAt, e.nextJob.stopsAt))) + e._s(e.nextJob.timeZoneAbbr ? ` ${e.nextJob.timeZoneAbbr}` : ""))])]), e.jobIsRecurrent(e.nextJob) ? t("div", {
                        staticClass: "row mt-5"
                    }, [t("div", {
                        staticClass: "d-flex align-items-baseline col-md-12"
                    }, [t("i", {
                        staticClass: "hi hi-refresh mr-5"
                    }), t("p", [e._v(e._s(e.scheduleTooltip(e.nextJob.schedule)))])])]) : e._e()]
                },
                proxy: !0
            }, {
                key: "when-empty",
                fn: function() {
                    return [t("div", {
                        staticClass: "row mt-5"
                    }, [t("div", {
                        staticClass: "col-md-12 text-center"
                    }, [t("img", {
                        staticClass: "schedule-job-illustration",
                        attrs: {
                            src: e.scheduleJobImageUrl,
                            alt: "Schedule a job",
                            height: "52"
                        }
                    })])]), t("div", {
                        staticClass: "row mt-20"
                    }, [t("div", {
                        staticClass: "col-md-12 text-center"
                    }, [t("a", {
                        attrs: {
                            id: "schedule-job-link",
                            href: "#"
                        },
                        on: {
                            click: function(a) {
                                return a.stopPropagation(), e.onOpenAddJobDialog.apply(null, arguments)
                            }
                        }
                    }, [e._v("Schedule a job")])])])]
                },
                proxy: !0
            }]),
            model: {
                value: e.nextJob,
                callback: function(a) {
                    e.nextJob = a
                },
                expression: "nextJob"
            }
        }), e.canManageBudget ? t("WorkOrderDetailsInfoBox", {
            attrs: {
                name: "Budget",
                icon: "hi-calculator-outline"
            },
            on: {
                edit: function(a) {
                    return e.onOpenEditWorkOrderDialog(e.tabs.budget)
                }
            },
            scopedSlots: e._u([{
                key: "when-present",
                fn: function() {
                    return [t("div", {
                        staticClass: "budget-spent-row row"
                    }, [t("div", {
                        staticClass: "col-md-12"
                    }, [t("strong", {
                        staticClass: "budget-spent"
                    }, [e.isHoursType ? [e._v(e._s(e.budgetHoursSpent))] : [e._v(e._s(e._f("currency")(e.budgetSpent, e.organization.currency)))]], 2), t("span", [e._v("/")]), t("span", {
                        staticClass: "budget-cost text-muted"
                    }, [e.isHoursType ? [e._v(e._s(e.budgetHours))] : [e._v(e._s(e._f("currency")(e.work_order.budget.cost, e.organization.currency)))]], 2)])]), e.work_order.budget.recurrence ? t("div", {
                        staticClass: "budget-recurrence-row row"
                    }, [t("div", {
                        staticClass: "col-md-12"
                    }, [t("i", {
                        staticClass: "hi hi-12 hi-refresh mr-5"
                    }), t("span", {
                        staticClass: "budget-recurrence text-capitalize"
                    }, [e._v(e._s(e.work_order.budget.recurrence))])])]) : e._e(), t("div", {
                        staticClass: "budget-progress-row row"
                    }, [t("div", {
                        staticClass: "col-md-12"
                    }, [t("AppProgressBar", {
                        attrs: {
                            tracked: e.budgetSpent,
                            total: e.totalProgressBar
                        }
                    })], 1)]), t("div", {
                        staticClass: "budget-status-row row small"
                    }, [t("div", {
                        staticClass: "col-md-4"
                    }, [t("span", {
                        staticClass: "budget-percentage-used"
                    }, [e._v(e._s(e.budgetPercentageUsed))])]), t("div", {
                        staticClass: "col-md-8 text-right"
                    }, [t("span", {
                        staticClass: "budget-amount-remaining"
                    }, [e._v(e._s(e.budgetAmountRemaining) + " remaining")])])])]
                },
                proxy: !0
            }, {
                key: "when-empty",
                fn: function() {
                    return [t("div", {
                        staticClass: "row mt-5"
                    }, [t("div", {
                        staticClass: "col-md-12 text-center"
                    }, [t("img", {
                        staticClass: "budget-illustration",
                        attrs: {
                            src: e.budgetImageUrl,
                            alt: "SetBudget",
                            height: "52"
                        }
                    })])]), t("div", {
                        staticClass: "row mt-20"
                    }, [t("div", {
                        staticClass: "col-md-12 text-center"
                    }, [t("a", {
                        staticClass: "set-budget",
                        attrs: {
                            href: "#"
                        },
                        on: {
                            click: function(a) {
                                return a.stopPropagation(), e.onOpenEditWorkOrderDialog(e.tabs.budget)
                            }
                        }
                    }, [e._v("Set a budget")])])])]
                },
                proxy: !0
            }], null, !1, 4109726777),
            model: {
                value: e.work_order.has_budget,
                callback: function(a) {
                    e.$set(e.work_order, "has_budget", a)
                },
                expression: "work_order.has_budget"
            }
        }) : e._e()], 1), t("div", {
            staticClass: "row"
        }, [t("div", {
            staticClass: "col-xs-12"
        }, [t("h4", [e._v("Instructions")]), e.work_order.instructions ? t("div", {
            staticClass: "work-order-instructions"
        }, [t("AppExcerpt", e._l(e.instructionsLines, function(a) {
            return t("p", {
                staticClass: "break-word"
            }, [a.length ? [e._v(e._s(a))] : [e._v(" ")]], 2)
        }), 0)], 1) : t("label", {
            staticClass: "control-label-btn"
        }, [t("i", {
            staticClass: "hi hi-16 hi-group-by"
        }), t("a", {
            attrs: {
                href: "#"
            },
            on: {
                click: function(a) {
                    return a.preventDefault(), e.onOpenEditWorkOrderDialog(e.tabs.general)
                }
            }
        }, [e._v("Add instructions")])])])]), t("WorkOrdersJobsSection", {
            attrs: {
                "all-jobs": e.allJobs,
                "end-date": e.jobs_query.stop_date,
                "start-date": e.jobs_query.start_date,
                "jobs-query-status": e.jobs_query.status
            },
            on: {
                "show-job": e.onOpenShowJobDialog,
                "edit-job": e.onOpenEditJobDialog,
                "delete-job": e.confirmDeleteJob,
                "complete-job": e.onCompleteJob,
                "reopen-job": e.onReopenJob,
                "new-job": e.onOpenAddJobDialog,
                "page-changed": e.onPageChange,
                "status-changed": e.onStatusChange,
                "date-range-change": e.onDateRangeChange
            }
        }), e.showEditWorkOrderDialog ? t("WorkOrdersDialog", {
            attrs: {
                editing: "",
                "editing-work-order": e.work_order,
                "default-tab": e.selectedEditWorkOrderDialogTab,
                "can-manage-budget": e.canManageBudget,
                "grouped-clients": e.groupedClientsForSelect
            },
            on: {
                close: e.onCloseEditWorkOrderDialog
            }
        }) : e._e(), e.showAddJobDialog ? t("JobsDialog", {
            attrs: {
                id: "new-job-dialog",
                organization: e.organization,
                "time-zone": e.timeZone,
                "time-zone-abbr": e.timeZoneAbbr,
                "real-org-time-zone": e.realOrgTimeZone,
                "work-order": e.work_order,
                "start-week-on": e.startWeekOn,
                "active-organization-members": e.activeOrganizationMembers
            },
            on: {
                close: e.onCloseAddJobDialog
            }
        }) : e._e(), e.showEditJobDialog ? t("JobsDialog", {
            attrs: {
                id: "edit-job-dialog",
                editing: "",
                job: e.editingJob,
                "time-zone": e.timeZone,
                "time-zone-abbr": e.timeZoneAbbr,
                "real-org-time-zone": e.realOrgTimeZone,
                "work-order": e.work_order,
                "start-week-on": e.startWeekOn,
                "active-organization-members": e.activeOrganizationMembers
            },
            on: {
                close: e.onCloseEditJobDialog,
                "close-view-job": e.onCloseShowJobDialog
            }
        }) : e._e(), e.work_order && e.showViewJobDialog ? t("ShowJobDialog", {
            attrs: {
                id: "show-job-dialog",
                job: e.viewingJob,
                "work-order": e.work_order,
                "can-edit-jobs": e.canEditJobs,
                "processing-job": e.processingJob
            },
            on: {
                close: e.onCloseShowJobDialog,
                "edit-job": e.onOpenEditJobDialog,
                "reopen-job": e.onReopenJob,
                "complete-job": e.onCompleteJob
            }
        }) : e._e(), t("RecurringJobsDialogManager")], 1)])
    },
    qt = [];
D();
const Vt = {
    name: "WorkOrdersShow",
    mixins: [Pe, Me, Ae, c, xe],
    components: {
        JobsDialog: y,
        ShowJobDialog: Ee,
        WorkOrdersDialog: C,
        WorkOrdersJobsSection: ze,
        WorkOrderDetailsInfoBox: Te,
        RecurringJobsDialogManager: k
    },
    props: {
        beta_dialog: Object,
        active_org_members: Array,
        clients: Array,
        current_user: Object,
        new_client_url: String,
        edit_client_url: String,
        googleMapsKey: String,
        is_owner_manager: Boolean,
        job_schedules: Array,
        job_site_minimum_radius: Number,
        jobs: Array,
        jobs_assignees: Array,
        jobs_query: Object,
        organization_members: Array,
        pagination: Object,
        time_zone: String,
        visits_report_url: String,
        wo_assignees: Array
    },
    data() {
        return {
            editingJob: null,
            workOrdersBackUrl: null,
            showAddJobDialog: !1,
            showViewJobDialog: !1,
            showEditJobDialog: !1,
            tabs: l,
            showEditWorkOrderDialog: !1,
            budgetImageUrl: We,
            addressMapImageUrl: Re,
            scheduleJobImageUrl: je,
            selectedEditWorkOrderDialogTab: l.general
        }
    },
    mounted() {
        this.setWorkOrdersIndexPath(), AjaxDialog.registerHook("response", "updateClientResponse", (i, e) => {
            e === "success" && i.client && this.$inertia.reload({
                only: ["clients"]
            })
        })
    },
    computed: { ..._({
            realOrgTimeZone: A,
            canManageBudget: O,
            groupedClientsForSelect: P,
            activeOrganizationMembers: M,
            backUrl: "back_url",
            timeZone: "organization.time_zone_name",
            startWeekOn: "organization.start_week_on",
            timeZoneAbbr: "organization.time_zone_abbr",
            editClientUrl({
                edit_client_url: i
            }) {
                const {
                    client: e
                } = this.work_order;
                return e ? i.replace("__CLIENT_ID__", e.id) : null
            },
            canEditJobs: ({
                is_owner_manager: i
            }) => !!i,
            organizationMembers({
                organization_members: i
            }) {
                return i.map(({
                    id: e,
                    name: t
                }) => ({
                    id: e,
                    text: t
                })).sort((e, t) => e.text.localeCompare(t.text))
            },
            allJobs({
                jobs: i,
                clients: e,
                wo_assignees: t,
                job_schedules: a
            }) {
                const r = {
                        organizationMembers: this.organizationMembers
                    },
                    s = {
                        clients: e,
                        wo_assignees: t,
                        job_schedules: a
                    };
                return i.map(o => Je(o, this.realOrgTimeZone, s, r))
            },
            work_order({
                work_order: i,
                organization: e,
                org_members: t,
                clients: a,
                wo_assignees: r
            }) {
                const s = e.time_zone_name,
                    o = {
                        clients: a,
                        wo_assignees: r
                    },
                    x = {
                        organizationMembers: this.organizationMembers
                    };
                return S(i, o, x, s)
            }
        }),
        nextJob() {
            return this.work_order.upcomingJob
        },
        workOrderName() {
            const {
                number: i,
                client: e
            } = this.work_order;
            return i && e ? `${i} - ${e.name}` : ""
        },
        lastWoStateIndex() {
            return (this.work_order.wo_states || []).length - 1 || 0
        },
        address() {
            return this.work_order.jobSite ? this.work_order.jobSite.address : ""
        },
        isHoursType() {
            return this.work_order.budget.type === Ie
        },
        totalProgressBar() {
            const {
                budget: i = {}
            } = this.work_order;
            return this.isHoursType ? i.hours : i.cost
        },
        budgetSpent() {
            const {
                budget: {
                    spent: i
                } = {}
            } = this.work_order;
            return i
        },
        budgetHoursSpent() {
            return p(this.budgetSpent)
        },
        budgetHours() {
            const {
                budget: {
                    hours: i
                }
            } = this.work_order;
            return p(i)
        },
        budgetPercentageUsed() {
            const {
                cost: i,
                hours: e
            } = this.work_order.budget, t = a => (this.budgetSpent / a * 100).toFixed(0) + "%";
            return this.isHoursType ? t(e) : t(i)
        },
        budgetAmountRemaining() {
            const {
                cost: i,
                hours: e
            } = this.work_order.budget, a = Math.max(0, (r => r - this.budgetSpent)(this.isHoursType ? e : i));
            return this.isHoursType ? p(a) : a.formatMoney(this.organization.currency)
        },
        instructionsLines() {
            return (this.work_order.instructions || "").split(`
`)
        },
        filterOnlyInertiaKeys() {
            return ["jobs", "work_order", "pagination", "jobs_query", "wo_assignees", "job_scheduled", "jobs_assignees"]
        }
    },
    methods: {
        setWorkOrdersIndexPath() {
            const i = this.backUrl ? new URL(this.backUrl) : {},
                e = w(Fe, {
                    organizationId: this.organization.id
                }),
                t = i.pathname === e,
                a = t ? i.pathname : e,
                r = new URL(a, window.location.origin);
            if (t && i.search) {
                const s = new URLSearchParams(i.search);
                s.delete("schedule_work"), r.search = s.toString()
            }
            this.workOrdersBackUrl = r.toString()
        },
        woStatusStyleClass(i, e) {
            const t = e ? "" : " mr-15";
            return (i ? `label-${i.symbol}` : "label-open") + t
        },
        onOpenEditWorkOrderDialog(i = l.general) {
            this.selectedEditWorkOrderDialogTab = i, this.showEditWorkOrderDialog = !0
        },
        onCloseEditWorkOrderDialog() {
            this.showEditWorkOrderDialog = !1
        },
        onFiltersChange(i) {
            const {
                origin: e,
                pathname: t
            } = window.location, a = new URLSearchParams(Object.entries({ ...this.jobs_query,
                ...i
            }).filter(([, s]) => !!s)), r = new URL(t, e);
            r.search = a.toString(), this.$inertia.visit(r.toString(), {
                only: this.filterOnlyInertiaKeys
            })
        },
        onPageChange(i) {
            this.onFiltersChange({
                page: i
            })
        },
        onStatusChange(i) {
            this.onFiltersChange({
                page: 1,
                status: i
            })
        },
        onDateRangeChange({
            start: i,
            end: e
        }) {
            this.onFiltersChange({
                page: 1,
                start_date: g(i),
                stop_date: g(e)
            })
        },
        onOpenEditClientDialog() {
            this.editClientUrl && AjaxDialog.run(this.editClientUrl)
        },
        onOpenShowJobDialog(i) {
            i && i.id && (this.viewingJob = i, this.showViewJobDialog = !0)
        },
        onOpenAddJobDialog() {
            this.showAddJobDialog = !0
        },
        onCloseAddJobDialog() {
            this.showAddJobDialog = !1
        },
        onOpenEditNextJob(i) {
            if (i) return this.onOpenEditJobDialog(this.allJobs.find(e => e.id === i.id));
            this.onOpenAddJobDialog()
        },
        onOpenEditJobDialog(i) {
            i && (this.editingJob = i, this.showEditJobDialog = !0)
        },
        onCloseShowJobDialog() {
            this.viewingJob = null, this.showViewJobDialog = !1
        },
        onCloseEditJobDialog() {
            this.editingJob = null, this.showEditJobDialog = !1
        }
    },
    watch: {
        allJobs(i) {
            if (!(!i || !i.length)) {
                if (this.viewingJob) {
                    const e = this.viewingJob.id;
                    this.viewingJob = i.find(t => t.id === e), this.showViewJobDialog = !!this.viewingJob
                }
                if (this.editingJob) {
                    const e = this.editingJob.id;
                    this.editingJob = i.find(t => t.id === e), this.showEditJobDialog = !!this.editingJob
                }
            }
        }
    }
};
var Ht = n(Vt, Lt, qt, !1, null, null, null, null);
const Bt = Ht.exports,
    Gt = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: Bt
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Zt = Object.assign({
        "../pages/Demos/AppYearPickerDemo.vue": Xe,
        "../pages/Demos/ReportTableAvatarIconInitial.vue": rt,
        "../pages/GettingStarted/Index.vue": ct,
        "../pages/OrganizationSettings/MemberEmailNotifications.vue": _t,
        "../pages/OrganizationSettings/MemberProfiles.vue": yt,
        "../pages/OrganizationSettings/OvertimePolicies.vue": Mt,
        "../pages/OrganizationSettings/WorkLimitsAndExpectations.vue": $e,
        "../pages/Schedules/Index.vue": jt,
        "../pages/Schedules/SchedulesDropdown.vue": Ue,
        "../pages/WorkOrders/Index.vue": Nt,
        "../pages/WorkOrders/Show.vue": Gt
    });
document.querySelector("#app") && Le({
    resolve: i => {
        const e = Zt[`../pages/${i}.vue`];
        if (!e) throw new Error(`Page not found: ${e}`);
        return typeof e == "function" ? e() : e
    },
    setup({
        el: i,
        app: e,
        props: t,
        plugin: a
    }) {
        u.use(He), u.use(a), u.component("InertiaLink", qe);
        const {
            props: {
                initialPage: {
                    props: r
                }
            }
        } = t;
        (r.googleMapsKey || r.google_maps_key) && u.use(Ve, r.googleMapsKey || r.google_maps_key), new u({
            name: "InertiaRoot",
            render: s => s(e, t)
        }).$mount(i)
    }
});