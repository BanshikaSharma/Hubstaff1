'use es6';

export const CUSTOM = 'CUSTOM';
export const CES = 'CES';
export const CSAT = 'CSAT';
export const NPS = 'NPS';