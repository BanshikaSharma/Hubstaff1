import set from 'transmute/set';
export const setFile = set('file');
export const setFileId = set('fileId');
export const setUploadProgress = set('uploadProgress');