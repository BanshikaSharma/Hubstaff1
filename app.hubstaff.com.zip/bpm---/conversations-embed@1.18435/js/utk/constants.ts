"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.USER_TOKEN_KEY = void 0;
const USER_TOKEN_KEY = exports.USER_TOKEN_KEY = '__hsUserToken';