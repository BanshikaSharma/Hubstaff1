export const COMPLETED_MESSAGE_ID = 'completedMessageId';
export const PARTIAL_ORDINAL = 'partialOrdinal';
export const COMPLETED_MESSAGE_TIMESTAMP = 'completedMessageTimestamp';
export const MESSAGE_TEXT = 'text';
export const ID = 'id';