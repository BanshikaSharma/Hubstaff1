import "./init-ef420420.js";
import {
    A as L,
    bu as R,
    bv as F,
    ab as M,
    z as E,
    V as u,
    h as q,
    a2 as P
} from "./vendor-f5db2be7.js";
import {
    A as H
} from "./app_messages-e83d8e06.js";
import {
    bm as J,
    m as _,
    br as U,
    kv as V,
    t as G,
    ce as K,
    kw as Q,
    kx as X,
    e4 as Y,
    n as w,
    cX as p,
    cQ as D,
    aZ as h,
    ky as I,
    jr as b,
    kz as Z
} from "./shared-5f1b437f.js";
L("required", { ...M,
    message: "can't be blank"
});
const ee = {
        install(t) {
            t.use(H), t.component("ValidationObserver", R), t.component("ValidationProvider", F), t.component("AppButton", J), t.component("AppSelect", _), t.component("AppDialog", U), t.component("WorkBreakPolicySelect", V), t.directive("tooltip", G), t.directive("loading", K)
        }
    },
    W = () => {
        a.timer.remaining != null ? a.timer.budgetLeft = TimeUtils.format_duration(moment.duration({
            seconds: a.budgetPeriods[0].allowed - a.timer.remaining
        }), !1) + "/" + TimeUtils.format_duration(moment.duration({
            seconds: a.budgetPeriods[0].allowed
        }), !1) : a.timer.budgetLeft = "No limit"
    };

function te(t, e) {
    const i = {};
    let s;
    for (s in t) Object.prototype.hasOwnProperty.call(t, s) && (i[s] = t[s]);
    for (s in e) Object.prototype.hasOwnProperty.call(e, s) && (i[s] = e[s]);
    return i
}
const a = {
        connected: !0,
        status: "Up to date",
        updating: !1,
        tracking: !1,
        loggedIn: !0,
        slave: !1,
        workBreakPolicies: [],
        user: {
            email: null,
            name: null,
            avatar: null
        },
        timer: {
            activeProject: null,
            activeTask: null,
            activeBreak: null,
            remaining: null,
            limit_type: null,
            workedProject: 0,
            workedToday: 0,
            budgetLeft: "No limit",
            overBudget: !1,
            projectName: null,
            taskName: null,
            errorMessage: null
        }
    },
    c = {
        tickTimerId: null,
        refreshStateTimerId: null,
        lastStateRefresh: null,
        callbackFn: null
    },
    r = {
        totalTrackedLastStop: null,
        totalTracked: 0,
        sessionStart: null,
        sessionTracked: 0
    };

function k() {
    let t = r.totalTracked;
    const e = moment();
    return r.sessionStart && (a.timer.activeBreak ? a.timer.activeBreak.paid && moment.duration(e.diff(r.sessionStart)) < a.timer.activeBreak.duration * 1e3 && (t += moment.duration(e.diff(r.totalTrackedLastStop)).asSeconds() || 0) : r.totalTrackedLastStop && r.totalTrackedLastStop > r.sessionStart ? t += moment.duration(e.diff(r.totalTrackedLastStop)).asSeconds() || 0 : t += moment.duration(e.diff(r.sessionStart)).asSeconds() || 0), t || 0
}

function f() {
    if (r.sessionStart) {
        const t = moment();
        if (a.timer.activeBreak) {
            const e = moment.duration(t.diff(r.sessionStart)),
                i = moment.duration(a.timer.activeBreak.duration * 1e3);
            return moment.duration(i - e).asSeconds() || 0
        }
        return moment.duration(t.diff(r.sessionStart)).asSeconds() || 0
    }
    return r.sessionTracked
}

function y(t) {
    const e = X("duration") === "hms" ? "always" : "never";
    return Y(moment.duration({
        seconds: t
    }), {
        showSeconds: e
    })
}

function ie() {
    const t = r.sessionTracked;
    if (r.sessionTracked = f(), a.timer.workedToday = k(), a.timer.workedProject = r.sessionTracked, !(a.timer.activeBreak && !a.timer.activeBreak.paid)) {
        if (a.timer.remaining != null) {
            const e = r.sessionTracked - t;
            a.timer.remaining += a.timer.activeBreak ? e : -e
        }
        W()
    }
}

function B(t) {
    a.budgetPeriods = t, a.budgetPeriods.length > 0 ? (a.timer.remaining = a.budgetPeriods[0].remaining, a.timer.limit_type = a.budgetPeriods[0].limit_type) : a.timer.remaining = null, W()
}

function S(t, e, i) {
    e && i && (t = E(t) ? null : t, a.workBreakPolicies = e.filter(s => Q(s, t)), a.timer.activeBreak = e.find(s => s.project_id === i))
}
const C = window.WEBTIMER_REFRESH_INTERVALS;

function se(t) {
    const e = moment.duration(moment().diff(c.lastStateRefresh)),
        i = moment.duration({
            minutes: a.tracking ? C.tracking : C.idle
        });
    e > i && t.getState().then(s => {
        c.callbackFn && c.callbackFn.call(null, s)
    })
}

function ae() {
    c.lastStateRefresh = moment()
}

function re(t) {
    const e = {
        setCallback(i) {
            c.callbackFn = i
        },
        startRefreshTimer(i = !0) {
            i && c.tickTimerId === null ? (c.lastStateRefresh = c.lastStateRefresh || moment(), c.refreshStateTimerId = window.setInterval(() => {
                se(this)
            }, 6e4)) : !i && c.tickTimerId !== null && (window.clearInterval(c.refreshStateTimerId), c.refreshStateTimerId = null)
        }
    };
    return t.setInitialState = function(i, s) {
        i.total_tracked && (r.totalTracked = i.total_tracked, r.totalTrackedLastStop = i.last_activity_stops_at, a.timer.workedToday = k(), a.timer.sessionTracked = f(), a.timer.workedProject = 0), a.user && (a.user = i.user), s({
            data: a
        })
    }, Object.keys(t).forEach(function(i) {
        e[i] = function() {
            const s = Array.prototype.slice.call(arguments);
            return new Promise(function(o, n) {
                return t[i].apply(null, s.concat([o, n]))
            })
        }
    }), e
}

function g(t = !0) {
    t && c.tickTimerId === null ? c.tickTimerId = window.setInterval(ie, 1e3) : !t && c.tickTimerId !== null && (window.clearInterval(c.tickTimerId), c.tickTimerId = null)
}
const oe = {
    name: "DurationTimer",
    props: {
        duration: {
            type: Number,
            required: !0
        },
        title: {
            type: String,
            required: !1,
            default: ""
        }
    },
    computed: {
        label() {
            return this.title ? this.title + y(this.duration) : y(this.duration)
        }
    }
};
var ne = function() {
        var e = this,
            i = e._self._c;
        return i("span", {
            staticClass: "duration-timer"
        }, [e._v(e._s(e.label))])
    },
    ce = [],
    le = w(oe, ne, ce, !1, null, null, null, null);
const N = le.exports,
    z = {
        computed: {
            breakOngoing() {
                return !!this.state.timer.activeBreak
            },
            breakOver() {
                return this.breakOngoing && this.state.timer.workedProject < 0
            }
        }
    };
var de = function() {
        var e = this,
            i = e._self._c;
        return e.webTimer.enabled ? i("div", {
            staticClass: "web-timer-topbar"
        }, [i("a", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: e.tooltipOptions,
                expression: "tooltipOptions"
            }],
            class: e.timerClasses,
            attrs: {
                href: "#",
                "data-original-title": e.toggleTimerTooltip
            },
            on: {
                click: function(s) {
                    return s.preventDefault(), s.stopPropagation(), e.toggleWidget.apply(null, arguments)
                }
            }
        }, [i("i", {
            staticClass: "hi hi-stopwatch"
        }), i("DurationTimer", {
            staticClass: "topbar-tracked",
            attrs: {
                duration: e.duration
            }
        }), i("i", {
            staticClass: "hi hi-arrow-top-right"
        })], 1)]) : e._e()
    },
    me = [];
const ue = {
    name: "WebTimerTopbar",
    components: {
        DurationTimer: N
    },
    mixins: [z],
    props: {
        state: {
            type: Object,
            required: !0
        },
        webTimer: {
            type: Object,
            required: !0
        }
    },
    data: () => ({
        tooltipOptions: {
            placement: "auto bottom",
            delay: {
                show: 1200,
                hide: 0
            },
            life: 5e3,
            closeOnClick: !0
        }
    }),
    computed: {
        toggleTimerTooltip() {
            return this.webTimer.widget.open ? "Close timer" : "Open timer"
        },
        timerClasses() {
            return {
                "is-tracking": this.state.tracking,
                "is-resting": this.breakOngoing,
                "is-rest-over": this.breakOver
            }
        },
        duration() {
            return this.state.timer.workedProject
        }
    },
    created() {
        this.$backend = this.$parent.$backend
    },
    methods: {
        toggleWidget() {
            this.$backend.toggleWidget()
        }
    }
};
var pe = w(ue, de, me, !1, null, null, null, null);
const ge = pe.exports,
    v = function() {
        const t = function(i) {
            B(i.budget_periods), S(i.last_work_session, i.work_break_policies, i.tracking_project_id), i.error ? a.timer.errorMessage = i.error : a.timer.errorMessage = null;
            const s = moment();
            if (i.tracking_project_id != null) {
                r.sessionStart = moment(i.tracking_started_at), r.sessionTracked = moment.duration(s.diff(r.sessionStart)).asSeconds() || 0;
                const o = moment(i.last_activity_stops_at);
                a.timer.remaining != null && o >= r.sessionStart && (a.timer.remaining -= moment.duration(s.diff(o)).asSeconds() || 0), a.timer.activeBreak && (r.sessionTracked = a.timer.activeBreak.duration - r.sessionTracked)
            } else r.sessionStart = null;
            a.timer.workedToday = k(), a.timer.workedProject = r.sessionTracked, r.totalTracked = i.total_tracked, r.totalTrackedLastStop = moment(i.last_activity_stops_at), a.user.id = i.current_user_id, i.tracking_project_id == null ? (a.selectedProjectId = null, a.selectedTaskId = null, a.timer.activeProject = null, a.timer.activeTask = null, a.timer.projectName = null, a.timer.taskName = null, a.slave = !1, a.tracking = !1) : (a.selectedProjectId = i.tracking_project_id, a.selectedTaskId = i.tracking_task_id, a.timer.activeProject = {
                id: i.previous_project_id,
                name: i.previous_project_name,
                type: i.previous_project_type,
                canTrack: a.slave || i.tracking_project_can_track
            }, a.timer.projectName = a.timer.activeProject.name, a.slave = i.slave, a.timer.workedProject = f(), i.tracking_task_id != null ? (a.timer.activeTask = {
                id: i.tracking_task_id,
                name: i.tracking_task_name
            }, a.timer.taskName = a.timer.activeTask.name) : a.timer.activeTask = null, a.tracking = a.slave || a.timer.activeProject.canTrack), g(a.tracking)
        };
        return re({
            getState: function(s) {
                p.get("/timer/check").then(o => {
                    t(o), ae(), s({
                        data: a
                    })
                }).catch(o => {
                    console.error(o)
                })
            },
            getProjects: function(s, o) {
                p.get("/timer/projects", s).then(n => {
                    const l = {
                        can_manage_projects: n.can_manage_projects,
                        projects_enabled: n.projects_enabled,
                        projects: n.projects,
                        pagination: n.pagination
                    };
                    o({
                        data: te(a, l)
                    })
                }).catch(n => {
                    console.error(n)
                })
            },
            getTasksForProject: function(s, o = {
                term: null
            }, n, l) {
                throw new Error("Not implemented")
            },
            startTick: function(s, o, n) {
                if (!s) throw new Error("No project passed to startTick");
                a.selectedProjectId = s.id, a.selectedTaskId = o ? o.id : null, a.timer.activeTask = o || null, a.timer.taskName = o ? o.name : null, a.timer.activeProject = s, a.timer.projectName = s.name, g(), n({
                    data: a
                })
            },
            startTimer: function(s, o, n, l) {
                return GettingStarted.completeStepOnClient("track_time"), a.tracking = !0, v.startTick(s, o).then(m => p.post("/timer/tracking_state", {
                    timer: {
                        project_id: a.selectedProjectId,
                        task_id: a.selectedTaskId
                    }
                })).then(m => (B(m.budget_periods), S(m.last_work_session, m.work_break_policies, a.selectedProjectId), r.sessionStart = moment(m.time), r.sessionTracked = moment.duration(moment().diff(r.sessionStart)).asSeconds() || 0, a.timer.workedProject = f(), n({
                    data: a
                }))).catch(m => {
                    a.tracking = !1, g(!1);
                    let j = "An error happened while starting the time.";
                    m.responseJSON && (j = m.responseJSON.error), l(j)
                })
            },
            stopTimer: function(s, o) {
                p.post("/timer/tracking_state", {}).then(n => {
                    r.totalTracked = n.total_tracked, r.totalTrackedLastStop = moment(n.time), a.timer.activeBreak = null, a.timer.workedProject = 0, a.timer.workedToday = k(), a.tracking = !1, g(!1), s({
                        data: a
                    })
                }).catch(n => {
                    let l = "An error happened while stopping the time.";
                    n.responseJSON && (l = n.responseJSON.error), o(l)
                })
            },
            startBreakTimer: function(s, o, n) {
                return p.post("/timer/tracking_state", {
                    timer: {
                        project_id: s.project_id
                    }
                }).then(l => (g(), r.sessionStart = moment(l.time), r.sessionTracked = s.duration, a.timer.workedProject = s.duration, a.timer.activeBreak = s, o({
                    data: a
                }))).catch(l => {
                    g(!1);
                    const m = l.responseJSON ? l.responseJSON.error : "An error happened while starting the break time.";
                    n(m)
                })
            },
            markScreenshotHintDismissed: function(s) {
                return p.post("/user/timer_screenshot_hint_seen", {}).then(() => {
                    s()
                }).catch(() => {})
            }
        })
    }(),
    O = D("web-timer"),
    d = new u({
        name: "WebTimerBackend",
        data() {
            const t = {
                    open: !1,
                    minimized: !1,
                    big: !0
                },
                e = O.get("widgetState");
            if (e !== null)
                for (const i in t) i in e && (t[i] = e[i]);
            return {
                state: {
                    budgetPeriods: [],
                    workBreakPolicies: [],
                    connected: !0,
                    loggedIn: !0,
                    selectedProjectId: null,
                    selectedTaskId: null,
                    status: !0,
                    tracking: !1,
                    updating: !1,
                    timer: {
                        remaining: null,
                        limit_type: null,
                        activeProject: null,
                        activeTask: null,
                        activeBreak: null,
                        projectName: null,
                        taskName: null,
                        budgetLeft: "No limit",
                        overBudget: !1,
                        workedProject: 0,
                        workedToday: 0,
                        errorMessage: null
                    },
                    user: {}
                },
                webTimer: {
                    enabled: !1,
                    loading: !1,
                    used: !1,
                    widget: t,
                    projectFlavour: "projects"
                }
            }
        },
        methods: {
            setup(t) {
                t !== null && (this.webTimer.enabled = t.enabled, this.webTimer.used = t.used, this.webTimer.projectFlavour = t.project_flavour, this.webTimer.organizationId = t.current_organization_id, this.$jsBackend.setInitialState({
                    total_tracked: t.total_tracked,
                    last_activity_stops_at: t.last_activity_stops_at,
                    user: {
                        id: t.current_user_id,
                        hide_screenshot_hint: t.hide_screenshot_hint
                    }
                }).then(e => {
                    this.updateBackend(e.data)
                }), this.webTimer.used && this.$jsBackend.startRefreshTimer(), t.tracking && (this.webTimer.loading = !0, this.$jsBackend.getState().then(e => {
                    var i;
                    this.updateBackend(e.data), this.state.selectedProjectId != null && (this.state.timer.activeProject.canTrack ? e.data.timer.errorMessage && this.state.tracking === !0 && this.stopTimer(e.data.timer.errorMessage) : this.state.slave || (this.$appMessage(`This ${this.getProjectLabel(this.state.timer.activeProject)} cannot be tracked on this client`), this.stopTimer())), this.state.tracking ? this.startTicker() : this.stopTimer((i = e.data.timer) == null ? void 0 : i.errorMessage), this.webTimer.loading = !1
                })))
            },
            toggleWidget() {
                this.webTimer.widget.open = !this.webTimer.widget.open
            },
            toggleWidgetSize() {
                this.webTimer.widget.big = !this.webTimer.widget.big
            },
            closeWidget() {
                this.webTimer.widget.open = !1
            },
            minimizeWidget() {
                this.webTimer.widget.minimized = !0
            },
            maximizeWidget() {
                this.webTimer.widget.minimized = !1
            },
            closeScreenshotHint() {
                return this.$jsBackend.markScreenshotHintDismissed().then(() => {
                    this.updateBackend({
                        user: Object.assign({}, this.state.user, {
                            hide_screenshot_hint: !0
                        })
                    })
                })
            },
            startTicker() {
                if (this.state.tracking) return this.$jsBackend.startTick(this.state.timer.activeProject, this.state.timer.activeTask).then(t => {
                    this.updateBackend(t.data)
                })
            },
            toggleTimer() {
                return this.state.timer.activeProject === null || this.state.timer.activeProject.id === -1 ? (this.$appMessage(`Make sure you select a ${h(this.webTimer.projectFlavour).toLowerCase()} before tracking`), !1) : this.state.tracking ? this.stopTimer() : this.startTimer()
            },
            startTimer() {
                return this.webTimer.used = !0, this.$jsBackend.startTimer(this.state.timer.activeProject, this.state.timer.activeTask).then(t => {
                    this.updateBackend(t.data)
                }).catch(t => {
                    this.$appMessage(t, {
                        sticky: !0
                    })
                })
            },
            stopTimer(t = null) {
                return t && this.$appMessage(t, {
                    sticky: !0
                }), this.$jsBackend.stopTimer().then(e => {
                    this.updateBackend(e.data)
                }).catch(e => {
                    this.$appMessage(e, {
                        sticky: !0
                    })
                })
            },
            startBreak(t) {
                const e = this.state.workBreakPolicies.find(i => i.project_id === t);
                return this.$jsBackend.stopTimer().then(i => {
                    this.updateBackend(i.data)
                }).then(() => {
                    this.$jsBackend.startBreakTimer(e)
                }).catch(i => {
                    this.$appMessage(i, {
                        sticky: !0
                    })
                })
            },
            stopBreak() {
                return this.stopTimer()
            },
            setProject(t) {
                t && t.id === "new_project" ? ($("#wt-project-select").val(null).trigger("change"), window.location.href = $("#web-timer").data("new-project-url")) : (this.state.tracking ? this.stopTimer() : Promise.resolve(!0)).then(() => {
                    Object.assign(this.state, {
                        selectedProjectId: t && t.id,
                        selectedTaskId: null
                    }), Object.assign(this.state.timer, {
                        activeProject: t,
                        projectName: t && t.name,
                        activeTask: null,
                        taskName: null
                    })
                })
            },
            setTask(t) {
                t && t.id === "new_task" ? ($("#wt-task-select").val(null).trigger("change"), AjaxDialog.run("/tasks/new.dialog?task[project_id]=" + this.state.selectedProjectId + "&task[close]=true")) : (this.state.tracking ? this.stopTimer() : Promise.resolve(!0)).then(() => {
                    Object.assign(this.state, {
                        selectedTaskId: t && t.id
                    }), Object.assign(this.state.timer, {
                        activeTask: t,
                        taskName: t && t.name
                    })
                })
            },
            updateBackend(t) {
                for (const e in t) q(t, e) && u.set(this.state, e, t[e])
            },
            refreshState() {
                this.$jsBackend.getState().then(t => {
                    t.data.timer.errorMessage && this.state.tracking === !0 && this.$appMessage(t.data.timer.errorMessage, {
                        sticky: !0
                    }), this.updateBackend(t.data)
                })
            },
            refreshTimerFormat() {
                this.state.timer.workedProject = -1, this.state.timer.workedToday = -1, u.nextTick(() => {
                    this.state.timer.workedProject = f(), this.state.timer.workedToday = k()
                })
            },
            getProjectLabel(t) {
                const e = t.type === I.workOrder ? "work_orders" : "projects";
                return h(e).toLowerCase()
            }
        },
        watch: {
            "webTimer.widget": {
                deep: !0,
                immediate: !0,
                handler(t) {
                    O.set("widgetState", t)
                }
            },
            "webTimer.used": {
                handler(t) {
                    this.$jsBackend.startRefreshTimer(t)
                }
            },
            "state.timer.remaining": {
                immediate: !0,
                handler(t) {
                    let e, i;
                    const s = this.state.timer.projectName;
                    if (t != null && t <= 0) {
                        switch (this.state.timer.limit_type) {
                            case 1:
                                e = "daily", i = "day";
                                break;
                            case 7:
                                e = "weekly", i = "week";
                                break;
                            case 30:
                                e = "monthly", i = "month";
                                break;
                            case 9999:
                                e = "the", i = "period";
                                break;
                            default:
                                e = "unknown", i = "period"
                        }
                        this.stopTimer(), this.$appMessage(`Stopped timer for ${this.getProjectLabel(this.state.timer.activeProject)} ` + s + " because " + e + " limit for this " + i + " has been reached", {
                            sticky: !0
                        })
                    }
                }
            },
            "state.timer.activeProject": {
                immediate: !0,
                handler(t) {
                    t != null && !t.canTrack && this.state.tracking === !0 && (this.$appMessage(`This ${this.getProjectLabel(t)} cannot be tracked on this client`), this.stopTimer())
                }
            }
        },
        render: t => {},
        created() {
            this.$jsBackend = v, v.setCallback(t => {
                t.data.timer.errorMessage && this.state.tracking === !0 && (this.$appMessage(t.data.timer.errorMessage, {
                    sticky: !0
                }), this.stopTimer()), this.updateBackend(t.data)
            })
        }
    }),
    A = {
        methods: {
            clearPreviousResults(t) {
                $(t.target).data("select2").$results.children(":not(.loading-results)").remove()
            }
        }
    },
    he = {
        name: "ProjectsSelect",
        components: {
            AppSelect: _
        },
        mixins: [A],
        props: {
            activeProject: {
                type: Object,
                default: null
            },
            slave: Boolean,
            state: {
                type: Object,
                required: !0
            }
        },
        computed: {
            labelText() {
                return h(this.state.projectFlavour)
            },
            selectPlaceholder() {
                return `Select a ${h(this.state.projectFlavour).toLowerCase()}`
            },
            noProjectText() {
                return `No ${h(this.state.projectFlavour).toLowerCase()}`
            },
            selected: {
                get() {
                    return this.activeProject == null ? "" : this.activeProject.id
                },
                set(t) {
                    const e = this.$refs.select.selectedData()[0];
                    let i = !1;
                    e !== void 0 && (i = e.canTrack === void 0 ? !0 : e.canTrack), this.$emit("updateActiveProject", e ? {
                        id: e.id,
                        name: e.text,
                        type: e.type,
                        canTrack: i
                    } : null)
                }
            },
            disabled() {
                return this.slave
            },
            select2Options() {
                return {
                    allowClear: !0,
                    placeholder: this.selectPlaceholder,
                    width: "100%",
                    language: {
                        noResults: () => this.noProjectText
                    },
                    ajax: {
                        delay: 250,
                        dataType: "json",
                        data: t => ({
                            q: t.term,
                            page: t.page || 1,
                            organization_id: this.state.organizationId
                        }),
                        processResults: t => {
                            const e = t.projects.map(i => ({
                                id: i.id,
                                text: i.name,
                                canTrack: i.can_track,
                                type: i.type
                            }));
                            return e.length > 0 ? {
                                results: e,
                                pagination: t.pagination
                            } : t.can_manage_projects && t.projects_enabled ? {
                                results: [{
                                    id: "new_project",
                                    text: "+ Add project",
                                    new: !0
                                }]
                            } : {
                                results: []
                            }
                        },
                        transport: (t, e, i) => (d.$jsBackend.getProjects(t.data).then(s => {
                            e({
                                can_manage_projects: s.data.can_manage_projects,
                                projects_enabled: s.data.projects_enabled,
                                projects: s.data.projects,
                                pagination: s.data.pagination,
                                params: t.data
                            })
                        }), {
                            abort: () => {}
                        })
                    }
                }
            }
        },
        watch: {
            activeProject: function(t, e) {
                t && this.$refs.select.ensureSelected({
                    id: t.id,
                    text: t.name,
                    type: t.type,
                    canTrack: t.canTrack
                })
            }
        }
    };
var ke = function() {
        var e = this,
            i = e._self._c;
        return i("div", {
            staticClass: "form-group"
        }, [i("label", {
            staticClass: "control-label"
        }, [e._v(e._s(e.labelText))]), i("AppSelect", {
            ref: "select",
            attrs: {
                "select2-id": "wt-project-select",
                async: "",
                "select2-options": e.select2Options,
                disabled: e.disabled
            },
            on: {
                opening: e.clearPreviousResults
            },
            model: {
                value: e.selected,
                callback: function(s) {
                    e.selected = s
                },
                expression: "selected"
            }
        })], 1)
    },
    fe = [],
    we = w(he, ke, fe, !1, null, null, null, null);
const be = we.exports,
    Te = {
        name: "TasksSelect",
        components: {
            AppSelect: _
        },
        mixins: [A],
        props: {
            activeProject: {
                type: Object,
                default: null
            },
            activeTask: {
                type: Object,
                default: null
            },
            userId: {
                type: [Number, null],
                required: !1,
                default: null
            },
            slave: Boolean,
            state: {
                type: Object,
                required: !0
            }
        },
        data() {
            return {}
        },
        computed: {
            labelText() {
                return b(this.state.projectFlavour)
            },
            selectPlaceholder() {
                return `Select a ${b(this.state.projectFlavour).toLowerCase()}`
            },
            selected: {
                get() {
                    return this.activeTask == null ? "" : this.activeTask.id
                },
                set(t) {
                    const e = this.$refs.select.selectedData()[0];
                    this.$emit("updateActiveTask", e ? {
                        id: e.id,
                        name: e.text
                    } : null)
                }
            },
            disabled() {
                const t = this.userId,
                    e = this.activeProject;
                return this.slave || !(t && e && e.id !== -1)
            },
            select2Options() {
                return {
                    allowClear: !0,
                    placeholder: this.selectPlaceholder,
                    width: "100%",
                    language: {
                        noResults: () => this.activeProject.type === I.work_order ? `No ${b("work_orders").toLowerCase()}` : `No ${b("projects").toLowerCase()}`
                    },
                    ajax: {
                        delay: 250,
                        dataType: "json",
                        url: "/tasks/search",
                        data: t => ({
                            project_id: this.activeProject && this.activeProject.id,
                            user_id: this.userId,
                            q: t.term,
                            page: t.page
                        }),
                        processResults: t => {
                            const e = t.results.map(i => ({
                                id: i.id,
                                text: i.text
                            }));
                            return !t.integrated && !t.pagination.more && t.allow_add_button && e.push({
                                id: "new_task",
                                text: "+ Add to-do",
                                new: !0
                            }), {
                                results: e,
                                pagination: t.pagination
                            }
                        },
                        transport: (t, e, i) => {
                            if (this.disabled) return e({
                                results: []
                            }), !1;
                            const s = $.ajax(t);
                            return s.then(e), s.fail(i), s
                        }
                    }
                }
            }
        },
        watch: {
            activeTask: function(t, e) {
                t && this.$refs.select.ensureSelected({
                    id: t.id,
                    text: t.name
                })
            }
        }
    };
var ve = function() {
        var e = this,
            i = e._self._c;
        return i("div", {
            staticClass: "form-group"
        }, [i("label", {
            staticClass: "control-label"
        }, [e._v(e._s(e.labelText))]), i("AppSelect", {
            ref: "select",
            attrs: {
                "select2-id": "wt-task-select",
                async: "",
                "select2-options": e.select2Options,
                disabled: e.disabled
            },
            on: {
                opening: e.clearPreviousResults
            },
            model: {
                value: e.selected,
                callback: function(s) {
                    e.selected = s
                },
                expression: "selected"
            }
        })], 1)
    },
    _e = [],
    je = w(Te, ve, _e, !1, null, null, null, null);
const Pe = je.exports;
var ye = function() {
        var e = this,
            i = e._self._c;
        return e.webTimer.enabled ? i("div", {
            staticClass: "web-timer-widget",
            class: e.webTimerClasses
        }, [i("div", {
            staticClass: "widget-header widget-maximized"
        }, [i("div", {
            staticClass: "widget-window-actions align-items-center"
        }, [i("i", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: e.tooltipOptions,
                expression: "tooltipOptions"
            }],
            staticClass: "minimize-widget",
            attrs: {
                "data-original-title": e.tooltipData.minimize
            },
            on: {
                click: function(s) {
                    return s.stopPropagation(), e.minimizeWidget()
                }
            }
        }), i("i", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: e.tooltipOptions,
                expression: "tooltipOptions"
            }],
            key: `max-close-${e.tooltipOptions.placement}`,
            staticClass: "hi hi-close hi-10",
            attrs: {
                "data-original-title": e.tooltipData.close
            },
            on: {
                click: function(s) {
                    return s.stopPropagation(), e.closeWidget()
                }
            }
        })]), i("div", {
            staticClass: "widget-main-content"
        }, [e.breakOngoing ? e._e() : i("div", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: e.tooltipOptions,
                expression: "tooltipOptions"
            }],
            staticClass: "web-timer-button cursor-pointer",
            class: {
                disabled: !e.trackingAllowed
            },
            attrs: {
                "data-original-title": e.tooltipData.startTime
            },
            on: {
                click: function(s) {
                    return s.stopPropagation(), e.toggleTimer()
                }
            }
        }, [i("i", {
            staticClass: "hi hi-play"
        }), i("i", {
            staticClass: "hi hi-stop"
        })]), e.breakVisible ? i("div", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: e.tooltipOptions,
                expression: "tooltipOptions"
            }],
            staticClass: "work-break-button cursor-pointer",
            attrs: {
                "data-original-title": e.tooltipData.startTime
            },
            on: {
                click: function(s) {
                    return s.stopPropagation(), e.toggleBreak()
                }
            }
        }, [i("i", {
            staticClass: "hi hi-work-break"
        }), i("i", {
            staticClass: "hi hi-stop"
        })]) : e._e(), i("div", {
            staticClass: "widget-tracking-context"
        }, [i("div", {
            staticClass: "tracking-project"
        }, [e._v(e._s(e.projectName))]), i("div", {
            staticClass: "tracking-task"
        }, [e._v(e._s(e.taskName))]), e.breakOngoing ? e._e() : i("div", {
            staticClass: "tracking-limit"
        }, [e._v(e._s(e.state.timer.budgetLeft))])]), i("div", {
            staticClass: "widget-tracked-time"
        }, [i("div", {
            staticClass: "current-project-time"
        }, [i("DurationTimer", {
            attrs: {
                duration: e.state.timer.workedProject
            }
        })], 1), i("div", {
            staticClass: "total-time"
        }, [i("DurationTimer", {
            attrs: {
                duration: e.state.timer.workedToday,
                title: "Today: "
            }
        })], 1)])])]), i("div", {
            staticClass: "widget-header widget-minimized"
        }, [i("div", {
            staticClass: "widget-main-content"
        }, [i("a", {
            staticClass: "web-timer-button",
            class: {
                disabled: !e.trackingAllowed
            },
            attrs: {
                href: "#"
            },
            on: {
                click: function(s) {
                    return s.preventDefault(), s.stopPropagation(), e.toggleTimer()
                }
            }
        }, [i("i", {
            staticClass: "hi hi-play"
        }), i("i", {
            staticClass: "hi hi-stop"
        })]), i("div", {
            staticClass: "widget-tracking-context"
        }, [i("div", {
            staticClass: "tracking-project"
        }, [e._v(e._s(e.projectName))])]), i("div", {
            staticClass: "widget-tracked-time"
        }, [i("div", {
            staticClass: "current-project-time"
        }, [i("DurationTimer", {
            attrs: {
                duration: e.state.timer.workedProject
            }
        })], 1)])]), i("div", {
            staticClass: "widget-window-actions align-items-center"
        }, [i("i", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: e.tooltipOptions,
                expression: "tooltipOptions"
            }],
            key: `min-close-${e.tooltipOptions.placement}`,
            staticClass: "maximize-widget",
            attrs: {
                "data-original-title": e.tooltipData.maximize
            },
            on: {
                click: function(s) {
                    return s.stopPropagation(), e.maximizeWidget()
                }
            }
        }), i("i", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: e.tooltipOptions,
                expression: "tooltipOptions"
            }],
            staticClass: "hi hi-close hi-10",
            attrs: {
                "data-original-title": e.tooltipData.close
            },
            on: {
                click: function(s) {
                    return s.stopPropagation(), e.closeWidget()
                }
            }
        })])]), i("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.showBigWidget,
                expression: "showBigWidget"
            }],
            staticClass: "widget-context"
        }, [i("div", {
            staticClass: "widget-context-picker-container"
        }, [i("ProjectsSelect", {
            attrs: {
                state: e.webTimer,
                slave: e.state.slave || e.breakOngoing,
                "active-project": e.state.timer.activeProject
            },
            on: {
                updateActiveProject: e.setProject
            }
        }), i("TasksSelect", {
            attrs: {
                state: e.webTimer,
                slave: e.state.slave || e.breakOngoing,
                "active-task": e.state.timer.activeTask,
                "active-project": e.state.timer.activeProject,
                "user-id": e.state.user.id
            },
            on: {
                updateActiveTask: e.setTask
            }
        })], 1)]), i("div", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: e.tooltipData.toggleFilters.options,
                expression: "tooltipData.toggleFilters.options"
            }],
            staticClass: "toggle-widget-size cursor-pointer",
            attrs: {
                "data-original-title": e.tooltipData.toggleFilters.text
            },
            on: {
                click: function(s) {
                    return s.stopPropagation(), e.toggleWidgetSize.apply(null, arguments)
                }
            }
        }, [i("i", {
            staticClass: "hi hi-caret"
        })]), e.showScreenShotHint ? [i("div", {
            staticClass: "widget-tooltip"
        }, [i("p", [i("i", {
            staticClass: "hi hi-info"
        }), i("span", [e._v("To record screenshots, please")]), i("a", {
            staticClass: "ajax-dialog mx-5",
            attrs: {
                href: e.downloadDialogPath
            }
        }, [e._v("download")]), i("span", [e._v("and use the desktop app.")])]), i("i", {
            staticClass: "hi hi-close hi-10",
            on: {
                click: function(s) {
                    return s.stopPropagation(), e.closeScreenshotHint.apply(null, arguments)
                }
            }
        })])] : e._e(), e.policy.showDialog ? i("AppDialog", {
            attrs: {
                "append-to-body": "",
                show: "",
                title: "Which break are you taking?"
            },
            on: {
                close: e.policyDialogCancel
            }
        }, [i("WorkBreakPolicySelect", {
            attrs: {
                label: "",
                value: e.policy.selectedID,
                "work-break-policy-options": e.policyDialogOptions
            },
            on: {
                input: e.pickPolicy
            }
        }), i("div", {
            attrs: {
                slot: "footer"
            },
            slot: "footer"
        }, [i("AppButton", {
            on: {
                click: function(s) {
                    return s.stopPropagation(), e.policyDialogCancel.apply(null, arguments)
                }
            }
        }, [e._v("Cancel")]), i("AppButton", {
            attrs: {
                type: "primary",
                disabled: !e.policySelected
            },
            on: {
                click: function(s) {
                    return s.stopPropagation(), e.policyDialogPick.apply(null, arguments)
                }
            }
        }, [e._v("Take break")])], 1)], 1) : e._e()], 2) : e._e()
    },
    $e = [];
const x = D("web-timer"),
    T = 576,
    Be = {
        name: "WebTimerWidget",
        components: {
            ProjectsSelect: be,
            TasksSelect: Pe,
            DurationTimer: N
        },
        mixins: [z],
        props: {
            state: {
                type: Object,
                required: !0
            },
            webTimer: {
                type: Object,
                required: !0
            }
        },
        data() {
            return {
                downloadDialogPath: Z,
                tooltipOptions: {
                    closeOnClick: !0,
                    placement: "top",
                    delay: {
                        show: 1200,
                        hide: 0
                    }
                },
                policy: {
                    showDialog: !1,
                    selectedID: null
                }
            }
        },
        computed: {
            webTimerClasses() {
                return {
                    "is-tracking": this.state.tracking,
                    "is-resting": this.breakOngoing,
                    "is-rest-over": this.breakOver,
                    opened: this.showWidget,
                    minimized: this.webTimer.widget.minimized,
                    maximized: !this.webTimer.widget.minimized,
                    "widget-big": this.showBigWidget
                }
            },
            showScreenShotHint() {
                return !this.$backend.state.user.hide_screenshot_hint && this.showBigWidget
            },
            showWidget() {
                return this.webTimer.widget.open && !this.webTimer.loading
            },
            showBigWidget() {
                return this.webTimer.widget.big && !this.webTimer.widget.minimized
            },
            projectName() {
                return this.breakOngoing ? "On break" : this.state.timer.projectName || "-"
            },
            taskName() {
                return this.breakOngoing ? this.state.timer.activeBreak.name : this.state.timer.taskName
            },
            projectSelected() {
                return this.state.timer.activeProject && this.state.timer.activeProject.id !== -1
            },
            trackingAllowed() {
                return this.projectSelected ? this.state.timer.activeProject.canTrack : !1
            },
            breakAllowed() {
                return this.state.tracking && this.state.workBreakPolicies.length
            },
            breakVisible() {
                return this.breakAllowed || this.breakOngoing
            },
            policyDialogOptions() {
                return this.state.workBreakPolicies || []
            },
            policySelected() {
                return !!this.policy.selectedID
            },
            tooltipData() {
                const t = this.webTimer.widget.big ? "Collapse" : "Expand";
                return {
                    minimize: "Minimize timer",
                    maximize: "Maximize timer",
                    close: "Close timer (does not stop timer)",
                    startTime: this.projectSelected && !this.trackingAllowed ? `This ${this.$backend.getProjectLabel(this.state.timer.activeProject)} cannot be tracked on this client` : "",
                    toggleFilters: {
                        text: t,
                        options: {
                            placement: "auto bottom",
                            delay: {
                                show: 1200,
                                hide: 0
                            }
                        }
                    }
                }
            }
        },
        watch: {
            "webTimer.enabled": function(t) {
                t && this.$el && u.nextTick().then(() => this.makeDraggable())
            }
        },
        created() {
            this.$backend = this.$parent.$backend, this.debounceToggleTimer = P(() => {
                this.$backend.toggleTimer()
            }, 250, {
                leading: !0,
                trailing: !1
            }), this.debounceResize = P(() => {
                window.innerWidth < T ? (this.$set(this.tooltipOptions, "placement", "bottom"), $(this.$el).draggable("disable")) : (this.$set(this.tooltipOptions, "placement", "top"), $(this.$el).draggable("option", "disabled") && $(this.$el).draggable("enable")), $(this.$el).css(this.getDraggableInitialPosition())
            }, 250), this.policy.showDialog = !1, this.policy.selectedID = null
        },
        mounted() {
            this.webTimer.enabled && this.makeDraggable(), this.debounceResize(), window.addEventListener("resize", this.debounceResize)
        },
        methods: {
            closeScreenshotHint() {
                this.$backend.closeScreenshotHint()
            },
            toggleTimer() {
                this.trackingAllowed && this.debounceToggleTimer()
            },
            toggleBreak() {
                this.breakAllowed && !this.breakOngoing ? this.policy.showDialog = !0 : this.stopBreak()
            },
            setTask(t) {
                this.$backend.setTask(t)
            },
            setProject(t) {
                this.$backend.setProject(t)
            },
            closeWidget() {
                this.$backend.closeWidget()
            },
            minimizeWidget() {
                this.$backend.minimizeWidget()
            },
            maximizeWidget() {
                this.$backend.maximizeWidget()
            },
            toggleWidgetSize() {
                this.$backend.toggleWidgetSize()
            },
            startBreak() {
                const t = this.policyDialogOptions.find(e => parseInt(e.id) === parseInt(this.policy.selectedID));
                t && this.$backend.startBreak(t.project_id)
            },
            stopBreak() {
                this.$backend.stopBreak()
            },
            policyDialogCancel() {
                this.policy.showDialog = !1
            },
            policyDialogPick() {
                this.policyDialogCancel(), this.startBreak()
            },
            pickPolicy(t) {
                this.policy.selectedID = t
            },
            makeDraggable() {
                const t = $(this.$el);
                t.css(this.getDraggableInitialPosition()), t.draggable({
                    containment: "window",
                    cancel: "i, .app-select, .toggle-widget-size, .web-timer-button",
                    scroll: !1,
                    stop: () => {
                        const e = t.position();
                        x.set("widgetLocation", {
                            left: e.left,
                            top: e.top
                        })
                    }
                })
            },
            getDraggableInitialPosition() {
                const t = x.get("widgetLocation") || {
                        top: 100,
                        left: 300
                    },
                    e = this.getWidgetSize(),
                    i = $(window),
                    s = i.width(),
                    o = i.height();
                return s <= T || o <= T ? (t.top = 46, s < e[0] ? t.left = 0 : t.left = s / 2 - e[0] / 2) : (t.left + e[0] > s && (s < e[0] ? t.left = 0 : t.left = s - e[0]), t.top + e[1] > o && (t.top = o - e[1])), t
            },
            getWidgetSize() {
                let t;
                return this.webTimer.widget.minimized ? t = [300, 60] : this.webTimer.widget.big ? t = [460, 298] : t = [460, 106], t
            }
        }
    };
var Se = w(Be, ye, $e, !1, null, null, null, null);
const Ce = Se.exports;
window.addEventListener("app.settings_updated", t => {
    const e = t.detail;
    e.name === "duration_format" && (window.TimeUtils.UserTimeFormats.duration = e.value, d.refreshTimerFormat())
}, !1);
$('div[data-vue="web-timer"]').each(function() {
    u.use(ee), d.setup($(this).data("initialState")), d.refreshTimerFormat();
    const t = new u({
        name: "WebTimerTopbar",
        render: o => o(ge, {
            props: {
                state: d.state,
                webTimer: d.webTimer
            }
        })
    });
    t.$backend = d;
    const e = new u({
        name: "WebTimerWidget",
        render: o => o(Ce, {
            props: {
                state: d.state,
                webTimer: d.webTimer
            }
        })
    });
    e.$backend = d;
    const i = document.createElement("div");
    document.body.appendChild(i), t.$mount(this), e.$mount(i);
    const s = document.createElement("div");
    document.body.appendChild(s), d.$mount(s), window.WebTimer = {
        topBar: t,
        widget: e,
        backend: d
    }
});