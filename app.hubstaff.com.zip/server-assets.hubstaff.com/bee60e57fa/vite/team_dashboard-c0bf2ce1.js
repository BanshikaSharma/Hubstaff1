import "./init-ef420420.js";
import {
    V as a
} from "./vendor-f5db2be7.js";
import {
    H as o
} from "./hub_app-778c98e3.js";
import {
    jm as r
} from "./shared-5f1b437f.js";
import "./app_messages-e83d8e06.js";
const t = document.querySelector("#dashboard-workforce-banner"),
    i = JSON.parse(t.getAttribute("data-initial-state"));
a.use(o);
a.use(r);
const n = new a({
    el: t,
    data: {
        initialState: JSON.parse(t.getAttribute("data-initial-state"))
    },
    name: "DashboardWorkforceBanner",
    render: e => e(r, {
        props: {
            initialState: i
        }
    })
});
window.VueSettingsInsights = {
    app: n
};