const BASE = 'feedback-web';
export const FETCHER = `${BASE}-fetcher`;
export const UI = `${BASE}-ui`;