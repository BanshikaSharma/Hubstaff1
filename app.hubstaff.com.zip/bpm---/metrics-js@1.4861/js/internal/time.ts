"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ONE_MINUTE = void 0;
const ONE_SECOND = 1000;
const ONE_MINUTE = exports.ONE_MINUTE = ONE_SECOND * 60;