import "./init-ef420420.js";
import {
    V as o
} from "./vendor-f5db2be7.js";
import {
    H as e
} from "./hub_app-778c98e3.js";
import {
    cj as i
} from "./shared-5f1b437f.js";
import "./app_messages-e83d8e06.js";
o.use(e);
const a = document.querySelector("#example-data-remove-dialog"),
    r = a ? JSON.parse(a.dataset.initialState) : {},
    p = new o({
        el: a,
        name: "DestroyExampleDataDialog",
        render: t => t(i, {
            props: {
                organizationId: r.organization_id
            }
        })
    });
window.DestroyExampleDataDialog = p;