import {
    V as t
} from "./vendor-f5db2be7.js";
import {
    fB as e
} from "./shared-5f1b437f.js";
document.addEventListener("readystatechange", () => {
    initPopoverAvatar()
});
window.initPopoverAvatar = () => {
    $('span[data-vue="popover-avatar"]').each((o, a) => new t({
        el: a,
        name: `PopoverAvatar ${a.dataset.id}`,
        render: r => r(e, {
            props: { ...a.dataset,
                html: a.innerHTML
            }
        })
    }))
};