import {
    N as n,
    g4 as l,
    r as d,
    g5 as m,
    g6 as u,
    g7 as r,
    g8 as c,
    e4 as p,
    X as h,
    n as f
} from "./shared-5f1b437f.js";
import {
    E as g,
    D as v,
    a4 as y
} from "./vendor-f5db2be7.js";
const _ = {
    name: "WorkLimitsAndExpectations",
    components: {
        MemberProfilesNav: n,
        ExpectedWorkDaysForm: l,
        AppPagination: d
    },
    data() {
        return {
            notify: !0,
            MAX_DAILY_LIMIT: m,
            showOverrideDialog: !1,
            showEmailChangesDialog: !1,
            hasDefaultFormChanges: !1,
            shouldNotifyMembers: !0,
            errors: {},
            tooltipOptions: Object.freeze({
                placement: "top"
            })
        }
    },
    computed: { ...g(["organization", "members", "pagination"]),
        ...v(["sortedWeekdays", "accountProvisioningFlag", "expectedWorkEnabled", "currentUserIsOrganizationOwner", "hasMembersWithCustomLimitsSettings"]),
        ...u("organization", {
            dailyLimit: "work_limits_and_expectations.daily_limit",
            limitByShifts: "work_limits_and_expectations.limits_by_shifts",
            weeklyLimit: "work_limits_and_expectations.weekly_limit",
            expectedPerWeek: "work_limits_and_expectations.expected_per_week",
            dowExpected: "dow_expected",
            dowLimit: "dow_limit"
        }, "updateField"),
        showPagination() {
            var i;
            return !this.loading && ((i = this.pagination) == null ? void 0 : i.total_pages) > 1
        },
        payRate() {
            return this.membership && this.membership.payments && this.membership.payments.pay_rate
        },
        weeklyLimitStatus() {
            const i = this.payRate > 0 && !this.hasFixedRate;
            return this.weeklyLimit ? this.currentUserIsOrganizationOwner && i ? `${this.formatLimitRate(this.weeklyLimit)} per week` : `${this.formatLimitDuration(this.weeklyLimit*3600)} hours per week` : "No limit"
        },
        limitsByShiftsEnabled() {
            return !1
        },
        dailyLimitStatus() {
            let i;
            const e = this.dailyLimit <= this.MAX_DAILY_LIMIT,
                t = this.payRate > 0 && !this.hasFixedRate;
            return this.dailyLimit ? e && (this.currentUserIsOrganizationOwner && t ? i = `${this.formatLimitRate(this.dailyLimit)} per day` : i = `${this.formatLimitDuration(this.dailyLimit*3600)} hours per day`) : i = "No limit", i
        },
        hasHotwiredFlag() {
            return this.organization.settings_page_hotwired_flag
        },
        feature() {
            return this.organization.feature
        }
    },
    created() {
        this.feature.available && this.loadData({
            page: this.pagination.current_page,
            organizationId: this.organization.id
        })
    },
    methods: { ...y(["updateDowLimit", "updateDowExpected", "loadData", "setUserLimits", "submitUserLimits"]),
        getExpectedDays(i) {
            return r(i)
        },
        filteredDowLimit(i) {
            const e = c.filter(t => !i.includes(t.text)).map(t => t.text);
            return r(e) || "-"
        },
        formatLimitDuration(i) {
            return p(i, {
                showSeconds: "never"
            })
        },
        setWeeklyLimit(i) {
            this.weeklyLimit = i, this.hasDefaultFormChanges = !0
        },
        setDailyLimit(i) {
            this.dailyLimit = i, this.hasDefaultFormChanges = !0
        },
        setExpectedPerWeek(i) {
            this.expectedPerWeek = i, this.hasDefaultFormChanges = !0
        },
        removeExpectedPerWeek() {
            this.expectedPerWeek = null, this.hasDefaultFormChanges = !0
        },
        removeDailyLimit() {
            this.dailyLimit = null, this.hasDefaultFormChanges = !0
        },
        removeWeeklyLimit() {
            this.weeklyLimit = null, this.hasDefaultFormChanges = !0
        },
        setDowLimit({
            day: i,
            event: e
        }) {
            if (e === "remove") {
                const t = this.dowLimit.indexOf(i),
                    s = this.dowLimit.slice(0, t).concat(this.dowLimit.slice(t + 1));
                this.dowLimit = s
            } else this.dowLimit = [...this.dowLimit, i];
            this.hasDefaultFormChanges = !0
        },
        setDowExpected(i) {
            this.dowExpected = i, this.hasDefaultFormChanges = !0
        },
        setLimitsByShifts(i) {
            this.limitByShifts = i
        },
        setPage(i) {
            this.loadData({
                page: i
            })
        },
        toggleOverrideDialog() {
            this.showOverrideDialog = !this.showOverrideDialog
        },
        toggleEmailChangesDialog() {
            this.showEmailChangesDialog = !this.showEmailChangesDialog
        },
        openMemberPage(i, e = "work hours") {
            const t = `/organizations/${this.organization.id}/members/${i}`;
            window.location.href = [t, e && `?tab=${e}`].filter(Boolean).join("")
        },
        opensShiftsPage(i = "work hours") {
            const e = h.shiftsLink({
                id: this.organization.id
            });
            window.location.href = [e, i && `?tab=${i}`].filter(Boolean).join("")
        },
        async validate() {
            await this.$refs.form.validate() && (this.hasMembersWithCustomLimitsSettings ? this.toggleOverrideDialog() : this.toggleEmailChangesDialog())
        },
        onOverrideSettingsDialogSubmit(i = !0) {
            this.toggleOverrideDialog(), this.submit({
                override: i,
                notify: this.shouldNotifyMembers
            })
        },
        onEmailChangesDialogSubmit(i = !1) {
            this.toggleEmailChangesDialog(), this.submit({
                override: !0,
                notify: i
            })
        },
        setErrors(i) {
            let e;
            Object.keys(i.errors[0]).forEach(async t => {
                e = i.errors[0][t], await this.$refs[`${t}_${i.userId}`].setErrors(e.join(", ")), this.dirty && (setTimeout(() => {
                    alert(e.join(", "))
                }, 100), this.dirty = !1)
            })
        },
        async submit({
            override: i,
            notify: e
        }) {
            var t;
            try {
                const s = {
                    weekly_limit: this.weeklyLimit,
                    daily_limit: this.dailyLimit,
                    expected_per_week: this.expectedPerWeek,
                    dow_limit: this.dowLimit,
                    dow_expected: this.dowExpected,
                    limits_by_shifts: this.limitByShifts,
                    override_members_limits: i,
                    notify_members: e
                };
                await this.$store.dispatch("setOrganizationLimits", s), this.$appMessage("Information saved successfully", {
                    header: '<i class="fa fa-info-circle"></i> Default settings saved'
                });
                const a = ((t = this.pagination) == null ? void 0 : t.current_page) || 1;
                this.loadData({
                    page: a
                })
            } catch (s) {
                this.$appMessage(s)
            }
        },
        changeUserLimits(i, e, t) {
            this.dirty = !0, this.setUserLimits({
                id: i.id,
                key: e,
                value: +t
            })
        },
        async onSubmitUserLimits(i) {
            try {
                await this.submitUserLimits(i)
            } catch (e) {
                e.errors && e.userId && this.setErrors(e)
            }
        }
    }
};
var b = function() {
        var e = this,
            t = e._self._c;
        return t("div", {
            staticClass: "expected-work-days-settings"
        }, [e.feature.available ? e._e() : t("div", {
            domProps: {
                innerHTML: e._s(e.feature.alert_html)
            }
        }), t("div", {
            staticClass: "row",
            class: {
                "section-disabled": !e.feature.available
            }
        }, [e.hasHotwiredFlag ? e._e() : t("div", {
            staticClass: "col-md-3"
        }, [t("MemberProfilesNav", {
            attrs: {
                "work-limits-and-expectations-settings-active": "",
                "organization-id": e.organization.id,
                "account-provisioning-flag": e.accountProvisioningFlag,
                "expected-work-enabled": e.expectedWorkEnabled
            }
        })], 1), t("div", {
            class: {
                "col-md-9": !e.hasHotwiredFlag, "col-md-12": e.hasHotwiredFlag
            }
        }, [t("div", {
            staticClass: "form-cta"
        }, [t("h4", [e._v("Default settings")]), t("AppButton", {
            attrs: {
                type: "primary",
                size: "sm",
                disabled: !e.hasDefaultFormChanges
            },
            on: {
                click: e.validate
            }
        }, [e._v(" Save ")]), t("AppButton", {
            attrs: {
                type: "text",
                size: "sm",
                disabled: !e.hasDefaultFormChanges
            }
        }, [e._v(" Cancel ")])], 1), t("ExpectedWorkDaysForm", {
            ref: "form",
            attrs: {
                "limit-by-shifts": e.limitByShifts,
                "weekly-limit": e.weeklyLimit,
                "daily-limit": e.dailyLimit,
                "expected-per-week": e.expectedPerWeek,
                "sorted-weekdays": e.sortedWeekdays,
                organization: e.organization,
                "dow-expected": e.dowExpected,
                "dow-limit": e.dowLimit,
                "weekly-limit-status": e.weeklyLimitStatus,
                "daily-limit-status": e.dailyLimitStatus,
                "limits-by-shifts-enabled": e.limitsByShiftsEnabled
            },
            on: {
                setWeeklyLimit: e.setWeeklyLimit,
                setDailyLimit: e.setDailyLimit,
                setExpectedPerWeek: e.setExpectedPerWeek,
                setDowLimit: e.setDowLimit,
                setDowExpected: e.setDowExpected,
                setLimitsByShifts: e.setLimitsByShifts,
                removeExpectedPerWeek: e.removeExpectedPerWeek,
                removeRecurringWeeklyLimit: e.removeWeeklyLimit,
                removeRecurringDailyLimit: e.removeDailyLimit
            }
        })], 1), t("div", {
            staticClass: "mt-20",
            class: {
                "section-disabled": !e.feature.available
            }
        }, [t("div", {
            staticClass: "col-md-12 px-15"
        }, [t("div", {
            staticClass: "border-top mb-20"
        }), t("h4", [e._v("Individual settings")]), t("div", {
            staticClass: "table-heading-description"
        }, [t("div", [e._v("Override the organization default for specific members")]), t("div", [e._e()], 1)]), t("AppScrollableTable", {
            attrs: {
                "has-fixed-column": !1
            }
        }, [t("ValidationObserver", [t("AppTable", {
            ref: "table",
            attrs: {
                hoverable: "",
                "table-data": e.members
            },
            scopedSlots: e._u([{
                key: "empty",
                fn: function() {
                    return [t("div", {
                        staticClass: "mt-20 text-center"
                    }, [t("h4", {
                        staticClass: "my-0"
                    }, [e._v("No members")])])]
                },
                proxy: !0
            }])
        }, [t("AppTableColumn", {
            attrs: {
                header: "Name"
            },
            scopedSlots: e._u([{
                key: "default",
                fn: function({
                    row: s
                }) {
                    return [t("div", {
                        staticClass: "d-flex align-items-center"
                    }, [t("AppAvatar", {
                        attrs: {
                            avatar: s.avatar_url,
                            size: "medium"
                        }
                    }), t("div", {
                        directives: [{
                            name: "tooltip",
                            rawName: "v-tooltip",
                            value: e.tooltipOptions,
                            expression: "tooltipOptions"
                        }],
                        key: s.id,
                        staticClass: "member-name",
                        attrs: {
                            title: s.name
                        }
                    }, [e._v(" " + e._s(s.name) + " ")])], 1)]
                }
            }])
        }), t("AppTableColumn", {
            attrs: {
                header: "Weekly work days",
                "cell-classes": "column-wide"
            },
            scopedSlots: e._u([{
                key: "default",
                fn: function({
                    row: s
                }) {
                    return [t("div", {
                        staticClass: "expected-work-link"
                    }, [t("AppHoverLink", {
                        attrs: {
                            title: "Edit member"
                        },
                        on: {
                            click: function(a) {
                                return e.openMemberPage(s.user_id)
                            }
                        }
                    }, [t("span", [e._v("Expected work days: ")]), t("span", {
                        staticClass: "days-of-work-string"
                    }, [t("b", [e._v(e._s(e.getExpectedDays(s.dow_expected)))])])])], 1), t("div", {
                        staticClass: "expected-work-link mt-5"
                    }, [t("AppHoverLink", {
                        attrs: {
                            title: "Edit member"
                        },
                        on: {
                            click: function(a) {
                                return e.openMemberPage(s.user_id)
                            }
                        }
                    }, [t("span", [e._v("Not allowed to track time on: ")]), t("span", {
                        staticClass: "days-of-work-string"
                    }, [t("b", [e._v(e._s(e.filteredDowLimit(s.dow_limit)))])])])], 1), s.limits_by_shifts ? t("div", {
                        staticClass: "expected-work-link mt-5"
                    }, [t("AppHoverLink", {
                        attrs: {
                            title: "Edit shift"
                        },
                        on: {
                            click: function(a) {
                                return e.openMemberPage(s.user_id)
                            }
                        }
                    }, [t("span", {
                        directives: [{
                            name: "tooltip",
                            rawName: "v-tooltip",
                            value: e.tooltipOptions,
                            expression: "tooltipOptions"
                        }],
                        attrs: {
                            title: "Settings disabled if you want to edit it go to member setting page => Some of the member's limits are based on shifts. Please visit the member's settings page to allow custom settings"
                        }
                    }, [t("b", [e._v("Limited by shifts")])])])], 1) : e._e()]
                }
            }])
        }), t("AppTableColumn", {
            attrs: {
                header: "Expected work hours",
                "cell-classes": "column-fixed"
            },
            scopedSlots: e._u([{
                key: "default",
                fn: function({
                    row: s
                }) {
                    return [t("ValidationProvider", {
                        ref: `expected_per_week_${s.id}`,
                        scopedSlots: e._u([{
                            key: "default",
                            fn: function({
                                errors: a
                            }) {
                                return [t("div", {
                                    class: {
                                        "has-error": a.length
                                    }
                                }, [t("div", {
                                    staticClass: "input-group"
                                }, [t("AppInput", {
                                    attrs: {
                                        value: s.expected_per_week,
                                        type: "number"
                                    },
                                    on: {
                                        input: function(o) {
                                            return e.changeUserLimits(s, "expected_per_week", o)
                                        },
                                        blur: function(o) {
                                            return e.onSubmitUserLimits(s)
                                        }
                                    }
                                }), t("span", {
                                    staticClass: "input-group-addon"
                                }, [e._v("wk")])], 1)])]
                            }
                        }], null, !0)
                    })]
                }
            }])
        }), t("AppTableColumn", {
            attrs: {
                header: "Weekly limit",
                "cell-classes": "column-fixed"
            },
            scopedSlots: e._u([{
                key: "default",
                fn: function({
                    row: s
                }) {
                    return [t("ValidationProvider", {
                        ref: `weekly_limit_${s.id}`,
                        scopedSlots: e._u([{
                            key: "default",
                            fn: function({
                                errors: a
                            }) {
                                return [t("div", {
                                    class: {
                                        "has-error": a.length
                                    }
                                }, [t("div", {
                                    staticClass: "input-group"
                                }, [t("AppInput", {
                                    attrs: {
                                        value: s.weekly_limit,
                                        type: "number"
                                    },
                                    on: {
                                        input: function(o) {
                                            return e.changeUserLimits(s, "weekly_limit", o)
                                        },
                                        blur: function(o) {
                                            return e.onSubmitUserLimits(s)
                                        }
                                    }
                                }), t("span", {
                                    staticClass: "input-group-addon"
                                }, [e._v("wk")])], 1)])]
                            }
                        }], null, !0)
                    })]
                }
            }])
        }), t("AppTableColumn", {
            attrs: {
                header: "Daily limit",
                "cell-classes": "column-fixed"
            },
            scopedSlots: e._u([{
                key: "default",
                fn: function({
                    row: s
                }) {
                    return [t("ValidationProvider", {
                        ref: `daily_limit_${s.id}`,
                        scopedSlots: e._u([{
                            key: "default",
                            fn: function({
                                errors: a
                            }) {
                                return [t("div", {
                                    class: {
                                        "has-error": a.length
                                    }
                                }, [t("div", {
                                    staticClass: "input-group"
                                }, [t("AppInput", {
                                    attrs: {
                                        value: s.daily_limit,
                                        disabled: s.limits_by_shifts,
                                        type: "number"
                                    },
                                    on: {
                                        input: function(o) {
                                            return e.changeUserLimits(s, "daily_limit", o)
                                        },
                                        blur: function(o) {
                                            return e.onSubmitUserLimits(s)
                                        }
                                    }
                                }), t("span", {
                                    staticClass: "input-group-addon"
                                }, [e._v("day")])], 1)])]
                            }
                        }], null, !0)
                    })]
                }
            }])
        })], 1)], 1)], 1), e.showPagination ? t("AppPagination", {
            attrs: {
                pagination: e.pagination,
                resource: {
                    one: "member",
                    many: "members"
                },
                "hide-pagination-showing-text": ""
            },
            on: {
                "page-changed": e.setPage
            }
        }) : e._e()], 1)])]), t("AppDialog", {
            staticClass: "work-time-limits-override-dialog",
            attrs: {
                show: e.showOverrideDialog,
                title: "Override individual settings?",
                size: "smedium",
                position: "centered",
                "append-to-body": ""
            },
            on: {
                close: e.toggleOverrideDialog
            }
        }, [t("p", {
            staticClass: "mb-20"
        }, [e._v(" Some members have settings with values that override the current defaults. Do you wish to reset all individual settings to new default values? ")]), t("div", {
            attrs: {
                slot: "footer"
            },
            slot: "footer"
        }, [t("div", {
            staticClass: "d-flex flex-column gap-10"
        }, [t("AppButton", {
            attrs: {
                type: "default"
            },
            on: {
                click: function(s) {
                    return e.onOverrideSettingsDialogSubmit()
                }
            }
        }, [e._v(" Reset all to new default values ")]), t("AppButton", {
            staticClass: "ml-0",
            attrs: {
                type: "primary"
            },
            on: {
                click: function(s) {
                    return e.onOverrideSettingsDialogSubmit(!1)
                }
            }
        }, [e._v(" Keep individual overriding values ")]), t("AppCheckbox", {
            staticClass: "mx-0 my-5",
            model: {
                value: e.shouldNotifyMembers,
                callback: function(s) {
                    e.shouldNotifyMembers = s
                },
                expression: "shouldNotifyMembers"
            }
        }, [e._v(" Email changes to members ")])], 1)])]), t("AppDialog", {
            attrs: {
                show: e.showEmailChangesDialog,
                title: "Email changes to members?",
                size: "smedium",
                position: "centered",
                "append-to-body": ""
            },
            on: {
                close: e.toggleEmailChangesDialog
            }
        }, [t("p", {
            staticClass: "mb-20"
        }, [e._v("If you choose to notify your members, they will receive an email with the changes made.")]), t("div", {
            attrs: {
                slot: "footer"
            },
            slot: "footer"
        }, [t("div", {
            staticClass: "d-flex flex-column gap-10"
        }, [t("AppButton", {
            attrs: {
                type: "default"
            },
            on: {
                click: function(s) {
                    return e.onEmailChangesDialogSubmit(!0)
                }
            }
        }, [e._v(" Save changes and notify members ")]), t("AppButton", {
            staticClass: "ml-0",
            attrs: {
                type: "default"
            },
            on: {
                click: e.onEmailChangesDialogSubmit
            }
        }, [e._v(" Save changes but don’t notify members ")])], 1)])])], 1)
    },
    w = [],
    k = f(_, b, w, !1, null, null, null, null);
const L = k.exports,
    C = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: L
    }, Symbol.toStringTag, {
        value: "Module"
    }));
export {
    L as W, C as _
};